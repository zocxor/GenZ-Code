import {getFirestore} from 'firebase-admin/firestore';
import {HttpsError,onCall} from 'firebase-functions/v2/https';
import {error} from 'firebase-functions/logger';
import {onDocumentUpdated} from 'firebase-functions/v2/firestore';
import {onSchedule} from 'firebase-functions/v2/scheduler';
import {communityAction, runDailySchedule, purgeContributions} from './communityFeatures';

export const communityFeature = onCall({region:'us-central1', timeoutSeconds:60}, async request => {
  try {
    return await communityAction(getFirestore(),request.data ?? {},request.auth);
  } catch (cause) {
    if (cause instanceof HttpsError) throw cause;
    error('communityFeature failed',cause);
    throw new HttpsError('internal','The server could not complete this request. Retry or check the communityFeature logs in Firebase.');
  }
});
export const publishDailyCodes = onSchedule({schedule:'every 1 minutes',timeZone:'UTC',region:'us-central1'}, async ()=>{
  await runDailySchedule(getFirestore());
});

export const cleanupContributions = onDocumentUpdated({document:'users/{uid}',region:'us-central1',retry:true}, async event=>{
  if(event.data?.after.get('status')==='deleted' && event.data.before.get('status')!=='deleted') await purgeContributions(getFirestore(),event.params.uid);
});
