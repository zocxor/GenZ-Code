import {useReducedMotion} from './motion';
/** Community keeps the existing live chat and shows reviewed term posts in a separate pane. */
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, ScrollView, Pressable, StyleSheet, KeyboardAvoidingView, Keyboard, Platform, Animated} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Button, Chip, Icon, IconName, IconTile, FadeIn, LiquidHero} from './ui';
import {useAccountUser} from './services';
import {subscribeChat, sendChatMessage, deleteOwnMessage} from './chat';
import CommunityPostsPanel from './CommunityPostsPanel';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {reportChatMessage, REPORT_REASONS} from './ugc';
import {CHAT_MAX_LENGTH, type ChatMessage} from '../shared/chat';
import {watchRewardedAd} from './ads';
import {fetchLeaderboard, publishLeaderboard, leaveLeaderboard, type LeaderboardRow} from './tokensSync';
import {earnTokens, spendTokens, setLeaderboardOptIn, type Action} from './learning';
import {TOKENS, type TokensState} from '../shared/tokens';

const timeOf = (at: number) => new Date(at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
const initialOf = (name: string) => (name.trim().charAt(0) || '?').toUpperCase();

export default function CommunityScreen({active, nickname, onSignIn, onOpenShop, onOpenDaily, onGoToPlay, onMyPosts, tokens, onTokensAction}: {active: boolean; nickname: string; onSignIn: () => void; onOpenShop: () => void; onOpenDaily: () => void; onGoToPlay: () => void; onMyPosts: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  const user = useAccountUser();
  const [view, setView] = useState<'chat' | 'posts'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [earning, setEarning] = useState(false);
  const [earnNote, setEarnNote] = useState('');
  const [joined, setJoined] = useState(false);
  // Entry gate: you need tokens to get in. Once you are in this session you
  // stay in the room even if a message spend drops your balance to zero — you
  // just cannot send more until you earn tokens. (The tab stays mounted, so
  // this survives switching tabs; a fresh app launch re-arms the gate.)
  useEffect(() => { if (active && tokens.balance > 0) setJoined(true); }, [active, tokens.balance]);
  const needsTokens = tokens.balance <= 0 && !joined;
  const [reporting, setReporting] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportNote, setReportNote] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportSent, setReportSent] = useState('');
  const [board, setBoard] = useState<LeaderboardRow[]>([]);
  const [boardBusy, setBoardBusy] = useState(false);
  const badges = useBadges(active && view==='chat' ? [...messages.map(m=>m.uid),...board.map(r=>r.uid)] : []);
  const scrollRef = useRef<ScrollView>(null);
  // Permanent keyboard fix: the composer must stay visible while typing.
  // adjustResize + KeyboardAvoidingView shrink the view, but on some Android
  // builds the fixed hero still eats the freed room, so the composer can end
  // up under the keyboard. When the keyboard opens we collapse the hero
  // (frees ~190px) and scroll to the newest message; that combination cannot
  // hide the composer, whatever the keyboard height is.
  const [keyboardOpen, setKeyboardOpen] = useState(false);
  const reduced = useReducedMotion();
  // Hero collapse animation: the hero fades out over 200ms as the
  // keyboard opens, then leaves the layout (freeing ~190px); on close it
  // returns and fades back in. kbOpenRef guards the delayed removal so a
  // quick open/close cannot leave the hero hidden.
  const heroAnim = useRef(new Animated.Value(1)).current;
  const kbOpenRef = useRef(false);
  const kbTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Tab entrance: the header fades in each time the tab becomes active
  // (tabs stay mounted, so a mount-only FadeIn would have finished unseen).
  const enterAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active || reduced) {enterAnim.setValue(active ? 1 : 0); return;}
    const animation = Animated.timing(enterAnim, {toValue: 1, duration: 200, useNativeDriver: true});
    animation.start();
    return () => animation.stop();
  }, [active, enterAnim, reduced]);

  useEffect(() => {
    if (!active || view !== 'chat') return;
    setLoadError('');
    return subscribeChat(setMessages, setLoadError);
  }, [active,view]);
  useEffect(() => {
    if (!active) return;
    let live = true;
    void fetchLeaderboard().then(rows => {if (live) setBoard(rows);});
    return () => {live = false;};
  }, [active]);
  useEffect(() => {
    if (active) scrollRef.current?.scrollToEnd({animated: !reduced});
  }, [messages, active, reduced]);
  // When the keyboard opens, fade the hero out, then collapse it, and scroll
  // the room to the latest message so the composer and the newest message
  // stay visible above the keyboard. When it closes, the hero comes back
  // and fades in. The delayed removal is guarded so a quick open/close
  // cannot strand the hero hidden.
  useEffect(() => {
    if (kbOpenRef.current) setKeyboardOpen(true);
    const show = Keyboard.addListener('keyboardDidShow', () => {
      kbOpenRef.current = true;
      if (reduced) {setKeyboardOpen(true); scrollRef.current?.scrollToEnd({animated: false}); return;}
      Animated.timing(heroAnim, {toValue: 0, duration: 200, useNativeDriver: true}).start();
      if (kbTimer.current) clearTimeout(kbTimer.current);
      kbTimer.current = setTimeout(() => { if (kbOpenRef.current) setKeyboardOpen(true); }, 200);
      setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 120);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => {
      kbOpenRef.current = false;
      if (kbTimer.current) clearTimeout(kbTimer.current);
      setKeyboardOpen(false);
      if (reduced) heroAnim.setValue(1);
      else Animated.timing(heroAnim, {toValue: 1, duration: 200, useNativeDriver: true}).start();
    });
    return () => {
      show.remove(); hide.remove();
      if (kbTimer.current) clearTimeout(kbTimer.current);
    };
  }, [heroAnim, reduced]);

  const send = async () => {
    if (sending || !text.trim()) return;
    if (tokens.balance < TOKENS.CHAT_MESSAGE_COST) {
      setSendError(`You need ${TOKENS.CHAT_MESSAGE_COST} token${TOKENS.CHAT_MESSAGE_COST === 1 ? '' : 's'} to send a message (you have ${tokens.balance}). Watch an ad or collect your daily reward to earn more.`);
      return;
    }
    setSending(true); setSendError('');
    const r = await sendChatMessage(nickname, text);
    setSending(false);
    if (r.ok) {
      // Deduct only after the message is accepted — never twice for one send
      // (the `sending` guard above blocks a second tap while this runs).
      onTokensAction(spendTokens(TOKENS.CHAT_MESSAGE_COST));
      setText('');
    } else setSendError(r.message);
  };

  const earn = async () => {
    if (earning) return;
    setEarning(true); setEarnNote('');
    const rewarded = await watchRewardedAd();
    setEarning(false);
    if (rewarded) {onTokensAction(earnTokens(TOKENS.REWARDED_AD)); setEarnNote(`+${TOKENS.REWARDED_AD} tokens earned. Welcome to the room.`);}
    else setEarnNote('No tokens this time — the ad closed early. Try again when you like.');
  };

  const report = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportChatMessage(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this message.'); setReporting(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const remove = async (id: string) => {
    const r = await deleteOwnMessage(id);
    if (!r.ok) setSendError(r.message);
  };

  const toggleBoard = async (on: boolean) => {
    if (boardBusy || !user) return;
    setBoardBusy(true);
    onTokensAction(setLeaderboardOptIn(on));
    if (on) await publishLeaderboard(nickname, tokens.balance);
    else await leaveLeaderboard();
    setBoard(await fetchLeaderboard());
    setBoardBusy(false);
  };

  const gateCard = <FadeIn><LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.gate}>
    <IconTile icon="chatbubbles-outline" from="#DCE7FF" to="#F2E9FF" size={48} iconSize={24} />
    <Text style={s.gateTitle}>You need tokens to join the chat</Text>
    <Text style={s.gateBody}>Earn tokens to join — watch an ad, play, or buy.</Text>
    {!!earnNote && <Text accessibilityLiveRegion="polite" style={s.gateOk}>{earnNote}</Text>}
    <Button title={earning ? 'Showing ad…' : `Watch an ad · +${TOKENS.REWARDED_AD} tokens`} icon="play-circle-outline" light disabled={earning} onPress={() => void earn()} />
    <Button title="Daily reward" icon="gift-outline" light onPress={onOpenDaily} />
    <Button title="Play to earn tokens" icon="game-controller-outline" light onPress={onGoToPlay} />
    <Button title="Buy tokens" icon="card-outline" light onPress={onOpenShop} />
    {!user && <Button title="Sign in or create an account" icon="log-in-outline" light onPress={onSignIn} />}
  </LinearGradient></FadeIn>;

  const reportBox = (title: string, onSubmit: () => void) => <Glass style={s.reportBox}>
    <Text style={s.label}>{title}</Text>
    <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reportReason === r} onPress={() => setReportReason(r)} />)}</View>
    <TextInput accessibilityLabel="Report details" value={reportNote} onChangeText={setReportNote} maxLength={300} multiline style={s.input} placeholder="Details (optional)" placeholderTextColor={C.muted} />
    {!!reportSent && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    <View style={s.reportButtons}>
      <Button title={reportBusy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={reportBusy || !reportReason} onPress={() => void onSubmit()} />
      <Button light title="Cancel" icon="close-outline" onPress={() => {setReporting(null);}} />
    </View>
  </Glass>;

  const chatDisabled = sending || !text.trim() || tokens.balance < TOKENS.CHAT_MESSAGE_COST;

  // 'height' on Android: with Expo SDK 54 + edge-to-edge the window does not
  // resize when the keyboard opens, so the 'padding' behaviour never lifts
  // the composer and the text box hides behind the keyboard. Shrinking the
  // whole view by the keyboard height keeps the composer pinned above it.
  // iOS keeps 'padding', which is reliable there.
  return <KeyboardAvoidingView style={s.fill} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={0}>
  <View style={s.fill}>
    <Animated.View style={[s.head, {opacity: enterAnim}]}>
      {view==='posts' ? <View style={{paddingHorizontal:6,gap:3}}><Text style={s.kbHeadTitle}>Community</Text><Text style={s.body}>Share original words and expressions.</Text></View> : keyboardOpen ? <FadeIn><View style={s.kbHead}><Text style={s.kbHeadTitle}>Community</Text><View style={s.kbHeadBalance}><Icon name="star" size={14} color={C.gold} /><Text style={s.kbHeadBalanceText}>{tokens.balance.toLocaleString()} tokens</Text><Pressable accessibilityRole="button" accessibilityLabel="Buy tokens" onPress={onOpenShop} style={s.kbHeadBuy}><Text style={s.kbHeadBuyText}>Buy</Text></Pressable></View></View></FadeIn> : <Animated.View style={{opacity: heroAnim}}><LiquidHero style={s.hero}>
        <View style={s.heroTop}>
          <Text style={s.heroEyebrow}>LIVE COMMUNITY</Text>
          {user && <Pressable accessibilityRole="button" accessibilityState={{selected: tokens.leaderboard}} onPress={() => void toggleBoard(!tokens.leaderboard)} style={[s.heroJoin, tokens.leaderboard && s.heroJoinOn]}>
            <Icon name="trophy-outline" size={15} color={tokens.leaderboard ? C.goldDeep : '#fff'} />
            <Text style={[s.heroJoinText, tokens.leaderboard && s.heroJoinTextOn]}>{boardBusy ? 'Please wait…' : tokens.leaderboard ? 'Leave board' : 'Join board'}</Text>
          </Pressable>}
        </View>
        <Text style={s.heroTitle}>Community</Text>
        <View style={s.heroLiveRow}><View style={s.liveDot} /><Text style={s.heroLiveText}>Live</Text><Text style={s.heroSub}>Chat and share new words.</Text></View>
        <View style={s.heroBalance}>
          <Icon name="star" size={15} color={C.gold} />
          <Text style={s.heroBalanceText}>{tokens.balance.toLocaleString()} tokens</Text>
          <Pressable accessibilityRole="button" accessibilityLabel="Buy tokens" onPress={onOpenShop} style={s.heroBuy}>
            <Text style={s.heroBuyText}>Buy</Text>
          </Pressable>
        </View>
      </LiquidHero></Animated.View>}
      <View style={s.switcher}>
        <Segment label="Chat" icon="chatbubbles-outline" selected={view === 'chat'} onPress={() => setView('chat')} />
        <Segment label="Posts" icon="newspaper-outline" selected={view === 'posts'} onPress={() => setView('posts')} />
      </View>
    </Animated.View>
    {view==='posts' ? <CommunityPostsPanel active={active} onSignIn={onSignIn} onHistory={onMyPosts}/> : <>
    {loadError && view === 'chat' ? <View style={[s.card, s.inlineCard]}><Text accessibilityRole="alert" style={s.err}>{loadError}</Text></View> : null}
    <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" style={s.scroll} contentContainerStyle={s.list}>
      <FadeIn><View style={s.card}>
        <View style={s.boardHead}>
          <IconTile icon="trophy-outline" from={C.gold} to="#DE8F0E" size={44} iconSize={22} />
          <View style={{flex: 1, gap: 2}}>
            <Text style={s.rowTitle}>Top token earners</Text>
            <Text style={s.body}>Nicknames only.</Text>
          </View>
        </View>
        {board.length === 0 ? <Text style={s.body}>No one yet — be first.</Text> : board.slice(0, 5).map((r, i, arr) => (
          <View key={r.uid} style={[s.boardRow, i === arr.length - 1 && s.boardRowLast, user && r.uid === user.uid && s.boardRowMe]}>
            <View style={[s.rankBadge, i === 0 && s.rankFirst, i === 1 && s.rankSecond, i === 2 && s.rankThird]}><Text style={[s.rankText, i === 2 && s.rankTextLight]}>{i + 1}</Text></View>
            <Text style={[s.boardName, user && r.uid === user.uid && s.boardMe]} numberOfLines={1}>{user && r.uid === user.uid ? 'You' : r.name}</Text><VerifiedBadge verified={badges.has(r.uid)}/>
            <Text style={s.boardTokens}>{r.tokens.toLocaleString()} tokens</Text>
          </View>
        ))}
        {!user && <Text style={s.body}>Sign in to join.</Text>}
      </View></FadeIn>
      {view === 'chat' ? (needsTokens ? gateCard : <>
      {!messages.length && !loadError ? <FadeIn><View style={[s.card, s.emptyCard]}>
        <IconTile icon="chatbubbles-outline" from={C.accent} to={C.purple} size={48} iconSize={24} />
        <Text style={s.rowTitle}>No messages yet.</Text>
        <Text style={s.body}>Say hi — keep it friendly.</Text>
      </View></FadeIn> : null}
      {messages.map(m => {
        const mine = !!user && m.uid === user.uid;
        return <View key={m.id} style={[s.msgWrap, mine && s.msgWrapMine]}>
          <View style={[s.metaRow, mine ? s.metaRowMine : s.metaRowTheirs]}>
            <Text style={s.name}>{mine ? 'You' : m.name}</Text><VerifiedBadge verified={badges.has(m.uid)}/>
            <Text style={s.time}>{timeOf(m.at)}</Text>
          </View>
          <View style={[s.msgLine, mine && s.msgLineMine]}>
            {!mine && <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.avatar}><Text style={s.avatarText}>{initialOf(m.name)}</Text></LinearGradient>}
            {mine ? (
              <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={[s.bubble, s.bubbleMine]}>
                <Text selectable style={[s.text, s.textMine]}>{m.text}</Text>
                <View style={s.actions}>
                  <Pressable accessibilityRole="button" accessibilityLabel="Delete my message" onPress={() => void remove(m.id)} style={s.mini}><Icon name="trash-outline" size={15} color="rgba(255,255,255,.9)" /><Text style={[s.miniText, s.miniTextMine]}>Delete</Text></Pressable>
                </View>
              </LinearGradient>
            ) : (
              <View style={[s.bubble, s.bubbleTheirs]}>
                <Text selectable style={s.text}>{m.text}</Text>
                <View style={s.actions}>
                  <Pressable accessibilityRole="button" accessibilityLabel={`Report message from ${m.name}`} onPress={() => {setReporting(reporting === m.id ? null : m.id); setReportReason(''); setReportNote(''); setReportSent('');}} style={s.mini}><Icon name="flag-outline" size={15} color={C.muted} /><Text style={s.miniText}>Report</Text></Pressable>
                </View>
              </View>
            )}
          </View>
          {reporting === m.id && reportBox('What’s wrong with this message?', () => void report(m.id))}
        </View>;
      })}
      </>) : null}
    </ScrollView>
    {!!reportSent && reporting === null && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    {needsTokens ? null : user ? (view === 'chat' ? <View style={[s.composer, keyboardOpen && s.composerKb]}>
      <View style={s.composerBar}>
        <TextInput accessibilityLabel="Message to the community" value={text} onChangeText={v => {setText(v); setSendError('');}} onFocus={() => setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 300)} maxLength={CHAT_MAX_LENGTH} multiline style={s.composerInput} placeholder={`Chat as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
        <Pressable accessibilityRole="button" accessibilityLabel="Send message" disabled={chatDisabled} onPress={() => void send()} style={s.sendBtn}>
          <LinearGradient colors={chatDisabled ? ['#d7e5f7', '#d7e5f7'] : [C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.sendBtnGrad}>
            <Icon name="paper-plane" size={20} color={chatDisabled ? C.muted : '#fff'} />
          </LinearGradient>
        </Pressable>
      </View>
      <View style={s.composerMeta}>
        <Text style={[s.costText, tokens.balance < TOKENS.CHAT_MESSAGE_COST && s.costWarn]}>{tokens.balance < TOKENS.CHAT_MESSAGE_COST ? `Need ${TOKENS.CHAT_MESSAGE_COST - tokens.balance} more token${TOKENS.CHAT_MESSAGE_COST - tokens.balance === 1 ? '' : 's'}` : `${TOKENS.CHAT_MESSAGE_COST} token${TOKENS.CHAT_MESSAGE_COST === 1 ? '' : 's'} per message`}</Text>
        <Text style={s.count}>{text.trim().length}/{CHAT_MAX_LENGTH}</Text>
      </View>
      {!!sendError && <Text accessibilityRole="alert" style={s.err}>{sendError}</Text>}
    </View> : null) : <View style={[s.card, s.signInCard]}>
      <IconTile icon="person-circle-outline" from={C.accent} to={C.purple} size={44} iconSize={22} />
      <Text style={s.rowTitle}>Sign in to chat</Text>
      <Text style={s.body}>Reading is free.</Text>
      <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
    </View>}
    </>}
  </View>
  </KeyboardAvoidingView>;
}

/** Segmented Chat / Posts switcher — active half is an accent→purple gradient. */
function Segment({label, icon, selected, onPress}: {label: string; icon: IconName; selected: boolean; onPress: () => void}) {
  return (
    <Pressable accessibilityRole="button" accessibilityState={{selected}} onPress={onPress} style={s.segment}>
      <LinearGradient colors={selected ? [C.accent, C.purple] : ['rgba(0,0,0,0)', 'rgba(0,0,0,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.segmentFill}>
        <Icon name={icon} size={17} color={selected ? '#fff' : C.muted} />
        <Text style={[s.segmentText, selected && s.segmentTextOn]}>{label}</Text>
      </LinearGradient>
    </Pressable>
  );
}

const s = StyleSheet.create({
  fill: {flex: 1, backgroundColor: C.bg},
  scroll: {flex: 1},
  head: {paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4, gap: 12},
  hero: {borderRadius: 20, padding: 14, gap: 8, overflow: 'hidden', shadowColor: '#101A3A', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.25, shadowRadius: 16, elevation: 5},
  heroTop: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10},
  heroEyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.8, color: 'rgba(255,255,255,.75)'},
  heroJoin: {flexDirection: 'row', alignItems: 'center', gap: 5, minHeight: 32, paddingHorizontal: 12, borderRadius: 16, backgroundColor: 'rgba(255,255,255,.16)', borderWidth: 1, borderColor: 'rgba(255,255,255,.35)'},
  heroJoinOn: {backgroundColor: C.gold, borderColor: C.gold},
  heroJoinText: {fontSize: 12, fontWeight: '800', color: '#fff'},
  heroJoinTextOn: {color: C.goldDeep},
  heroTitle: {fontSize: 30, lineHeight: 35, fontWeight: '900', letterSpacing: -1, color: '#fff'},
  heroSub: {fontSize: 14, lineHeight: 20, color: 'rgba(255,255,255,.82)'},
  heroBalance: {flexDirection: 'row', alignItems: 'center', gap: 7, alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,.14)', borderWidth: 1, borderColor: 'rgba(255,255,255,.25)', borderRadius: 16, paddingVertical: 6, paddingLeft: 10, paddingRight: 6},
  heroBalanceText: {fontSize: 13, fontWeight: '800', color: '#fff'},
  heroBuy: {backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4},
  heroBuyText: {fontSize: 12, fontWeight: '800', color: C.navy},
  heroLiveRow: {flexDirection: 'row', alignItems: 'center', gap: 6},
  liveDot: {width: 8, height: 8, borderRadius: 4, backgroundColor: '#4ade80'},
  heroLiveText: {fontSize: 12, fontWeight: '800', color: '#fff'},
  kbHead: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 16, paddingVertical: 8, paddingHorizontal: 14},
  kbHeadTitle: {fontSize: 17, fontWeight: '900', letterSpacing: -0.4, color: C.navy},
  kbHeadBalance: {flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.soft, borderWidth: 1, borderColor: '#d6e8fb', borderRadius: 14, paddingVertical: 5, paddingLeft: 9, paddingRight: 5},
  kbHeadBalanceText: {fontSize: 12, fontWeight: '800', color: C.navy},
  kbHeadBuy: {backgroundColor: C.accent, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4},
  kbHeadBuyText: {fontSize: 12, fontWeight: '800', color: '#fff'},
  switcher: {flexDirection: 'row', backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 4}, shadowOpacity: 0.08, shadowRadius: 12, elevation: 2},
  segment: {flex: 1, borderRadius: 14, overflow: 'hidden'},
  segmentFill: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, minHeight: 44, borderRadius: 14},
  segmentText: {fontSize: 14, fontWeight: '800', color: C.muted},
  segmentTextOn: {color: '#fff'},
  title: {fontSize: 24, lineHeight: 29, fontWeight: '900', letterSpacing: -0.8, color: C.navy},
  body: {fontSize: 14, lineHeight: 20, color: C.muted},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 20, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.1, shadowRadius: 14, elevation: 3},
  inlineCard: {marginHorizontal: 16, marginTop: 8, padding: 14},
  signInCard: {marginHorizontal: 16, marginBottom: 10},
  emptyCard: {alignItems: 'center', padding: 20, gap: 8},
  gate: {borderRadius: 20, padding: 18, gap: 10, overflow: 'hidden', shadowColor: '#7654F6', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.3, shadowRadius: 16, elevation: 5},
  gateTitle: {fontSize: 20, fontWeight: '900', letterSpacing: -0.4, color: '#fff'},
  gateBody: {fontSize: 14, lineHeight: 20, color: 'rgba(255,255,255,.85)'},
  gateOk: {fontSize: 13, lineHeight: 19, color: '#fff', fontWeight: '700'},
  boardHead: {flexDirection: 'row', alignItems: 'center', gap: 12},
  boardRow: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eef3fa'},
  boardRowLast: {borderBottomWidth: 0, paddingBottom: 0},
  boardRowMe: {backgroundColor: C.soft, borderRadius: 12, paddingHorizontal: 8, marginHorizontal: -8},
  rankBadge: {width: 28, height: 28, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center'},
  rankFirst: {backgroundColor: C.gold},
  rankSecond: {backgroundColor: '#cbd5e1'},
  rankThird: {backgroundColor: '#d08a4a'},
  rankText: {fontSize: 13, fontWeight: '900', color: C.navy},
  rankTextLight: {color: '#fff'},
  boardName: {flex: 1, fontSize: 15, fontWeight: '700', color: C.navy},
  boardMe: {color: C.accent},
  boardTokens: {fontSize: 14, fontWeight: '800', color: C.goldDeep},
  list: {padding: 12, gap: 10, paddingBottom: 12},
  msgWrap: {alignItems: 'flex-start', gap: 4},
  msgWrapMine: {alignItems: 'flex-end'},
  metaRow: {flexDirection: 'row', gap: 8, alignItems: 'baseline', paddingHorizontal: 4},
  metaRowMine: {},
  metaRowTheirs: {marginLeft: 44},
  msgLine: {flexDirection: 'row', alignItems: 'flex-end', gap: 8, width: '100%'},
  msgLineMine: {justifyContent: 'flex-end'},
  avatar: {width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', flexShrink: 0, borderWidth: 2, borderColor: '#fff'},
  avatarText: {color: '#fff', fontSize: 15, fontWeight: '900'},
  bubble: {borderRadius: 18, paddingVertical: 12, paddingHorizontal: 14, gap: 6, flexShrink: 1},
  bubbleTheirs: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1, borderBottomLeftRadius: 6},
  bubbleMine: {maxWidth: '88%', borderBottomRightRadius: 6},
  name: {fontSize: 13, fontWeight: '800', color: C.navy},
  time: {fontSize: 11, color: C.muted},
  text: {fontSize: 16, lineHeight: 23, color: C.navy},
  textMine: {color: '#fff'},
  actions: {flexDirection: 'row', gap: 8},
  mini: {flexDirection: 'row', gap: 4, alignItems: 'center', minHeight: 28, paddingHorizontal: 4},
  miniLiked: {backgroundColor: C.soft, borderRadius: 12, paddingHorizontal: 8},
  miniText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  miniTextMine: {color: 'rgba(255,255,255,.9)'},
  reportBox: {width: '100%', marginTop: 8},
  label: {fontSize: 14, color: C.navy, fontWeight: '800'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  reportButtons: {gap: 10},
  ok: {fontSize: 13, lineHeight: 19, color: '#0d6e4a'},
  err: {fontSize: 13, lineHeight: 19, color: '#a23842'},
  composer: {backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#dce8f5', paddingHorizontal: 12, paddingTop: 10, paddingBottom: 10, gap: 6},
  composerKb: {elevation: 8, shadowColor: '#101A3A', shadowOffset: {width: 0, height: -4}, shadowOpacity: 0.18, shadowRadius: 12, borderTopWidth: 2, borderTopColor: C.accent},
  composerBar: {flexDirection: 'row', alignItems: 'flex-end', gap: 10},
  composerInput: {flex: 1, minHeight: 48, maxHeight: 120, borderRadius: 22, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  sendBtn: {width: 48, height: 48, borderRadius: 24, overflow: 'hidden', flexShrink: 0},
  sendBtnGrad: {width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center'},
  composerMeta: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4},
  costText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  costWarn: {color: C.warn},
  count: {fontSize: 12, color: C.muted},
  input: {minHeight: 48, borderRadius: 18, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  rowTitle: {fontSize: 17, fontWeight: '800', color: C.navy},
});
