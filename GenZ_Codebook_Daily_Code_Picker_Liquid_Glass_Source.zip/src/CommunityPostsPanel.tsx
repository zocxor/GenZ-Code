import React,{useEffect,useRef,useState} from 'react';
import {KeyboardAvoidingView,Modal,Platform,Pressable,ScrollView,Share,StyleSheet,Text,TextInput,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import * as Clipboard from 'expo-clipboard';
import {Button,C,Chip,Glass,LiquidHero,Icon,RoundIcon,confirmAction,type IconName} from './ui';
import {ConfirmFee,useEligibleBalance} from './ContributionScreens';
import {errorOf,feature,interactions,ms,policy,requestKey,savedPosts,watchComments,watchPosts,type FeedFilter,type FeatureRow} from './communityFeatures';
import {reportPost} from './communityPosts';
import {useAccountUser} from './services';
import {useReducedMotion} from './motion';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {screenPost} from '../shared/chat';
import {REPORT_REASONS} from './ugc';

const filters:FeedFilter[]=['Latest','Trending','Code Words','Slangs'];
const nameOf=(row:FeatureRow)=>row.name||'Code Explorer';
const dateOf=(row:FeatureRow)=>ms(row.createdAt)?new Date(ms(row.createdAt)).toLocaleDateString(undefined,{month:'short',day:'numeric'}):'';
const copyText=(row:FeatureRow)=>row.term?`${row.term}: ${row.meaning??''}`:row.text??'';

export default function CommunityPostsPanel({active,onSignIn,onHistory}:{active:boolean;onSignIn:()=>void;onHistory:()=>void}) {
  const uid=useAccountUser()?.uid;
  const [filter,setFilter]=useState<FeedFilter>('Latest'),[showSaved,setShowSaved]=useState(false);
  const [rows,setRows]=useState<FeatureRow[]>([]),[savedRows,setSavedRows]=useState<FeatureRow[]>([]);
  const [liked,setLiked]=useState<Set<string>>(new Set()),[saved,setSaved]=useState<Set<string>>(new Set());
  const [notice,setNotice]=useState(''),[loading,setLoading]=useState(true),[refresh,setRefresh]=useState(0);
  const [mode,setMode]=useState<'create'|'comments'|'report'|null>(null),[selected,setSelected]=useState<FeatureRow|null>(null);
  const [menu,setMenu]=useState('');
  const pending=useRef(new Set<string>());
  const visible=showSaved?savedRows:rows;
  const verified=useBadges(active?visible.map(r=>r.uid):[]);
  const reduced=useReducedMotion();
  useEffect(()=>{
    if(!active)return;
    setLoading(true);setRows([]);setNotice('');
    return watchPosts(filter,data=>{setRows(data);setLoading(false);},()=>{setNotice('Could not load posts. Check your connection and retry.');setLoading(false);});
  },[filter,active,refresh]);
  useEffect(()=>{
    let mounted=true;
    setLiked(new Set());setSaved(new Set());setShowSaved(false);
    if(uid&&active)void interactions(uid).then(r=>{if(mounted){setLiked(r.liked);setSaved(r.saved);}},()=>{});
    return ()=>{mounted=false;};
  },[uid,active]);
  useEffect(()=>{
    if(!showSaved||!active)return;
    let live=true;
    void savedPosts(saved).then(r=>{if(live)setSavedRows(r);});
    return ()=>{live=false;};
  },[showSaved,active,saved,refresh]);
  const signed=(fn:()=>void)=>{if(uid)fn();else onSignIn();};
  const act=(key:string,task:()=>Promise<void>)=>{
    if(pending.current.has(key))return;
    pending.current.add(key);
    void task().catch(e=>setNotice(errorOf(e))).finally(()=>pending.current.delete(key));
  };
  const toggle=(row:FeatureRow,type:'like'|'save')=>signed(()=>act(type+row.id,async()=>{
    const set=type==='like'?liked:saved, update=type==='like'?setLiked:setSaved;
    const enabled=!set.has(row.id);
    await feature(type+'-post',{id:row.id,enabled});
    update(prev=>{const next=new Set(prev);if(enabled)next.add(row.id);else next.delete(row.id);return next;});
    if(type==='save')setNotice(enabled?'Saved to your collection.':'Removed from saved posts.');
  }));
  const open=(next:'comments'|'report',row:FeatureRow)=>{setMenu('');setSelected(row);setMode(next);};
  return <View style={{flex:1}}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.feed}>
      <View style={s.actions}>{filters.map(f=><Chip key={f} label={f} selected={!showSaved&&filter===f} onPress={()=>{setShowSaved(false);setFilter(f);}}/>)}</View>
      <View style={s.actions}>
        <Chip label="Saved" icon="bookmark-outline" selected={showSaved} onPress={()=>signed(()=>setShowSaved(v=>!v))}/>
        <Chip label="My Posts" icon="albums-outline" onPress={()=>signed(onHistory)}/>
      </View>
      <Pressable accessibilityRole="button" accessibilityLabel="Add a code word or slang" onPress={()=>signed(()=>setMode('create'))}>
        <LiquidHero style={s.callout}><Icon name="create-outline" size={24} color="#fff"/><View style={{flex:1}}><Text style={s.calloutTitle}>Add a code word or slang</Text><Text style={{color:'#DCE6FF'}}>Share an original term for review</Text></View><Text style={s.cost}>{policy.postFee} tokens</Text></LiquidHero>
      </Pressable>
      {!!notice&&<Text accessibilityRole="alert" style={s.body}>{notice}</Text>}
      {!showSaved&&notice.startsWith('Could not load')&&<Button light title="Retry feed" onPress={()=>setRefresh(x=>x+1)}/>}
      {loading&&!showSaved&&<Text style={s.body}>Loading posts…</Text>}
      {(!loading||showSaved)&&!visible.length&&<Glass><Text style={s.title}>{showSaved?'No saved posts yet':'No approved posts in this view'}</Text><Text style={s.body}>{showSaved?'Save a useful word from the feed to find it here.':'Approved submissions appear here after review.'}</Text></Glass>}
      {visible.map(row=><Glass key={row.id}>
        <View style={s.row}>
          <View style={s.avatar}><Text style={s.avatarText}>{nameOf(row).charAt(0).toUpperCase()}</Text></View>
          <View style={[s.row,{flex:1,flexWrap:'wrap'}]}><Text style={s.author}>{nameOf(row)}</Text><VerifiedBadge verified={verified.has(row.uid)}/><Text style={s.body}>{dateOf(row)}</Text></View>
          <Pressable accessibilityRole="button" accessibilityLabel="Post options" accessibilityState={{expanded:menu===row.id}} onPress={()=>setMenu(menu===row.id?'':row.id)} style={s.action}><Icon name="ellipsis-vertical" size={19}/></Pressable>
        </View>
        {menu===row.id&&<View style={s.actions}>{uid===row.uid?
          <Chip label="Remove my post" icon="trash-outline" onPress={()=>confirmAction('Remove this post?', 'It will no longer be public.',()=>act(row.id,async()=>{await feature('delete-post',{id:row.id});setMenu('');setNotice('Post removed.');}))}/>:
          <Chip label="Report" icon="flag-outline" onPress={()=>signed(()=>open('report',row))}/>}</View>}
        {!!row.term&&<View style={s.actions}><Text style={s.term}>{row.term}</Text>{!!row.category&&<Text style={s.category}>{row.category}</Text>}</View>}
        <Text selectable style={s.meaning}>{row.meaning??row.text}</Text>
        {!!row.example&&<Text selectable style={s.body}>Example: {row.example}</Text>}
        <View style={s.actions}>
          <Action icon={liked.has(row.id)?'heart':'heart-outline'} label={`${row.likeCount??0} likes`} selected={liked.has(row.id)} onPress={()=>toggle(row,'like')}/>
          <Action icon="chatbubble-outline" label={`${row.commentCount??0} comments`} onPress={()=>open('comments',row)}/>
          <Action icon={saved.has(row.id)?'bookmark':'bookmark-outline'} label={saved.has(row.id)?'Saved':'Save'} selected={saved.has(row.id)} onPress={()=>toggle(row,'save')}/>
          <Action icon="copy-outline" label="Copy" onPress={()=>act('copy',async()=>{await Clipboard.setStringAsync(copyText(row));setNotice('Copied word and meaning.');})}/>
          <Action icon="share-social-outline" label="Share" onPress={()=>act('share',async()=>{
            if(Platform.OS==='web'){await Clipboard.setStringAsync(copyText(row));setNotice('Copied for sharing.');}
            else await Share.share({message:copyText(row)});
          })}/>
        </View>
      </Glass>)}
    </ScrollView>
    <Modal visible={mode!==null} animationType={reduced?'none':'slide'} onRequestClose={()=>setMode(null)}>
      {mode&&<SafeAreaView style={s.screen}>
        <KeyboardAvoidingView style={{flex:1}} behavior={Platform.OS==='ios'?'padding':undefined}>
          <View style={s.bar}><RoundIcon name="arrow-back" label="Close" onPress={()=>setMode(null)}/><Text style={s.title}>{mode==='create'?'Create post':mode==='report'?'Report post':'Comments'}</Text></View>
          {mode==='create'?<Composer uid={uid} onDone={()=>{setMode(null);setNotice('Submitted for review. Track its status in My Posts.');}}/>:selected&&
            <PostThread key={selected.id+mode} row={selected} report={mode==='report'} uid={uid} onDone={()=>{setMode(null);setNotice('Report sent.');}}/>}
        </KeyboardAvoidingView>
      </SafeAreaView>}
    </Modal>
  </View>;
}

function Action({icon,label,selected,onPress}:{icon:IconName;label:string;selected?:boolean;onPress:()=>void}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{selected}} style={[s.action,selected&&s.on]} onPress={onPress}>
    <Icon name={icon} size={17} color={selected?C.purple:C.blue}/><Text style={s.actionText}>{label}</Text>
  </Pressable>;
}

function Composer({uid,onDone}:{uid?:string;onDone:()=>void}) {
  const [term,setTerm]=useState(''),[meaning,setMeaning]=useState(''),[example,setExample]=useState(''),[category,setCategory]=useState('');
  const [error,setError]=useState(''),[busy,setBusy]=useState(false);
  const busyRef=useRef(false), key=useRef(requestKey()), scroller=useRef<ScrollView>(null);
  const credit=useEligibleBalance(uid);
  const positions=useRef<Record<string,number>>({});
  const focus=(field:string)=>setTimeout(()=>scroller.current?.scrollTo({y:Math.max(0,(positions.current[field]??0)-10),animated:false}),240);
  const update=(fn:(v:string)=>void)=>(v:string)=>{key.current=requestKey();fn(v);};
  const ready=!!term.trim()&&!!meaning.trim()&&!!category;
  const send=async()=>{
    if(!ready||busyRef.current)return;
    const check=screenPost([term,meaning,example].filter(Boolean).join('\n'));
    if(!check.ok){setError(check.message);return;}
    busyRef.current=true;setBusy(true);setError('');
    try {await feature('create-post',{term,meaning,example,category,requestId:key.current});onDone();}
    catch(e){setError(errorOf(e));}
    finally {busyRef.current=false;setBusy(false);}
  };
  return <>
    <ScrollView ref={scroller} contentContainerStyle={s.feed} keyboardShouldPersistTaps="handled" automaticallyAdjustKeyboardInsets={Platform.OS==='ios'}>
      <Glass>
        <Text style={s.title}>Share a new code word</Text>
        <Text style={s.body}>Use an original expression and a clear explanation. Only approved posts are public.</Text>
        {([['Word / Term',term,setTerm,30],['Meaning / Explanation',meaning,setMeaning,200],['Example (optional)',example,setExample,200]] as const).map(([label,value,setter,max])=>
          <View key={label} style={{gap:4}} onLayout={e=>{positions.current[label]=e.nativeEvent.layout.y;}}>
            <Text style={s.author}>{label} · {value.length}/{max}</Text>
            <TextInput accessibilityLabel={label} value={value} onChangeText={update(setter)} maxLength={max} editable={!busy} onFocus={()=>focus(label)}
              multiline={max>30} style={[s.input,max>30&&{minHeight:64}]} placeholderTextColor={C.muted}/>
          </View>)}
        <Text style={s.author}>Category</Text>
        <View style={s.actions}>{policy.postCategories.map(c=><Chip key={c} label={c} selected={category===c} onPress={()=>{if(!busy)update(setCategory)(c);}}/>)}</View>
        <Text style={s.body}>Submissions are manually reviewed. The submission fee is charged once when the post is accepted into the review queue.</Text>
        {!!credit.error&&<Button light title="Retry balance check" onPress={credit.reload}/>}
      </Glass>
    </ScrollView>
    <View style={s.footer}>
      {!!(error||credit.error)&&<Text accessibilityRole="alert" style={s.body}>{error||credit.error}</Text>}
      <ConfirmFee fee={policy.postFee} balance={credit.balance} summary={`Submit “${term}” for moderation. The submission fee is non-refundable.`} disabled={!ready||busy} onConfirm={()=>void send()}/>
    </View>
  </>;
}

function PostThread({row,report,uid,onDone}:{row:FeatureRow;report:boolean;uid?:string;onDone:()=>void}) {
  const [rows,setRows]=useState<FeatureRow[]>([]),[value,setValue]=useState(''),[reason,setReason]=useState('');
  const [error,setError]=useState(''),[busy,setBusy]=useState(false);
  const lock=useRef(false);
  const badges=useBadges(rows.map(r=>r.uid));
  useEffect(()=>{if(!report)return watchComments(row.id,setRows,()=>setError('Could not load comments.'));},[row.id,report]);
  const send=async()=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setError('');
    try {
      if(report){const result=await reportPost(row.id,reason,value);if(!result.ok)throw new Error(result.message);onDone();}
      else {await feature('comment-post',{id:row.id,text:value});setValue('');}
    } catch(e){setError(errorOf(e));}
    finally {lock.current=false;setBusy(false);}
  };
  return <>
    <ScrollView contentContainerStyle={s.feed} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>{row.term??'Community post'}</Text>
      {report?<View style={s.actions}>{REPORT_REASONS.map(r=><Chip key={r} label={r} selected={reason===r} onPress={()=>setReason(r)}/>)}</View>:
        rows.length?rows.map(r=><Glass key={r.id}><View style={s.row}><Text style={s.author}>{nameOf(r)}</Text><VerifiedBadge verified={badges.has(r.uid)}/><Text style={s.body}>{dateOf(r)}</Text></View><Text style={s.meaning}>{r.text}</Text></Glass>):
          <Text style={s.body}>No comments yet.</Text>}
    </ScrollView>
    <View style={s.footer}>
      {!!error&&<Text accessibilityRole="alert" style={s.body}>{error}</Text>}
      {uid?<><TextInput accessibilityLabel={report?'Report details':'Your comment'} value={value} onChangeText={setValue} maxLength={report?300:200} multiline style={s.input}/>
        <Button title={report?'Send report':'Add comment'} disabled={busy||(report?!reason:!value.trim())} onPress={()=>void send()}/></>:
        <Text style={s.body}>Sign in to join the discussion.</Text>}
    </View>
  </>;
}

const s=StyleSheet.create({
  feed:{padding:14,gap:12,paddingBottom:22,maxWidth:620,width:'100%',alignSelf:'center'},actions:{flexDirection:'row',flexWrap:'wrap',gap:6},
  row:{flexDirection:'row',alignItems:'center',gap:7},title:{fontSize:20,fontWeight:'900',color:C.ink},author:{fontSize:14,fontWeight:'800',color:C.ink},
  body:{fontSize:13,lineHeight:18,color:C.muted},meaning:{fontSize:15,lineHeight:21,color:C.ink},avatar:{width:32,height:32,borderRadius:12,backgroundColor:'#EBE2FF',alignItems:'center',justifyContent:'center'},avatarText:{fontWeight:'900',color:C.purple},
  callout:{padding:13,borderRadius:16,flexDirection:'row',gap:8,alignItems:'center'},calloutTitle:{fontSize:15,fontWeight:'900',color:'#fff'},cost:{backgroundColor:'#FFE2A1',color:'#63400C',padding:6,borderRadius:9,fontWeight:'800',overflow:'hidden'},
  term:{backgroundColor:'#4B2DB3',color:'#fff',fontWeight:'900',fontSize:17,borderRadius:10,overflow:'hidden',paddingHorizontal:9,paddingVertical:4},
  category:{color:'#55287C',backgroundColor:'#F4E9FF',fontWeight:'800',paddingHorizontal:8,paddingVertical:5,borderRadius:9,overflow:'hidden'},
  action:{minHeight:36,paddingHorizontal:7,flexDirection:'row',alignItems:'center',gap:4,borderRadius:11,backgroundColor:C.soft},actionText:{fontWeight:'700',fontSize:12,color:C.ink},on:{backgroundColor:'#EBE2FF'},
  screen:{flex:1,backgroundColor:C.bg},bar:{padding:10,paddingHorizontal:14,flexDirection:'row',alignItems:'center',gap:12,borderBottomWidth:1,borderBottomColor:C.line},
  footer:{padding:10,paddingHorizontal:14,gap:5,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:C.line},input:{backgroundColor:'#fff',borderColor:C.line,borderWidth:1,borderRadius:12,padding:9,color:C.ink,minHeight:42},
});
