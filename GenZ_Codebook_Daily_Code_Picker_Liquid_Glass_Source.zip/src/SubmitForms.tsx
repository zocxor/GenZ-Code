/** Add-a-word (instant community words), report-an-entry and feedback forms (signed-in users; server rate-limited). */
import React, {useEffect, useState} from 'react';
import {View, Text, TextInput, Pressable, StyleSheet} from 'react-native';
import {C, Glass, Button, Chip, Icon} from './ui';
import {suggestWord, reportEntry, sendFeedback, resendVerification, REPORT_REASONS, UgcResult} from './ugc';
import {CONTENT_CATEGORIES} from '../shared/contentSchema';
import {containsOwnName, OWN_NAME_ERROR} from '../shared/community';
import {useAccountUser} from './services';
import {TOKENS, suggestCost, canSuggest, type TokensState} from '../shared/tokens';
import {earnTokens, spendTokens, creditAccepted, type Action} from './learning';
import {fetchIsStaff} from './staff';
import {watchRewardedAd, rewardedAdUnitId} from './ads';
import {creditAcceptedWords} from './tokensSync';

function useSubmit() {
  const [busy, setBusy] = useState(false), [result, setResult] = useState<UgcResult | null>(null);
  const run = async (fn: () => Promise<UgcResult>) => {if (busy) return; setBusy(true); setResult(null); try {setResult(await fn());} catch (e) {setResult({ok: false, message: `Couldn’t send that right now. Please try again. (code: ${e instanceof Error ? e.name : 'unexpected'})`});} finally {setBusy(false);}};
  return {busy, result, run, reset: () => setResult(null), fail: (message: string) => setResult({ok: false, message})};
}
function SignInFirst({onSignIn, what}: {onSignIn: () => void; what: string}) {
  return <Glass><Icon name="person-circle-outline" size={32} color={C.blue} /><Text style={s.title}>Sign in to {what}</Text><Text style={s.body}>A free account keeps submissions accountable and lets us prevent spam. Your learning still works without one.</Text><Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} /></Glass>;
}
function Outcome({result, success}: {result: UgcResult | null; success: string}) {
  if (!result) return null;
  return <Text accessibilityRole="alert" style={result.ok ? s.ok : s.err}>{result.ok ? success : result.message}</Text>;
}

export function SuggestWordForm({onSignIn, initialTerm = '', nickname = '', onOpenTerm, onOpenShop, onOpenDaily, tokens, onTokensAction}: {onSignIn: () => void; initialTerm?: string; nickname?: string; onOpenTerm?: (id: string) => void; onOpenShop?: () => void; onOpenDaily?: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  const user = useAccountUser();
  const [term, setTerm] = useState(initialTerm), [meaning, setMeaning] = useState(''), [example, setExample] = useState(''), [category, setCategory] = useState('Chat');
  const [requireReview,setRequireReview]=useState(false);
  const [sent, setSent] = useState(''), [note, setNote] = useState('');
  const [earning, setEarning] = useState(false);
  const [spent, setSpent] = useState(0); // tokens charged for the word just sent (captured at send time)
  const [isStaff, setIsStaff] = useState(false);
  const {busy, result, run, reset, fail} = useSubmit();
  const cost = suggestCost(tokens, isStaff);
  const affordable = canSuggest(tokens, isStaff);
  const rewardAvailable = rewardedAdUnitId() !== null;
  // Staff (admins and moderators) suggest for free; everyone else pays 20
  // tokens, earned by watching ads, playing quizzes, or buying a package.
  useEffect(() => {
    if (!user?.uid) {setIsStaff(false); return;}
    let live = true;
    void fetchIsStaff(user.uid).then(v => {if (live) setIsStaff(v);});
    return () => {live = false;};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.uid]);
  // Words a moderator accepted pay +20 tokens each. Checked when the form opens;
  // already-paid words are skipped, so re-opening never pays twice.
  useEffect(() => {
    let live = true;
    void creditAcceptedWords().then(keys => {if (live && keys.length) onTokensAction(creditAccepted(keys));});
    return () => {live = false;};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const earn = async () => {
    if (earning) return;
    setEarning(true);
    const rewarded = await watchRewardedAd();
    setEarning(false);
    if (rewarded) {onTokensAction(earnTokens(TOKENS.REWARDED_AD)); setNote(`+${TOKENS.REWARDED_AD} tokens earned. Thanks for watching.`);}
    else setNote('No tokens this time — the ad closed early. Try again when you like.');
  };
  const send = () => {
    if (containsOwnName({term, meaning, example}, nickname)) {fail(OWN_NAME_ERROR); return;}
    if (!affordable) {fail(`You need ${cost} tokens to suggest a word (you have ${tokens.balance}). Watch an ad below to earn ${TOKENS.REWARDED_AD} tokens.`); return;}
    setNote(''); setSent(term.trim()); setSpent(cost);
    void run(async () => {
      const r = await suggestWord({term, meaning, example, category, requireReview});
      // Tokens are spent only after the word is accepted by the server, never on a failed send.
      if (r.ok) {
        if (cost > 0) onTokensAction(spendTokens(cost));
      }
      return r;
    });
  };
  const again = () => {setTerm(''); setMeaning(''); setExample(''); setNote(''); setSpent(0); reset();};
  if (!user) return <SignInFirst onSignIn={onSignIn} what="add a word" />;
  if (result?.ok) return <Glass>
    <Icon name={result.live ? 'sparkles' : 'checkmark-circle'} size={36} color={result.live ? C.blue : '#13805a'} />
    <Text style={s.title}>{result.live ? `“${sent}” is live!` : 'Thanks! Sent for a quick check.'}</Text>
    <Text style={s.body}>{result.live ? 'It’s in Words now, and other people get it within a few minutes. Moderators can hide words that break the rules.' : 'This word needs a moderator to look at it before it’s published. You don’t need to do anything else.'}</Text>
    <Text style={s.body}>{spent > 0 ? `This cost ${spent} tokens.` : 'Free for staff — no tokens spent.'}{!result.live ? ' If a moderator accepts it, you earn 20 tokens.' : ''}</Text>
    {result.live && result.termId && onOpenTerm && <Button title="See it in Words" icon="book-outline" onPress={() => onOpenTerm(result.termId!)} />}
    <Button light title="Add another word" icon="add-circle-outline" onPress={again} />
  </Glass>;
  return <>
    <View style={s.intro}>
      <View style={s.introIcon}><Icon name="flash" size={20} color="#fff" /></View>
      <View style={{flex: 1, gap: 2}}><Text style={s.introTitle}>Share an original dictionary entry</Text><Text style={s.small}>Choose Daily Code eligibility to send the word for administrator approval first.</Text></View>
    </View>
    <Glass>
      <View style={s.tokensRow}><Icon name="star" size={18} color="#c38a1d" /><Text style={s.tokensText}>Your tokens: {tokens.balance}</Text><Text style={s.small}>· {isStaff ? 'Free for staff' : `This word costs ${cost} tokens`}</Text></View>
      <Text style={s.label}>Word or phrase</Text>
      <TextInput accessibilityLabel="Suggested word" value={term} onChangeText={setTerm} maxLength={60} autoCapitalize="none" style={s.input} placeholder="e.g. delulu or 143" placeholderTextColor={C.muted} />
      <Text style={s.label}>What it means</Text>
      <TextInput accessibilityLabel="Meaning" value={meaning} onChangeText={setMeaning} maxLength={500} multiline style={[s.input, s.multi]} placeholder="Explain it simply and neutrally" placeholderTextColor={C.muted} />
      <Text style={s.label}>Example (optional)</Text>
      <TextInput accessibilityLabel="Example" value={example} onChangeText={setExample} maxLength={300} style={s.input} placeholder="Avoid real names or private details" placeholderTextColor={C.muted} />
      <Text style={s.label}>Category</Text>
      <View style={s.wrap}>{CONTENT_CATEGORIES.map(c => <Chip key={c} label={c} selected={category === c} onPress={() => setCategory(c)} />)}</View>
      <Chip label="Request review for Daily Code eligibility" icon="calendar-outline" selected={requireReview} onPress={()=>setRequireReview(v=>!v)} />
      <Outcome result={result} success="" />
      {!!note && <Text accessibilityLiveRegion="polite" style={s.ok}>{note}</Text>}
      {result && !result.ok && result.existingId && onOpenTerm && <Button light title="Open it" icon="open-outline" onPress={() => onOpenTerm(result.existingId!)} />}
      {result && !result.ok && result.needsVerification && <>
        <Button light title="Send the verification e-mail again" icon="mail-outline" disabled={busy} onPress={() => void resendVerification().then(setNote)} />
        <Button title={busy ? 'Checking…' : 'I’ve verified, publish now'} icon="checkmark-circle-outline" disabled={busy} onPress={send} />
      </>}
      {rewardAvailable && <Button light title={earning ? 'Showing ad…' : `Watch an ad · +${TOKENS.REWARDED_AD} tokens`} icon="play-circle-outline" disabled={earning || busy} onPress={() => void earn()} />}
      {onOpenDaily && <Button light title="Daily reward" icon="gift-outline" disabled={busy} onPress={onOpenDaily} />}
      {onOpenShop && <Button light title="Buy tokens" icon="card-outline" disabled={busy} onPress={onOpenShop} />}
      <Button title={busy ? 'Submitting…' : affordable ? `${requireReview?'Send for review':'Submit word'} · ${cost>0?`${cost} tokens`:'Free'}` : `Need ${cost - tokens.balance} more tokens`} icon="paper-plane-outline" disabled={busy || !affordable || !term.trim() || meaning.trim().length < 2} onPress={send} />
      <Text style={s.small}>Published with your account ID so moderators can act on abuse. Anyone can report a word. Earn tokens by watching an ad, playing quizzes, or getting a word accepted by a moderator — or buy a package from your wallet.</Text>
    </Glass>
  </>;
}

export function ReportForm({termId, expression, onSignIn}: {termId: string; expression: string; onSignIn: () => void}) {
  const user = useAccountUser();
  const [reason, setReason] = useState<string>(''), [note, setNote] = useState('');
  const {busy, result, run} = useSubmit();
  if (!user) return <SignInFirst onSignIn={onSignIn} what="report an entry" />;
  if (result?.ok) return <Glass><Icon name="flag" size={30} color="#13805a" /><Text style={s.title}>Report sent. Thank you.</Text><Text style={s.body}>A moderator will review “{expression}”.</Text></Glass>;
  return <Glass>
    <Text style={s.title}>What’s wrong with “{expression}”?</Text>
    <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reason === r} onPress={() => setReason(r)} />)}</View>
    <TextInput accessibilityLabel="Report details" value={note} onChangeText={setNote} maxLength={300} multiline style={[s.input, s.multi]} placeholder="Details (optional)" placeholderTextColor={C.muted} />
    <Outcome result={result} success="" />
    <Button title={busy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={busy || !reason} onPress={() => void run(() => reportEntry(termId, reason, note))} />
  </Glass>;
}

export function FeedbackForm({onSignIn}: {onSignIn: () => void}) {
  const user = useAccountUser();
  const [rating, setRating] = useState(0), [message, setMessage] = useState('');
  const {busy, result, run} = useSubmit();
  if (!user) return <SignInFirst onSignIn={onSignIn} what="send feedback" />;
  if (result?.ok) return <Glass><Icon name="heart" size={30} color="#c2417a" /><Text style={s.title}>Thanks for the feedback!</Text><Text style={s.body}>It goes straight to the GenZ Codebook team.</Text></Glass>;
  return <Glass>
    <Text style={s.title}>How is GenZ Codebook working for you?</Text>
    <View style={s.stars}>{[1, 2, 3, 4, 5].map(n => <Pressable key={n} accessibilityRole="button" accessibilityLabel={`${n} star${n > 1 ? 's' : ''}`} accessibilityState={{selected: rating === n}} onPress={() => setRating(n)} style={s.star}><Icon name={n <= rating ? 'star' : 'star-outline'} size={34} color="#c38a1d" /></Pressable>)}</View>
    <TextInput accessibilityLabel="Feedback message" value={message} onChangeText={setMessage} maxLength={1000} multiline style={[s.input, s.multi]} placeholder="What should we improve? (optional)" placeholderTextColor={C.muted} />
    <Outcome result={result} success="" />
    <Button title={busy ? 'Sending…' : 'Send feedback'} icon="send-outline" disabled={busy || !rating} onPress={() => void run(() => sendFeedback(rating, message))} />
    <Text style={s.small}>Includes your rating, message, app version and platform. Don’t include personal information.</Text>
  </Glass>;
}

const s = StyleSheet.create({
  title: {fontSize: 19, fontWeight: '800', color: C.ink, letterSpacing: -0.3},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  label: {fontSize: 14, fontWeight: '800', color: C.ink},
  input: {minHeight: 52, padding: 14, borderWidth: 1, borderColor: '#bccfe6', borderRadius: 16, backgroundColor: '#e7f0fb', fontSize: 16, color: C.ink},
  multi: {minHeight: 96, textAlignVertical: 'top'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  stars: {flexDirection: 'row', justifyContent: 'center', gap: 4},
  star: {minWidth: 48, minHeight: 48, alignItems: 'center', justifyContent: 'center'},
  small: {fontSize: 12, lineHeight: 18, color: C.muted},
  ok: {padding: 12, borderRadius: 14, backgroundColor: '#e1f5e9', color: '#175e47'},
  err: {padding: 12, borderRadius: 14, backgroundColor: '#fff0ee', color: '#96383f', lineHeight: 20},
  intro: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: 20, backgroundColor: '#e4edff', borderWidth: 1, borderColor: '#c9d9fb'},
  tokensRow: {flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap'},
  tokensText: {fontSize: 15, fontWeight: '800', color: C.ink},
  introIcon: {width: 38, height: 38, borderRadius: 13, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center'},
  introTitle: {fontSize: 15, fontWeight: '800', color: C.ink},
});

/** Single lazy entry point used by App for the three submission sheets. */
export function FormHost({kind, term, initialTerm, nickname, onSignIn, onOpenTerm, onOpenShop, onOpenDaily, tokens, onTokensAction}: {kind: 'feedback' | 'suggest' | 'report'; term: {id: string; expression: string} | null; initialTerm?: string; nickname?: string; onSignIn: () => void; onOpenTerm?: (id: string) => void; onOpenShop?: () => void; onOpenDaily?: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  if (kind === 'feedback') return <FeedbackForm onSignIn={onSignIn} />;
  if (kind === 'report' && term) return <ReportForm termId={term.id} expression={term.expression} onSignIn={onSignIn} />;
  return <SuggestWordForm onSignIn={onSignIn} initialTerm={initialTerm} nickname={nickname} onOpenTerm={onOpenTerm} onOpenShop={onOpenShop} onOpenDaily={onOpenDaily} tokens={tokens} onTokensAction={onTokensAction} />;
}
