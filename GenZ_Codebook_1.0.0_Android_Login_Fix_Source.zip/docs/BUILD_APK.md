# Building the GenZ Codebook APK and Play AAB

Rebuild the APK from this source to install version code 18 with the Android sign-in screen transition fix.

## Option A — GitHub Actions (no local setup)

1. Commit the extracted source at the root of your **private** GitHub repository. Include `.github/workflows/` and the Gradle wrapper files.
2. GitHub → **Actions** → **Android APK** → **Run workflow** (keep the default ABIs).
3. After the build succeeds, open the run → **Artifacts** → download `genz-code-apk`. It contains `app-internal.apk` and `apk-report.txt` (signature, package/version, permissions, SHA-256).

The workflow also runs typecheck, unit tests and the security scan, and fails if the APK contains camera, microphone or storage permissions.

## Option B — your own computer

Prerequisites: Node 22, **JDK 17**, Android Studio with SDK Platform 36, Build-Tools 36.0.0, NDK 27.1.12297006, CMake 3.22.1 (Android Studio → SDK Manager → SDK Tools → "Show package details"). Set `ANDROID_HOME` (Windows: `%LOCALAPPDATA%\Android\Sdk`; macOS: `~/Library/Android/sdk`).

```bash
npm ci
npm run typecheck && npm test
cd android
./gradlew assembleInternal -PreactNativeArchitectures=arm64-v8a,armeabi-v7a     # Windows: .\gradlew.bat …
```

Output: `android/app/build/outputs/apk/internal/app-internal.apk`. Install it with `adb install -r app-internal.apk`, or copy it to the phone.

Do **not** set `EXPO_PUBLIC_FIREBASE_EMULATOR_HOST` when building. If you have ever built with it set, clear the Metro cache first: `npx expo start --clear`, then stop it.

## Which signing key?

| Build | Signed with | Use for | Updates |
|---|---|---|---|
| `assembleInternal` (APK) | Project internal test key (`android/app/debug.keystore`) | Testers, sideloading | Installs **over** earlier internal builds; data is kept |
| `bundleRelease` (AAB) | **Your upload key** (`GENZ_UPLOAD_*` variables / GitHub secrets) | Google Play | Blocked by `npm run release:check` until every gate in `production-readiness.json` has evidence |

Important for testers' data: Android refuses to update an app signed with a different certificate, so moving from an internal (test-key) install to a Play or upload-key build requires uninstalling, which deletes device-only data. From 0.8.0, testers who sign in keep their learning data in their account and get it back after reinstalling. Ask testers to sign in before you switch them to Play builds. For seamless updates afterwards, distribute through a Play **internal testing** track.

GitHub secrets for `release-aab`: `GENZ_UPLOAD_KEYSTORE_BASE64` (output of `base64 -w0 your-upload.keystore`), `GENZ_UPLOAD_STORE_PASSWORD`, `GENZ_UPLOAD_KEY_ALIAS`, `GENZ_UPLOAD_KEY_PASSWORD`. Never commit the keystore or passwords.

## After installing: device checklist

Check that a successful login opens Decode and that the session survives a force-stop and reopen. If Android closes the app, connect the phone with USB debugging, run `adb logcat -c`, reproduce the close, and then run `adb logcat -b crash -d`. Share the relevant `FATAL EXCEPTION` section for `com.genzmode.app` with any account details removed.

Save a word → force-stop → reopen → it is still saved. Finish a quiz → reboot the phone → the score is still there. Turn on airplane mode, make changes, turn it off → "Backed up" appears. Pick a profile photo (no permission prompt should appear). Sign in on a second phone → saves sync across. Install the next build over this one → data is kept.


## 0.8.1: smaller APK and the Play AAB

- The APK job builds **arm64-v8a only** by default (covers almost all phones since 2017) and compresses native libraries (`-Pexpo.useLegacyPackaging=true`). Brand images were resized to their display size (3.8 MB → 0.86 MB). The run log prints the exact APK size. Add `,armeabi-v7a` to the ABI box only for very old 32-bit phones.
- **Play AAB:** tick **"Also build the Play Store AAB"** when running *Android APK*. It builds the `beta` variant, signed with **your upload key**, with all CPU architectures (Play sends each phone only what it needs). Its versionCode is `100 + run number`, so every upload is higher than the previous one. Upload it to **Play Console → Testing → Internal testing**. The production `release` build stays blocked by the readiness gates.
- Upload-key secrets (GitHub → Settings → Secrets and variables → Actions → New repository secret):
  - `GENZ_UPLOAD_KEYSTORE_BASE64`: on Windows PowerShell run `[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\path\to\your-upload-key.jks")) | Set-Clipboard` and paste.
  - `GENZ_UPLOAD_STORE_PASSWORD`, `GENZ_UPLOAD_KEY_ALIAS`, `GENZ_UPLOAD_KEY_PASSWORD`: from when you created the key.
  The AAB report lists the certificate SHA-256; it must match the upload key registered in Play Console.
