/**
 * User submissions: new words, content reports and app feedback.
 *
 * New words go live instantly as community words (communityWords/{id}) when the owner's switch
 * allows it and the word filter does not flag them; otherwise they wait for moderators
 * (submissions). Every write is batched with a rate-limit stamp (users/{uid}/limits/ugc);
 * Firestore rules reject writes less than 60 s apart, unknown fields, oversize text, links,
 * spoofed owner IDs, unverified e-mail (for instant publishing) and restricted accounts.
 * Before writing, the same conditions are checked here so people get a specific reason
 * instead of a generic failure.
 */
import {Platform} from 'react-native';
import type {User} from 'firebase/auth';
import {cleanText, validateEntry, CONTENT_CATEGORIES} from '../shared/contentSchema';
import {communityId, screenWord} from '../shared/community';
import {APP_VERSION} from './secure/config';
import {findExistingTerm, addLocalCommunityWord} from './contentSync';

export const REPORT_REASONS = ['Wrong meaning', 'Offensive or harmful', 'Outdated', 'Spelling or formatting', 'Other'] as const;
export type UgcResult =
  | {ok: true; live?: boolean; termId?: string}
  | {ok: false; message: string; needsVerification?: boolean; existingId?: string};
type Fail = Extract<UgcResult, {ok: false}>;
const fail = (message: string, extra: Partial<Fail> = {}): Fail => ({ok: false, message, ...extra});

const libs = () => Promise.all([import('firebase/firestore/lite'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

/** Specific, honest messages; unknown failures include the backend code for support. */
function errorText(e: unknown, CloudError: typeof import('./sync/engine').CloudError): string {
  if (e instanceof CloudError) {
    if (e.code === 'server-setup') return 'Adding words isn’t available yet: the GenZ Code server is still being set up. Please try again later. (code: server-setup)';
    if (e.code === 'offline') return 'You’re offline. Connect to the internet and try again.';
    if (e.code === 'unauthenticated') return 'Your session expired. Sign in again, then try once more.';
    if (e.code === 'permission-denied') return 'The server didn’t accept this. If you just verified your e-mail, wait a minute and try again. (code: permission-denied)';
    return `Couldn’t send that right now. Please try again. (code: ${e.raw || e.code})`;
  }
  return 'Couldn’t send that right now. Please try again.';
}

/** Signed-in, active account with no recent submission. Returns the user or a reason. */
async function prepare(): Promise<{user: User; wait: number} | Fail> {
  const [{doc, getDoc}, {cloudDb, accountAuth}, {firestoreCloud}] = await libs();
  const user = accountAuth.currentUser;
  if (!user) return fail('Sign in to send this. It helps us prevent spam.');
  const status = await firestoreCloud.ensureAccount(user.uid, {appVersion: APP_VERSION, platform: Platform.OS});
  if (status === 'suspended') return fail('Your account is restricted, so it can’t send this. Contact support if you think this is a mistake.');
  if (status === 'deleted') return fail('This account is being deleted.');
  const stamp = await getDoc(doc(cloudDb(), 'users', user.uid, 'limits', 'ugc'));
  const last = stamp.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
  return {user, wait: Math.min(60, Math.ceil((last + 61_000 - Date.now()) / 1000))};
}

/** Rules read the e-mail_verified claim from the ID token, so refresh it after verifying. */
async function emailVerified(user: User): Promise<boolean> {
  const {reload} = await import('firebase/auth');
  if (!user.emailVerified) {await reload(user); if (!user.emailVerified) return false;}
  if ((await user.getIdTokenResult()).claims.email_verified === true) return true;
  return (await user.getIdTokenResult(true)).claims.email_verified === true;
}

async function submit(collectionName: 'submissions' | 'reports' | 'feedback', body: Record<string, unknown>): Promise<UgcResult> {
  const [{doc, collection, writeBatch, serverTimestamp}, {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    const ready = await prepare();
    if ('ok' in ready) return ready;
    if (ready.wait > 0) return fail(`Please wait ${ready.wait} s before sending another one.`);
    const db = cloudDb(), batch = writeBatch(db);
    batch.set(doc(db, 'users', ready.user.uid, 'limits', 'ugc'), {last: serverTimestamp()});
    batch.set(doc(collection(db, collectionName)), {...body, uid: ready.user.uid, status: collectionName === 'feedback' ? 'new' : collectionName === 'reports' ? 'open' : 'pending', createdAt: serverTimestamp()});
    await batch.commit();
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}

/** Add a word. Live for everyone immediately unless the owner turned that off or the filter flags it. */
export async function suggestWord(input: {term: string; meaning: string; example: string; category: string}): Promise<UgcResult> {
  const v = validateEntry({...input, language: 'English'});
  if (!v.ok) return fail(v.errors[0]!);
  if (!(CONTENT_CATEGORIES as readonly string[]).includes(input.category)) return fail('Choose a category.');
  const screen = screenWord(input);
  if (!screen.ok) return fail(screen.message);
  const {term, meaning, example, category} = v.entry;
  const existing = findExistingTerm(term);
  if (existing) return fail(`“${existing.expression}” is already in GenZ Code.`, {existingId: existing.id});

  const [{doc, getDoc, writeBatch, serverTimestamp}, {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    const db = cloudDb();
    const config = await getDoc(doc(db, 'config', 'app'));
    const flags = config.exists() ? config.data() : {};
    if (flags.ugcEnabled === false) return fail('Adding words is paused right now. Please try again later.');
    if (flags.communityWordsEnabled === false || screen.review) {
      const r = await submit('submissions', {term, meaning, example, category});
      return r.ok ? {ok: true, live: false} : r;
    }
    const ready = await prepare();
    if ('ok' in ready) return ready;
    if (!(await emailVerified(ready.user))) return fail('Verify your e-mail to publish words. Open the link we sent you, then tap “I’ve verified”.', {needsVerification: true});
    const id = communityId(term), ref = doc(db, 'communityWords', id);
    const current = await getDoc(ref);
    if (current.exists()) {
      const data = current.data();
      if (data.status === 'live') {await addLocalCommunityWord(id, data); return fail(`Someone already added “${data.term}”. It’s in the list now.`, {existingId: id});}
      return fail('That word can’t be added right now.');
    }
    if (ready.wait > 0) return fail(`Please wait ${ready.wait} s before adding another word.`);
    const batch = writeBatch(db);
    batch.set(doc(db, 'users', ready.user.uid, 'limits', 'ugc'), {last: serverTimestamp()});
    batch.set(ref, {id, term, meaning, example, category, uid: ready.user.uid, status: 'live', createdAt: serverTimestamp(), updatedAt: serverTimestamp()});
    await batch.commit();
    await addLocalCommunityWord(id, {term, meaning, example, category});
    return {ok: true, live: true, termId: id};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}
export function reportEntry(termId: string, reason: string, note: string): Promise<UgcResult> {
  if (!(REPORT_REASONS as readonly string[]).includes(reason)) return Promise.resolve(fail('Choose a reason.'));
  return submit('reports', {termId, reason, note: cleanText(note, 300)});
}
export function sendFeedback(rating: number, message: string): Promise<UgcResult> {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return Promise.resolve(fail('Choose a rating from 1 to 5.'));
  return submit('feedback', {rating, message: cleanText(message, 1000), appVersion: APP_VERSION, platform: Platform.OS});
}
/** Resend the verification e-mail for the signed-in account. */
export async function resendVerification(): Promise<string> {
  const [{sendEmailVerification}, {accountAuth}] = await Promise.all([import('firebase/auth'), import('./firebase/app')]);
  const user = accountAuth.currentUser;
  if (!user?.email) return 'Sign in first.';
  try {await sendEmailVerification(user); return `Verification e-mail sent to ${user.email}. Open the link, then tap “I’ve verified”.`;}
  catch {return 'Couldn’t send the e-mail right now. Please wait a minute and try again.';}
}
