/**
 * Community chat room: one shared room for everyone, by nickname.
 *
 * Guests can read the room; only signed-in users can post. Messages are screened
 * on the device before sending (see shared/chat.ts) and again by the server rules.
 * Any message can be reported; moderators hide reported messages from the admin
 * portal. The room only shows live messages, newest last, capped at the newest 50.
 */
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, ScrollView, Pressable, StyleSheet} from 'react-native';
import {C, Glass, Button, Chip, Icon} from './ui';
import {useAccountUser} from './services';
import {subscribeChat, sendChatMessage, deleteOwnMessage} from './chat';
import {reportChatMessage, REPORT_REASONS} from './ugc';
import {CHAT_RULES, CHAT_MAX_LENGTH, type ChatMessage} from '../shared/chat';

const timeOf = (at: number) => new Date(at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});

export default function CommunityScreen({active, nickname, onSignIn}: {active: boolean; nickname: string; onSignIn: () => void}) {
  const user = useAccountUser();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [reporting, setReporting] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportNote, setReportNote] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportSent, setReportSent] = useState('');
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    if (!active) return;
    setLoadError('');
    return subscribeChat(setMessages, setLoadError);
  }, [active]);
  useEffect(() => {
    if (active) scrollRef.current?.scrollToEnd({animated: true});
  }, [messages, active]);

  const send = async () => {
    if (sending || !text.trim()) return;
    setSending(true); setSendError('');
    const r = await sendChatMessage(nickname, text);
    setSending(false);
    if (r.ok) setText('');
    else setSendError(r.message);
  };

  const report = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportChatMessage(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this message.'); setReporting(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const remove = async (id: string) => {
    const r = await deleteOwnMessage(id);
    if (!r.ok) setSendError(r.message);
  };

  return <View style={s.fill}>
    <View style={s.head}>
      <Text style={s.title}>Community</Text>
      <Text style={s.body}>One room. Everyone chatting, by nickname.</Text>
      <Text style={s.rules}>{CHAT_RULES}</Text>
    </View>
    {loadError ? <Glass><Text accessibilityRole="alert" style={s.err}>{loadError}</Text></Glass> : null}
    <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" contentContainerStyle={s.list}>
      {!messages.length && !loadError ? <Glass><Icon name="chatbubbles-outline" size={30} color={C.blue} /><Text style={s.rowTitle}>No messages yet.</Text><Text style={s.body}>Say hi — keep it friendly.</Text></Glass> : null}
      {messages.map(m => {
        const mine = !!user && m.uid === user.uid;
        return <View key={m.id} style={[s.row, mine && s.rowMine]}>
          <View style={[s.bubble, mine ? s.bubbleMine : s.bubbleTheirs]}>
            <View style={s.meta}><Text style={s.name}>{mine ? 'You' : m.name}</Text><Text style={s.time}>{timeOf(m.at)}</Text></View>
            <Text selectable style={s.text}>{m.text}</Text>
            <View style={s.actions}>
              {mine
                ? <Pressable accessibilityRole="button" accessibilityLabel="Delete my message" onPress={() => void remove(m.id)} style={s.mini}><Icon name="trash-outline" size={15} color={C.muted} /><Text style={s.miniText}>Delete</Text></Pressable>
                : <Pressable accessibilityRole="button" accessibilityLabel={`Report message from ${m.name}`} onPress={() => {setReporting(reporting === m.id ? null : m.id); setReportReason(''); setReportNote(''); setReportSent('');}} style={s.mini}><Icon name="flag-outline" size={15} color={C.muted} /><Text style={s.miniText}>Report</Text></Pressable>}
            </View>
          </View>
          {reporting === m.id && <Glass style={s.reportBox}>
            <Text style={s.label}>What’s wrong with this message?</Text>
            <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reportReason === r} onPress={() => setReportReason(r)} />)}</View>
            <TextInput accessibilityLabel="Report details" value={reportNote} onChangeText={setReportNote} maxLength={300} multiline style={s.input} placeholder="Details (optional)" placeholderTextColor={C.muted} />
            {!!reportSent && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
            <View style={s.reportButtons}>
              <Button title={reportBusy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={reportBusy || !reportReason} onPress={() => void report(m.id)} />
              <Button light title="Cancel" icon="close-outline" onPress={() => setReporting(null)} />
            </View>
          </Glass>}
        </View>;
      })}
    </ScrollView>
    {!!reportSent && reporting === null && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    {user ? <View style={s.composer}>
      <TextInput accessibilityLabel="Message to the community" value={text} onChangeText={v => {setText(v); setSendError('');}} maxLength={CHAT_MAX_LENGTH} multiline style={s.input} placeholder={`Chat as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
      {!!sendError && <Text accessibilityRole="alert" style={s.err}>{sendError}</Text>}
      <View style={s.sendRow}>
        <Text style={s.count}>{text.trim().length}/{CHAT_MAX_LENGTH}</Text>
        <Button title={sending ? 'Sending…' : 'Send'} icon="paper-plane-outline" disabled={sending || !text.trim()} onPress={() => void send()} />
      </View>
    </View> : <Glass><Icon name="person-circle-outline" size={32} color={C.blue} /><Text style={s.rowTitle}>Sign in to chat</Text><Text style={s.body}>A free account keeps the room accountable and lets us prevent spam. You can still read the conversation.</Text><Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} /></Glass>}
  </View>;
}

const s = StyleSheet.create({
  fill: {flex: 1},
  head: {paddingHorizontal: 22, paddingTop: 6, gap: 6},
  title: {fontSize: 32, lineHeight: 38, fontWeight: '900', letterSpacing: -1.2, color: C.ink},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  rules: {fontSize: 12, lineHeight: 18, color: C.muted, backgroundColor: 'rgba(255,255,255,.6)', borderRadius: 12, padding: 10, borderWidth: 1, borderColor: '#fff'},
  list: {padding: 22, gap: 12, paddingBottom: 16},
  row: {alignItems: 'flex-start'},
  rowMine: {alignItems: 'flex-end'},
  bubble: {maxWidth: '88%', borderRadius: 18, padding: 12, gap: 4, borderWidth: 1},
  bubbleTheirs: {backgroundColor: 'rgba(255,255,255,.8)', borderColor: '#fff'},
  bubbleMine: {backgroundColor: '#dceaff', borderColor: '#cfe0ff'},
  meta: {flexDirection: 'row', gap: 8, alignItems: 'baseline'},
  name: {fontSize: 13, fontWeight: '800', color: C.blue},
  time: {fontSize: 11, color: C.muted},
  text: {fontSize: 16, lineHeight: 23, color: C.ink},
  actions: {flexDirection: 'row', gap: 8},
  mini: {flexDirection: 'row', gap: 4, alignItems: 'center', minHeight: 28, paddingHorizontal: 4},
  miniText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  reportBox: {width: '100%', marginTop: 8},
  label: {fontSize: 14, color: C.ink, fontWeight: '800'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  reportButtons: {gap: 10},
  ok: {fontSize: 13, lineHeight: 19, color: '#0d6e4a'},
  err: {fontSize: 13, lineHeight: 19, color: '#a23842'},
  composer: {paddingHorizontal: 22, paddingBottom: 10, gap: 8},
  input: {minHeight: 52, borderRadius: 17, borderWidth: 1, borderColor: '#bccfe6', padding: 14, fontSize: 16, color: C.ink, backgroundColor: '#e7f0fb'},
  sendRow: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  count: {fontSize: 12, color: C.muted},
  rowTitle: {fontSize: 16, fontWeight: '800', color: C.ink},
});
