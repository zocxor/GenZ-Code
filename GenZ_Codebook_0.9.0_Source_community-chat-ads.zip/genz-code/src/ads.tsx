/**
 * Google AdMob (free service; the SDK costs nothing, the app earns from impressions).
 *
 * Which ID is which:
 *  - App ID (ca-app-pub-9776667186789824~9376759074) identifies the app to the SDK.
 *    It lives in app.json (config plugin + react-native-google-mobile-ads key) and in
 *    android/app/src/main/AndroidManifest.xml. It is never passed to an ad view.
 *  - Banner ad unit ID (ca-app-pub-9776667186789824/5427038644) is the ID the banner
 *    itself needs. That is the only ID a banner takes.
 *  - Interstitial ad unit ID: not created yet in AdMob. The placeholder below stays
 *    empty until one is created; no interstitial is loaded or shown anywhere until then.
 *
 * The banner is shown in exactly one place: the Suggest a word sheet (the create
 * flow). Nowhere else in the app. While developing, Google's test banner is served
 * instead of the real one — never tap a real ad in a debug build; AdMob treats that
 * as invalid traffic. Ads are non-personalised, matching the app's privacy stance
 * and avoiding a consent form for basic serving.
 */
import React, {useState} from 'react';
import {Platform, View} from 'react-native';
import {BannerAd, BannerAdSize, InterstitialAd, MobileAds, TestIds} from 'react-native-google-mobile-ads';
import {IS_DEV} from './secure/config';

export const ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074';
export const BANNER_AD_UNIT_ID = 'ca-app-pub-9776667186789824/5427038644';
/** TODO: create an interstitial ad unit in AdMob and paste its ID here. Until then no interstitial is loaded or shown. */
export const INTERSTITIAL_AD_UNIT_ID = '';

/** The banner's ad unit ID: Google's test banner in dev, the real one in release builds. */
export function bannerAdUnitId(): string {
  return IS_DEV ? TestIds.BANNER : BANNER_AD_UNIT_ID;
}

/** Interstitial ad unit ID, or null until one is created in AdMob. */
export function interstitialAdUnitId(): string | null {
  return INTERSTITIAL_AD_UNIT_ID ? (IS_DEV ? TestIds.INTERSTITIAL : INTERSTITIAL_AD_UNIT_ID) : null;
}

let adsStarted = false;
/** Initialise the SDK once, Android only. Safe to call on every launch; a failure only means no ads. */
export function initAds(): void {
  if (adsStarted || Platform.OS !== 'android') return;
  adsStarted = true;
  void MobileAds().initialize().catch(() => undefined);
}

/** A preloaded interstitial, or null when no interstitial ad unit ID is configured yet. */
export function preloadInterstitial(): InterstitialAd | null {
  const unitId = interstitialAdUnitId();
  if (!unitId) return null;
  const ad = InterstitialAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
  ad.load();
  return ad;
}

/**
 * The one banner in the app: shown at the bottom of the Suggest a word sheet only.
 * Android only; renders nothing on iOS/web or while the ad fails to load.
 */
export function SuggestAdBanner() {
  const [failed, setFailed] = useState(false);
  if (Platform.OS !== 'android' || failed) return null;
  return <View style={{alignItems: 'center'}}>
    <BannerAd
      unitId={bannerAdUnitId()}
      size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER}
      requestOptions={{requestNonPersonalizedAdsOnly: true}}
      onAdFailedToLoad={() => setFailed(true)}
    />
  </View>;
}
