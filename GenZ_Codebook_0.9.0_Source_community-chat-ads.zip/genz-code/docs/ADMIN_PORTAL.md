# Admin portal & Firebase backend — setup and operations (0.9.0)

The portal is a separate web app (`admin/`), hosted on Firebase Hosting at `/admin/`. No admin code or credential ships in the mobile APK. All permissions are enforced by `firebase/firestore.rules`; the portal UI only hides what a role cannot do.

## Quick start with GitHub Actions (no local tools)

1. **Deploy credentials:** Firebase console → Project settings → **Service accounts** → **Generate new private key** (downloads a JSON file). In Google Cloud console → **IAM**, edit the `firebase-adminsdk-…@gen-z-code-55caf.iam.gserviceaccount.com` principal and add the roles **Firebase Admin** and **Service Usage Consumer**. Open the JSON in Notepad, copy everything, and save it as the GitHub repository secret **`FIREBASE_SERVICE_ACCOUNT`**. Then delete the downloaded file. This key can change your Firebase project: never upload it to the repository.
2. **Actions → Deploy Firebase → Run workflow** (untick the two-step box unless you upgraded to Identity Platform). It runs the security-rules tests on the official emulator, and only if they all pass it publishes the Firestore rules and indexes and the admin portal, privacy policy and deletion page.
3. **Make yourself Super Admin:** Authentication → Users → copy your **User UID**. Firestore → **Start collection** `admins` → Document ID = your UID → fields: `role` (string) `super_admin`, `active` (boolean) `true`, `email` (string) your email, `updatedAt` (timestamp) now, `updatedBy` (string) `console`, `lastAuditId` (string) `bootstrap`.
4. Open **https://gen-z-code-55caf.web.app/admin/** and sign in with the app account's e-mail and password (the e-mail must be verified).

**Two-step verification (optional, 0.8.5):** authenticator-app codes need *Firebase Authentication with Identity Platform*, which the Firebase console offers only as a paid upgrade for this project. Admin sign-in therefore uses a verified e-mail + password by default, with the `admins` allow-list, audit log and 30-minute timeout. To require codes later: upgrade, run Deploy Firebase with the two-step box ticked, then create the Firestore document `config/security` with the boolean field `adminMfaRequired = true` (console only; no app or portal can change it). Every admin will then be asked to scan a QR code at their next sign-in. Use a long, unique password for admin accounts in the meantime.

Creating an account in the app never makes it an admin. Admin access exists only in this web portal and only for UIDs listed in `admins`.

## One-time setup (project owner)

1. **Test the rules first** (needs Java 21+): `npm i -g firebase-tools && npm run test:rules`. Do not deploy rules that fail.
2. *(Optional, paid)* **Upgrade Authentication to Identity Platform**, enable TOTP (Deploy Firebase does this), then set `config/security.adminMfaRequired = true`. Until then, rules require a verified e-mail for every admin request but no second factor.
3. In Authentication settings enable **email enumeration protection**, set the **password policy** (12+ characters to match the app), and review **authorized domains** (keep `gen-z-code-55caf.web.app`).
4. Deploy: `firebase deploy --only firestore:rules,firestore:indexes` then `cd admin && npm ci && npm run build && cd .. && firebase deploy --only hosting`.
5. Retention: Firestore TTL policies need a billing account, so they are not deployed. About once a month a Super Admin opens **Audit & security → Delete expired entries** (security events after 90 days, audit entries after 365 days; rules allow deleting only expired entries, and each clean-up is logged). On a paid plan you can instead add TTL policies on `securityEvents.expireAt` and `auditLogs.expireAt` (Firestore → Time-to-live).
6. **Bootstrap the first Super Admin** (console writes bypass rules by design): create an account in the app or portal, copy its UID from Authentication, then in Firestore create `admins/<UID>` with `{role: "super_admin", active: true, email: "<email>", updatedAt: <now>, updatedBy: "console", lastAuditId: "bootstrap"}`. Sign in at `/admin/`, verify your e-mail, enrol an authenticator app, sign in again. Add a **second** Super Admin from the portal (nobody can edit their own role).
7. Create `config/app` from Settings in the portal (UGC on/off, content updates on/off).
8. Enable PITR / scheduled backups (see DATA_RETENTION.md) and Cloud Billing budget alerts.
9. Restrict the Firebase API key in Google Cloud (Identity Toolkit, Token Service, Cloud Firestore only) — see FIREBASE_SECURITY_0.5.md for the JS-SDK caveats.
10. Strongly recommended: enable **App Check** (Play Integrity) for Firestore once a native App Check provider is added; not configured in this release.

## Community words (0.8.3): suggestions that go live instantly

- In the app, **Suggest a word** (Words tab banner, Decode tab, You tab, and "not found" searches) publishes the word to `communityWords/{id}` **immediately**. It appears in everyone's Words list and decoder within about 10 minutes (on the author's phone, instantly), labelled **Community**.
- Requirements enforced by Firestore rules: signed in, **verified e-mail**, active (not suspended) account, at most one submission per 60 s, word/meaning/example within limits, a valid category, **no links, e-mail addresses or phone numbers**, one document per word (no duplicates, no overwriting), kill switch on.
- The app also refuses words already in the dictionary, and sends words caught by its word filter (slurs, sexual content, self-harm phrases) to **Moderation → Word suggestions** instead of publishing them.
- **Moderation → Community words**: Live / Hidden lists with **Hide** and **Restore** (Super Admin, Content Manager, Moderator). Every action is written to the audit log in the same batch. Apps drop hidden words on their next refresh.
- **Settings → "Publish suggested words instantly"**: untick to send every new word to review instead. "Accept word suggestions and reports" remains the master kill switch.
- Reports on community words arrive in **Content reports** with the word's ID (`c-…`); hide it from the Community words list.
- Account deletion scrubs that person's words (text and UID removed; `{id, status: 'removed'}` remains so every app removes the word).
- Hidden words keep their text in the database (so they can be restored) and stay readable through the API; deletion of a contributor's account removes the text.

## Community chat (0.9.0): one room for everyone

- In the app, the **Community** tab opens a single chat room. Anyone can read live messages; only signed-in users with a **verified e-mail** and an active account can post, by nickname (max 24 characters), one message per 10 s. Messages are capped at 500 characters, **no links, e-mail addresses or phone numbers**.
- Before sending, the app screens each message (sexual content, abuse, hate, threats, self-harm phrases — including leet-speak) and refuses it with a reason. The server rules re-check length, links and the rate limit, so a tampered client cannot flood the room. A client-side filter can be bypassed, so reports and moderator hiding are the backstop.
- Reports on a chat message arrive in **Moderation → Chat reports** (same reasons as content reports). **Moderation → Community chat** lists live/hidden messages with **Hide** and **Restore** (Super Admin, Content Manager, Moderator). Every action is written to the audit log in the same batch (`chat.hide`, `chat.restore`, `chat.report.resolve`, `chat.report.dismiss`). Hiding removes the message from the room immediately.
- **Settings → \"Community chat is open\"**: untick to close the room (posting is refused; reading still works). **Dashboard → Reports & feedback** shows open chat reports.
- Account deletion scrubs that person's messages (text and nickname removed; `{status: 'removed'}` remains) and deletes their chat reports. Users can delete their own messages in the app. Moderators hide messages instead of deleting them; the rules also let a Super Admin delete a message outright (for illegal content), but the portal has no delete button for it.
- Free-tier cost (Spark plan): one room open costs at most 50 reads, then one read per new message; one write + one rate-limit stamp per message. No Cloud Functions are used.

## Ads (0.9.0): one banner, Suggest a word only

- Google AdMob banner (ad unit `ca-app-pub-9776667186789824/5427038644`) is shown only at the bottom of the **Suggest a word** sheet, Android only, non-personalised. App ID `ca-app-pub-9776667186789824~9376759074` is in `app.json` (config plugin + `react-native-google-mobile-ads` key) and in `android/app/src/main/AndroidManifest.xml` (the CI build does not run `expo prebuild`, so the manifest entry is what the shipped APK/AAB uses).
- No interstitial is configured yet: `INTERSTITIAL_AD_UNIT_ID` in `src/ads.tsx` is empty, so nothing is loaded or shown. To add one later, create an interstitial ad unit in AdMob and paste its ID there.
- While developing, Google's test banner is served instead of the real one. Never tap a real ad in a debug build.
- The privacy policy (`admin/site/privacy.html`) and the in-app Threat Shield screen disclose the banner and the advertising ID. The Play Console **Data safety** section must be updated by hand (ads + advertising ID collection) before the 0.9.0 release.

## Roles

| Role | Can |
|---|---|
| Super Admin | Everything, including roles, settings, audit and security logs, account deletion processing |
| Content Manager | Create/edit/import/export content, submit for review, publish/archive/roll back, review suggestions, moderate reports |
| Moderator | Read content, review suggestions, moderate reports, read accounts (no e-mail), suspend/reactivate |
| Support Admin | Read accounts incl. e-mail and learning history, support notes, suspend/reactivate, process deletion requests, triage feedback |
| Analyst | Dashboard aggregates, read content, export content, read feedback. No e-mail or learning data |

## What is enforced on the server (rules) vs. done in the console

| Action | Where |
|---|---|
| Role checks, MFA requirement, field validation, ownership | Firestore rules |
| Audit entry for every privileged write (same batch, same actor/target/time) | Firestore rules (`audited()`) |
| Publish only after review; public copy written in the same batch; history immutable | Firestore rules |
| Rate limits: sync writes ≥2 s, activity ≥20 s, submissions ≥60 s, security events ≥10 s | Firestore rules |
| Suspend (blocks sync + submissions) | Portal → rules |
| **Disable sign-in** for a suspended user | Firebase Console → Authentication (no Cloud Functions in this release) |
| **Delete the Authentication account** after processing a deletion request | Firebase Console → Authentication |

Optional upgrade: a small Cloud Functions codebase (Blaze plan) could disable/delete Auth users from the portal and compute nightly aggregate stats; intentionally not added because it requires a paid plan and an owner decision.

## Operations checklist

- Weekly: review Security events (admin_access_denied, sync_permission_denied spikes) and open reports.
- Monthly: purge deletion tombstones whose Auth account is gone; apply the retention periods in DATA_RETENTION.md.
- Each release: `npm run security:scan`, `npm audit --omit=dev`, `npm run test:rules`, and build with `--clear`.
