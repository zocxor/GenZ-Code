import {MotionConfig, motion, useReducedMotion} from 'motion/react';
import React, {createContext, useContext, useEffect, useState} from 'react';
import {onAuthStateChanged, signInWithEmailAndPassword, signOut, getMultiFactorResolver, TotpMultiFactorGenerator, TotpSecret, multiFactor, sendEmailVerification, reload, User, MultiFactorResolver, MultiFactorError} from 'firebase/auth';
import {doc, getDoc, getCount, collection, query, where, serverTimestamp, Timestamp} from 'firebase/firestore/lite';
import QRCode from 'qrcode';
import {auth, db, addAudit, newBatch, armIdleTimeout, errorMessage} from './firebase';
import {Role, ROLE_LABELS, can, isRole, Permission} from './rbac';
import {Notice, Field} from './ui';
import {BYLINE, RIGHTS, copyright} from '../../shared/brand';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Content from './pages/Content';
import Moderation from './pages/Moderation';
import Verification from './pages/Verification';
import Logs from './pages/Logs';
import Admins from './pages/Admins';
import Settings from './pages/Settings';

export type AdminSession = {user: User; uid: string; email: string; role: Role};
const SessionCtx = createContext<AdminSession | null>(null);
export const useSession = () => {const s = useContext(SessionCtx); if (!s) throw new Error('No admin session'); return s;};

/** Display version: the first public release. Keep at 1.0.0 until Kashif says
    to move to the next version. Twin: app.json version (the app footer, APK
    and AAB all show the same string). */
const PORTAL_VERSION = '1.0.0';

type Gate = {phase: 'loading'} | {phase: 'signed-out'} | {phase: 'denied'; reason: string} | {phase: 'verify'; user: User} | {phase: 'enroll'; user: User; role: Role} | {phase: 'ready'; session: AdminSession};

/** Two-step verification is required only when the owner sets config/security.adminMfaRequired (rules enforce the same). */
async function mfaRequired(): Promise<boolean> {
  try {const d = await getDoc(doc(db, 'config', 'security')); return d.exists() && d.data().adminMfaRequired === true;} catch {return true;}
}

const PAGES: {id: string; label: string; title: string; desc: string; perm: Permission; el: () => React.ReactElement}[] = [
  {id: 'dashboard', label: 'Dashboard', title: 'Dashboard', desc: 'Real-time insights, user engagement and learning performance.', perm: 'dashboard.read', el: () => <Dashboard />},
  {id: 'users', label: 'Users', title: 'Users', desc: 'Manage app users, view activity and account status.', perm: 'users.read', el: () => <Users />},
  {id: 'content', label: 'Content', title: 'Content', desc: 'Manage words, meanings, categories and learning content.', perm: 'content.read', el: () => <Content />},
  {id: 'moderation', label: 'Moderation', title: 'Moderation', desc: 'Review and manage user-generated content, reports and flags.', perm: 'reports.moderate', el: () => <Moderation />},
  {id: 'verification', label: 'Verification', title: 'Verification', desc: 'Review Verified Contributor applications (5,000-token fee) and revoke badges.', perm: 'reports.moderate', el: () => <Verification />},
  {id: 'feedback', label: 'Feedback', title: 'Feedback', desc: 'View user feedback, suggestions and issues.', perm: 'feedback.read', el: () => <Moderation feedbackOnly />},
  {id: 'logs', label: 'Audit & security', title: 'Audit & security', desc: 'Monitor system activity, login history and security events.', perm: 'audit.read', el: () => <Logs />},
  {id: 'admins', label: 'Admins & roles', title: 'Admins & roles', desc: 'Manage administrators, roles and access permissions.', perm: 'admins.manage', el: () => <Admins />},
  {id: 'settings', label: 'Settings', title: 'Settings', desc: 'Configure app, system and admin preferences.', perm: 'dashboard.read', el: () => <Settings />},
];

async function logDenied(user: User) {
  try {
    const b = newBatch();
    b.set(doc(db, 'users', user.uid, 'limits', 'sec'), {last: serverTimestamp()});
    b.set(doc(collection(db, 'securityEvents')), {uid: user.uid, type: 'admin_access_denied', detail: 'portal', platform: 'web', appVersion: 'admin-0.8.0', at: serverTimestamp(), expireAt: Timestamp.fromMillis(Date.now() + 90 * 86400_000)});
    await b.commit();
  } catch {/* best effort */}
}

export default function App() {
  const [gate, setGate] = useState<Gate>({phase: 'loading'});
  useEffect(() => onAuthStateChanged(auth, async user => {
    if (!user) {setGate({phase: 'signed-out'}); return;}
    try {
      const snap = await getDoc(doc(db, 'admins', user.uid));
      const data = snap.exists() ? snap.data() : null;
      if (!data || data.active !== true || !isRole(data.role)) {
        await logDenied(user);
        await signOut(auth);
        setGate({phase: 'denied', reason: 'This account is not an active GenZ Codebook administrator. The attempt was recorded.'});
        return;
      }
      await reload(user);
      if (!user.emailVerified) {setGate({phase: 'verify', user}); return;}
      const token = await user.getIdTokenResult(true);
      if (!token.signInSecondFactor && await mfaRequired()) {setGate({phase: 'enroll', user, role: data.role}); return;}
      const b = newBatch();
      addAudit(b, user.uid, data.role, 'admin.login', `admins/${user.uid}`, token.signInSecondFactor ? 'portal sign-in (password + authenticator)' : 'portal sign-in (password)');
      await b.commit().catch(() => {});
      setGate({phase: 'ready', session: {user, uid: user.uid, email: user.email ?? '', role: data.role}});
    } catch (e) {
      await signOut(auth);
      setGate({phase: 'denied', reason: errorMessage(e)});
    }
  }), []);
  useEffect(() => (gate.phase === 'ready' ? armIdleTimeout(() => setGate({phase: 'denied', reason: 'Signed out after 30 minutes of inactivity.'})) : undefined), [gate.phase]);

  if (gate.phase === 'loading') return <div className="center-screen"><p className="muted">Checking session…</p></div>;
  if (gate.phase === 'signed-out' || gate.phase === 'denied') return <SignIn notice={gate.phase === 'denied' ? gate.reason : ''} />;
  if (gate.phase === 'enroll') return <EnrollMfa user={gate.user} role={gate.role} />;
  if (gate.phase === 'verify') return <VerifyEmail user={gate.user} />;
  return <SessionCtx.Provider value={gate.session}><MotionConfig reducedMotion="user"><Shell /></MotionConfig></SessionCtx.Provider>;
}

/** Inline section icons (stroke SVGs, no dependency, no external assets). */
const ICONS: Record<string, React.ReactNode> = {
  dashboard: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>,
  users: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="9" cy="8" r="3.5" /><path d="M3.5 19c.6-3 2.8-4.5 5.5-4.5s4.9 1.5 5.5 4.5" /><circle cx="17" cy="9" r="2.6" /><path d="M16.2 14.6c2.2.3 3.8 1.7 4.3 4" /></svg>,
  content: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 6C10.5 4.5 8 4 4 4v14c4 0 6.5.5 8 2 1.5-1.5 4-2 8-2V4c-4 0-6.5.5-8 2Z" /><path d="M12 6v14" /></svg>,
  moderation: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M5 21V4" /><path d="M5 4h13l-2.5 4L18 12H5" /></svg>,
  verification: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3 5 6v5c0 5 3 8.5 7 10 4-1.5 7-5 7-10V6Z" /><path d="m9 12 2 2 4-4" /></svg>,
  feedback: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.5 8.5 0 0 1-12.4 7.5L3 21l2-5.6A8.5 8.5 0 1 1 21 11.5Z" /></svg>,
  logs: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3 5 6v5c0 5 3 8.5 7 10 4-1.5 7-5 7-10V6Z" /><path d="m9 12 2 2 4-4" /></svg>,
  admins: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="15" r="4" /><path d="m11 12 8-8" /><path d="M17 5l2.5 2.5" /><path d="M14 8l2 2" /></svg>,
  settings: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1" /></svg>,
};

function Shell() {
  const s = useSession();
  const reduced = useReducedMotion();
  const allowed = PAGES.filter(p => can(s.role, p.perm));
  const [page, setPage] = useState(() => allowed.find(p => p.id === location.hash.slice(1))?.id ?? allowed[0]!.id);
  /** Pending word suggestions, shown as a badge on the Moderation nav item
      and on the header bell. Only for roles that review submissions;
      refreshes on page change and every minute, so a new suggestion is
      noticed without a reload. The Dashboard already shows the same number
      as its "Pending suggestions" stat. */
  const [pending, setPending] = useState<number | null>(null);
  const [q, setQ] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [sectionsOpen, setSectionsOpen] = useState(false);
  const menuRef = React.useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!can(s.role, 'submissions.review')) return;
    let alive = true;
    const load = () => {void getCount(query(collection(db, 'submissions'), where('status', '==', 'pending'))).then(r => {if (alive) setPending(r.data().count);}).catch(() => {if (alive) setPending(null);});};
    load();
    const t = setInterval(load, 60_000);
    return () => {alive = false; clearInterval(t);};
  }, [s.role, page]);
  /** Pending verification applications on the Verification nav item. Same 60s
      refresh as the Moderation badge, gated by the moderator perm. */
  const [pendingVerifications, setPendingVerifications] = useState<number | null>(null);
  useEffect(() => {
    if (!can(s.role, 'reports.moderate')) return;
    let alive = true;
    const load = () => {void getCount(query(collection(db, 'verificationApplications'), where('status', '==', 'pending'))).then(r => {if (alive) setPendingVerifications(r.data().count);}).catch(() => {if (alive) setPendingVerifications(null);});};
    load();
    const t = setInterval(load, 60_000);
    return () => {alive = false; clearInterval(t);};
  }, [s.role, page]);
  useEffect(() => {const f = () => {const id = location.hash.slice(1); if (allowed.some(p => p.id === id)) setPage(id);}; window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f);}, []);
  useEffect(() => {
    if (!menuOpen) return;
    const close = (e: MouseEvent) => {if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);};
    const escape = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      setMenuOpen(false);
      menuRef.current?.querySelector('button')?.focus();
    };
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', escape);
    return () => {document.removeEventListener('mousedown', close); document.removeEventListener('keydown', escape);};
  }, [menuOpen]);
  const current = allowed.find(p => p.id === page) ?? allowed[0]!;
  const go = (id: string) => {location.hash = `#${id}`; setPage(id); setMenuOpen(false); setSectionsOpen(false);};
  /** Header quick search: hands the query to the Users page, which runs it
      (by e-mail prefix or user ID) on mount and then clears it. Only shown
      to roles that can read users. */
  const quickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const v = q.trim();
    if (!v) return;
    try {sessionStorage.setItem('adminQuickSearch', v);} catch {}
    setQ('');
    go('users');
  };
  const showSearch = can(s.role, 'users.read');
  const showBell = can(s.role, 'submissions.review') || can(s.role, 'reports.moderate');
  const initials = (s.email.split('@')[0] ?? 'A').slice(0, 1).toUpperCase();
  return <div className="layout">
    <aside className="side">
      <div className="side-heading">
        <div className="brand"><img src="/admin/icon-sidebar.png" alt="" width="42" height="42" /><div><strong>GenZ Codebook</strong><span>Admin portal</span></div></div>
        <button type="button" className="sections-toggle" aria-controls="portal-sections" aria-expanded={sectionsOpen} onClick={() => setSectionsOpen(open => !open)}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
          Sections
        </button>
      </div>
      <div className="ver"><span className="pill pill-info">v{PORTAL_VERSION}</span><span className="muted">Workspace</span></div>
      <nav id="portal-sections" aria-label="Sections" className={sectionsOpen ? 'sections-open' : undefined}>{allowed.map(p => <a key={p.id} href={`#${p.id}`} className={p.id === current.id ? 'active' : ''} aria-current={p.id === current.id ? 'page' : undefined} onClick={() => {setPage(p.id); setSectionsOpen(false);}}><span className="nav-ico" aria-hidden="true">{ICONS[p.id]}</span>{p.label}{p.id === 'moderation' && pending !== null && pending > 0 ? <span className="nav-badge" aria-label={`${pending} pending word suggestions`}>{pending > 99 ? '99+' : pending}</span> : null}{p.id === 'verification' && pendingVerifications !== null && pendingVerifications > 0 ? <span className="nav-badge" aria-label={`${pendingVerifications} pending verification applications`}>{pendingVerifications > 99 ? '99+' : pendingVerifications}</span> : null}</a>)}</nav>
      <div className="whoami"><span className="muted">{s.email}</span><span className="pill pill-info">{ROLE_LABELS[s.role]}</span><button className="btn ghost" onClick={() => void signOut(auth)}>Sign out</button></div>
      <p className="copyright">{BYLINE}<br />{copyright()}. {RIGHTS}</p>
    </aside>
    <main className="main" id="main">
      <header className="topbar">
        <div className="topbar-title"><h1>{current.title}</h1><p>{current.desc}</p></div>
        {showSearch && <form className="topbar-search" onSubmit={quickSearch} role="search">
          <input aria-label="Search users" placeholder="Search users by e-mail or ID…" value={q} onChange={e => setQ(e.target.value)} maxLength={254} />
          <button className="btn" type="submit">Search</button>
        </form>}
        {showBell && <button className="icon-btn-top" aria-label={pending ? `${pending} pending word suggestions — open Moderation` : 'No pending word suggestions — open Moderation'} onClick={() => go('moderation')}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" /></svg>
          {pending !== null && pending > 0 ? <span className="top-badge">{pending > 99 ? '99+' : pending}</span> : null}
        </button>}
        <div className="profile-menu" ref={menuRef}>
          <button className="profile-btn" aria-label={`Account options for ${s.email}`} aria-expanded={menuOpen} onClick={() => setMenuOpen(o => !o)}>
            <span className="avatar" aria-hidden="true">{initials}</span>
            <span className="who"><strong>{s.email}</strong><span>{ROLE_LABELS[s.role]}</span></span>
            <span aria-hidden="true">▾</span>
          </button>
          {menuOpen && <div className="menu">
            <div className="menu-head"><strong>{s.email}</strong><span>{ROLE_LABELS[s.role]}</span></div>
            <a href="#settings" onClick={e => {e.preventDefault(); go('settings');}}>Settings</a>
            {can(s.role, 'audit.read') && <a href="#logs" onClick={e => {e.preventDefault(); go('logs');}}>Audit &amp; security</a>}
            <button className="danger" onClick={() => void signOut(auth)}>Sign out</button>
          </div>}
        </div>
      </header>
      <motion.div key={current.id} className="content" initial={reduced ? false : {opacity: .85}} animate={{opacity: 1}} transition={{duration: reduced ? 0 : .18}}>{current.el()}</motion.div>
    </main>
  </div>;
}

function SignIn({notice}: {notice: string}) {
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [code, setCode] = useState('');
  const [resolver, setResolver] = useState<MultiFactorResolver | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      if (resolver) {
        const hint = resolver.hints.find(h => h.factorId === TotpMultiFactorGenerator.FACTOR_ID);
        if (!hint) throw new Error('No authenticator app is enrolled for this account.');
        await resolver.resolveSignIn(TotpMultiFactorGenerator.assertionForSignIn(hint.uid, code.trim()));
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (err) {
      const c = (err as {code?: string}).code;
      if (c === 'auth/multi-factor-auth-required') {setResolver(getMultiFactorResolver(auth, err as MultiFactorError)); setPassword('');}
      else if (c === 'auth/invalid-verification-code') setError('That code is not valid. Check your authenticator app and try again.');
      else if (c === 'auth/too-many-requests') setError('Too many attempts. Wait a few minutes before trying again.');
      else if (c === 'auth/invalid-credential' || c === 'auth/wrong-password' || c === 'auth/user-not-found') setError('The email or password is incorrect.');
      else setError(err instanceof Error && !c ? err.message : 'Sign-in failed. Please try again.');
    } finally {setBusy(false); setCode('');}
  };
  return <div className="center-screen">
    <div className="auth-layout">
      <section className="auth-intro" aria-labelledby="admin-brand-title">
        <img src="/admin/icon-128.png" alt="" width="68" height="68" />
        <span className="eyebrow">ADMIN PORTAL</span>
        <h2 id="admin-brand-title">GenZ Codebook</h2>
        <p>Manage the dictionary, review community activity, and see how people use the app.</p>
      </section>
      <form className="card auth" onSubmit={submit}>
      <h1>{resolver ? 'Two-step verification' : 'Staff sign-in'}</h1>
      <p className="auth-caption">{resolver ? 'Enter the current code from your authenticator app.' : 'Use your verified staff account to open the portal.'}</p>
      {notice && <Notice kind="info">{notice}</Notice>}
      {error && <Notice kind="error">{error}</Notice>}
      {resolver ? <Field label="6-digit code from your authenticator app"><input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} autoFocus required /></Field> : <>
        <Field label="Email"><input type="email" autoComplete="username" value={email} onChange={e => setEmail(e.target.value)} required maxLength={254} /></Field>
        <Field label="Password"><input type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} required maxLength={4096} /></Field>
      </>}
      <button className="btn primary" disabled={busy}>{busy ? 'Please wait…' : resolver ? 'Verify' : 'Sign in'}</button>
      {resolver && <button type="button" className="link" onClick={() => {setResolver(null); setCode('');}}>Use a different account</button>}
      <p className="muted small">Access requires an administrator role and a verified e-mail (plus an authenticator app if two-step verification is switched on). Sessions end when you close this tab or after 30 minutes of inactivity. All administrative actions are logged.</p>
      <p className="copyright">{BYLINE} · {copyright()}. {RIGHTS}</p>
      </form>
    </div>
  </div>;
}

function VerifyEmail({user}: {user: User}) {
  const [info, setInfo] = useState(''), [busy, setBusy] = useState(false);
  const send = async () => {setBusy(true); try {await sendEmailVerification(user); setInfo(`Verification link sent to ${user.email}. Open it, then click “I’ve verified”.`);} catch {setInfo('Couldn’t send the e-mail right now. Wait a minute and try again.');} finally {setBusy(false);}};
  return <div className="center-screen"><div className="card auth">
    <h1>Verify your e-mail</h1>
    <p className="muted">Administrator access needs a verified e-mail address. The server enforces this.</p>
    {info && <Notice kind="info">{info}</Notice>}
    <button className="btn primary" disabled={busy} onClick={() => void send()}>Send verification e-mail</button>
    <button className="btn" onClick={() => location.reload()}>I’ve verified</button>
    <button className="btn ghost" onClick={() => void signOut(auth)}>Sign out</button>
  </div></div>;
}

function EnrollMfa({user, role}: {user: User; role: Role}) {
  const [secret, setSecret] = useState<TotpSecret | null>(null), [qr, setQr] = useState(''), [code, setCode] = useState('');
  const [error, setError] = useState(''), [info, setInfo] = useState(''), [busy, setBusy] = useState(false);
  const start = async () => {
    setBusy(true); setError('');
    try {
      await reload(user);
      if (!user.emailVerified) {await sendEmailVerification(user); setInfo('Verify your email first: we sent a link. Then reload this page and sign in again.'); return;}
      const s = await TotpMultiFactorGenerator.generateSecret(await multiFactor(user).getSession());
      setSecret(s);
      setQr(await QRCode.toDataURL(s.generateQrCodeUrl(user.email ?? 'admin', 'GenZ Codebook Admin'), {margin: 1, width: 220}));
    } catch (e) {
      const c = (e as {code?: string}).code;
      setError(c === 'auth/operation-not-allowed' ? 'TOTP multi-factor authentication is not enabled for this Firebase project (Identity Platform). See docs/ADMIN_PORTAL.md.' : c === 'auth/requires-recent-login' ? 'Sign in again, then enrol.' : 'Could not start enrolment.');
    } finally {setBusy(false);}
  };
  const finish = async () => {
    if (!secret) return;
    setBusy(true); setError('');
    try {
      await multiFactor(user).enroll(TotpMultiFactorGenerator.assertionForEnrollment(secret, code.trim()), 'Authenticator app');
      await signOut(auth);
    } catch {setError('That code did not verify. Check the time on your device and try again.');} finally {setBusy(false);}
  };
  return <div className="center-screen"><div className="card auth">
    <h1>Set up two-step verification</h1>
    <p className="muted">Your {ROLE_LABELS[role]} role requires an authenticator app before any admin data can be accessed. The server enforces this: without a second factor every admin request is refused.</p>
    {info && <Notice kind="info">{info}</Notice>}
    {error && <Notice kind="error">{error}</Notice>}
    {!secret ? <button className="btn primary" disabled={busy} onClick={() => void start()}>Start setup</button> : <>
      {qr && <img src={qr} alt="QR code for your authenticator app" width={220} height={220} className="qr" />}
      <p className="small muted">Can’t scan? Enter this key manually: <code className="secret">{secret.secretKey}</code></p>
      <Field label="Enter the 6-digit code"><input inputMode="numeric" maxLength={6} value={code} onChange={e => setCode(e.target.value.replace(/\D/g, ''))} /></Field>
      <button className="btn primary" disabled={busy || code.length !== 6} onClick={() => void finish()}>Verify and finish</button>
      <p className="small muted">After enrolment you’ll be signed out. Sign in again with your password and a code.</p>
    </>}
    <button className="btn ghost" onClick={() => void signOut(auth)}>Cancel and sign out</button>
  </div></div>;
}
