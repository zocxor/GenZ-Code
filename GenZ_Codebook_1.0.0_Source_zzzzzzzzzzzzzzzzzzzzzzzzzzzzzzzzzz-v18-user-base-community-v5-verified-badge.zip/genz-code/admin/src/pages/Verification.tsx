import React, {useEffect, useMemo, useRef, useState} from 'react';
import {collection, query, where, orderBy, limit, getDocs, doc, getDoc, serverTimestamp} from 'firebase/firestore/lite';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can} from '../rbac';
import {Card, Stats, Stat, Skeleton, Notice, Pill, ConfirmButton, useLoad, when, fmt} from '../ui';

type VerificationRow = {
  id: string; uid: string; status: 'pending' | 'approved' | 'rejected'; tokensPaid: number;
  createdAt: {toMillis(): number}; updatedAt: {toMillis(): number};
  decidedAt: {toMillis(): number} | null; decidedBy: string | null;
};
const listByStatus = async (status: string) => (await getDocs(query(collection(db, 'verificationApplications'), where('status', '==', status), orderBy('createdAt', 'desc'), limit(100)))).docs.map(d => ({id: d.id, ...d.data()}) as VerificationRow);

type Identity = {name: string | null; email: string | null};
/** Resolve applicant UIDs to their nickname (synced profile name) and e-mail.
    Same pattern as Moderation's useIdentities: the rules gate directory +
    sync/profile to PII roles, so roles without users.pii never attempt the
    reads and keep the UID fallback. Each UID is fetched once and cached. */
function useIdentities(uids: string[], canSeePii: boolean) {
  const [map, setMap] = useState<Record<string, Identity>>({});
  const requested = useRef<Set<string>>(new Set());
  const key = useMemo(() => [...new Set(uids)].sort().join('|'), [uids]);
  useEffect(() => {
    if (!canSeePii) return;
    const missing = [...new Set(uids)].filter(u => u && !requested.current.has(u));
    if (!missing.length) return;
    for (const u of missing) requested.current.add(u);
    void Promise.all(missing.map(async u => {
      try {
        const [dir, prof] = await Promise.all([getDoc(doc(db, 'directory', u)), getDoc(doc(db, 'users', u, 'sync', 'profile'))]);
        const email = dir.exists() ? String((dir.data() as {email?: unknown}).email ?? '') : '';
        const name = prof.exists() ? String(((prof.data() as {profile?: {name?: unknown}}).profile?.name ?? '')) : '';
        return [u, {name: name || null, email: email || null}] as const;
      } catch {return [u, {name: null, email: null}] as const;}
    })).then(entries => setMap(m => ({...m, ...Object.fromEntries(entries)})));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, canSeePii]);
  return map;
}

/** Shield-check icon (20px, same stroke style as the Moderation stat icons). */
const statIcoProps = {width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round'} as const;
const icoShield = <svg {...statIcoProps}><path d="M12 3 5 6v5c0 5 3 8.5 7 10 4-1.5 7-5 7-10V6Z" /><path d="m9 12 2 2 4-4" /></svg>;

/** Verified Contributor applications: a 5,000-token fee, manual review, and
 *  an audited approve / reject / revoke. The badge itself is a server-side
 *  fact (rules-enforced) — the portal only records the decision, it never
 *  trusts the client. The fee is not refunded on rejection, and a revoked
 *  user can apply again (paying the fee again). */
export default function Verification() {
  const s = useSession();
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null);
  const [busy, setBusy] = useState(false);
  const pending = useLoad(() => listByStatus('pending'), []);
  const decided = useLoad(async () => {
    const [approved, rejected] = await Promise.all([listByStatus('approved'), listByStatus('rejected')]);
    return [...approved, ...rejected].sort((a, b) => b.createdAt.toMillis() - a.createdAt.toMillis());
  }, []);
  const allUids = useMemo(() => [...new Set([...(pending.data ?? []), ...(decided.data ?? [])].map(x => x.uid))], [pending.data, decided.data]);
  const identities = useIdentities(allUids, can(s.role, 'users.pii'));
  const approvedCount = (decided.data ?? []).filter(x => x.status === 'approved').length;
  const rejectedCount = (decided.data ?? []).filter(x => x.status === 'rejected').length;

  /** Name (bold) + e-mail (small) for the applicant; the truncated UID only when
      neither resolves (or the role may not read PII). Full UID on hover. */
  const byCell = (uid: string) => {
    const id = identities[uid];
    if (id?.name) return <span title={uid}><strong>{id.name}</strong>{id.email ? <><br /><span className="muted small">{id.email}</span></> : null}</span>;
    if (id?.email) return <span title={uid}><strong>{id.email}</strong></span>;
    return <code title={uid}>{uid.slice(0, 8)}…</code>;
  };
  const viewUser = (uid: string) => {
    try {sessionStorage.setItem('adminQuickSearch', uid);} catch {}
    location.hash = '#users';
  };
  const run = async (fn: () => Promise<void>, ok: string, reload: () => void) => {
    setBusy(true); setMsg(null);
    try {await fn(); setMsg({kind: 'ok', text: ok}); reload();}
    catch (e) {setMsg({kind: 'error', text: errorMessage(e)});}
    finally {setBusy(false);}
  };
  const reloadAll = () => {pending.reload(); decided.reload();};
  /** One audited batch: the decision + the audit entry. The rules require
      the audit entry in the same batch (lastAuditId) or the write fails. */
  const decide = (x: VerificationRow, status: 'approved' | 'rejected', action: 'verification.approve' | 'verification.reject' | 'verification.revoke', ok: string) => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, action, `verificationApplications/${x.uid}`, `${x.uid}: ${status}`);
    b.update(doc(db, 'verificationApplications', x.uid), {status, updatedAt: serverTimestamp(), decidedAt: serverTimestamp(), decidedBy: s.uid, lastAuditId});
    await b.commit();
  }, ok, reloadAll);
  const approve = (x: VerificationRow) => void decide(x, 'approved', 'verification.approve', 'Application approved — the user now has the verified shield.');
  const reject = (x: VerificationRow) => void decide(x, 'rejected', 'verification.reject', 'Application rejected. The 5,000-token fee is not refunded.');
  const revoke = (x: VerificationRow) => void decide(x, 'rejected', 'verification.revoke', 'Verification revoked. The user can apply again (paying the fee again).');

  return <div className="stack">
    <Stats>
      <Stat label="Pending applications" num={pending.data?.length ?? null} icon={icoShield} tint="blue" />
      <Stat label="Verified" num={approvedCount} icon={icoShield} tint="purple" />
      <Stat label="Rejected" num={rejectedCount} icon={icoShield} tint="amber" />
    </Stats>
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    <Card title="Pending applications" subtitle={`${fmt(pending.data?.length)} pending (newest 100). The fee is 5,000 tokens, paid on application and not refunded on rejection.`}>
      {pending.error ? <Notice kind="error">{errorMessage(pending.error)}</Notice> : pending.data?.length ? <div className="table-wrap"><table><thead><tr><th>Applicant</th><th>Applied</th><th>Fee paid</th><th /></tr></thead><tbody>{pending.data.map(x => <tr key={x.id}><td>{byCell(x.uid)}<br /><button className="btn ghost" onClick={() => viewUser(x.uid)}>View user</button></td><td>{when(x.createdAt)}</td><td>{fmt(x.tokensPaid)} tokens</td><td className="row"><button className="btn" disabled={busy} onClick={() => approve(x)}>Approve</button><button className="btn ghost" disabled={busy} onClick={() => reject(x)}>Reject</button></td></tr>)}</tbody></table></div> : <p className="muted">{pending.loading ? 'Loading…' : 'No pending applications.'}</p>}
    </Card>
    <Card title="Decided" subtitle={`${fmt(decided.data?.length)} decided (newest 100). Revoking an approval sets the application back to rejected; the user can apply again.`}>
      {decided.error ? <Notice kind="error">{errorMessage(decided.error)}</Notice> : decided.data?.length ? <div className="table-wrap"><table><thead><tr><th>Applicant</th><th>Decision</th><th>Decided by</th><th>Decided</th><th /></tr></thead><tbody>{decided.data.map(x => <tr key={x.id}><td>{byCell(x.uid)}<br /><button className="btn ghost" onClick={() => viewUser(x.uid)}>View user</button></td><td><Pill tone={x.status === 'approved' ? 'good' : 'bad'}>{x.status === 'approved' ? 'Approved' : 'Rejected'}</Pill></td><td>{x.decidedBy ? <code title={x.decidedBy}>{x.decidedBy.slice(0, 8)}…</code> : <span className="muted">—</span>}</td><td>{x.decidedAt ? when(x.decidedAt) : <span className="muted">—</span>}</td><td>{x.status === 'approved' && <ConfirmButton label="Revoke" word="REVOKE" disabled={busy} onConfirm={() => revoke(x)} />}</td></tr>)}</tbody></table></div> : <p className="muted">{decided.loading ? 'Loading…' : 'No decided applications yet.'}</p>}
    </Card>
  </div>;
}
