/**
 * Verified Contributor Badge — client data layer.
 *
 * The badge is a server-side fact, never a client claim: the application
 * lives in Firestore (`verificationApplications/{uid}`) and only a moderator
 * (via the admin portal, audited) can set status to 'approved'. The client
 * can never approve itself — the rules reject any owner write that sets
 * status to anything but 'pending'.
 *
 * Token split (be honest about it): the token balance is DEVICE-LOCAL
 * (earned tokens live in the learning state; only purchased tokens sync
 * via the Firestore ledger). So the 5,000-token fee is deducted on the
 * device via spendTokens, exactly like the 25-token post fee — but ONLY
 * after applyForVerification() returns ok, i.e. only after the Firestore
 * application write succeeded. Never before, never twice. The server-side
 * record of the fee is the application doc itself (tokensPaid: 5000),
 * enforced by the rules. There is no Cloud Function and no user-doc
 * verified flag — the application document is the source of truth.
 */
import {TOKENS} from '../shared/tokens';

export type VerificationStatus = 'none' | 'pending' | 'approved' | 'rejected';
export type VerificationApplication = {
  uid: string; status: 'pending' | 'approved' | 'rejected'; tokensPaid: number;
  createdAtMs: number; updatedAtMs: number; decidedAtMs: number | null; decidedBy: string | null;
};
export type VerificationResult = {ok: true} | {ok: false; message: string};
const fail = (message: string): VerificationResult => ({ok: false, message});

const libs = () => Promise.all([import('firebase/firestore/lite'), import('firebase/firestore'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

function errorText(e: unknown, CloudError: typeof import('./sync/engine').CloudError): string {
  if (e instanceof CloudError) {
    if (e.code === 'offline') return 'You’re offline. Connect to the internet and try again.';
    if (e.code === 'unauthenticated') return 'Your session expired. Sign in again, then try once more.';
    if (e.code === 'permission-denied') return 'The server didn’t accept that. If you just verified your e-mail, wait a minute and try again. (code: permission-denied)';
    if (e.code === 'server-setup') return 'The GenZ Codebook server isn’t set up yet: its security rules haven’t been published, so the database refuses every request. Publish the rules, then try again. (code: rules-missing)';
    return `Couldn’t send that right now. Please try again. (code: ${e.raw || e.code})`;
  }
  return 'Couldn’t send that right now. Please try again.';
}

const toMs = (v: unknown): number | null => {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'object' && v !== null && typeof (v as {toMillis?: unknown}).toMillis === 'function') {
    const ms = (v as {toMillis: () => number}).toMillis();
    return Number.isFinite(ms) ? ms : null;
  }
  return null;
};

export function toVerificationApplication(uid: string, data: unknown): VerificationApplication | null {
  if (typeof data !== 'object' || data === null) return null;
  const d = data as Record<string, unknown>;
  if (d.uid !== uid) return null;
  if (d.status !== 'pending' && d.status !== 'approved' && d.status !== 'rejected') return null;
  if (typeof d.tokensPaid !== 'number') return null;
  const createdAtMs = toMs(d.createdAt);
  const updatedAtMs = toMs(d.updatedAt);
  if (createdAtMs === null || updatedAtMs === null) return null;
  const decidedAtMs = d.decidedAt === null || d.decidedAt === undefined ? null : toMs(d.decidedAt);
  if (d.decidedAt !== null && d.decidedAt !== undefined && decidedAtMs === null) return null;
  const decidedBy = d.decidedBy === null || d.decidedBy === undefined ? null : typeof d.decidedBy === 'string' ? d.decidedBy : null;
  if (d.decidedBy !== null && d.decidedBy !== undefined && decidedBy === null) return null;
  return {uid, status: d.status, tokensPaid: d.tokensPaid, createdAtMs, updatedAtMs, decidedAtMs, decidedBy};
}

/** My application, or null when signed out, when there is none, or on error. */
export async function fetchMyVerification(): Promise<VerificationApplication | null> {
  try {
    const [{doc, getDoc}, , {cloudDb, accountAuth}] = await libs();
    const uid = accountAuth.currentUser?.uid;
    if (!uid) return null;
    const snap = await getDoc(doc(cloudDb(), 'verificationApplications', uid));
    if (!snap.exists()) return null;
    return toVerificationApplication(uid, snap.data());
  } catch {return null;}
}

/** Live subscription to my application (full-SDK onSnapshot, like subscribePosts). */
export function subscribeMyVerification(onChange: (app: VerificationApplication | null) => void, onError: (message: string) => void): () => void {
  let stop = () => {};
  void libs().then(([, live, {cloudDbLive, accountAuth}]) => {
    const uid = accountAuth.currentUser?.uid;
    if (!uid) {onChange(null); return;}
    const ref = live.doc(cloudDbLive(), 'verificationApplications', uid);
    stop = live.onSnapshot(ref, snap => {
      onChange(snap.exists() ? toVerificationApplication(uid, snap.data()) : null);
    }, () => onError('Couldn’t load your verification status. Check your connection and try again.'));
  }).catch(() => onError('Couldn’t load your verification status. Check your connection and try again.'));
  return () => stop();
}

/**
 * Apply for verification (or re-apply after a rejection). Returns ok only
 * when the Firestore write succeeded — the caller deducts the 5,000-token
 * fee after this returns ok, never inside this function, never twice.
 * A pending application or an existing approval is refused here so the
 * fee is never charged twice; the rules enforce the same server-side.
 */
export async function applyForVerification(): Promise<VerificationResult> {
  const [{doc, getDoc, setDoc, serverTimestamp}, , {cloudDb, accountAuth}, {toCloudError}, {CloudError}] = await libs();
  const user = accountAuth.currentUser;
  if (!user) return fail('Sign in to apply for verification.');
  try {
    const db = cloudDb();
    const ref = doc(db, 'verificationApplications', user.uid);
    const existing = await getDoc(ref);
    if (existing.exists()) {
      const current = toVerificationApplication(user.uid, existing.data());
      if (current?.status === 'pending') return fail('You already have a pending application.');
      if (current?.status === 'approved') return fail('You are already verified.');
      // 'rejected' (or an unreadable shape): re-apply below. setDoc replaces
      // the whole document, which clears the admin's decision (decidedAt,
      // decidedBy, lastAuditId) — the rules require exactly that.
    }
    await setDoc(ref, {uid: user.uid, status: 'pending', tokensPaid: TOKENS.VERIFICATION_FEE, createdAt: serverTimestamp(), updatedAt: serverTimestamp(), decidedAt: null, decidedBy: null});
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}

/** The UIDs in `uids` whose application is approved. Per-UID errors are swallowed (treated as not verified). */
export async function fetchVerifiedUids(uids: string[]): Promise<Set<string>> {
  const out = new Set<string>();
  const unique = [...new Set(uids.filter(Boolean))];
  if (!unique.length) return out;
  try {
    const [{doc, getDoc}, , {cloudDb}] = await libs();
    const db = cloudDb();
    const results = await Promise.all(unique.map(async uid => {
      try {
        const snap = await getDoc(doc(db, 'verificationApplications', uid));
        return snap.exists() && toVerificationApplication(uid, snap.data())?.status === 'approved' ? uid : null;
      } catch {return null;}
    }));
    for (const uid of results) if (uid) out.add(uid);
  } catch {/* no verified authors on error */}
  return out;
}
