// Community posts: validation, the 25-token price, and the wiring that ties
// the posts feature together (service, screen, rules). The posts themselves
// live in Firestore (communityPosts); the emulator rules tests cover the
// server-side checks, and these tests cover the pure parts that run locally.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {screenPost, toCommunityPost, POST_MAX_LENGTH, POST_RATE_LIMIT_SECONDS, POST_PAGE_SIZE} from '../shared/chat';
import {TOKENS} from '../shared/tokens';
import {emptyState} from '../src/profile';
import {earnTokens, spendTokens} from '../src/learning';

test('post filter: ordinary posts pass, empty and oversize posts are refused', () => {
  assert.deepEqual(screenPost('Hot take: “rizz” is just confidence with Wi-Fi.'), {ok: true});
  assert.deepEqual(screenPost('  hello everyone  '), {ok: true});
  assert.equal(screenPost('').ok, false);
  assert.equal(screenPost('   ').ok, false);
  assert.equal(screenPost('x'.repeat(POST_MAX_LENGTH + 1)).ok, false);
  assert.equal(screenPost('x'.repeat(POST_MAX_LENGTH)).ok, true);
  assert.equal(POST_MAX_LENGTH, 500);
  assert.equal(POST_RATE_LIMIT_SECONDS, 10);
  assert.equal(POST_PAGE_SIZE, 50);
});

test('post filter: sexual content, abuse, hate and threats are blocked, including leet-speak', () => {
  for (const bad of [
    'check out this porn link', 'you are a stupid slut', 'fuck you',
    'i hate you, nigger', 'you retard', 'send nudes pls',
    'kys', 'kill yourself', 'go die', 'i will kill you',
    'sh!t happens', 'b!tch please', 'sh1t happens', 'bhenchod', 'g4ndu',
  ]) {
    assert.equal(screenPost(bad).ok, false, bad);
  }
  assert.equal(screenPost('what does rizz mean?').ok, true);
  assert.equal(screenPost('that fit is fire, no cap').ok, true);
});

test('post filter: links, e-mail addresses and phone numbers are refused', () => {
  for (const bad of ['see https://x.example', 'visit www.spam.example', 'mail me@spam.io', 'call 0300 1234567']) {
    assert.equal(screenPost(bad).ok, false, bad);
  }
  assert.equal(screenPost('my number is 143').ok, true);
});

test('posts are validated before they are shown', () => {
  const at = {toMillis: () => 1780000000000};
  const good = {hidden: false, uid: 'u1', name: 'Aya', text: 'hi', likeCount: 3, createdAt: at};
  assert.deepEqual(toCommunityPost('p1', good), {id: 'p1', uid: 'u1', name: 'Aya', text: 'hi', at: 1780000000000, likeCount: 3});
  assert.equal(toCommunityPost('p1', {...good, hidden: true}), null, 'hidden posts never render');
  assert.equal(toCommunityPost('p1', {...good, likeCount: -1}), null, 'negative likeCount is invalid');
  assert.equal(toCommunityPost('p1', {...good, likeCount: 1.5}), null, 'fractional likeCount is invalid');
  assert.equal(toCommunityPost('p1', {...good, likeCount: '3'}), null, 'likeCount must be a number');
  assert.equal(toCommunityPost('p1', {...good, name: 'x'.repeat(25)}), null);
  assert.equal(toCommunityPost('p1', {...good, text: 'x'.repeat(POST_MAX_LENGTH + 1)}), null);
  assert.equal(toCommunityPost('p1', {...good, text: '   '}), null);
  assert.equal(toCommunityPost('p1', {...good, createdAt: undefined}), null, 'no timestamp, no post');
  assert.equal(toCommunityPost('p1', null), null);
});

test('posts: creating a post costs 25 tokens and deducts exactly that, once', () => {
  assert.equal(TOKENS.POST_COST, 25);
  const now = Date.now();
  const s = emptyState();
  const funded = earnTokens(25)(s, now);
  const afterOne = spendTokens(TOKENS.POST_COST)(funded, now);
  assert.equal(afterOne.tokens.balance, 0);
  // Insufficient balance (24 tokens): no deduction, state unchanged.
  const almost = earnTokens(24)(s, now);
  const blocked = spendTokens(TOKENS.POST_COST)(almost, now);
  assert.equal(blocked, almost);
  assert.equal(blocked.tokens.balance, 24);
  // Zero balance: no deduction, state unchanged.
  const broke = spendTokens(TOKENS.POST_COST)(s, now);
  assert.equal(broke, s);
  assert.equal(broke.tokens.balance, 0);
});

test('posts: the service, screen and rules are wired to the 25-token price', () => {
  const service = readFileSync('src/communityPosts.ts', 'utf8');
  assert.ok(service.includes('Creating a post costs 25 tokens (TOKENS.POST_COST)'), 'service header documents the 25-token price');
  assert.ok(!service.includes('spendTokens'), 'the service never deducts tokens itself — the screen deducts after acceptance');
  assert.ok(service.includes('runTransaction'), 'likes use a transaction so likeCount and the like document stay in sync');
  assert.ok(service.includes('communityPostLikes'), 'likes live in their own collection');
  assert.ok(service.includes('postReports'), 'post reports go to their own collection');
  assert.ok(service.includes('subscribePosts'), 'posts subscribe live, newest first');
  const screen = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.ok(screen.includes("useState<'chat' | 'posts'>"), 'Chat / Posts switcher state');
  assert.ok(screen.includes('label="Posts"'), 'Posts tab chip');
  assert.ok(screen.includes('label="Chat"'), 'Chat tab chip');
  assert.ok(screen.includes('${TOKENS.POST_COST} tokens'), 'compose button names the 25-token price');
  assert.ok(screen.includes('spendTokens(TOKENS.POST_COST)'), '25 tokens deducted only after the post is accepted');
  assert.ok(screen.includes('CHAT_MESSAGE_COST'), 'chat still costs 1 token a message');
  const rules = readFileSync('firebase/firestore.rules', 'utf8');
  assert.ok(rules.includes('match /communityPosts/{id}'), 'posts collection rules');
  assert.ok(rules.includes('match /communityPostLikes/{likeId}'), 'like document rules');
  assert.ok(rules.includes('match /postReports/{id}'), 'post report rules');
  assert.ok(rules.includes("kind in ['ugc', 'sec', 'chat', 'post']"), 'posts have their own rate-limit stamp kind');
  assert.ok(rules.includes('postLimited()'), 'post rate-limit helper');
  assert.ok(!rules.includes('post.report'), 'no new audit-log action was added for posts');
  const indexes = JSON.parse(readFileSync('firebase/firestore.indexes.json', 'utf8'));
  assert.ok(indexes.indexes.some((i: {collectionGroup: string}) => i.collectionGroup === 'communityPosts'), 'composite index for the posts feed query');
});

test('verification: word cards show the shield only for approved authors, and the admin page has its query index', () => {
  // The shield is a server-side fact (an approved application doc). The
  // client only reads it — it never decides it. The badge renders in the
  // wordHead author row, immediately after the display name, and only when
  // the author uid is in the resolved verified set.
  const screen = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.ok(screen.includes('fetchVerifiedUids'), 'verified authors are resolved from the application docs');
  assert.ok(screen.includes('verifiedUids'), 'a cached verified-author set is kept');
  assert.ok(screen.includes('{verifiedUids.has(w.uid) && <VerifiedBadge />}'), 'the shield renders only when the author is verified');
  assert.ok(screen.includes('VerifiedBadge'), 'the VerifiedBadge component is used');
  const ui = readFileSync('src/ui.tsx', 'utf8');
  assert.ok(ui.includes('export function VerifiedBadge'), 'VerifiedBadge is a shared brand primitive');
  assert.ok(ui.includes('accessibilityLabel="Verified contributor"'), 'the shield is accessible');
  // The admin page queries verificationApplications by status + createdAt,
  // which needs the composite index (same shape as every other moderated
  // collection). The Deploy Firebase workflow deploys it.
  const indexes = JSON.parse(readFileSync('firebase/firestore.indexes.json', 'utf8'));
  assert.ok(indexes.indexes.some((i: {collectionGroup: string}) => i.collectionGroup === 'verificationApplications'), 'composite index for the verification admin queries');
});
