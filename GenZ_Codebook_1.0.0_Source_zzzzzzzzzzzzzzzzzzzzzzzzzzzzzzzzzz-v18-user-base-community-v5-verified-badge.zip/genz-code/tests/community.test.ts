import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {communityId, screenWord, containsOwnName, OWN_NAME_ERROR, COMMUNITY_ID_PATTERN, CONTACT_PATTERN, PHONE_PATTERN} from '../shared/community';
import {toCommunityRecord, communityTerm, addLocalCommunityWord, findExistingTerm} from '../src/contentSync';
import {termsById, terms} from '../src/content';
import {search, decode} from '../src/engine';
import {logger} from '../src/secure/logger';
logger.setSink(null);

test('one stable, rule-compatible document ID per word', () => {
  assert.equal(communityId('rizz'), 'c-rizz');
  assert.equal(communityId('  RIZZ '), 'c-rizz');
  assert.equal(communityId('143'), 'c-143');
  assert.equal(communityId('No Cap'), communityId('no   cap'));
  assert.notEqual(communityId('no cap'), communityId('no-cap'));
  for (const w of ['rizz', 'no cap', '😭💀', 'کیا سین ہے', 'a'.repeat(60), 'x!y?z', "it's giving"]) {
    const id = communityId(w);
    assert.match(id, COMMUNITY_ID_PATTERN, w);
    assert.ok(id.length <= 80);
  }
});

test('word filter: contact details refused, sensitive words go to moderators, normal slang goes live', () => {
  assert.deepEqual(screenWord({term: 'skibidi', meaning: 'A nonsense word for fun.', example: ''}), {ok: true, review: false});
  assert.deepEqual(screenWord({term: 'bc', meaning: 'because', example: 'I left early bc I was tired'}), {ok: true, review: false});
  assert.deepEqual(screenWord({term: '143', meaning: 'I love you (1-4-3 letters)', example: ''}), {ok: true, review: false});
  for (const bad of [{meaning: 'see https://x.example'}, {meaning: 'visit www.spam.example'}, {example: 'mail me@spam.io'}, {meaning: 'call 0300 1234567'}]) {
    const r = screenWord({term: 'x', meaning: 'fine meaning', example: '', ...bad});
    assert.equal(r.ok, false, JSON.stringify(bad));
  }
  assert.deepEqual(screenWord({term: 'kys', meaning: 'short for something hurtful', example: ''}), {ok: true, review: true});
  assert.deepEqual(screenWord({term: 'r3tard', meaning: 'an insult', example: ''}), {ok: true, review: true});
  assert.equal(screenWord({term: 'ok', meaning: 'x', example: ''}).ok, false);
});

test('Firestore rules use the same link / phone patterns as the app', () => {
  const rules = readFileSync('firebase/firestore.rules', 'utf8');
  const contact = rules.match(/function noContact\(v\) \{ return !v\.lower\(\)\.matches\('\(\?s\)\.\*(.+)\.\*'\); \}/)?.[1];
  const phone = rules.match(/function noPhone\(v\) \{ return !v\.matches\('\(\?s\)\.\*(.+)\.\*'\); \}/)?.[1];
  assert.ok(contact && phone, 'rules functions found');
  // Rules `matches` must match the whole string; (?s) lets . cross newlines.
  const rulesContact = new RegExp(`^.*${contact}.*$`, 's'), rulesPhone = new RegExp(`^.*${phone}.*$`, 's');
  const samples = ['hello', 'see https://a.b', 'HTTP://A.B', 'www.x.y', 'me@x.io', 'ok\nhttps://x.y', '143', 'call 0300 1234567', '1-4-3', '+92 (300) 123-4567', 'email@ me'];
  for (const s of samples) {
    assert.equal(rulesContact.test(s.toLowerCase()), CONTACT_PATTERN.test(s), `contact: ${JSON.stringify(s)}`);
    assert.equal(rulesPhone.test(s), PHONE_PATTERN.test(s), `phone: ${JSON.stringify(s)}`);
  }
});

test('community records are validated before use', () => {
  assert.equal(toCommunityRecord('bad id', {status: 'live', term: 'x', meaning: 'yy', category: 'Chat'}), null);
  assert.equal(toCommunityRecord('c-x', {status: 'pending', term: 'x', meaning: 'yy', category: 'Chat'}), null);
  assert.equal(toCommunityRecord('c-x', {status: 'live', term: 'x', meaning: 'yy', category: 'Nope'}), null);
  assert.equal(toCommunityRecord('c-x', {status: 'live', term: 'x', meaning: '<script>alert(1)</script>', category: 'Chat'}), null);
  assert.deepEqual(toCommunityRecord('c-x', {status: 'hidden', term: 'secret text'}), {status: 'hidden'});
  const r = toCommunityRecord('c-x', {status: 'live', term: ' x ', meaning: 'a  meaning', example: '', category: 'Chat', uid: 'u1'});
  assert.deepEqual(r, {status: 'live', term: 'x', meaning: 'a meaning', example: '', category: 'Chat'});
  const t = communityTerm('c-x', r!);
  assert.equal(t?.status, 'Community');
  assert.equal(t?.expression, 'x');
});

test('a published word is searchable and decodable at once, and never replaces a bundled word', async () => {
  const before = terms.length;
  await addLocalCommunityWord('c-zorptastic', {term: 'zorptastic', meaning: 'Extremely good, in a weird way.', example: 'that fit is zorptastic', category: 'Social'});
  assert.equal(terms.length, before + 1);
  assert.equal(termsById.get('c-zorptastic')?.status, 'Community');
  assert.equal(search('zorptastic')[0]?.id, 'c-zorptastic');
  assert.equal(decode('ngl that was zorptastic').segments.find(s => s.term?.id === 'c-zorptastic')?.text, 'zorptastic');
  assert.equal(findExistingTerm('ZORPTASTIC')?.id, 'c-zorptastic');
  // Duplicate of a bundled word: ignored, the bundled entry stays.
  const idk = findExistingTerm('idk')!;
  assert.ok(idk && idk.status !== 'Community');
  await addLocalCommunityWord('c-idk', {term: 'idk', meaning: 'Something misleading.', example: '', category: 'Chat'});
  assert.equal(termsById.get('c-idk'), undefined);
  assert.equal(findExistingTerm('idk')?.id, idk.id);
  assert.equal(terms.length, before + 1);
});

test('token economy: insufficient tokens shows watch-ad, daily reward and Premium choices; suggest is never free for non-staff', () => {
  // No "first free" anywhere: every suggestion costs 20 tokens except staff.
  const dashboard = readFileSync('src/ProfileDashboard.tsx', 'utf8');
  assert.ok(!dashboard.includes('first free'), 'no free first suggestion');
  assert.ok(dashboard.includes('suggest a word 20'), 'suggest cost stated as 20');
  const tokens = readFileSync('shared/tokens.ts', 'utf8');
  assert.ok(tokens.includes('SUGGEST_COST'), 'suggest cost constant');
  // Community gate card: the three separate choices from the spec.
  const community = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.ok(community.includes("Watch an ad · +${TOKENS.REWARDED_AD} tokens"), 'gate offers watch an ad');
  assert.ok(community.includes('title="Daily reward"'), 'gate offers daily reward');
  assert.ok(community.includes('title="Premium options"'), 'gate offers Premium options');
  assert.ok(community.includes('onOpenDaily'), 'gate wires the daily sheet');
  // Suggest form: same three choices when the user cannot afford a word.
  const forms = readFileSync('src/SubmitForms.tsx', 'utf8');
  assert.ok(forms.includes('title="Daily reward"'), 'suggest offers daily reward');
  assert.ok(forms.includes('title="Premium options"'), 'suggest offers Premium options');
  assert.ok(forms.includes('onOpenDaily'), 'suggest wires the daily sheet');
  // The interstitial trigger lives in App.tsx (openSheet/go), not in the
  // screens — Community and Suggest must not trigger one themselves. The
  // only ad callers here are the voluntary earn buttons.
  assert.ok(!community.includes('showInterstitialIfReady'), 'no interstitial trigger on Community');
  assert.ok(!forms.includes('showInterstitialIfReady'), 'no interstitial trigger on Suggest');
});

test('verification: the 5,000-token fee is disclosed before confirmation and deducted only after the application write succeeds', () => {
  // The fee is device-local (the balance lives in the learning state, like the
  // 25-token post fee), so the deduction happens on the device — but ONLY
  // after applyForVerification() returns ok, never before, never twice. The
  // server-side record is the application doc (tokensPaid: 5000), and the
  // verified flag itself is rules-enforced — the client can never approve.
  const tokens = readFileSync('shared/tokens.ts', 'utf8');
  assert.ok(tokens.includes('VERIFICATION_FEE: 5000'), 'single source of truth for the fee is 5,000 tokens');
  const dashboard = readFileSync('src/ProfileDashboard.tsx', 'utf8');
  assert.ok(dashboard.includes('Apply for the verified shield. The fee is 5,000 tokens and is not refunded if your application is rejected.'), 'fee disclosure is visible before the user confirms');
  assert.ok(dashboard.includes('You need 5,000 tokens to apply'), 'insufficient-balance message names the 5,000-token fee');
  assert.ok(dashboard.includes('applyForVerification'), 'the application is submitted through the guarded submit');
  const submitAt = dashboard.indexOf('applyForVerification()');
  const deductAt = dashboard.indexOf('onTokensAction(spendTokens(TOKENS.VERIFICATION_FEE))');
  assert.ok(submitAt >= 0 && deductAt >= 0, 'submit and deduct are both present');
  assert.ok(submitAt < deductAt, 'the application write happens before any deduction');
  assert.ok(dashboard.includes('if (r.ok)'), 'tokens are deducted only when the application write succeeded');
  assert.ok(dashboard.includes('applying'), 'an applying guard stops a double-tap from deducting twice');
  assert.ok(dashboard.includes('Your previous application was rejected. You can apply again'), 'rejected users are told the fee applies again');
});

test('own-name block: nickname as a whole word, or as the whole term, is refused; a substring is fine', () => {
  // Nickname in the term.
  assert.equal(containsOwnName({term: 'Ali', meaning: 'a word', example: ''}, 'Ali'), true);
  // Term equals the nickname, case-insensitive.
  assert.equal(containsOwnName({term: 'ALI', meaning: 'a word', example: ''}, 'ali'), true);
  // Nickname in the meaning, case-insensitive.
  assert.equal(containsOwnName({term: 'rizz', meaning: 'Ali is the coolest', example: ''}, 'ali'), true);
  // Nickname in the example, case-insensitive.
  assert.equal(containsOwnName({term: 'rizz', meaning: 'charm', example: 'Ali said it first'}, 'ALI'), true);
  // A common word that merely contains the nickname as a substring is fine.
  assert.equal(containsOwnName({term: 'alibi', meaning: 'an excuse', example: ''}, 'Ali'), false);
  assert.equal(containsOwnName({term: 'rizz', meaning: 'an alibi for later', example: ''}, 'Ali'), false);
  // Multi-word nickname: the whole phrase must appear, not just one word of it.
  assert.equal(containsOwnName({term: 'rizz', meaning: 'the Code Explorer guide', example: ''}, 'Code Explorer'), true);
  assert.equal(containsOwnName({term: 'rizz', meaning: 'code is fun to learn', example: ''}, 'Code Explorer'), false);
  // No nickname, or a one-letter nickname, never blocks.
  assert.equal(containsOwnName({term: 'Ali', meaning: 'a word', example: ''}, ''), false);
  assert.equal(containsOwnName({term: 'a', meaning: 'a word', example: ''}, 'A'), false);
  // The error message is the one the forms show.
  assert.match(OWN_NAME_ERROR, /own name or nickname/);
});
