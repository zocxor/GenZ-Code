/**
 * Billing verification tests (pure logic in shared/billing.ts).
 *
 * These cover the client-side layer: a purchase is only creditable when it
 * is a known product, in the PURCHASED state, with a Play order ID, a purchase
 * token, and a matching package name. No receipt is required: react-native-iap
 * 15.x returns an empty transactionReceipt on Android, so requiring one would
 * reject every real purchase. The duplicate guard (one ledger document per
 * order ID) is enforced by the Firestore rules and covered by
 * firebase/rules-tests/rules.test.mjs, not here.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {verifyPurchaseRecord, PURCHASE_STATE, BILLING_PACKAGE} from '../shared/billing';

const good = {
  productId: 'tokens_5000',
  orderId: 'GPA.1234-5678-9012-34567',
  purchaseToken: 'purchase-token-abc',
  purchaseState: PURCHASE_STATE.PURCHASED,
  packageName: BILLING_PACKAGE,
};

test('billing: a real PURCHASED purchase verifies, with exactly the catalog amount', () => {
  const r = verifyPurchaseRecord(good);
  assert.equal(r.ok, true);
  if (r.ok) {
    assert.equal(r.productId, 'tokens_5000');
    assert.equal(r.tokens, 5000);
    assert.equal(r.orderId, 'GPA.1234-5678-9012-34567');
  }
});

test('billing: every package verifies at its own amount', () => {
  for (const [id, tokens] of [['tokens_1000', 1000], ['tokens_2500', 2500], ['tokens_10000', 10000], ['tokens_25000', 25000], ['tokens_50000', 50000], ['tokens_100000', 100000]] as const) {
    const r = verifyPurchaseRecord({...good, productId: id});
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.tokens, tokens);
  }
});

test('billing: pending and unspecified purchases are never creditable', () => {
  const pending = verifyPurchaseRecord({...good, purchaseState: PURCHASE_STATE.PENDING});
  assert.equal(pending.ok, false);
  if (!pending.ok) assert.match(pending.reason, /pending/i);
  assert.equal(verifyPurchaseRecord({...good, purchaseState: PURCHASE_STATE.UNSPECIFIED}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseState: undefined}).ok, false);
});

test('billing: unknown products, missing order IDs and missing tokens are refused', () => {
  assert.equal(verifyPurchaseRecord({...good, productId: 'tokens_999'}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, productId: 'tokens_5000 '}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, orderId: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, orderId: undefined}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseToken: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseToken: undefined}).ok, false);
});

test('billing: a purchase for another package is refused', () => {
  assert.equal(verifyPurchaseRecord({...good, packageName: 'com.other.app'}).ok, false);
  // No package name reported at all is tolerated (older Play responses omit it).
  assert.equal(verifyPurchaseRecord({...good, packageName: undefined}).ok, true);
});

test('billing: no receipt is required — react-native-iap 15.x returns an empty receipt on Android', () => {
  // The native layer never sets transactionReceipt, so a purchase with an
  // empty or absent receipt must still verify. The purchase token is the
  // credential the backend checks against Google's servers.
  assert.equal(verifyPurchaseRecord({...good}).ok, true);
});

test('billing: root tsconfig excludes functions/ — the apk job never installs functions/node_modules', () => {
  // CI failure 2026-11-09: the apk job's `tsc --noEmit` (root) tried to
  // type-check functions/src/index.ts, but the apk job never runs `npm ci`
  // in functions/, so firebase-admin / firebase-functions / googleapis were
  // missing (TS2307) and the gate failed. functions/ has its own tsconfig
  // and its own typecheck in the Deploy Firebase workflow — the root
  // typecheck must not cover it.
  const tsconfig = JSON.parse(readFileSync('tsconfig.json', 'utf8')) as {exclude?: string[]};
  assert.ok(Array.isArray(tsconfig.exclude), 'tsconfig has an exclude list');
  assert.ok(tsconfig.exclude!.includes('functions'), 'root tsconfig excludes functions/');
  // functions/ still has its own tsconfig + typecheck (the deploy workflow runs it).
  const fnTsconfig = JSON.parse(readFileSync('functions/tsconfig.json', 'utf8')) as {include?: string[]};
  assert.ok(fnTsconfig.include?.includes('src'), 'functions/tsconfig.json still covers its own src');
});

test('billing: react-native-iap is 15.x — 14.0.0 broke the Play AAB Gradle build', () => {
  // CI failure 2026-11-09: react-native-iap 14.0.0's generated Nitro spec
  // calls super.updateNative(), which react-native-nitro-modules 0.37.2
  // does not have — :react-native-iap:compileReleaseKotlin FAILED and the
  // play-aab job failed. 15.0.0+ generates a spec without updateNative.
  const pkg = JSON.parse(readFileSync('package.json', 'utf8')) as {dependencies?: Record<string, string>};
  const iap = pkg.dependencies?.['react-native-iap'] ?? '';
  assert.ok(iap.startsWith('^15.') || iap.startsWith('15.'), `react-native-iap is 15.x, got ${iap}`);
  const installed = JSON.parse(readFileSync('node_modules/react-native-iap/package.json', 'utf8')) as {version?: string};
  assert.ok(installed.version?.startsWith('15.'), `installed react-native-iap is 15.x, got ${installed.version}`);
});

test('audit: every admin-portal audit action is allowed by the Firestore rules', () => {
  // CI failure 2026-11-09: the Deploy Firebase rules test 35 (token grant)
  // failed because 'tokens.send' was in the admin portal's AuditAction type
  // but NOT in the auditLogs allow-create action list in firestore.rules —
  // so a Super Admin granting tokens got PERMISSION_DENIED on the audit
  // write and the whole grant batch failed. The emulator rules tests cannot
  // run in this VM (no Java), so this root test pins the two lists together
  // and fails locally the moment they drift apart.
  const adminSrc = readFileSync('admin/src/firebase.ts', 'utf8');
  const adminMatch = adminSrc.match(/export type AuditAction = (.*?);/s);
  assert.ok(adminMatch, 'admin portal has an AuditAction type');
  const adminGroup = adminMatch[1];
  assert.ok(adminGroup, 'admin portal AuditAction type has a body');
  const adminActions = new Set([...adminGroup.matchAll(/'([^']+)'/g)].map(m => m[1]));
  const rules = readFileSync('firebase/firestore.rules', 'utf8');
  const rulesMatch = rules.match(/request\.resource\.data\.action in \[(.*?)\]/s);
  assert.ok(rulesMatch, 'firestore.rules has an audit action allowlist');
  const rulesGroup = rulesMatch[1];
  assert.ok(rulesGroup, 'firestore.rules audit action allowlist has a body');
  const rulesActions = new Set([...rulesGroup.matchAll(/'([^']+)'/g)].map(m => m[1]));
  // Pinned count: 27 actions through the token-grant fix, + 'community.edit' and
  // 'community.delete' (community-word edit/delete, 2026-11-09), + the three
  // verification actions ('verification.approve', 'verification.reject',
  // 'verification.revoke', 2026-11-10). If either list grows by one entry
  // without the other, both the count and the set comparison below fail.
  assert.equal(adminActions.size, 32, `portal AuditAction has ${adminActions.size} actions, expected 32`);
  assert.equal(rulesActions.size, 32, `rules audit allowlist has ${rulesActions.size} actions, expected 32`);
  for (const a of adminActions) assert.ok(rulesActions.has(a), `audit action '${a}' is in the portal but not allowed by the rules`);
  for (const a of rulesActions) assert.ok(adminActions.has(a), `audit action '${a}' is allowed by the rules but not in the portal type`);
});

test('verification: rules gate the application by the 5,000-token fee and only a moderator can decide', () => {
  // The badge is a server-side fact: the client can apply (paying the fee)
  // and re-apply after a rejection, but it can never approve itself — the
  // decide is moderator-only and audited. The emulator rules tests (59) cover
  // the behaviour; this pins the source so a silent rules edit fails locally.
  const rules = readFileSync('firebase/firestore.rules', 'utf8');
  const block = rules.match(/match \/verificationApplications\/\{uid\} \{([\s\S]*?)\n  \}/);
  assert.ok(block, 'verificationApplications rules block exists');
  const body = block[1];
  assert.ok(body, 'verificationApplications rules block has a body');
  assert.ok(body.includes('tokensPaid == 5000'), 'the application fee is exactly 5,000 tokens');
  assert.ok(body.includes("request.resource.data.status == 'pending'"), 'applications start (and re-apply) as pending');
  assert.ok(body.includes('allow get: if true;'), 'the badge is public information');
  assert.ok(body.includes('allow list: if hasRole(MODERATE());'), 'only moderators can list applications');
  assert.ok(body.includes("resource.data.status == 'rejected'"), 'owner re-apply is only from a rejection');
  assert.ok(body.includes('hasRole(MODERATE())'), 'decide is moderator-only');
  assert.ok(body.includes("audited('verificationApplications/' + uid)"), 'decide is audited');
  assert.ok(!body.includes("request.resource.data.status == 'approved'"), 'no rule path lets anyone but the moderator set approved');
  // The three decision actions are in the portal type and the rules allowlist.
  const adminSrc = readFileSync('admin/src/firebase.ts', 'utf8');
  for (const a of ['verification.approve', 'verification.reject', 'verification.revoke']) {
    assert.ok(adminSrc.includes(`'${a}'`), `portal AuditAction has '${a}'`);
    assert.ok(rules.includes(`'${a}'`), `rules audit allowlist has '${a}'`);
  }
});
