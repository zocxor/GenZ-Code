/**
 * Code Points: the earn-and-spend currency of GenZ Codebook.
 *
 * Pure logic only — no React Native, no Firebase — so the rules are unit-tested
 * in Node. The balance lives in the learning state (profile.ts) and is stored
 * on this device only; it does not sync between devices, because a wallet
 * cannot be merged last-writer-wins without losing concurrent earns/spends.
 * The public leaderboard (src/pointsSync.ts) mirrors the balance, opt-in only.
 *
 * Earning (all local, all free):
 *  - Rewarded ad, watched by choice: +10
 *  - First activity of a new day: +5, plus +25 every 7th day of a streak
 *  - Quiz: +1 per point a new personal best improves by; a perfect round: +10
 *  - Daily Five finished: +15, once per day
 *  - A suggested word a moderator accepts: +20
 * Spending:
 *  - Suggest a word: 20 (the first one is free, so nobody is ever blocked)
 *  - Unlock a quiz level early: 50 (skips the 60% requirement for one level)
 */
export const POINTS = {
  REWARDED_AD: 10,
  DAILY_VISIT: 5,
  STREAK_WEEK_BONUS: 25,
  ACCEPTED_WORD: 20,
  SUGGEST_COST: 20,
  UNLOCK_LEVEL_COST: 50,
  DAILY_FIVE: 15,
  PERFECT_ROUND: 10,
  MAX_BALANCE: 1_000_000,
  CREDITED_LIMIT: 400,
} as const;

/** Points levels. Same shape as the XP ranks, different ladder: points are a currency, XP is skill. */
export const POINT_LEVELS: [number, string][] = [[0, 'Rookie'], [100, 'Chatter'], [250, 'Word Explorer'], [500, 'Slang Star'], [900, 'Code Master'], [1500, 'Code Legend']];
export function levelFor(balance: number): {level: number; name: string; floor: number; next: {points: number; name: string} | null; progress: number} {
  let i = 0;
  const b = Math.max(0, Math.floor(balance));
  while (i + 1 < POINT_LEVELS.length && b >= POINT_LEVELS[i + 1]![0]) i++;
  const [floor, name] = POINT_LEVELS[i]!;
  const next = POINT_LEVELS[i + 1];
  return {level: i + 1, name, floor, next: next ? {points: next[0], name: next[1]} : null, progress: next ? (b - floor) / (next[0] - floor) : 1};
}

export type PointsState = {
  balance: number;
  /** The first suggested word is free; after that each one costs SUGGEST_COST. */
  freeUsed: boolean;
  /** YYYY-MM-DD the daily-visit bonus was last paid, so it pays once per day. */
  lastDaily: string;
  /** YYYY-MM-DD the Daily Five bonus was last paid. */
  lastDailyFive: string;
  /** Keys already paid the accepted-word bonus: `sub:<submission doc id>`. */
  credited: string[];
  /** Quiz stage ids unlocked early with points. */
  unlockedLevels: string[];
  /** Opted in to the public leaderboard (nickname + points, nothing else). */
  leaderboard: boolean;
  /** Update stamp (wall-clock ms). */
  u: number;
};

export function emptyPoints(): PointsState {
  return {balance: 0, freeUsed: false, lastDaily: '', lastDailyFive: '', credited: [], unlockedLevels: [], leaderboard: false, u: 0};
}

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const STAGE_ID = /^(?:chat|emoji|campus|context|shuffle-[a-z]{1,20}|daily-\d{4}-\d{2}-\d{2})$/;
const CREDIT_KEY = /^(?:sub|word):[A-Za-z0-9_-]{1,100}$/;
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const num = (v: unknown, min: number = 0, max: number = POINTS.MAX_BALANCE): v is number => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;

/** Strictly parse stored points. Never throws; invalid parts fall back to defaults. */
export function parsePoints(input: unknown): PointsState {
  const p = emptyPoints();
  if (!isObj(input)) return p;
  p.balance = num(input.balance) ? Math.floor(input.balance) : 0;
  p.freeUsed = input.freeUsed === true;
  p.lastDaily = typeof input.lastDaily === 'string' && DAY.test(input.lastDaily) ? input.lastDaily : '';
  p.lastDailyFive = typeof input.lastDailyFive === 'string' && DAY.test(input.lastDailyFive) ? input.lastDailyFive : '';
  if (Array.isArray(input.credited)) p.credited = input.credited.filter((k): k is string => typeof k === 'string' && CREDIT_KEY.test(k)).slice(-POINTS.CREDITED_LIMIT);
  if (Array.isArray(input.unlockedLevels)) p.unlockedLevels = [...new Set(input.unlockedLevels.filter((id): id is string => typeof id === 'string' && STAGE_ID.test(id)))];
  p.leaderboard = input.leaderboard === true;
  p.u = num(input.u, 0, 8.64e15) ? Math.floor(input.u) : 0;
  return p;
}

/** What suggesting a word costs right now: free the first time, SUGGEST_COST after. */
export function suggestCost(p: PointsState): number {
  return p.freeUsed ? POINTS.SUGGEST_COST : 0;
}
export function canSuggest(p: PointsState): boolean {
  return p.balance >= suggestCost(p);
}
export function canUnlockLevel(p: PointsState, stageId: string): boolean {
  return !p.unlockedLevels.includes(stageId) && p.balance >= POINTS.UNLOCK_LEVEL_COST;
}
