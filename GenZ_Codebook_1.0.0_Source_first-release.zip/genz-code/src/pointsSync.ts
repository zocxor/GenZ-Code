/**
 * Code Points, server side: the accepted-word bonus and the public leaderboard.
 *
 * - Accepted-word bonus: a suggested word that goes to moderators (submissions,
 *   status 'pending') pays +20 when a moderator accepts it (status 'accepted').
 *   This checks the user's own submissions and credits each accepted one once;
 *   the paid keys live in the local points state, so a re-check never pays twice.
 *   Words published instantly (live) pay nothing — the publication itself is the
 *   reward, and paying for it would make suggesting free in net terms.
 * - Leaderboard: opt-in only. When opted in, the app publishes {name, points}
 *   to leaderboard/{uid} — nickname and points, nothing else — and anyone can
 *   read the top 20. Leaving deletes the entry. Best-effort and throttled; a
 *   failure never blocks the app. Points are client-reported, like the synced
 *   quiz scores: a determined user could inflate them, so the board is for fun,
 *   not a competition with prizes.
 */
import {accountAuth} from './firebase/app';

export type LeaderboardRow = {uid: string; name: string; points: number};

const libs = () => Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);

let lastPublishAt = 0;
let lastPublishedPoints = -1;

/** Credit +20 per accepted submission not yet paid. Returns the keys to credit (empty when nothing is new). */
export async function creditAcceptedWords(): Promise<string[]> {
  try {
    const user = accountAuth.currentUser;
    if (!user) return [];
    const [{collection, query, where, getDocs}, {cloudDb: dbFn}] = await libs();
    const snap = await getDocs(query(collection(dbFn(), 'submissions'), where('uid', '==', user.uid)));
    return snap.docs.filter(d => d.data().status === 'accepted').map(d => `sub:${d.id}`);
  } catch {return [];}
}

/** Publish (or refresh) this user's leaderboard entry. Throttled to once a minute and skipped when the balance is unchanged. */
export async function publishLeaderboard(name: string, points: number): Promise<void> {
  try {
    const user = accountAuth.currentUser;
    if (!user) return;
    const now = Date.now();
    if (points === lastPublishedPoints && now - lastPublishAt < 60_000) return;
    const [{doc, setDoc, serverTimestamp}, {cloudDb: dbFn}] = await libs();
    await setDoc(doc(dbFn(), 'leaderboard', user.uid), {name: name.slice(0, 24) || 'Code Explorer', points: Math.max(0, Math.floor(points)), updatedAt: serverTimestamp()});
    lastPublishAt = now;
    lastPublishedPoints = points;
  } catch {/* leaderboard is best-effort; never block the app */}
}

/** Remove this user's leaderboard entry (opting out, or account deletion). */
export async function leaveLeaderboard(): Promise<void> {
  try {
    const user = accountAuth.currentUser;
    if (!user) return;
    const [{doc, deleteDoc}, {cloudDb: dbFn}] = await libs();
    await deleteDoc(doc(dbFn(), 'leaderboard', user.uid));
    lastPublishedPoints = -1;
  } catch {/* ignore */}
}

/** Top 20 by points, highest first. Public read; no sign-in needed. */
export async function fetchLeaderboard(): Promise<LeaderboardRow[]> {
  try {
    const [{collection, query, orderBy, limit, getDocs}, {cloudDb: dbFn}] = await libs();
    const snap = await getDocs(query(collection(dbFn(), 'leaderboard'), orderBy('points', 'desc'), limit(20)));
    return snap.docs.map(d => {
      const data = d.data();
      return {uid: d.id, name: typeof data.name === 'string' && data.name ? data.name.slice(0, 24) : 'Code Explorer', points: typeof data.points === 'number' ? Math.floor(data.points) : 0};
    });
  } catch {return [];}
}
