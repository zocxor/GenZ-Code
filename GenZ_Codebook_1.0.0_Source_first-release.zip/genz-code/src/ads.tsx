/**
 * Google AdMob (free service; the SDK costs nothing, the app earns from impressions).
 *
 * Which ID is which:
 *  - App ID (ca-app-pub-9776667186789824~9376759074) identifies the app to the SDK.
 *    It lives in app.json (config plugin + react-native-google-mobile-ads key) and in
 *    android/app/src/main/AndroidManifest.xml. It is never passed to an ad view.
 *  - Banner ad unit ID (ca-app-pub-9776667186789824/5427038644) is the ID the banner
 *    itself needs. That is the only ID a banner takes.
 *  - Interstitial ad unit ID: not created yet in AdMob. The placeholder below stays
 *    empty until one is created; no interstitial is loaded or shown in release builds
 *    until then. In dev builds Google's test interstitial is used, so the flow can
 *    be checked now.
 *  - Rewarded ad unit ID: not created yet either. Same story: test rewarded ad in
 *    dev, real one once the unit exists. Rewarded ads are opt-in — the user taps
 *    to watch one and earns 10 Code Points. They are the only ads that pay points.
 *
 * Where ads appear:
 *  - Banner: at the bottom of the Suggest a word sheet AND at the bottom of the
 *    Community screen. Nowhere else in the app.
 *  - Interstitial (full-screen): when the user opens Suggest a word or the
 *    Community tab, at most once a minute — showing one on every single tap
 *    would spam people and risk AdMob flagging the placement, so the cooldown
 *    is deliberate. A full-screen ad shows until the user closes it (video
 *    ads normally let the user skip after a few seconds); no duration is forced.
 *  - Rewarded: only when the user taps "Watch an ad" to earn points.
 * While developing, Google's test ads are served instead of the real ones — never
 * tap a real ad in a debug build; AdMob treats that as invalid traffic. Ads are
 * non-personalised, matching the app's privacy stance and avoiding a consent form
 * for basic serving.
 */
import React, {useState} from 'react';
import {Platform, View} from 'react-native';
import {AdEventType, BannerAd, BannerAdSize, InterstitialAd, MobileAds, RewardedAd, RewardedAdEventType, TestIds} from 'react-native-google-mobile-ads';
import {IS_DEV} from './secure/config';

export const ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074';
export const BANNER_AD_UNIT_ID = 'ca-app-pub-9776667186789824/5427038644';
/** TODO: create an interstitial ad unit in AdMob and paste its ID here. Until then no interstitial is loaded or shown in release builds. */
export const INTERSTITIAL_AD_UNIT_ID = '';
/** TODO: create a rewarded ad unit in AdMob and paste its ID here. Until then no rewarded ad is available in release builds. */
export const REWARDED_AD_UNIT_ID = '';
/** Interstitials show at most this often, so opening a tab twice in a row does not stack full-screen ads. */
export const INTERSTITIAL_COOLDOWN_MS = 60_000;

/** The banner's ad unit ID: Google's test banner in dev, the real one in release builds. */
export function bannerAdUnitId(): string {
  return IS_DEV ? TestIds.BANNER : BANNER_AD_UNIT_ID;
}

/** Interstitial ad unit ID: Google's test interstitial in dev; the real one in release builds, or null until one is created in AdMob. */
export function interstitialAdUnitId(): string | null {
  if (IS_DEV) return TestIds.INTERSTITIAL;
  return INTERSTITIAL_AD_UNIT_ID || null;
}

/** Rewarded ad unit ID: Google's test rewarded ad in dev; the real one in release builds, or null until one is created in AdMob. */
export function rewardedAdUnitId(): string | null {
  if (IS_DEV) return TestIds.REWARDED;
  return REWARDED_AD_UNIT_ID || null;
}

let adsStarted = false;
/** Initialise the SDK once, Android only, and preload the first interstitial. Safe to call on every launch; a failure only means no ads. */
export function initAds(): void {
  if (adsStarted || Platform.OS !== 'android') return;
  adsStarted = true;
  void MobileAds().initialize().then(() => preloadInterstitial()).catch(() => undefined);
}

let interstitial: InterstitialAd | null = null;
let interstitialLoaded = false;
let lastInterstitialShownAt = 0;

/** Preload one interstitial so it is ready when the user opens Suggest or Community. No-op without an ad unit ID. */
export function preloadInterstitial(): void {
  if (Platform.OS !== 'android') return;
  const unitId = interstitialAdUnitId();
  if (!unitId || interstitial) return;
  const ad = InterstitialAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
  ad.addAdEventListener(AdEventType.LOADED, () => {interstitialLoaded = true;});
  ad.addAdEventListener(AdEventType.CLOSED, () => {interstitial = null; interstitialLoaded = false; preloadInterstitial();});
  ad.addAdEventListener(AdEventType.ERROR, () => {interstitial = null; interstitialLoaded = false;});
  interstitial = ad;
  ad.load();
}

/**
 * Show the preloaded interstitial if one is ready and the cooldown has passed.
 * Returns true when an ad was shown. Never blocks: when nothing is ready, or
 * the user opened a tab again within the cooldown, it silently does nothing
 * and the screen opens as normal.
 */
export function showInterstitialIfReady(): boolean {
  if (Platform.OS !== 'android' || !interstitial || !interstitialLoaded) return false;
  if (Date.now() - lastInterstitialShownAt < INTERSTITIAL_COOLDOWN_MS) return false;
  lastInterstitialShownAt = Date.now();
  try {interstitial.show(); return true;} catch {return false;}
}

/**
 * Show one rewarded ad. Resolves true only when the user actually earned the
 * reward (watched to the end); closing early, an error, or no ad unit ID
 * resolves false and pays nothing. The caller credits the points.
 */
export function watchRewardedAd(): Promise<boolean> {
  return new Promise(resolve => {
    if (Platform.OS !== 'android') return resolve(false);
    const unitId = rewardedAdUnitId();
    if (!unitId) return resolve(false);
    let done = false;
    const unsubs: (() => void)[] = [];
    const finish = (earned: boolean) => {
      if (done) return;
      done = true;
      for (const u of unsubs) {try {u();} catch {/* ignore */}}
      resolve(earned);
    };
    const ad = RewardedAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
    unsubs.push(
      ad.addAdEventListener(RewardedAdEventType.LOADED, () => {try {ad.show();} catch {finish(false);}}),
      ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => finish(true)),
      ad.addAdEventListener(AdEventType.CLOSED, () => finish(false)),
      ad.addAdEventListener(AdEventType.ERROR, () => finish(false)),
    );
    ad.load();
  });
}

/**
 * The one banner in the app: shown at the bottom of the Suggest a word sheet
 * and at the bottom of the Community screen. Android only; renders nothing on
 * iOS/web or while the ad fails to load.
 */
export function AdBanner() {
  const [failed, setFailed] = useState(false);
  if (Platform.OS !== 'android' || failed) return null;
  return <View style={{alignItems: 'center'}}>
    <BannerAd
      unitId={bannerAdUnitId()}
      size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER}
      requestOptions={{requestNonPersonalizedAdsOnly: true}}
      onAdFailedToLoad={() => setFailed(true)}
    />
  </View>;
}
