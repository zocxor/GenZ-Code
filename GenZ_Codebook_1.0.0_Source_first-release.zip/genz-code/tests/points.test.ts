import test from 'node:test';
import assert from 'node:assert/strict';
import {POINTS, levelFor, emptyPoints, parsePoints, suggestCost, canSuggest, canUnlockLevel} from '../shared/points';
import {emptyState, localDayOf} from '../src/profile';
import {recordAnswer, recordRound, resetScores, earnPoints, spendPoints, useFreeSuggestion, unlockLevelWithPoints, creditAccepted, setLeaderboardOptIn} from '../src/learning';

test('points: levels rise at 100 / 250 / 500 / 900 / 1500 with progress to the next one', () => {
  assert.deepEqual([levelFor(0).name, levelFor(99).name, levelFor(100).name, levelFor(250).name, levelFor(500).name, levelFor(900).name, levelFor(1500).name],
    ['Rookie', 'Rookie', 'Chatter', 'Word Explorer', 'Slang Star', 'Code Master', 'Code Legend']);
  assert.equal(levelFor(100).level, 2);
  assert.equal(levelFor(150).progress, 50 / 150);
  assert.equal(levelFor(1500).next, null);
  assert.equal(levelFor(1500).progress, 1);
});

test('points: the first suggestion is free, later ones cost 20, and the balance gates them', () => {
  const p = emptyPoints();
  assert.equal(suggestCost(p), 0);
  assert.equal(canSuggest(p), true);
  const used = {...p, freeUsed: true};
  assert.equal(suggestCost(used), POINTS.SUGGEST_COST);
  assert.equal(canSuggest(used), false);
  assert.equal(canSuggest({...used, balance: 19}), false);
  assert.equal(canSuggest({...used, balance: 20}), true);
  assert.equal(canUnlockLevel(used, 'emoji'), false);
  assert.equal(canUnlockLevel({...used, balance: 50}, 'emoji'), true);
  assert.equal(canUnlockLevel({...used, balance: 50, unlockedLevels: ['emoji']}, 'emoji'), false);
});

test('points: stored points are validated, never negative, and the credited list is bounded', () => {
  assert.deepEqual(parsePoints(null), emptyPoints());
  assert.deepEqual(parsePoints({balance: -5, credited: ['sub:abc', 'junk', 42], unlockedLevels: ['chat', 'nope!']}).balance, 0);
  const p = parsePoints({balance: 42.9, freeUsed: 'yes', lastDaily: '2026-11-07', lastDailyFive: 'tomorrow', credited: ['sub:a1', 'sub:b2'], unlockedLevels: ['chat', 'emoji', 'chat'], leaderboard: 1, u: -3});
  assert.equal(p.balance, 42);
  assert.equal(p.freeUsed, false);
  assert.equal(p.lastDaily, '2026-11-07');
  assert.equal(p.lastDailyFive, '');
  assert.deepEqual(p.credited, ['sub:a1', 'sub:b2']);
  assert.deepEqual(p.unlockedLevels, ['chat', 'emoji']);
  assert.equal(p.leaderboard, false);
  assert.equal(p.u, 0);
  const many = parsePoints({credited: Array.from({length: 500}, (_, i) => `sub:k${i}`)});
  assert.equal(many.credited.length, POINTS.CREDITED_LIMIT);
  assert.equal(many.credited[0], 'sub:k100');
});

test('points: the first answer of a new day pays +5, and the 7th day of a streak pays +25 more', () => {
  const now = new Date('2026-11-07T12:00:00').getTime();
  const s = emptyState();
  const afterFirst = recordAnswer(undefined, true)(s, now);
  assert.equal(afterFirst.points.balance, POINTS.DAILY_VISIT);
  assert.equal(afterFirst.points.lastDaily, '2026-11-07');
  const afterSecond = recordAnswer(undefined, false)(afterFirst, now + 1000);
  assert.equal(afterSecond.points.balance, POINTS.DAILY_VISIT);
  // Six days already played, today is the 7th in a row: +5 daily + 25 streak bonus.
  const days: Record<string, number> = {};
  for (let i = 1; i <= 6; i++) days[localDayOf(now - i * 86_400_000)] = 1;
  const streakState = {...emptyState(), days};
  const week = recordAnswer(undefined, true)(streakState, now);
  assert.equal(week.points.balance, POINTS.DAILY_VISIT + POINTS.STREAK_WEEK_BONUS);
});

test('points: quiz rounds pay for improvement, a perfect round, and the Daily Five once a day', () => {
  const now = Date.now();
  const s = {...emptyState(), best: {chat: {v: 60, u: 1}}};
  const improved = recordRound('chat', 4, 5, 'a-1')(s, now);
  assert.equal(improved.points.balance, 20, 'best 60 -> 80 pays 20');
  const perfect = recordRound('chat', 5, 5, 'a-2')(improved, now + 1);
  assert.equal(perfect.points.balance, 20 + 20 + POINTS.PERFECT_ROUND, 'best 80 -> 100 pays 20 more, plus the perfect-round bonus');
  const daily = recordRound('daily-2026-11-07', 3, 5, 'a-3')(perfect, now + 2);
  assert.equal(daily.points.balance, perfect.points.balance + POINTS.DAILY_FIVE);
  const dailyAgain = recordRound('daily-2026-11-07', 3, 5, 'a-4')(daily, now + 3);
  assert.equal(dailyAgain.points.balance, daily.points.balance, 'Daily Five pays once per day');
  const sameAttempt = recordRound('chat', 5, 5, 'a-2')(perfect, now + 4);
  assert.equal(sameAttempt, perfect, 'replaying an attempt id is a no-op');
});

test('points: spending, unlocking a level, and crediting accepted words', () => {
  const now = Date.now();
  const rich = {...emptyState(), points: {...emptyPoints(), balance: 60}};
  assert.equal(spendPoints(70)(rich, now), rich, 'cannot spend more than the balance');
  const spent = spendPoints(20)(rich, now);
  assert.equal(spent.points.balance, 40);
  const unlocked = unlockLevelWithPoints('emoji')(spent, now);
  assert.equal(unlocked.points.balance, 40, '50 is needed to unlock, 40 is not enough');
  const unlocked2 = unlockLevelWithPoints('emoji')({...rich, points: {...rich.points, balance: 50}}, now);
  assert.equal(unlocked2.points.balance, 0);
  assert.deepEqual(unlocked2.points.unlockedLevels, ['emoji']);
  assert.equal(unlockLevelWithPoints('emoji')(unlocked2, now), unlocked2, 'already unlocked');
  const credited = creditAccepted(['sub:x1', 'sub:x2'])(unlocked2, now);
  assert.equal(credited.points.balance, 2 * POINTS.ACCEPTED_WORD);
  assert.equal(creditAccepted(['sub:x1'])(credited, now), credited, 'already-paid words never pay twice');
  const earned = earnPoints(10)(credited, now);
  assert.equal(earned.points.balance, 2 * POINTS.ACCEPTED_WORD + 10);
  const capped = earnPoints(1000)({...emptyState(), points: {...emptyPoints(), balance: POINTS.MAX_BALANCE - 5}}, now);
  assert.equal(capped.points.balance, POINTS.MAX_BALANCE);
  assert.throws(() => earnPoints(0)(rich, now), RangeError);
});

test('points: free suggestion and leaderboard opt-in are one-way toggles', () => {
  const now = Date.now();
  const s = emptyState();
  const used = useFreeSuggestion(s, now);
  assert.equal(used.points.freeUsed, true);
  assert.equal(useFreeSuggestion(used, now), used);
  const joined = setLeaderboardOptIn(true)(used, now);
  assert.equal(joined.points.leaderboard, true);
  assert.equal(setLeaderboardOptIn(true)(joined, now), joined);
  assert.equal(setLeaderboardOptIn(false)(joined, now).points.leaderboard, false);
});

test('points: the balance is stored on this device only — resetting scores leaves it alone', () => {
  const now = Date.now();
  const s = {...emptyState(), points: {...emptyPoints(), balance: 123}, best: {chat: {v: 80, u: 1}}, days: {'2026-11-07': 3}};
  const reset = resetScores(s, now);
  assert.equal(reset.points.balance, 123);
  assert.deepEqual(reset.best, {});
  assert.deepEqual(reset.days, {});
});
