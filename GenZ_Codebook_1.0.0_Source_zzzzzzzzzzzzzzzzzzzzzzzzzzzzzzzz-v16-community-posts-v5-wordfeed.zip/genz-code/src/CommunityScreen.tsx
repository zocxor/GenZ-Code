/**
 * Community: one shared room for everyone, by nickname — chat and a word feed.
 *
 * The room is for token holders: you need tokens (balance above zero) to get
 * in and use it — earn them by watching an ad, playing quizzes, or buying a
 * package. Every chat message costs 1 token (CHAT_MESSAGE_COST) and every
 * word suggestion costs 25 tokens (POST_COST), shown before you send and
 * deducted only after the suggestion is accepted; the Post button is disabled
 * when the balance is too low. Once you are in the room this session you stay
 * in it even if your balance drops to zero — you just cannot send more until
 * you earn tokens. Guests can read the room once they hold tokens; only
 * signed-in users can post. Messages and words are screened on the device
 * before sending (see shared/chat.ts and src/ugc.ts) and again by the server
 * rules. Any chat message can be reported; moderators hide reported items
 * from the admin portal. The room only shows live messages, newest last,
 * capped at the newest 50; the Posts tab shows live community words only
 * (status 'live'), newest first, capped at the newest 50. A suggestion is
 * either published instantly or queued for a moderator (Pending); only
 * approved words ever appear publicly. Words have no likes or comments —
 * Save, Copy and Share are local to the device.
 *
 * The composer sits in a KeyboardAvoidingView so the keyboard never covers
 * the text box while typing — and when the keyboard opens the hero banner
 * collapses, so the composer stays in front no matter the keyboard height.
 * On the Posts tab the filters row and the leaderboard card also hide while
 * typing, so the word composer and the Post button stay visible above the
 * keyboard and the feed gets maximum room; they return when the keyboard
 * closes.
 */
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, ScrollView, Pressable, StyleSheet, KeyboardAvoidingView, Keyboard, Platform, Animated, Share} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Button, Chip, Icon, IconName, IconTile, FadeIn} from './ui';
import {useAccountUser} from './services';
import {subscribeChat, sendChatMessage, deleteOwnMessage} from './chat';
import {subscribeLiveWords, type CommunityWord, type WordFilter} from './communityWords';
import {reportChatMessage, suggestWord, REPORT_REASONS} from './ugc';
import {fetchPublicDisplayName} from './referral';
import {CONTENT_CATEGORIES} from '../shared/contentSchema';
import {CHAT_MAX_LENGTH, type ChatMessage} from '../shared/chat';
import {watchRewardedAd} from './ads';
import {fetchLeaderboard, publishLeaderboard, leaveLeaderboard, type LeaderboardRow} from './tokensSync';
import {earnTokens, spendTokens, setLeaderboardOptIn, type Action} from './learning';
import {TOKENS, type TokensState} from '../shared/tokens';

const timeOf = (at: number) => new Date(at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
const initialOf = (name: string) => (name.trim().charAt(0) || '?').toUpperCase();

/** Relative time for a word card ("12 min ago"). Computed at render; the feed re-renders when new words arrive. */
const relativeTime = (ms: number) => {
  if (!ms) return '';
  const s = Math.max(0, Math.floor((Date.now() - ms) / 1000));
  if (s < 60) return 'just now';
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(ms).toLocaleDateString();
};

/** Term-pill gradient per category (the feed has no likes, so the pill is the visual anchor). */
const CATEGORY_COLORS: Record<string, [string, string]> = {
  Chat: ['#7c3aed', '#a855f7'],
  Numbers: ['#2563eb', '#3b82f6'],
  Social: ['#059669', '#10b981'],
  Emoji: ['#d97706', '#f59e0b'],
  Gaming: ['#0891b2', '#06b6d4'],
  Campus: ['#db2777', '#ec4899'],
  Work: ['#4f46e5', '#6366f1'],
  Regional: ['#65a30d', '#84cc16'],
};
const categoryColors = (category: string): [string, string] => CATEGORY_COLORS[category] ?? [C.accent, C.purple];

/** Local-only saved word ids (no server write). */
const SAVED_WORDS_KEY = 'genz:savedCommunityWords';

type PostsFilter = 'latest' | 'trending' | 'code' | 'slang';
/** The four filter chips mapped onto the live-words subscription. */
const filterToQuery = (filter: PostsFilter): WordFilter =>
  filter === 'trending' ? {sort: 'trending', group: null}
  : filter === 'code' ? {sort: 'latest', group: 'code'}
  : filter === 'slang' ? {sort: 'latest', group: 'slang'}
  : {sort: 'latest', group: null};

export default function CommunityScreen({active, nickname, onSignIn, onOpenShop, onOpenDaily, onGoToPlay, tokens, onTokensAction}: {active: boolean; nickname: string; onSignIn: () => void; onOpenShop: () => void; onOpenDaily: () => void; onGoToPlay: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  const user = useAccountUser();
  const [view, setView] = useState<'chat' | 'posts'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [earning, setEarning] = useState(false);
  const [earnNote, setEarnNote] = useState('');
  const [joined, setJoined] = useState(false);
  // Entry gate: you need tokens to get in. Once you are in this session you
  // stay in the room even if a message spend drops your balance to zero — you
  // just cannot send more until you earn tokens. (The tab stays mounted, so
  // this survives switching tabs; a fresh app launch re-arms the gate.)
  useEffect(() => { if (active && tokens.balance > 0) setJoined(true); }, [active, tokens.balance]);
  const needsTokens = tokens.balance <= 0 && !joined;
  const [reporting, setReporting] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportNote, setReportNote] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportSent, setReportSent] = useState('');
  const [board, setBoard] = useState<LeaderboardRow[]>([]);
  const [boardBusy, setBoardBusy] = useState(false);
  // Posts tab: a live word feed (communityWords, status 'live' only). The old
  // free-text communityPosts system is untouched on disk; this tab no longer
  // renders it, so its subscription, likes and report/delete helpers are gone
  // from this screen. Words have no likes or comments — Save/Copy/Share are
  // local to the device.
  const [words, setWords] = useState<CommunityWord[]>([]);
  const [wordLoadError, setWordLoadError] = useState('');
  const [wordText, setWordText] = useState('');
  const [meaningText, setMeaningText] = useState('');
  const [wordExample, setWordExample] = useState('');
  const [wordCategory, setWordCategory] = useState<string | null>(null);
  const [filter, setFilter] = useState<PostsFilter>('latest');
  const [wordNames, setWordNames] = useState<Map<string, string>>(new Map());
  const [savedWordIds, setSavedWordIds] = useState<Set<string>>(new Set());
  const [posting, setPosting] = useState(false);
  const [postError, setPostError] = useState('');
  const [postNote, setPostNote] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const scrollRef = useRef<ScrollView>(null);
  // Permanent keyboard fix: the composer must stay visible while typing.
  // adjustResize + KeyboardAvoidingView shrink the view, but on some Android
  // builds the fixed hero still eats the freed room, so the composer can end
  // up under the keyboard. When the keyboard opens we collapse the hero
  // (frees ~190px) and scroll to the newest message; that combination cannot
  // hide the composer, whatever the keyboard height is.
  const [keyboardOpen, setKeyboardOpen] = useState(false);
  // Hero collapse animation: the hero fades + slides up over 200ms as the
  // keyboard opens, then leaves the layout (freeing ~190px); on close it
  // returns and fades back in. kbOpenRef guards the delayed removal so a
  // quick open/close cannot leave the hero hidden.
  const heroAnim = useRef(new Animated.Value(1)).current;
  const kbOpenRef = useRef(false);
  const kbTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Tab entrance: the head fades/slides in each time the tab becomes active
  // (tabs stay mounted, so a mount-only FadeIn would have finished unseen).
  const enterAnim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (active) Animated.timing(enterAnim, {toValue: 1, duration: 300, useNativeDriver: true}).start();
    else enterAnim.setValue(0);
  }, [active]);

  useEffect(() => {
    if (!active) return;
    setLoadError('');
    return subscribeChat(setMessages, setLoadError);
  }, [active]);
  useEffect(() => {
    if (!active || view !== 'posts') return;
    setWordLoadError('');
    return subscribeLiveWords(setWords, setWordLoadError, filterToQuery(filter));
  }, [active, view, filter]);
  // Saved word ids are local only (AsyncStorage); they load once per session.
  useEffect(() => {
    let live = true;
    void AsyncStorage.getItem(SAVED_WORDS_KEY).then(raw => {
      if (!live || !raw) return;
      try {
        const ids = JSON.parse(raw);
        if (Array.isArray(ids)) setSavedWordIds(new Set(ids.filter((id): id is string => typeof id === 'string')));
      } catch {/* a corrupt saved list just starts empty */}
    });
    return () => {live = false;};
  }, []);
  // Nicknames for word authors, resolved once per uid and cached. The current
  // user's own words show as "You"; an unresolved uid shows "Code Explorer".
  // Names come only from docs the author published themselves (see
  // fetchPublicDisplayName) — never an e-mail, phone number or UID.
  useEffect(() => {
    if (!active || view !== 'posts') return;
    const missing = [...new Set(words.map(w => w.uid))].filter(uid => !wordNames.has(uid) && (!user || uid !== user.uid));
    if (!missing.length) return;
    let live = true;
    void Promise.all(missing.map(async uid => [uid, await fetchPublicDisplayName(uid)] as const)).then(pairs => {
      if (!live) return;
      setWordNames(prev => {
        const next = new Map(prev);
        for (const [uid, name] of pairs) if (name) next.set(uid, name);
        return next;
      });
    });
    return () => {live = false;};
  }, [active, view, words, wordNames, user]);
  useEffect(() => {
    if (!active) return;
    let live = true;
    void fetchLeaderboard().then(rows => {if (live) setBoard(rows);});
    return () => {live = false;};
  }, [active]);
  useEffect(() => {
    if (active) scrollRef.current?.scrollToEnd({animated: true});
  }, [messages, active]);
  // When the keyboard opens, fade the hero out, then collapse it, and scroll
  // the room to the latest message so the composer and the newest message
  // stay visible above the keyboard. When it closes, the hero comes back
  // and fades in. The delayed removal is guarded so a quick open/close
  // cannot strand the hero hidden.
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () => {
      kbOpenRef.current = true;
      Animated.timing(heroAnim, {toValue: 0, duration: 200, useNativeDriver: true}).start();
      if (kbTimer.current) clearTimeout(kbTimer.current);
      kbTimer.current = setTimeout(() => { if (kbOpenRef.current) setKeyboardOpen(true); }, 200);
      setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 120);
    });
    const hide = Keyboard.addListener('keyboardDidHide', () => {
      kbOpenRef.current = false;
      if (kbTimer.current) clearTimeout(kbTimer.current);
      setKeyboardOpen(false);
      Animated.timing(heroAnim, {toValue: 1, duration: 200, useNativeDriver: true}).start();
    });
    return () => {
      show.remove(); hide.remove();
      if (kbTimer.current) clearTimeout(kbTimer.current);
    };
  }, []);

  const send = async () => {
    if (sending || !text.trim()) return;
    if (tokens.balance < TOKENS.CHAT_MESSAGE_COST) {
      setSendError(`You need ${TOKENS.CHAT_MESSAGE_COST} token${TOKENS.CHAT_MESSAGE_COST === 1 ? '' : 's'} to send a message (you have ${tokens.balance}). Watch an ad or collect your daily reward to earn more.`);
      return;
    }
    setSending(true); setSendError('');
    const r = await sendChatMessage(nickname, text);
    setSending(false);
    if (r.ok) {
      // Deduct only after the message is accepted — never twice for one send
      // (the `sending` guard above blocks a second tap while this runs).
      onTokensAction(spendTokens(TOKENS.CHAT_MESSAGE_COST));
      setText('');
    } else setSendError(r.message);
  };

  const submitWord = async () => {
    if (posting || !wordText.trim() || !meaningText.trim() || !wordCategory) return;
    if (tokens.balance < TOKENS.POST_COST) {
      setPostError(`You need ${TOKENS.POST_COST} tokens to post (you have ${tokens.balance}). Watch an ad or collect your daily reward to earn more.`);
      return;
    }
    setPosting(true); setPostError(''); setPostNote('');
    const r = await suggestWord({term: wordText, meaning: meaningText, example: wordExample, category: wordCategory});
    setPosting(false);
    if (r.ok) {
      // Deduct only after the suggestion is accepted — never twice for one
      // submit (the `posting` guard above blocks a second tap while this
      // runs). Both outcomes cost the same: a live word and a queued
      // (Pending) word are both an accepted submission.
      onTokensAction(spendTokens(TOKENS.POST_COST));
      setWordText(''); setMeaningText(''); setWordExample(''); setWordCategory(null);
      setPostNote(r.live ? 'Your word is live.' : 'Submitted — a moderator will review it. See My Suggestions for its status.');
    } else setPostError(r.message);
  };

  /** Save / unsave a word on this device only (no server write). */
  const toggleSaveWord = (id: string) => {
    const next = new Set(savedWordIds);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSavedWordIds(next);
    void AsyncStorage.setItem(SAVED_WORDS_KEY, JSON.stringify([...next])).catch(() => {});
  };

  const copyWord = async (w: CommunityWord) => {
    await Clipboard.setStringAsync(`${w.term} — ${w.meaning}`);
    setCopiedId(w.id);
    setTimeout(() => setCopiedId(prev => (prev === w.id ? null : prev)), 1500);
  };

  const shareWord = async (w: CommunityWord) => {
    try {await Share.share({message: `${w.term} — ${w.meaning}`});} catch {/* sharing is optional; a cancelled share is not an error */}
  };

  const earn = async () => {
    if (earning) return;
    setEarning(true); setEarnNote('');
    const rewarded = await watchRewardedAd();
    setEarning(false);
    if (rewarded) {onTokensAction(earnTokens(TOKENS.REWARDED_AD)); setEarnNote(`+${TOKENS.REWARDED_AD} tokens earned. Welcome to the room.`);}
    else setEarnNote('No tokens this time — the ad closed early. Try again when you like.');
  };

  const report = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportChatMessage(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this message.'); setReporting(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const remove = async (id: string) => {
    const r = await deleteOwnMessage(id);
    if (!r.ok) setSendError(r.message);
  };

  const toggleBoard = async (on: boolean) => {
    if (boardBusy || !user) return;
    setBoardBusy(true);
    onTokensAction(setLeaderboardOptIn(on));
    if (on) await publishLeaderboard(nickname, tokens.balance);
    else await leaveLeaderboard();
    setBoard(await fetchLeaderboard());
    setBoardBusy(false);
  };

  const gateCard = <FadeIn><LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.gate}>
    <IconTile icon="chatbubbles-outline" from="rgba(255,255,255,.28)" to="rgba(255,255,255,.14)" size={48} iconSize={24} />
    <Text style={s.gateTitle}>{view === 'posts' ? 'You need tokens to post' : 'You need tokens to join the chat'}</Text>
    <Text style={s.gateBody}>{view === 'posts' ? 'Earn tokens to post — watch an ad, play, or buy.' : 'Earn tokens to join — watch an ad, play, or buy.'}</Text>
    {!!earnNote && <Text accessibilityLiveRegion="polite" style={s.gateOk}>{earnNote}</Text>}
    <Button title={earning ? 'Showing ad…' : `Watch an ad · +${TOKENS.REWARDED_AD} tokens`} icon="play-circle-outline" light disabled={earning} onPress={() => void earn()} />
    <Button title="Daily reward" icon="gift-outline" light onPress={onOpenDaily} />
    <Button title="Premium options" icon="star-outline" light onPress={onOpenShop} />
    <Button title="Play to earn tokens" icon="game-controller-outline" light onPress={onGoToPlay} />
    <Button title="Buy tokens" icon="card-outline" light onPress={onOpenShop} />
    {!user && <Button title="Sign in or create an account" icon="log-in-outline" light onPress={onSignIn} />}
  </LinearGradient></FadeIn>;

  const reportBox = (title: string, onSubmit: () => void) => <Glass style={s.reportBox}>
    <Text style={s.label}>{title}</Text>
    <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reportReason === r} onPress={() => setReportReason(r)} />)}</View>
    <TextInput accessibilityLabel="Report details" value={reportNote} onChangeText={setReportNote} maxLength={300} multiline style={s.input} placeholder="Details (optional)" placeholderTextColor={C.muted} />
    {!!reportSent && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    <View style={s.reportButtons}>
      <Button title={reportBusy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={reportBusy || !reportReason} onPress={() => void onSubmit()} />
      <Button light title="Cancel" icon="close-outline" onPress={() => {setReporting(null);}} />
    </View>
  </Glass>;

  const chatDisabled = sending || !text.trim() || tokens.balance < TOKENS.CHAT_MESSAGE_COST;
  const wordDisabled = posting || !wordText.trim() || !meaningText.trim() || !wordCategory || tokens.balance < TOKENS.POST_COST;

  // 'height' on Android: with Expo SDK 54 + edge-to-edge the window does not
  // resize when the keyboard opens, so the 'padding' behaviour never lifts
  // the composer and the text box hides behind the keyboard. Shrinking the
  // whole view by the keyboard height keeps the composer pinned above it.
  // iOS keeps 'padding', which is reliable there.
  return <KeyboardAvoidingView style={s.fill} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={0}>
  <View style={s.fill}>
    <Animated.View style={[s.head, {opacity: enterAnim, transform: [{translateY: enterAnim.interpolate({inputRange: [0, 1], outputRange: [8, 0]})}]}]}>
      {keyboardOpen ? <FadeIn><View style={s.kbHead}><Text style={s.kbHeadTitle}>Community</Text><View style={s.kbHeadBalance}><Icon name="star" size={14} color={C.gold} /><Text style={s.kbHeadBalanceText}>{tokens.balance.toLocaleString()} tokens</Text><Pressable accessibilityRole="button" accessibilityLabel="Buy tokens" onPress={onOpenShop} style={s.kbHeadBuy}><Text style={s.kbHeadBuyText}>Buy</Text></Pressable></View></View></FadeIn> : <Animated.View style={{opacity: heroAnim, transform: [{translateY: heroAnim.interpolate({inputRange: [0, 1], outputRange: [-12, 0]})}]}}><LinearGradient colors={[C.navy, '#1E2A6B', C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.hero}>
        <View style={s.heroTop}>
          <Text style={s.heroEyebrow}>COMMUNITY · ONE ROOM</Text>
          {user && <Pressable accessibilityRole="button" accessibilityState={{selected: tokens.leaderboard}} onPress={() => void toggleBoard(!tokens.leaderboard)} style={[s.heroJoin, tokens.leaderboard && s.heroJoinOn]}>
            <Icon name="trophy-outline" size={15} color={tokens.leaderboard ? C.goldDeep : '#fff'} />
            <Text style={[s.heroJoinText, tokens.leaderboard && s.heroJoinTextOn]}>{boardBusy ? 'Please wait…' : tokens.leaderboard ? 'Leave' : 'Join'}</Text>
          </Pressable>}
        </View>
        <Text style={s.heroTitle}>Community</Text>
        <View style={s.heroLiveRow}><View style={s.liveDot} /><Text style={s.heroLiveText}>Live</Text><Text style={s.heroSub}>One room. Everyone chatting.</Text></View>
        <View style={s.heroBalance}>
          <Icon name="star" size={15} color={C.gold} />
          <Text style={s.heroBalanceText}>{tokens.balance.toLocaleString()} tokens</Text>
          <Pressable accessibilityRole="button" accessibilityLabel="Buy tokens" onPress={onOpenShop} style={s.heroBuy}>
            <Text style={s.heroBuyText}>Buy</Text>
          </Pressable>
        </View>
      </LinearGradient></Animated.View>}
      <View style={s.switcher}>
        <Segment label="Chat" icon="chatbubbles-outline" selected={view === 'chat'} onPress={() => setView('chat')} />
        <Segment label="Posts" icon="newspaper-outline" selected={view === 'posts'} onPress={() => setView('posts')} />
      </View>
    </Animated.View>
    {loadError && view === 'chat' ? <View style={[s.card, s.inlineCard]}><Text accessibilityRole="alert" style={s.err}>{loadError}</Text></View> : null}
    {wordLoadError && view === 'posts' ? <View style={[s.card, s.inlineCard]}><Text accessibilityRole="alert" style={s.err}>{wordLoadError}</Text></View> : null}
    <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" style={s.scroll} contentContainerStyle={s.list}>
      {/* On the Posts tab the leaderboard hides while typing, so the word
          composer and the Post button stay visible above the keyboard and
          the feed gets maximum room. It returns when the keyboard closes.
          The Chat tab keeps it always, as before. */}
      {!(view === 'posts' && keyboardOpen) && <FadeIn><View style={s.card}>
        <View style={s.boardHead}>
          <IconTile icon="trophy-outline" from={C.gold} to="#DE8F0E" size={44} iconSize={22} />
          <View style={{flex: 1, gap: 2}}>
            <Text style={s.rowTitle}>Top token earners</Text>
            <Text style={s.body}>Nicknames only.</Text>
          </View>
        </View>
        {board.length === 0 ? <Text style={s.body}>No one yet — be first.</Text> : board.slice(0, 5).map((r, i, arr) => (
          <View key={r.uid} style={[s.boardRow, i === arr.length - 1 && s.boardRowLast, user && r.uid === user.uid && s.boardRowMe]}>
            <View style={[s.rankBadge, i === 0 && s.rankFirst, i === 1 && s.rankSecond, i === 2 && s.rankThird]}><Text style={[s.rankText, i === 2 && s.rankTextLight]}>{i + 1}</Text></View>
            <Text style={[s.boardName, user && r.uid === user.uid && s.boardMe]} numberOfLines={1}>{user && r.uid === user.uid ? 'You' : r.name}</Text>
            <Text style={s.boardTokens}>{r.tokens.toLocaleString()} tokens</Text>
          </View>
        ))}
        {!user && <Text style={s.body}>Sign in to join.</Text>}
      </View></FadeIn>}
      {/* Posts filters: hidden while typing (same rule as the leaderboard),
          so the composer and the Post button stay above the keyboard. */}
      {view === 'posts' && !keyboardOpen && <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.filterScroll} contentContainerStyle={s.filterRow}>
        <Chip label="Latest" icon="time-outline" selected={filter === 'latest'} onPress={() => setFilter('latest')} />
        <Chip label="Trending" icon="flame-outline" selected={filter === 'trending'} onPress={() => setFilter('trending')} />
        <Chip label="Code Words" icon="code-slash-outline" selected={filter === 'code'} onPress={() => setFilter('code')} />
        <Chip label="Slangs" icon="chatbubbles-outline" selected={filter === 'slang'} onPress={() => setFilter('slang')} />
      </ScrollView>}
      {view === 'chat' ? (needsTokens ? gateCard : <>
      {!messages.length && !loadError ? <FadeIn><View style={[s.card, s.emptyCard]}>
        <IconTile icon="chatbubbles-outline" from={C.accent} to={C.purple} size={48} iconSize={24} />
        <Text style={s.rowTitle}>No messages yet.</Text>
        <Text style={s.body}>Say hi — keep it friendly.</Text>
      </View></FadeIn> : null}
      {messages.map(m => {
        const mine = !!user && m.uid === user.uid;
        return <View key={m.id} style={[s.msgWrap, mine && s.msgWrapMine]}>
          <View style={[s.metaRow, mine ? s.metaRowMine : s.metaRowTheirs]}>
            <Text style={s.name}>{mine ? 'You' : m.name}</Text>
            <Text style={s.time}>{timeOf(m.at)}</Text>
          </View>
          <View style={[s.msgLine, mine && s.msgLineMine]}>
            {!mine && <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.avatar}><Text style={s.avatarText}>{initialOf(m.name)}</Text></LinearGradient>}
            {mine ? (
              <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={[s.bubble, s.bubbleMine]}>
                <Text selectable style={[s.text, s.textMine]}>{m.text}</Text>
                <View style={s.actions}>
                  <Pressable accessibilityRole="button" accessibilityLabel="Delete my message" onPress={() => void remove(m.id)} style={s.mini}><Icon name="trash-outline" size={15} color="rgba(255,255,255,.9)" /><Text style={[s.miniText, s.miniTextMine]}>Delete</Text></Pressable>
                </View>
              </LinearGradient>
            ) : (
              <View style={[s.bubble, s.bubbleTheirs]}>
                <Text selectable style={s.text}>{m.text}</Text>
                <View style={s.actions}>
                  <Pressable accessibilityRole="button" accessibilityLabel={`Report message from ${m.name}`} onPress={() => {setReporting(reporting === m.id ? null : m.id); setReportReason(''); setReportNote(''); setReportSent('');}} style={s.mini}><Icon name="flag-outline" size={15} color={C.muted} /><Text style={s.miniText}>Report</Text></Pressable>
                </View>
              </View>
            )}
          </View>
          {reporting === m.id && reportBox('What’s wrong with this message?', () => void report(m.id))}
        </View>;
      })}
      </>) : (needsTokens ? gateCard : <>
      {!words.length && !wordLoadError ? <FadeIn><View style={[s.card, s.emptyCard]}>
        <IconTile icon="newspaper-outline" from={C.accent} to={C.purple} size={48} iconSize={24} />
        <Text style={s.rowTitle}>No words yet.</Text>
        <Text style={s.body}>Be the first to suggest one.</Text>
      </View></FadeIn> : null}
      {words.map((w, i) => {
        // Words have no likes and no comments — the card shows the term, its
        // meaning, the contributor and the time. Save / Copy / Share are
        // local to the device. There is no word-report button: moderation
        // runs through submissions and the admin portal.
        const mine = !!user && w.uid === user.uid;
        const displayName = mine ? 'You' : (wordNames.get(w.uid) ?? 'Code Explorer');
        const saved = savedWordIds.has(w.id);
        const copied = copiedId === w.id;
        const [from, to] = categoryColors(w.category);
        return <FadeIn key={w.id} delay={Math.min(i * 40, 200)}><View style={s.wordCard}>
          <View style={s.wordHead}>
            <LinearGradient colors={[from, to]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.avatar}><Text style={s.avatarText}>{initialOf(displayName)}</Text></LinearGradient>
            <View style={{flex: 1, gap: 1}}>
              <Text style={s.name}>{displayName}</Text>
              <Text style={s.time}>{relativeTime(w.createdAtMs)}</Text>
            </View>
            {mine && <View style={s.youPill}><Text style={s.youPillText}>YOU</Text></View>}
          </View>
          <View style={s.termRow}>
            <LinearGradient colors={[from, to]} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.termPill}><Text style={s.termText}>{w.term}</Text></LinearGradient>
            <View style={s.catChip}><Text style={s.catChipText}>#{w.category}</Text></View>
          </View>
          <Text selectable style={s.text}><Text style={{fontWeight: '800'}}>Meaning: </Text>{w.meaning}</Text>
          {w.example ? <Text selectable style={s.body}>“{w.example}”</Text> : null}
          <View style={s.wordActions}>
            <Pressable accessibilityRole="button" accessibilityLabel={saved ? `Unsave ${w.term}` : `Save ${w.term}`} onPress={() => toggleSaveWord(w.id)} style={[s.mini, saved && s.miniLiked]}>
              <Icon name={saved ? 'bookmark' : 'bookmark-outline'} size={16} color={saved ? C.accent : C.muted} />
              <Text style={[s.miniText, saved && s.miniTextLiked]}>Save</Text>
            </Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel={`Copy ${w.term}`} onPress={() => void copyWord(w)} style={s.mini}>
              <Icon name="copy-outline" size={16} color={C.muted} />
              <Text style={s.miniText}>{copied ? 'Copied' : 'Copy'}</Text>
            </Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel={`Share ${w.term}`} onPress={() => void shareWord(w)} style={s.mini}>
              <Icon name="share-social-outline" size={16} color={C.muted} />
              <Text style={s.miniText}>Share</Text>
            </Pressable>
          </View>
        </View></FadeIn>;
      })}
      </>)}
    </ScrollView>
    {!!reportSent && reporting === null && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    {needsTokens ? null : user ? (view === 'chat' ? <View style={[s.composer, keyboardOpen && s.composerKb]}>
      <View style={s.composerBar}>
        <TextInput accessibilityLabel="Message to the community" value={text} onChangeText={v => {setText(v); setSendError('');}} onFocus={() => setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 300)} maxLength={CHAT_MAX_LENGTH} multiline style={s.composerInput} placeholder={`Chat as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
        <Pressable accessibilityRole="button" accessibilityLabel="Send message" disabled={chatDisabled} onPress={() => void send()} style={s.sendBtn}>
          <LinearGradient colors={chatDisabled ? ['#d7e5f7', '#d7e5f7'] : [C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.sendBtnGrad}>
            <Icon name="paper-plane" size={20} color={chatDisabled ? C.muted : '#fff'} />
          </LinearGradient>
        </Pressable>
      </View>
      <View style={s.composerMeta}>
        <Text style={[s.costText, tokens.balance < TOKENS.CHAT_MESSAGE_COST && s.costWarn]}>{tokens.balance < TOKENS.CHAT_MESSAGE_COST ? `Need ${TOKENS.CHAT_MESSAGE_COST - tokens.balance} more token${TOKENS.CHAT_MESSAGE_COST - tokens.balance === 1 ? '' : 's'}` : `${TOKENS.CHAT_MESSAGE_COST} token${TOKENS.CHAT_MESSAGE_COST === 1 ? '' : 's'} per message`}</Text>
        <Text style={s.count}>{text.trim().length}/{CHAT_MAX_LENGTH}</Text>
      </View>
      {!!sendError && <Text accessibilityRole="alert" style={s.err}>{sendError}</Text>}
    </View> : <View style={[s.composer, s.wordComposer, keyboardOpen && s.composerKb]}>
      {/* The gradient header collapses while typing, so the inputs and the
          Post button get maximum room above the keyboard; it returns when
          the keyboard closes. */}
      {!keyboardOpen && <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.wordComposerHead}>
        <IconTile icon="create-outline" from="rgba(255,255,255,.28)" to="rgba(255,255,255,.14)" size={40} iconSize={20} />
        <View style={{flex: 1, gap: 1}}>
          <Text style={s.wordComposerTitle}>Suggest a Code Word / Slang</Text>
          <Text style={s.wordComposerSub}>Share a new word, slang or its meaning with the community.</Text>
        </View>
      </LinearGradient>}
      <TextInput accessibilityLabel="Code word or slang" value={wordText} onChangeText={v => {setWordText(v); setPostError(''); setPostNote('');}} maxLength={60} style={s.wordInput} placeholder="Write a code word or slang…" placeholderTextColor={C.muted} returnKeyType="next" />
      <TextInput accessibilityLabel="What does it mean" value={meaningText} onChangeText={v => {setMeaningText(v); setPostError(''); setPostNote('');}} maxLength={500} multiline style={[s.wordInput, s.wordMeaning]} placeholder="What does it mean?…" placeholderTextColor={C.muted} />
      <TextInput accessibilityLabel="Example (optional)" value={wordExample} onChangeText={setWordExample} maxLength={300} style={s.wordInput} placeholder="Example (optional)…" placeholderTextColor={C.muted} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.wordCats}>
        {CONTENT_CATEGORIES.map(c => <Chip key={c} label={c} selected={wordCategory === c} onPress={() => setWordCategory(wordCategory === c ? null : c)} />)}
      </ScrollView>
      <View style={s.wordPostRow}>
        <Text style={[s.costText, tokens.balance < TOKENS.POST_COST && s.costWarn]}>{tokens.balance < TOKENS.POST_COST ? `Need ${TOKENS.POST_COST - tokens.balance} more tokens` : `${TOKENS.POST_COST} tokens`}</Text>
        <Text style={s.count}>{wordText.trim().length}/60 · {meaningText.trim().length}/500</Text>
        <Pressable accessibilityRole="button" accessibilityLabel="Post this word" disabled={wordDisabled} onPress={() => void submitWord()} style={s.postBtn}>
          <LinearGradient colors={wordDisabled ? ['#d7e5f7', '#d7e5f7'] : [C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.postBtnGrad}>
            <Icon name="paper-plane" size={16} color={wordDisabled ? C.muted : '#fff'} />
            <Text style={[s.postBtnText, wordDisabled && s.postBtnTextDisabled]}>{posting ? 'Posting…' : 'Post'}</Text>
          </LinearGradient>
        </Pressable>
      </View>
      {!!postError && <Text accessibilityRole="alert" style={s.err}>{postError}</Text>}
      {!!postNote && <Text accessibilityLiveRegion="polite" style={s.ok}>{postNote}</Text>}
    </View>) : <View style={[s.card, s.signInCard]}>
      <IconTile icon="person-circle-outline" from={C.accent} to={C.purple} size={44} iconSize={22} />
      <Text style={s.rowTitle}>{view === 'posts' ? 'Sign in to post' : 'Sign in to chat'}</Text>
      <Text style={s.body}>Reading is free.</Text>
      <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
    </View>}
  </View>
  </KeyboardAvoidingView>;
}

/** Segmented Chat / Posts switcher — active half is an accent→purple gradient. */
function Segment({label, icon, selected, onPress}: {label: string; icon: IconName; selected: boolean; onPress: () => void}) {
  return (
    <Pressable accessibilityRole="button" accessibilityState={{selected}} onPress={onPress} style={s.segment}>
      <LinearGradient colors={selected ? [C.accent, C.purple] : ['rgba(0,0,0,0)', 'rgba(0,0,0,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.segmentFill}>
        <Icon name={icon} size={17} color={selected ? '#fff' : C.muted} />
        <Text style={[s.segmentText, selected && s.segmentTextOn]}>{label}</Text>
      </LinearGradient>
    </Pressable>
  );
}

const s = StyleSheet.create({
  fill: {flex: 1, backgroundColor: C.bg},
  scroll: {flex: 1},
  head: {paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4, gap: 12},
  hero: {borderRadius: 22, padding: 18, gap: 10, overflow: 'hidden', shadowColor: '#101A3A', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.25, shadowRadius: 16, elevation: 5},
  heroTop: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10},
  heroEyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.8, color: 'rgba(255,255,255,.75)'},
  heroJoin: {flexDirection: 'row', alignItems: 'center', gap: 5, minHeight: 32, paddingHorizontal: 12, borderRadius: 16, backgroundColor: 'rgba(255,255,255,.16)', borderWidth: 1, borderColor: 'rgba(255,255,255,.35)'},
  heroJoinOn: {backgroundColor: C.gold, borderColor: C.gold},
  heroJoinText: {fontSize: 12, fontWeight: '800', color: '#fff'},
  heroJoinTextOn: {color: C.goldDeep},
  heroTitle: {fontSize: 30, lineHeight: 35, fontWeight: '900', letterSpacing: -1, color: '#fff'},
  heroSub: {fontSize: 14, lineHeight: 20, color: 'rgba(255,255,255,.82)'},
  heroBalance: {flexDirection: 'row', alignItems: 'center', gap: 7, alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,.14)', borderWidth: 1, borderColor: 'rgba(255,255,255,.25)', borderRadius: 16, paddingVertical: 6, paddingLeft: 10, paddingRight: 6},
  heroBalanceText: {fontSize: 13, fontWeight: '800', color: '#fff'},
  heroBuy: {backgroundColor: '#fff', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4},
  heroBuyText: {fontSize: 12, fontWeight: '800', color: C.navy},
  heroLiveRow: {flexDirection: 'row', alignItems: 'center', gap: 6},
  liveDot: {width: 8, height: 8, borderRadius: 4, backgroundColor: '#4ade80'},
  heroLiveText: {fontSize: 12, fontWeight: '800', color: '#fff'},
  kbHead: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 16, paddingVertical: 8, paddingHorizontal: 14},
  kbHeadTitle: {fontSize: 17, fontWeight: '900', letterSpacing: -0.4, color: C.navy},
  kbHeadBalance: {flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: C.soft, borderWidth: 1, borderColor: '#d6e8fb', borderRadius: 14, paddingVertical: 5, paddingLeft: 9, paddingRight: 5},
  kbHeadBalanceText: {fontSize: 12, fontWeight: '800', color: C.navy},
  kbHeadBuy: {backgroundColor: C.accent, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4},
  kbHeadBuyText: {fontSize: 12, fontWeight: '800', color: '#fff'},
  switcher: {flexDirection: 'row', backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 4}, shadowOpacity: 0.08, shadowRadius: 12, elevation: 2},
  segment: {flex: 1, borderRadius: 14, overflow: 'hidden'},
  segmentFill: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, minHeight: 44, borderRadius: 14},
  segmentText: {fontSize: 14, fontWeight: '800', color: C.muted},
  segmentTextOn: {color: '#fff'},
  title: {fontSize: 24, lineHeight: 29, fontWeight: '900', letterSpacing: -0.8, color: C.navy},
  body: {fontSize: 14, lineHeight: 20, color: C.muted},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 20, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.1, shadowRadius: 14, elevation: 3},
  inlineCard: {marginHorizontal: 16, marginTop: 8, padding: 14},
  signInCard: {marginHorizontal: 16, marginBottom: 10},
  emptyCard: {alignItems: 'center', padding: 20, gap: 8},
  gate: {borderRadius: 20, padding: 18, gap: 10, overflow: 'hidden', shadowColor: '#7654F6', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.3, shadowRadius: 16, elevation: 5},
  gateTitle: {fontSize: 20, fontWeight: '900', letterSpacing: -0.4, color: '#fff'},
  gateBody: {fontSize: 14, lineHeight: 20, color: 'rgba(255,255,255,.85)'},
  gateOk: {fontSize: 13, lineHeight: 19, color: '#fff', fontWeight: '700'},
  boardHead: {flexDirection: 'row', alignItems: 'center', gap: 12},
  boardRow: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eef3fa'},
  boardRowLast: {borderBottomWidth: 0, paddingBottom: 0},
  boardRowMe: {backgroundColor: C.soft, borderRadius: 12, paddingHorizontal: 8, marginHorizontal: -8},
  rankBadge: {width: 28, height: 28, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center'},
  rankFirst: {backgroundColor: C.gold},
  rankSecond: {backgroundColor: '#cbd5e1'},
  rankThird: {backgroundColor: '#d08a4a'},
  rankText: {fontSize: 13, fontWeight: '900', color: C.navy},
  rankTextLight: {color: '#fff'},
  boardName: {flex: 1, fontSize: 15, fontWeight: '700', color: C.navy},
  boardMe: {color: C.accent},
  boardTokens: {fontSize: 14, fontWeight: '800', color: C.goldDeep},
  list: {padding: 12, gap: 10, paddingBottom: 12},
  msgWrap: {alignItems: 'flex-start', gap: 4},
  msgWrapMine: {alignItems: 'flex-end'},
  metaRow: {flexDirection: 'row', gap: 8, alignItems: 'baseline', paddingHorizontal: 4},
  metaRowMine: {},
  metaRowTheirs: {marginLeft: 44},
  msgLine: {flexDirection: 'row', alignItems: 'flex-end', gap: 8, width: '100%'},
  msgLineMine: {justifyContent: 'flex-end'},
  avatar: {width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', flexShrink: 0, borderWidth: 2, borderColor: '#fff'},
  avatarText: {color: '#fff', fontSize: 15, fontWeight: '900'},
  bubble: {borderRadius: 18, paddingVertical: 12, paddingHorizontal: 14, gap: 6, flexShrink: 1},
  bubbleTheirs: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1, borderBottomLeftRadius: 6},
  bubbleMine: {maxWidth: '88%', borderBottomRightRadius: 6},
  name: {fontSize: 13, fontWeight: '800', color: C.navy},
  time: {fontSize: 11, color: C.muted},
  text: {fontSize: 16, lineHeight: 23, color: C.navy},
  textMine: {color: '#fff'},
  actions: {flexDirection: 'row', gap: 8},
  mini: {flexDirection: 'row', gap: 4, alignItems: 'center', minHeight: 28, paddingHorizontal: 4},
  miniLiked: {backgroundColor: C.soft, borderRadius: 12, paddingHorizontal: 8},
  miniText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  miniTextMine: {color: 'rgba(255,255,255,.9)'},
  miniTextLiked: {color: C.navy},
  reportBox: {width: '100%', marginTop: 8},
  label: {fontSize: 14, color: C.navy, fontWeight: '800'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  reportButtons: {gap: 10},
  ok: {fontSize: 13, lineHeight: 19, color: '#0d6e4a'},
  err: {fontSize: 13, lineHeight: 19, color: '#a23842'},
  composer: {backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#dce8f5', paddingHorizontal: 12, paddingTop: 10, paddingBottom: 10, gap: 6},
  composerKb: {elevation: 8, shadowColor: '#101A3A', shadowOffset: {width: 0, height: -4}, shadowOpacity: 0.18, shadowRadius: 12, borderTopWidth: 2, borderTopColor: C.accent},
  composerBar: {flexDirection: 'row', alignItems: 'flex-end', gap: 10},
  composerInput: {flex: 1, minHeight: 48, maxHeight: 120, borderRadius: 22, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  sendBtn: {width: 48, height: 48, borderRadius: 24, overflow: 'hidden', flexShrink: 0},
  sendBtnGrad: {width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center'},
  composerMeta: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4},
  costText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  costWarn: {color: C.warn},
  count: {fontSize: 12, color: C.muted},
  input: {minHeight: 48, borderRadius: 18, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  rowTitle: {fontSize: 17, fontWeight: '800', color: C.navy},
  wordCard: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 20, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.1, shadowRadius: 14, elevation: 3},
  wordHead: {flexDirection: 'row', alignItems: 'center', gap: 10},
  youPill: {backgroundColor: C.soft, borderWidth: 1, borderColor: '#d6e8fb', borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3},
  youPillText: {fontSize: 10, fontWeight: '900', letterSpacing: 1, color: C.accent},
  termRow: {flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap'},
  termPill: {borderRadius: 16, paddingVertical: 7, paddingHorizontal: 14, overflow: 'hidden'},
  termText: {fontSize: 17, fontWeight: '900', letterSpacing: -0.3, color: '#fff'},
  catChip: {backgroundColor: '#F2F7FF', borderWidth: 1, borderColor: '#e3eefb', borderRadius: 12, paddingVertical: 5, paddingHorizontal: 9},
  catChipText: {fontSize: 12, fontWeight: '800', color: C.accent},
  wordActions: {flexDirection: 'row', gap: 8, alignItems: 'center', borderTopWidth: 1, borderTopColor: '#eef3fa', paddingTop: 10},
  filterScroll: {marginHorizontal: -2},
  filterRow: {flexDirection: 'row', gap: 8, paddingHorizontal: 2, paddingVertical: 2},
  wordComposer: {gap: 8},
  wordComposerHead: {flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 16, padding: 12, overflow: 'hidden'},
  wordComposerTitle: {fontSize: 16, fontWeight: '900', letterSpacing: -0.3, color: '#fff'},
  wordComposerSub: {fontSize: 12, lineHeight: 17, color: 'rgba(255,255,255,.85)'},
  wordInput: {minHeight: 48, borderRadius: 18, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 11, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  wordMeaning: {minHeight: 64, maxHeight: 120},
  wordCats: {flexDirection: 'row', gap: 8, paddingVertical: 2},
  wordPostRow: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 4},
  postBtn: {borderRadius: 16, overflow: 'hidden', flexShrink: 0},
  postBtnGrad: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 44, paddingHorizontal: 18, borderRadius: 16},
  postBtnText: {fontSize: 15, fontWeight: '900', color: '#fff'},
  postBtnTextDisabled: {color: C.muted},
});
