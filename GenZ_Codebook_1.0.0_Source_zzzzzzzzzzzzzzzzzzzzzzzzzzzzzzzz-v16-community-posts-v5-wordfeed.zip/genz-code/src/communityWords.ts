/**
 * Community words (the Posts tab feed): live, public words from `communityWords`.
 *
 * This is the word feed, not the old free-text `communityPosts` system (which
 * is left intact on disk and untouched by the Posts tab). A word is public only
 * when `status == 'live'` — words waiting on a moderator live in `submissions`
 * (status 'pending') and never appear here, and moderator-hidden words have
 * status 'hidden'. There are no likes, no comments and no stored nickname on a
 * word: the feed shows the term, its meaning, the category, the contributor's
 * nickname (resolved separately, privacy-safe) and the time. Save / Copy /
 * Share are all local to the device.
 *
 * Filters (the mapping is part of the contract, because the reference design's
 * "Code Word / Slang / New Term" chips are not real categories — the rules
 * only accept the CONTENT_CATEGORIES below):
 *   Latest   — orderBy createdAt desc (the only query with a deployed
 *               composite index: status + createdAt).
 *   Trending — orderBy updatedAt desc, i.e. recently active. There is no
 *               status+updatedAt index, so when the server refuses it we fall
 *               back to the Latest query and sort client-side by updatedAt.
 *   Code Words — categories ['Chat', 'Numbers', 'Emoji', 'Gaming'].
 *   Slangs     — categories ['Social', 'Campus', 'Work', 'Regional'].
 * The category groups are queried with `where('category', 'in', [...])`;
 * that also has no composite index, so on refusal we fall back to the Latest
 * query and filter client-side by category group. Either way the feed shows
 * the same live words, newest first, capped at 50.
 */
import {CONTENT_CATEGORIES} from '../shared/contentSchema';

export type CommunityWord = {
  id: string;
  uid: string;
  term: string;
  meaning: string;
  example: string;
  category: string;
  status: 'live';
  createdAtMs: number;
  updatedAtMs: number;
};

export type WordSort = 'latest' | 'trending';
export type WordGroup = 'code' | 'slang' | null;

/** Reference-design groups mapped onto the real rule categories. */
export const WORD_GROUP_CATEGORIES: Record<'code' | 'slang', string[]> = {
  code: ['Chat', 'Numbers', 'Emoji', 'Gaming'],
  slang: ['Social', 'Campus', 'Work', 'Regional'],
};

export type WordFilter = {
  sort: WordSort;
  group: WordGroup;
};

const libs = () => Promise.all([import('firebase/firestore/lite'), import('firebase/firestore'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

const msOf = (v: unknown): number => {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (v && typeof v === 'object' && typeof (v as {toMillis?: unknown}).toMillis === 'function') {
    const ms = (v as {toMillis: () => unknown}).toMillis();
    return typeof ms === 'number' ? ms : 0;
  }
  return 0;
};

/** Map one communityWords document; returns null for anything unusable (never a fake word). */
export function toCommunityWord(id: string, data: unknown): CommunityWord | null {
  if (!data || typeof data !== 'object') return null;
  const d = data as Record<string, unknown>;
  if (d.status !== 'live') return null;
  if (typeof d.term !== 'string' || !d.term.trim()) return null;
  if (typeof d.meaning !== 'string' || !d.meaning.trim()) return null;
  if (typeof d.category !== 'string' || !(CONTENT_CATEGORIES as readonly string[]).includes(d.category)) return null;
  if (typeof d.uid !== 'string' || !d.uid) return null;
  const createdAtMs = msOf(d.createdAt);
  return {
    id,
    uid: d.uid,
    term: d.term,
    meaning: d.meaning,
    example: typeof d.example === 'string' ? d.example : '',
    category: d.category,
    status: 'live',
    createdAtMs,
    updatedAtMs: msOf(d.updatedAt) || createdAtMs,
  };
}

/**
 * Live words, newest first. Subscribes only while the Posts view is open;
 * returns the unsubscribe function. When the requested server query has no
 * composite index (Trending, or a category group), it falls back to the
 * indexed Latest query and sorts/filters client-side.
 */
export function subscribeLiveWords(
  onWords: (words: CommunityWord[]) => void,
  onError: (message: string) => void,
  opts: WordFilter = {sort: 'latest', group: null},
): () => void {
  let stop = () => {};
  let stopped = false;
  void libs().then(([, live, {cloudDbLive}]) => {
    if (stopped) return;
    const db = cloudDbLive();
    const base = live.collection(db, 'communityWords');
    const run = (useServer: boolean) => {
      const q = !useServer || (opts.sort === 'latest' && !opts.group)
        ? live.query(base, live.where('status', '==', 'live'), live.orderBy('createdAt', 'desc'), live.limit(50))
        : opts.group
          ? live.query(base, live.where('status', '==', 'live'), live.where('category', 'in', WORD_GROUP_CATEGORIES[opts.group]), live.orderBy('createdAt', 'desc'), live.limit(50))
          : live.query(base, live.where('status', '==', 'live'), live.orderBy('updatedAt', 'desc'), live.limit(50));
      stop = live.onSnapshot(q, snap => {
        let words = snap.docs
          .map(d => toCommunityWord(d.id, d.data()))
          .filter((w): w is CommunityWord => w !== null);
        if (!useServer) {
          if (opts.group) words = words.filter(w => WORD_GROUP_CATEGORIES[opts.group!].includes(w.category));
          if (opts.sort === 'trending') words = [...words].sort((a, b) => b.updatedAtMs - a.updatedAtMs);
        }
        onWords(words);
      }, () => {
        if (useServer) run(false);
        else onError('Couldn’t load the words. Check your connection and try again.');
      });
    };
    run(true);
  }).catch(() => onError('Couldn’t load the words. Check your connection and try again.'));
  return () => {stopped = true; stop();};
}
