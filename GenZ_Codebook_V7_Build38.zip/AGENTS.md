# Instructions for AI assistants

This is the **GenZ Codebook** Android app (Expo/React Native + Firebase project `gen-z-code-55caf`, package `com.genzmode.app`).

**Before changing anything, read [`docs/PROJECT_GUIDE.md`](docs/PROJECT_GUIDE.md) and follow it.** In short:

- Never delete user data or rename Firestore collections, fields, ledger types, Play product IDs, function names or the package name.
- Never touch signing, release credentials, app icon/splash/branding, or put secrets in code.
- Don't run `expo prebuild`; don't flip `SPARK_MODE`.
- Make the smallest change, run the checks in section 10, raise the build number, add an entry to `docs/V7_UPGRADE_REPORT.md`.
- Deliver one complete project ZIP (section 11) and say what the owner must deploy or upload.
- If a key, permission or account is missing, ask the owner — never invent it.
