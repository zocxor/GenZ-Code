import {randomBytes} from 'node:crypto';
import {FieldValue,Timestamp,type Firestore} from 'firebase-admin/firestore';
import {HttpsError} from 'firebase-functions/v2/https';
import {wallet} from './communityFeatures';
export async function rewardIntent(db:Firestore,uid:string,now=Date.now()){
  const day=new Date(now).toISOString().slice(0,10),id=randomBytes(24).toString('hex');
  return db.runTransaction(async tx=>{
    const quota=db.doc(`users/${uid}/adAllowance/${day}`),[user,used]=await Promise.all([tx.get(db.doc('users/'+uid)),tx.get(quota)]);
    if(user.get('status')!=='active')throw new HttpsError('permission-denied','An active account is required.');
    const starts=Number(used.get('starts')??0);
    if(starts>=20)throw new HttpsError('resource-exhausted','Your daily rewarded-ad allowance is used. Try again tomorrow UTC.');
    tx.set(quota,{starts:starts+1,updatedAt:FieldValue.serverTimestamp()});
    tx.create(db.doc('adRewardIntents/'+id),{uid,createdAt:Timestamp.fromMillis(now),expiresAt:Timestamp.fromMillis(now+20*60000),used:false});
    return {id,reward:10,remaining:19-starts};
  });
}
export async function dailyReward(db:Firestore,uid:string,now=Date.now()){
  const day=new Date(now).toISOString().slice(0,10);
  return db.runTransaction(async tx=>{
    const receipt=db.doc(`users/${uid}/tokenLedger/daily-${day}`),[user,prior,w]=await Promise.all([tx.get(db.doc('users/'+uid)),tx.get(receipt),wallet(db,tx,uid)]);
    if(user.get('status')!=='active')throw new HttpsError('permission-denied','An active account is required.');
    if(prior.exists)return {id:day,duplicate:true,balance:w.balance};
    const amount=Math.min(10,Math.max(0,1000000-w.balance));
    tx.create(receipt,{type:'feature_reward',amount,ref:'daily-'+day,note:'Daily account reward',createdAt:FieldValue.serverTimestamp()});
    tx.set(w.ref,{...w.legacy,balance:Math.min(1000000,Math.max(0,Number(w.legacy.balance??0))+amount),earnedTotal:Number(w.legacy.earnedTotal??0)+amount,updatedAt:FieldValue.serverTimestamp()});
    return {id:day,balance:w.balance+amount};
  });
}
