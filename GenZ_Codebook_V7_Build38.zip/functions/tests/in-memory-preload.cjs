// Runs the emulator test files without Java/emulators, against the in-memory Firestore (tests/fake-firestore.cjs)
// and a small fake of Firebase Auth. The GitHub deploy workflow still runs them against the real emulators.
// Usage (in functions/): npm run build && npm run test:memory
const Module = require('module');
const path = require('path');
const base = process.env.FAKE_BASE || path.resolve(__dirname, '..');
const {createDb} = require(path.join(base, 'tests/fake-firestore.cjs'));
const db = createDb(() => Date.now());
process.env.FIRESTORE_EMULATOR_HOST = 'in-memory';
const load = Module._load;
Module._load = function (request, parent, isMain) {
  const real = load.apply(this, arguments);
  if (request === 'firebase-admin/app') return {...real, initializeApp: () => ({}), deleteApp: async () => {}};
  if (request === 'firebase-admin/firestore') return {...real, getFirestore: () => db};
  return real;
};
// Fake Firebase Auth for tests/vps-api.test.cjs: users, ID tokens and the sign-in REST call.
process.env.FIREBASE_AUTH_EMULATOR_HOST = 'fake-auth.invalid';
const users = new Map();
const fakeAuth = {
  createUser: async u => {users.set(u.email, u); return u;},
  verifyIdToken: async t => {
    const m = /^tok:(.+):(true|false)$/.exec(String(t));
    if (!m) throw Object.assign(new Error('bad token'), {code: 'auth/argument-error'});
    return {uid: m[1], email_verified: m[2] === 'true'};
  },
};
const realFetch = global.fetch;
global.fetch = async (url, init) => {
  if (String(url).startsWith('http://fake-auth.invalid/')) {
    const {email} = JSON.parse(init.body);
    const u = users.get(email);
    return new Response(JSON.stringify(u ? {idToken: `tok:${u.uid}:${u.emailVerified === true}`} : {error: 'unknown'}), {headers: {'Content-Type': 'application/json'}});
  }
  return realFetch(url, init);
};
const load2 = Module._load;
Module._load = function (request) {
  const real = load2.apply(this, arguments);
  if (request === 'firebase-admin/auth') return {...real, getAuth: () => fakeAuth};
  return real;
};
