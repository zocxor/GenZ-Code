// Runs the real compiled Google Play purchase handlers (lib/index.js: verifyPurchase, verifySubscription,
// rtdnHandler) against the in-memory Firestore, with the Google Play Developer API simulated.
// Covers: Credit packs are credited exactly once and count as spendable Credits; wrong pack / pending /
// cancelled purchases are refused; a Premium subscription belongs to one account only; renewals grant again;
// an old plan's notice can't switch off a newer active plan.
// Run: npm run build && node --test tests/play-purchases.fake.test.cjs
const Module = require('module');
const {test, beforeEach} = require('node:test');
const assert = require('node:assert/strict');
const {FieldValue} = require('firebase-admin/firestore');
const {createDb} = require('./fake-firestore.cjs');

let now = Date.UTC(2026, 10, 14, 12);
const db = createDb(() => now);
const play = {products: new Map(), subs: new Map(), acknowledged: []};
const fakeAuth = {verifyIdToken: async t => {
  const m = /^tok:(.+)$/.exec(String(t));
  if (!m) throw new Error('bad token');
  return {uid: m[1], email_verified: true};
}};
const publisher = {purchases: {
  products: {get: async ({productId, token}) => {
    const p = play.products.get(token);
    if (!p) throw Object.assign(new Error('not found'), {code: 404});
    if (p.productId !== productId && p.strictProduct) throw Object.assign(new Error('mismatch'), {code: 400});
    return {data: {...p}};
  }},
  subscriptionsv2: {get: async ({token}) => {
    const s = play.subs.get(token);
    if (!s) throw Object.assign(new Error('gone'), {code: 410});
    return {data: JSON.parse(JSON.stringify(s))};
  }},
  subscriptions: {acknowledge: async ({token}) => {play.acknowledged.push(token);}},
}};
const load = Module._load;
Module._load = function (request) {
  if (request === 'googleapis') return {google: {auth: {GoogleAuth: class {}}, androidpublisher: () => publisher}};
  if (request === 'firebase-admin') return {apps: [{}], initializeApp() {}, firestore: Object.assign(() => db, {FieldValue}), auth: () => fakeAuth};
  const real = load.apply(this, arguments);
  if (request === 'firebase-admin/app') return {...real, initializeApp: () => ({}), getApps: () => [{}]};
  if (request === 'firebase-admin/firestore') return {...real, getFirestore: () => db};
  if (request === 'firebase-admin/auth') return {...real, getAuth: () => fakeAuth};
  return real;
};
process.env.PLAY_SERVICE_ACCOUNT_JSON = JSON.stringify({client_email: 'genz-play-verification@example.iam.gserviceaccount.com', private_key: 'test-only'});
const backend = require('../lib/index.js');
const {communityAction} = require('../lib/communityFeatures');

function call(handler, uid, body) {
  return new Promise((resolve, reject) => {
    const res = {code: 200, status(c) {this.code = c; return this;}, json(b) {resolve({code: this.code, ...b});}};
    const req = {method: 'POST', body, get: h => (h === 'Authorization' && uid ? 'Bearer tok:' + uid : undefined)};
    Promise.resolve(backend[handler](req, res)).catch(reject);
  });
}
const buyPack = (uid, body) => call('verifyPurchaseHandler', uid, body);
const verifySub = (uid, body) => call('verifySubscriptionHandler', uid, body);
const balance = async uid => (await communityAction(db, {action: 'balance'}, {uid, token: {email_verified: true}}, now)).balance;
const iso = ms => new Date(ms).toISOString();
const DAY = 86400000;
function sub(productId, basePlanId, orderId, {state = 'SUBSCRIPTION_STATE_ACTIVE', expiry = now + 30 * DAY} = {}) {
  return {subscriptionState: state, acknowledgementState: 'ACKNOWLEDGEMENT_STATE_PENDING', latestOrderId: orderId,
    lineItems: [{productId, expiryTime: iso(expiry), autoRenewingPlan: {autoRenewEnabled: true}, offerDetails: {basePlanId}, latestSuccessfulOrderId: orderId}]};
}

beforeEach(() => {
  now = Date.UTC(2026, 10, 14, 12);
  db.store.clear();
  play.products.clear(); play.subs.clear(); play.acknowledged.length = 0;
  for (const uid of ['ali', 'sara']) {db.store.set('users/' + uid, {status: 'active'}); db.store.set(`users/${uid}/sync/profile`, {profile: {name: uid}});}
});

test('a Credit pack is credited once, under Google Play’s order ID, and counts as spendable Credits', async () => {
  play.products.set('tokA', {purchaseState: 0, consumptionState: 0, orderId: 'GPA.1111-2222-3333-44444', productId: 'tokens_5000'});
  const first = await buyPack('ali', {productId: 'tokens_5000', orderId: 'device-side-id', purchaseToken: 'tokA'});
  assert.deepEqual([first.code, first.verified, first.duplicate, first.tokens], [200, true, false, 5000]);
  assert.ok(db.store.has('users/ali/tokenLedger/order-GPA.1111-2222-3333-44444'), 'ledger uses Play’s order ID');
  assert.equal(await balance('ali'), 5000);
  const again = await buyPack('ali', {productId: 'tokens_5000', orderId: 'device-side-id', purchaseToken: 'tokA'});
  assert.deepEqual([again.verified, again.duplicate], [true, true]);
  assert.equal(await balance('ali'), 5000, 'never credited twice');
  const other = await buyPack('sara', {productId: 'tokens_5000', orderId: 'x', purchaseToken: 'tokA'});
  assert.equal(other.duplicate, true);
  assert.equal(await balance('sara'), 0, 'another account cannot claim the same purchase');
});

test('wrong pack, pending, cancelled, unknown and malformed purchases are never credited', async () => {
  play.products.set('cheap', {purchaseState: 0, orderId: 'GPA.9', productId: 'tokens_1000'});
  const swapped = await buyPack('ali', {productId: 'tokens_100000', orderId: 'GPA.9', purchaseToken: 'cheap'});
  assert.deepEqual([swapped.verified, swapped.retryable], [false, false]);
  play.products.set('pend', {purchaseState: 2, orderId: 'GPA.8', productId: 'tokens_1000'});
  const pending = await buyPack('ali', {productId: 'tokens_1000', orderId: 'GPA.8', purchaseToken: 'pend'});
  assert.deepEqual([pending.verified, pending.retryable], [false, true]);
  play.products.set('gone', {purchaseState: 1, orderId: 'GPA.7', productId: 'tokens_1000'});
  assert.equal((await buyPack('ali', {productId: 'tokens_1000', orderId: 'GPA.7', purchaseToken: 'gone'})).verified, false);
  assert.equal((await buyPack('ali', {productId: 'tokens_1000', orderId: 'GPA.6', purchaseToken: 'never-bought'})).verified, false);
  assert.equal((await buyPack('ali', {productId: 'tokens_1000', orderId: 'GPA.5', purchaseToken: 'a/b'})).code, 400);
  assert.equal((await buyPack('ali', {productId: 'tokens_999', orderId: 'GPA.5', purchaseToken: 'x'})).code, 400);
  assert.equal((await buyPack(null, {productId: 'tokens_1000', orderId: 'GPA.5', purchaseToken: 'x'})).code, 401);
  assert.equal(await balance('ali'), 0);
});

test('Premium: first verification grants the period Credits once; a second account on the same phone gets nothing', async () => {
  play.subs.set('subA', sub('premium_monthly', 'monthly', 'GPA.M-1'));
  const first = await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'subA'});
  assert.deepEqual([first.verified, first.duplicate, first.tokens], [true, false, 10000]);
  assert.equal(db.store.get('users/ali/subscription/current').state, 'SUBSCRIPTION_STATE_ACTIVE');
  assert.equal(await balance('ali'), 10000);
  assert.ok(play.acknowledged.includes('subA'), 'acknowledged server-side so Google does not refund it');
  const reopen = await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'subA'});
  assert.deepEqual([reopen.verified, reopen.duplicate, reopen.tokens], [true, true, 0]);
  const otherAccount = await verifySub('sara', {productId: 'premium_monthly', purchaseToken: 'subA'});
  assert.deepEqual([otherAccount.verified, otherAccount.retryable], [false, false]);
  assert.match(otherAccount.reason, /another GenZ Codebook account/);
  assert.equal(await balance('sara'), 0);
  assert.equal(db.store.has('users/sara/subscription/current'), false);
  assert.equal(db.store.get('subscriptionTokens/subA').uid, 'ali', 'the subscription stays linked to its first account');
  assert.equal(await balance('ali'), 10000);
});

test('Premium: each renewal (new order ID) grants again; the same order never does', async () => {
  play.subs.set('subA', sub('premium_monthly', 'monthly', 'GPA.M-1'));
  await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'subA'});
  now += 31 * DAY;
  play.subs.set('subA', sub('premium_monthly', 'monthly', 'GPA.M-1..0'));
  const renewal = await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'subA'});
  assert.equal(renewal.tokens, 10000);
  assert.equal(await balance('ali'), 20000);
  assert.equal((await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'subA'})).tokens, 0);
  assert.equal(await balance('ali'), 20000);
});

test('Premium: an old plan’s expiry after an upgrade does not switch off the new active plan', async () => {
  play.subs.set('old', sub('premium_monthly', 'monthly', 'GPA.M-1'));
  await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'old'});
  play.subs.set('new', sub('premium_yearly', 'yearly', 'GPA.Y-1', {expiry: now + 365 * DAY}));
  const upgraded = await verifySub('ali', {productId: 'premium_yearly', purchaseToken: 'new'});
  assert.deepEqual([upgraded.verified, upgraded.tokens], [true, 200000]);
  play.subs.set('old', sub('premium_monthly', 'monthly', 'GPA.M-1', {state: 'SUBSCRIPTION_STATE_EXPIRED', expiry: now - DAY}));
  const stale = await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'old'});
  assert.equal(stale.verified, false);
  assert.equal(db.store.get('users/ali/subscription/current').purchaseToken, 'new');
  assert.equal(db.store.get('users/ali/subscription/current').productId, 'premium_yearly');
  play.subs.delete('old');
  await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'old'});
  assert.equal(db.store.get('users/ali/subscription/current').purchaseToken, 'new', 'a refunded old plan does not clear the new one');
  assert.equal(await balance('ali'), 210000);
});

test('Premium: a pending payment grants nothing until Google Play completes it', async () => {
  play.subs.set('p', sub('premium_monthly', 'monthly', 'GPA.P-1', {state: 'SUBSCRIPTION_STATE_PENDING'}));
  const r = await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'p'});
  assert.deepEqual([r.verified, r.retryable], [false, true]);
  assert.equal(await balance('ali'), 0);
});

test('Google Play notifications (RTDN) re-sync the linked account and grant renewals once', async () => {
  const run = backend.rtdnHandler.run;
  assert.equal(typeof run, 'function');
  play.subs.set('subA', sub('premium_monthly', 'monthly', 'GPA.M-1'));
  await verifySub('ali', {productId: 'premium_monthly', purchaseToken: 'subA'});
  now += 31 * DAY;
  play.subs.set('subA', sub('premium_monthly', 'monthly', 'GPA.M-1..0'));
  const message = token => ({data: {message: {data: Buffer.from(JSON.stringify({subscriptionNotification: {notificationType: 2, purchaseToken: token}})).toString('base64')}}});
  await run(message('subA'));
  await run(message('subA'));
  assert.equal(await balance('ali'), 20000);
  await run(message('unknown-token'));
  await run({data: {message: {data: 'not json'}}});
  play.subs.set('subA', sub('premium_monthly', 'monthly', 'GPA.M-1..0', {state: 'SUBSCRIPTION_STATE_EXPIRED', expiry: now - 1}));
  await run(message('subA'));
  assert.equal(db.store.get('users/ali/subscription/current').state, 'SUBSCRIPTION_STATE_EXPIRED');
});
