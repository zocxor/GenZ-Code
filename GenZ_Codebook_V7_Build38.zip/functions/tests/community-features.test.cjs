const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const {initializeApp,deleteApp}=require('firebase-admin/app');
const {getFirestore,Timestamp}=require('firebase-admin/firestore');
const {communityAction,runDailySchedule,purgeContributions}=require('../lib/communityFeatures');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST,'These tests require the Firestore emulator.');
const app=initializeApp({projectId:'demo-genz-feature-core'});
const db=getFirestore(app);
after(()=>deleteApp(app));
const now=Date.UTC(2026,10,10,12);
const staff={uid:'feature-admin',token:{email_verified:true}};
const as=uid=>({uid,token:{email_verified:true}});
const run=(actor,action,data={},time=now)=>communityAction(db,{action,...data},actor,time);
const balance=async actor=>(await run(actor,'balance')).balance;
async function seedUser(uid,credits=0){
  const b=db.batch(), ts=Timestamp.fromMillis(now);
  b.set(db.doc('users/'+uid),{status:'active'});
  b.set(db.doc(`users/${uid}/sync/profile`),{profile:{name:'Code Learner'}});
  // Deliberately forge an opening cache that must be ignored by the server.
  b.set(db.doc(`users/${uid}/tokenWallet/wallet`),{balance:999999});
  b.set(db.doc(`users/${uid}/tokenLedger/migration-v1`),{type:'migration',amount:999999,createdAt:ts});
  // Today's free word and this month's free Daily Code are already used, so these tests cover the paid path.
  const day=new Date(now).toISOString().slice(0,10);
  b.set(db.doc(`users/${uid}/allowances/code-${day}`),{kind:'code',ref:'seed',createdAt:ts});
  b.set(db.doc(`users/${uid}/allowances/daily-${day.slice(0,7)}`),{kind:'daily',ref:'seed',createdAt:ts});
  if(credits){
    b.set(db.doc('processedTokens/'+uid),{uid,orderId:uid,tokens:credits,createdAt:ts});
    b.set(db.doc(`users/${uid}/tokenLedger/order-${uid}`),{type:'purchase',purchaseToken:uid,ref:uid,amount:credits,createdAt:ts});
  }
  await b.commit();
  return as(uid);
}
const status=async (name,id)=>(await db.doc(name+'/'+id).get()).get('status');
const rejectCode=code=>e=>e.code===code;
const seedWord=(uid,id,st)=>db.doc('submissions/'+id).set({uid,status:st,term:'Focusglow',meaning:'A burst of concentration.',category:'Work',reviewedBy:st==='accepted'?staff.uid:''});
const admin=async()=>{await db.doc('admins/'+staff.uid).set({active:true,role:'super_admin'});await db.doc('config/app').set({postPostingMode:'review'});};

test('daily: approval gate, concurrent bookings, idempotency, reschedule, automatic publication and refund',async()=>{
  await admin();
  const a=await seedUser('daily-a',1000),b=await seedUser('daily-b',1000);
  await seedWord(a.uid,'daily-word-a','pending');await seedWord(b.uid,'daily-word-b','accepted');
  const input={requestId:'daily-one',wordId:'daily-word-a',date:'2026-11-12'};
  await assert.rejects(run(a,'apply-daily',input),rejectCode('failed-precondition'));
  assert.equal(await balance(a),1000);
  await seedWord(a.uid,'daily-word-a','accepted');
  const second={...input,requestId:'daily-two',wordId:'daily-word-b'};
  const raced=await Promise.allSettled([run(a,'apply-daily',input),run(b,'apply-daily',second)]);
  assert.equal(raced.filter(r=>r.status==='fulfilled').length,1);
  const win=raced.findIndex(r=>r.status==='fulfilled'), winner=win===0?a:b, loser=win===0?b:a;
  const winnerInput=win===0?input:second, loserInput=win===0?second:input;
  const id=raced[win].value.id;
  assert.equal(raced[1-win].reason.details.next,'2026-11-13');
  assert.equal(await balance(winner),900);assert.equal(await balance(loser),1000);
  assert.equal((await run(winner,'apply-daily',winnerInput)).duplicate,true);
  await assert.rejects(run(winner,'apply-daily',{...winnerInput,requestId:'other',date:'2026-11-14'}),rejectCode('already-exists'));
  await assert.rejects(run(winner,'daily-admin',{id,command:'approve'}),rejectCode('permission-denied'));
  await run(staff,'daily-admin',{id,command:'approve'});
  await run(staff,'daily-admin',{id,command:'schedule',date:'2026-11-12'});
  const other=(await run(loser,'apply-daily',{...loserInput,date:'2026-11-13'})).id;
  await assert.rejects(run(staff,'daily-admin',{id,command:'schedule',date:'2026-11-13'}),rejectCode('already-exists'));
  await run(staff,'daily-admin',{id,command:'schedule',date:'2026-11-14'});
  await Promise.all([run(staff,'daily-admin',{id:other,command:'reject'}),run(staff,'daily-admin',{id:other,command:'reject'})]);
  assert.equal(await balance(loser),1000);
  assert.equal((await db.doc('dailyCodeApplications/'+other).get()).get('payment'),'refunded');
  await runDailySchedule(db,Date.UTC(2026,10,14,0,1));
  await runDailySchedule(db,Date.UTC(2026,10,14,0,2));
  assert.equal(await status('dailyCodeApplications',id),'published');
  assert.equal((await db.doc('dailyCodeApplications/'+id).get()).get('requestedDate'),'2026-11-12');
  assert.equal((await db.doc('dailyCodePublic/2026-11-14').get()).get('term'),'Focusglow');
  assert.equal(await balance(winner),900);
});

test('daily: pending cancellation and missed date refund once, and an empty day gets a generated entry',async()=>{
  const u=await seedUser('daily-expiry',1000);await seedWord(u.uid,'daily-expiry-word','accepted');
  const data={requestId:'cancel',wordId:'daily-expiry-word',date:'2026-11-11'};
  const first=await run(u,'apply-daily',data);
  await Promise.all([run(u,'cancel-daily',{id:first.id}),run(u,'cancel-daily',{id:first.id})]);
  assert.equal(await balance(u),1000);
  const second=await run(u,'apply-daily',{...data,requestId:'expire'});
  await runDailySchedule(db,Date.UTC(2026,10,12,0,1));
  assert.equal(await balance(u),1000);
  assert.equal(await status('dailyCodeApplications',second.id),'rejected');
  assert.ok((await db.doc('dailyCodePublic/2026-11-12').get()).get('term'));
});

test('daily: admin dictionary picker validates its source, protects reservations and publishes the chosen word',async()=>{
  await admin();
  await seedWord('daily-editor-author','daily-editor-approved','accepted');
  await seedWord('daily-editor-author','daily-editor-pending','pending');
  const choice={command:'schedule-word',date:'2026-11-18',wordSource:'submission',wordId:'daily-editor-approved'};
  await assert.rejects(run(as('ordinary-reader'),'daily-admin',choice),rejectCode('permission-denied'));
  await assert.rejects(run(staff,'daily-admin',{...choice,wordId:'daily-editor-pending'}),rejectCode('failed-precondition'));
  await assert.rejects(run(staff,'daily-admin',{...choice,wordSource:'bundled',wordId:'invented-word'}),rejectCode('failed-precondition'));
  const generated={command:'generate',date:choice.date};
  const results=await Promise.allSettled([run(staff,'daily-admin',choice),run(staff,'daily-admin',choice)]);
  assert.equal(results.filter(r=>r.status==='fulfilled').length,1);
  assert.equal(results.find(r=>r.status==='rejected').reason.code,'already-exists');
  await assert.rejects(run(staff,'daily-admin',generated),rejectCode('already-exists'));
  assert.equal((await db.doc('dailyCodeDates/'+choice.date).get()).get('term'),'Focusglow');
  assert.equal((await db.doc('dailyCodePublic/'+choice.date).get()).exists,false);
  await runDailySchedule(db,Date.UTC(2026,10,18,0,1));
  const result=(await db.doc('dailyCodePublic/'+choice.date).get()).data();
  assert.equal(result.term,'Focusglow');
  assert.equal(result.meaning,'A burst of concentration.');
  assert.equal(result.category,'Work');

  const bundled=require('../lib/validation/dictionary.json').selectable[0];
  await run(staff,'daily-admin',{...choice,date:'2026-11-19',wordSource:'bundled',wordId:bundled.id});
  await runDailySchedule(db,Date.UTC(2026,10,19,0,1));
  assert.equal((await db.doc('dailyCodePublic/2026-11-19').get()).get('term'),bundled.term);

  const cms=db.doc('publishedContent/daily-editor-cms');
  await cms.set({term:'Archive example',meaning:'A published editorial example.',category:'Work',status:'published',sensitivity:'None'});
  await run(staff,'daily-admin',{...choice,date:'2026-11-20',wordSource:'published',wordId:cms.id});
  await cms.update({status:'archived'});
  await runDailySchedule(db,Date.UTC(2026,10,20,0,1));
  assert.notEqual((await db.doc('dailyCodePublic/2026-11-20').get()).get('term'),'Archive example');
});

test('daily: live community words are eligible and post-scheduling edits or hides are caught',async()=>{
  await admin();
  const word=db.doc('communityWords/c-hdot');
  const fields={term:'HDOT',meaning:'A test definition.',category:'Social',status:'live'};
  await word.set(fields);
  const choice={command:'schedule-word',wordSource:'community',wordId:word.id,date:'2026-11-21'};
  await assert.rejects(run(as('ordinary-reader'),'daily-admin',choice),rejectCode('permission-denied'));
  await run(staff,'daily-admin',choice);
  await runDailySchedule(db,Date.UTC(2026,10,21,0,1));
  assert.equal((await db.doc('dailyCodePublic/2026-11-21').get()).get('term'),'HDOT');

  await run(staff,'daily-admin',{...choice,date:'2026-11-22'});
  await word.update({meaning:'Changed after review.'});
  await runDailySchedule(db,Date.UTC(2026,10,22,0,1));
  assert.notEqual((await db.doc('dailyCodePublic/2026-11-22').get()).get('term'),'HDOT');

  await run(staff,'daily-admin',{...choice,date:'2026-11-23'});
  await word.update({status:'hidden'});
  await assert.rejects(run(staff,'daily-admin',{...choice,date:'2026-11-24'}),rejectCode('failed-precondition'));
  await runDailySchedule(db,Date.UTC(2026,10,23,0,1));
  assert.notEqual((await db.doc('dailyCodePublic/2026-11-23').get()).get('term'),'HDOT');
});

test('posts: eligible fee, validation, duplicate race, review, like, comment, save and removal',async()=>{
  await admin();
  const u=await seedUser('post-author',1000), poor=await seedUser('post-poor');
  const payload={requestId:'post-1',term:'Zelvarift',meaning:'A satisfying break from distractions.',category:'Slang',example:'I took a zelvarift.'};
  await assert.rejects(run(poor,'create-post',payload),rejectCode('failed-precondition'));
  await assert.rejects(run(u,'create-post',{...payload,term:'x'.repeat(31)}),rejectCode('invalid-argument'));
  await assert.rejects(run(u,'create-post',{...payload,meaning:'Visit www.spam.example'}),rejectCode('invalid-argument'));
  const raced=await Promise.all([run(u,'create-post',payload),run(u,'create-post',payload)]);
  assert.equal(raced[0].id,raced[1].id);assert.equal(await balance(u),950);
  const id=raced[0].id;
  await assert.rejects(run(u,'create-post',{...payload,requestId:'post-2'}),rejectCode('already-exists'));
  assert.equal(await status('communityPosts',id),'pending');
  assert.equal((await db.doc('communityPosts/'+id).get()).get('name'),'Code Learner');
  await assert.rejects(run(poor,'like-post',{id,enabled:true}),rejectCode('not-found'));
  await assert.rejects(run(u,'post-admin',{id,command:'approve'}),rejectCode('permission-denied'));
  await run(staff,'post-admin',{id,command:'approve'});
  await run(poor,'like-post',{id,enabled:true});await run(poor,'like-post',{id,enabled:true});
  await run(poor,'comment-post',{id,text:'This was helpful.'});await run(poor,'comment-post',{id,text:'This was helpful.'});
  await run(poor,'save-post',{id,enabled:true});
  let post=await db.doc('communityPosts/'+id).get();
  assert.equal(post.get('engagementScore'),2);
  assert.equal(post.get('likeCount'),1);assert.equal(post.get('commentCount'),1);
  assert.ok((await db.doc(`users/${poor.uid}/savedCommunityPosts/${id}`).get()).exists);
  await run(poor,'like-post',{id,enabled:false});await run(poor,'save-post',{id,enabled:false});
  await run(u,'delete-post',{id});
  post=await db.doc('communityPosts/'+id).get();assert.equal(post.get('hidden'),true);
  const rejected=await run(u,'create-post',{...payload,requestId:'reject-post',term:'Venvaflow'});
  await run(staff,'post-admin',{id:rejected.id,command:'reject'});
  assert.equal(await status('communityPosts',rejected.id),'rejected');
  assert.equal(await balance(u),900);
});

test('posts: 500 displayed legacy tokens cannot pay, but a verified admin grant can',async()=>{
  await admin();
  const u=await seedUser('post-account-credits');
  const wallet=db.doc(`users/${u.uid}/tokenWallet/wallet`);
  await wallet.set({balance:500});
  const post={requestId:'credits-test',term:'Zelvacompass',meaning:'A test expression for checking account credits.',category:'Code Word'};
  assert.equal(await balance(u),0);
  await assert.rejects(run(u,'create-post',post),rejectCode('failed-precondition'));
  assert.equal((await wallet.get()).get('balance'),500);

  const at=Timestamp.fromMillis(now);
  const grant=db.batch();
  grant.set(db.doc('auditLogs/credit-test-grant'),{action:'tokens.send',role:'super_admin',target:`users/${u.uid}`,summary:'Sent 50 tokens',at});
  grant.set(db.doc(`users/${u.uid}/tokenLedger/credit-test-grant`),{type:'adjustment',ref:'admin-grant',amount:50,lastAuditId:'credit-test-grant',createdAt:at});
  grant.set(wallet,{balance:550});
  await grant.commit();
  assert.equal(await balance(u),50);
  const result=await run(u,'create-post',post);
  assert.equal(await status('communityPosts',result.id),'pending');
  assert.equal((await run(u,'create-post',post)).duplicate,true);
  assert.equal(await balance(u),0);
  assert.equal((await wallet.get()).get('balance'),500);
});

test('verification: concurrent apply, no rejection refund, approval and revocation',async()=>{
  await admin();
  const u=await seedUser('badge-author',15000);
  const first=await Promise.allSettled([run(u,'apply-verification',{requestId:'badge-a'}),run(u,'apply-verification',{requestId:'badge-b'})]);
  assert.equal(first.filter(r=>r.status==='fulfilled').length,1);
  const id=first.find(r=>r.status==='fulfilled').value.id;
  assert.equal(await balance(u),10000);
  await assert.rejects(run(u,'verification-admin',{id,command:'approved'}),rejectCode('permission-denied'));
  await run(staff,'verification-admin',{id,command:'rejected'});
  assert.equal(await balance(u),10000);
  const next=await run(u,'apply-verification',{requestId:'badge-c'});
  await run(staff,'verification-admin',{id:next.id,command:'approved'});
  const badge=db.doc(`verifiedContributors/${u.uid}`);
  assert.equal((await badge.get()).get('verified'),true);
  await run(staff,'verification-admin',{id:next.id,command:'revoked'});
  assert.equal((await badge.get()).exists,false);
  assert.equal(await balance(u),5000);
  await purgeContributions(db,u.uid);
  assert.equal((await db.doc('verificationApplications/'+next.id).get()).exists,false);
});

test('publishing modes: open by default, review when restricted, paused without charges; code fee is 100',async()=>{
  await admin();await db.doc('config/app').set({});
  const user=await seedUser('new-policy-user',1000);
  const code={requestId:'code-one',term:'Zelvaglow',meaning:'A positive test expression.',example:'',category:'Social'};
  const created=await run(user,'create-code',code);
  assert.equal(created.live,true);assert.equal(await balance(user),900);
  assert.equal((await run(user,'create-code',code)).duplicate,true);assert.equal(await balance(user),900);
  assert.equal((await db.doc('communityWords/'+created.termId).get()).get('status'),'live');
  const posted=await run(user,'create-post',{...code,requestId:'post-existing',category:'Slang'});
  assert.equal(await status('communityPosts',posted.id),'approved');assert.equal(await balance(user),850);
  await run(staff,'post-admin',{id:posted.id,command:'hide'});
  assert.equal(await status('communityPosts',posted.id),'hidden');
  await run(staff,'post-admin',{id:posted.id,command:'restore'});
  assert.equal(await status('communityPosts',posted.id),'approved');
  await db.doc('config/app').set({dictionaryPostingMode:'review',postPostingMode:'review'});
  const pending=await run(user,'create-code',{...code,requestId:'review-code',term:'Zelvareview'});
  assert.equal(pending.live,false);assert.equal(await status('submissions',pending.id),'pending');
  await assert.rejects(run(user,'code-admin',{id:pending.id,command:'approve'}),rejectCode('permission-denied'));
  await run(staff,'code-admin',{id:pending.id,command:'approve'});
  assert.equal(await status('submissions',pending.id),'accepted');
  await db.doc('config/app').set({dictionaryPostingMode:'paused',postPostingMode:'paused'});
  const before=await balance(user);
  await assert.rejects(run(user,'create-code',{...code,requestId:'blocked-code',term:'Zelvapaused'}),rejectCode('failed-precondition'));
  await assert.rejects(run(user,'create-post',{...code,requestId:'blocked-post',category:'Slang'}),rejectCode('failed-precondition'));
  assert.equal(await balance(user),before);
  await run(staff,'post-admin',{id:posted.id,command:'delete'});
  assert.equal((await db.doc('communityPosts/'+posted.id).get()).exists,false);
});

test('daily application accepts a bundled code and chat pass charges 30 once per UTC day',async()=>{
  await admin();const user=await seedUser('chat-pass-user',1000);
  const code=require('../lib/validation/dictionary.json').selectable[0];
  const application=await run(user,'apply-daily',{requestId:'any-code',wordSource:'bundled',wordId:code.id,date:'2026-11-29'});
  assert.equal(await status('dailyCodeApplications',application.id),'pending');assert.equal(await balance(user),900);
  const results=await Promise.all([run(user,'chat-pass'),run(user,'chat-pass')]);
  assert.equal(results.filter(r=>r.duplicate).length,1);assert.equal(await balance(user),870);
  assert.equal((await run(user,'chat-pass-status')).active,true);
  assert.equal((await run(user,'chat-pass-status',{},now+86400000)).active,false);
  await run(user,'chat-pass',{},now+86400000);assert.equal(await balance(user),840);
});

test('AdMob signature rejects tampering; verified callbacks credit once and fund account fees',async()=>{
  const {generateKeyPairSync,sign}=require('node:crypto');
  const {verifyRewardQuery,creditAdReward}=require('../lib/adRewards');
  const {privateKey,publicKey}=generateKeyPairSync('ec',{namedCurve:'prime256v1'});
  const key=publicKey.export({type:'spki',format:'pem'});
  const user=await seedUser('reward-user',0);
  const query='ad_unit=4151797642&reward_amount=10&transaction_id=verified-ad-one&user_id='+user.uid;
  const signature=sign('sha256',Buffer.from(query),privateKey).toString('base64url');
  const signed=query+'&signature='+signature+'&key_id=1';
  const verified=verifyRewardQuery(signed,new Map([['1',key]]));
  assert.throws(()=>verifyRewardQuery(signed.replace('reward_amount=10','reward_amount=100'),new Map([['1',key]])));
  assert.throws(()=>verifyRewardQuery(signed,new Map([['2',key]])));
  await Promise.all([creditAdReward(db,verified),creditAdReward(db,verified)]);
  assert.equal(await balance(user),10);
  for(const transaction of ['verified-ad-two','verified-ad-three','verified-ad-four','verified-ad-five']){
    const data=new URLSearchParams(verified);data.set('transaction_id',transaction);await creditAdReward(db,data);
  }
  assert.equal(await balance(user),50);
  await run(user,'create-post',{requestId:'ad-funded-post',term:'Zelvareward',meaning:'An ad-funded test expression.',category:'Slang'});
  assert.equal(await balance(user),0);
});

test('500 audited admin-granted tokens fund code creation, posts, daily chat and Daily Code exactly once',async()=>{
  await admin();await db.doc('config/app').set({});
  const user=await seedUser('release-admin-grant-user');
  const at=Timestamp.fromMillis(now),batch=db.batch();
  batch.set(db.doc('auditLogs/release-real-grant'),{actor:staff.uid,role:'super_admin',action:'tokens.send',target:`users/${user.uid}`,summary:'Sent 500 tokens — release account grant',at});
  batch.set(db.doc(`users/${user.uid}/tokenLedger/release-real-grant`),{type:'adjustment',ref:'admin-grant',amount:500,balanceAfter:500,lastAuditId:'release-real-grant',createdAt:at});
  batch.set(db.doc(`users/${user.uid}/tokenWallet/wallet`),{balance:500,earnedTotal:500,purchasedTotal:0,spentTotal:0});
  await batch.commit();
  assert.equal(await balance(user),500);
  const codeInput={requestId:'grant-code',term:'Zelvagrantflow',meaning:'An original test expression for a positive moment.',category:'Social',example:''};
  const code=await run(user,'create-code',codeInput);
  assert.equal(code.live,true);assert.equal(await balance(user),400);
  const post={requestId:'grant-post',term:codeInput.term,meaning:codeInput.meaning,category:'Slang'};
  const created=await run(user,'create-post',post);
  assert.equal(await status('communityPosts',created.id),'approved');assert.equal(await balance(user),350);
  await Promise.all([run(user,'chat-pass'),run(user,'chat-pass')]);
  assert.equal((await run(user,'chat-pass-status')).active,true);assert.equal(await balance(user),320);
  const application={requestId:'grant-daily',wordSource:'community',wordId:code.termId,date:'2026-12-01'};
  const daily=await run(user,'apply-daily',application);
  assert.equal(await balance(user),220);
  await run(staff,'daily-admin',{id:daily.id,command:'approve'});
  await run(staff,'daily-admin',{id:daily.id,command:'schedule',date:'2026-12-01'});
  assert.equal(await status('dailyCodeApplications',daily.id),'scheduled');
  await run(user,'create-code',codeInput);await run(user,'create-post',post);await run(user,'apply-daily',application);await run(user,'chat-pass');
  assert.equal(await balance(user),220);
  const wallet=(await db.doc(`users/${user.uid}/tokenWallet/wallet`).get()).data();
  assert.equal(wallet.balance,220);
  assert.equal((await db.collection(`users/${user.uid}/tokenLedger`).where('type','==','feature_fee').get()).size,4);
});
