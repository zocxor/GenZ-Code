import test from 'node:test';
import assert from 'node:assert/strict';
import {buildTree, chainStats, leaders, uplineOf, chainRows, csvCell, type Claim} from '../src/lib/referralTree';

const c = (newUserUid: string, referrerUid: string, t: number): Claim => ({newUserUid, referrerUid, code: 'GZ' + referrerUid.toUpperCase().padEnd(6, 'X').slice(0, 6), createdAtMs: t});
// lead ─┬─ a ─┬─ a1 ── a1x
//       │     └─ a2
//       ├─ b
//       └─ c        other ── o1
const claims = [c('a', 'lead', 1), c('b', 'lead', 2), c('c', 'lead', 3), c('a1', 'a', 4), c('a2', 'a', 5), c('a1x', 'a1', 6), c('o1', 'other', 7)];

test('referral chain: direct invites, whole chain, levels and depth for a lead user', () => {
  const tree = buildTree(claims);
  assert.deepEqual(chainStats(tree, 'lead'), {direct: 3, total: 6, depth: 3, levels: [3, 2, 1], lastJoinMs: 6});
  assert.deepEqual(chainStats(tree, 'a'), {direct: 2, total: 3, depth: 2, levels: [2, 1], lastJoinMs: 6});
  assert.deepEqual(chainStats(tree, 'b'), {direct: 0, total: 0, depth: 0, levels: [], lastJoinMs: 0});
});

test('referral chain: leaders are ranked by whole chain, then direct invites', () => {
  const ranked = leaders(buildTree(claims));
  // Ties (other, a1: 1 invite each) go to the most recent sign-up first.
  assert.deepEqual(ranked.map(r => [r.uid, r.direct, r.total]), [['lead', 3, 6], ['a', 2, 3], ['other', 1, 1], ['a1', 1, 1]]);
  assert.deepEqual(leaders(buildTree(claims), 1).map(r => r.uid), ['lead']);
});

test('referral chain: upline walks from a user back to the lead user', () => {
  const tree = buildTree(claims);
  assert.deepEqual(uplineOf(tree, 'a1x').map(x => x.referrerUid), ['a1', 'a', 'lead']);
  assert.deepEqual(uplineOf(tree, 'lead'), []);
});

test('referral chain: one claim per user, no self-referral, cycle-safe', () => {
  const tree = buildTree([c('x', 'y', 1), c('x', 'z', 2), c('s', 's', 3), c('y', 'x', 4)]);
  assert.equal(tree.parentOf.get('x')!.referrerUid, 'y', 'first claim wins');
  assert.equal(tree.parentOf.has('s'), false, 'self-referral ignored');
  assert.deepEqual(chainStats(tree, 'x'), {direct: 1, total: 1, depth: 1, levels: [1], lastJoinMs: 4}, 'a loop never counts anyone twice');
  assert.deepEqual(uplineOf(tree, 'x').map(u => u.referrerUid), ['y'], 'the upline stops instead of looping back');
});

test('referral chain: CSV rows by level and safe CSV cells', () => {
  const rows = chainRows(buildTree(claims), 'lead');
  assert.deepEqual(rows.map(r => [r.level, r.uid, r.invitedBy]), [[1, 'c', 'lead'], [1, 'b', 'lead'], [1, 'a', 'lead'], [2, 'a2', 'a'], [2, 'a1', 'a'], [3, 'a1x', 'a1']]);
  assert.equal(csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
  assert.equal(csvCell('plain'), 'plain');
});
