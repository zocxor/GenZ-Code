/**
 * Referral chains (pure — no Firebase, unit-tested).
 *
 * Every completed referral is one referralClaims/{newUserUid} document:
 * {referrerUid, code, createdAt}. A user can be referred only once, so the
 * claims form a forest: each user has at most one "invited by" parent, and a
 * lead user is the root of their chain. "Whole chain" counts everyone below a
 * user at any depth (the people they invited, the people those people invited,
 * and so on). Cycles cannot happen through the app (you can only use a code
 * that existed before you signed up), but every walk is cycle-safe anyway.
 */
export type Claim = {newUserUid: string; referrerUid: string; code: string; createdAtMs: number};
export type ReferralTree = {children: Map<string, Claim[]>; parentOf: Map<string, Claim>};
export type ChainStats = {direct: number; total: number; depth: number; levels: number[]; lastJoinMs: number};
export type Leader = ChainStats & {uid: string};

export function buildTree(claims: Claim[]): ReferralTree {
  const children = new Map<string, Claim[]>(), parentOf = new Map<string, Claim>();
  for (const c of claims) {
    if (!c.referrerUid || !c.newUserUid || c.referrerUid === c.newUserUid || parentOf.has(c.newUserUid)) continue;
    parentOf.set(c.newUserUid, c);
    const list = children.get(c.referrerUid) ?? [];
    list.push(c);
    children.set(c.referrerUid, list);
  }
  for (const list of children.values()) list.sort((a, b) => b.createdAtMs - a.createdAtMs || a.newUserUid.localeCompare(b.newUserUid));
  return {children, parentOf};
}

/** Direct invites, whole-chain size, number of levels and per-level counts below `uid`. */
export function chainStats(tree: ReferralTree, uid: string, maxDepth = 50): ChainStats {
  const seen = new Set<string>([uid]);
  const levels: number[] = [];
  let frontier = [uid], lastJoinMs = 0;
  while (frontier.length && levels.length < maxDepth) {
    const next: string[] = [];
    for (const id of frontier) for (const c of tree.children.get(id) ?? []) {
      if (seen.has(c.newUserUid)) continue;
      seen.add(c.newUserUid);
      next.push(c.newUserUid);
      if (c.createdAtMs > lastJoinMs) lastJoinMs = c.createdAtMs;
    }
    if (!next.length) break;
    levels.push(next.length);
    frontier = next;
  }
  const total = levels.reduce((a, b) => a + b, 0);
  return {direct: levels[0] ?? 0, total, depth: levels.length, levels, lastJoinMs};
}

/** Everyone who invited at least one person, biggest whole chain first. */
export function leaders(tree: ReferralTree, limitN = 100): Leader[] {
  return [...tree.children.keys()]
    .map(uid => ({uid, ...chainStats(tree, uid)}))
    .sort((a, b) => b.total - a.total || b.direct - a.direct || b.lastJoinMs - a.lastJoinMs || a.uid.localeCompare(b.uid))
    .slice(0, Math.max(0, limitN));
}

/** Who invited `uid`, then who invited them, … up to the lead user (nearest first). */
export function uplineOf(tree: ReferralTree, uid: string, max = 50): Claim[] {
  const out: Claim[] = [], seen = new Set<string>([uid]);
  let cur = tree.parentOf.get(uid);
  while (cur && out.length < max && !seen.has(cur.referrerUid)) {
    out.push(cur);
    seen.add(cur.referrerUid);
    cur = tree.parentOf.get(cur.referrerUid);
  }
  return out;
}

/** Flat rows (level, user, invited by, joined) for a CSV export of one chain. */
export function chainRows(tree: ReferralTree, uid: string, maxDepth = 50): {level: number; uid: string; invitedBy: string; code: string; joinedMs: number}[] {
  const rows: {level: number; uid: string; invitedBy: string; code: string; joinedMs: number}[] = [];
  const seen = new Set<string>([uid]);
  let frontier = [uid], level = 0;
  while (frontier.length && level < maxDepth) {
    level++;
    const next: string[] = [];
    for (const id of frontier) for (const c of tree.children.get(id) ?? []) {
      if (seen.has(c.newUserUid)) continue;
      seen.add(c.newUserUid);
      next.push(c.newUserUid);
      rows.push({level, uid: c.newUserUid, invitedBy: c.referrerUid, code: c.code, joinedMs: c.createdAtMs});
    }
    frontier = next;
  }
  return rows;
}

export const csvCell = (v: string | number) => {
  const s = String(v);
  return /[",\n]/.test(s) || /^[=+\-@]/.test(s) ? `"${s.replace(/^([=+\-@])/, "'$1").replace(/"/g, '""')}"` : s;
};
