/**
 * Merges Daily Code data into one admin list:
 * - dailyCodeDates/{date}: reservations (admin-scheduled words, or {applicationId} for user requests)
 * - dailyCodePublic/{date}: what was actually published on a date
 * - dailyCodeApplications: user requests (100 Credits, 1 free a month), including rejected/cancelled ones
 * Pure: no Firebase imports, so it is unit-tested.
 */
export type DailyTab = 'upcoming' | 'pending' | 'approved' | 'published' | 'rejected' | 'all';
type Doc = Record<string, unknown> & {id: string};
export type DailyRow = {
  key: string; date: string; code: string; meaning: string; category: string; submittedBy: string; uid?: string;
  applicationId?: string; approval: string; publication: string; edited: boolean; canEdit: boolean; canApprove: boolean; tabs: DailyTab[];
};
const str = (v: unknown) => typeof v === 'string' ? v : '';

export function dailyRows({slots, published, applications, closed, today}: {slots: Doc[]; published: Doc[]; applications: Record<string, Record<string, unknown>>; closed: Doc[]; today: string}): DailyRow[] {
  const bySlot = new Map(slots.map(s => [s.id, s]));
  const byPub = new Map(published.map(p => [p.id, p]));
  const dates = [...new Set([...bySlot.keys(), ...byPub.keys()])].sort();
  const rows: DailyRow[] = dates.map(date => {
    const slot = bySlot.get(date), pub = byPub.get(date);
    const applicationId = str(slot?.applicationId) || undefined;
    const app = applicationId ? applications[applicationId] : undefined;
    const edited = slot?.edited === true;
    const source = pub ?? (edited ? slot : app ?? slot) ?? {};
    const slotStatus = str(slot?.status);
    const approval = app ? str(app.status) || 'pending' : slot ? (slotStatus === 'pending' ? 'pending' : 'approved') : 'automatic';
    const publication = pub ? 'published' : date < today ? 'missed' : date === today ? 'publishing today' : 'scheduled';
    const upcoming = date > today && !pub;
    const canEdit = upcoming && !!slot && ['scheduled', 'pending'].includes(slotStatus);
    const canApprove = !!app && str(app.status) === 'pending';
    const tabs: DailyTab[] = [];
    if (date >= today) tabs.push('upcoming');
    if (approval === 'pending') tabs.push('pending');
    if (['approved', 'scheduled'].includes(approval) && !pub) tabs.push('approved');
    if (pub) tabs.push('published');
    return {key: 'd' + date, date, code: str(source.term), meaning: str(source.meaning), category: str(source.category),
      submittedBy: app ? `${str(app.name) || 'Code Explorer'} · user request` : slot ? (str(slot.replacedBy) ? 'Administrator (replaced)' : 'Administrator') : 'Automatic word',
      uid: app ? str(app.uid) || undefined : undefined, applicationId, approval, publication, edited, canEdit, canApprove, tabs};
  });
  for (const a of closed) {
    rows.push({key: 'a' + a.id, date: str(a.requestedDate) || str(a.reservedDate) || '—', code: str(a.term), meaning: str(a.meaning), category: str(a.category),
      submittedBy: `${str(a.name) || 'Code Explorer'} · user request`, uid: str(a.uid) || undefined, applicationId: a.id,
      approval: str(a.status), publication: 'not published', edited: false, canEdit: false, canApprove: false, tabs: ['rejected']});
  }
  return rows;
}
