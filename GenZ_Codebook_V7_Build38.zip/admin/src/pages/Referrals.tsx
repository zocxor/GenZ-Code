/**
 * Referrals: who invited whom.
 *
 * Lead users ranked by the size of their whole chain (people they invited, the
 * people those people invited, and so on), a search by invite code / user ID /
 * e-mail, and a chain view that shows every level, who invited each person,
 * and a CSV export. Reads only referralClaims (code + user IDs + date), which
 * the rules already allow for roles with users.read. Names come from the synced
 * profile and e-mails from the directory, only for roles allowed to see them;
 * everyone else sees the user's public invite code.
 */
import React, {useEffect, useMemo, useState} from 'react';
import {collection, query, orderBy, limit, getDocs, getDoc, getCount, doc, where} from 'firebase/firestore/lite';
import {db, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can} from '../rbac';
import {resolveReferrerName} from '../lib/referralNames';
import {classifyUserSearch} from '../lib/userSearch';
import {buildTree, chainStats, leaders, uplineOf, chainRows, csvCell, type Claim, type ReferralTree} from '../lib/referralTree';
import {referralCodeForUid} from '../../../shared/referral';
import {Card, Stats, Stat, Skeleton, Notice, Pill, fmt, when, download, useLoad} from '../ui';

const LIMIT = 10000;
const PAGE = 100;
type Label = {name: string | null; email: string | null; code: string};
const labelCache = new Map<string, Promise<Label>>();
function labelFor(uid: string, pii: boolean): Promise<Label> {
  const key = (pii ? 'p:' : 'n:') + uid;
  let p = labelCache.get(key);
  if (!p) {
    p = Promise.all([
      resolveReferrerName(uid),
      pii ? getDoc(doc(db, 'directory', uid)).then(d => (typeof d.get('email') === 'string' ? d.get('email') as string : null)).catch(() => null) : Promise.resolve(null),
    ]).then(([name, email]) => ({name, email, code: referralCodeForUid(uid)}));
    labelCache.set(key, p);
  }
  return p;
}
function useLabels(uids: string[], pii: boolean): Record<string, Label> {
  const key = uids.join(',');
  const [labels, setLabels] = useState<Record<string, Label>>({});
  useEffect(() => {
    let live = true;
    const ids = key ? key.split(',') : [];
    void Promise.all(ids.map(async id => [id, await labelFor(id, pii)] as const)).then(rows => {if (live) setLabels(Object.fromEntries(rows));});
    return () => {live = false;};
  }, [key, pii]);
  return labels;
}
const nameOf = (uid: string, l?: Label) => l?.name ?? `User ${l?.code ?? referralCodeForUid(uid)}`;
function Who({uid, label}: {uid: string; label?: Label}) {
  return <span><strong>{nameOf(uid, label)}</strong>{label?.email && <span className="muted small"> · {label.email}</span>}<span className="muted small"> · {label?.code ?? referralCodeForUid(uid)}</span></span>;
}

export default function Referrals() {
  const s = useSession();
  const pii = can(s.role, 'users.pii');
  const data = useLoad(async () => {
    const col = collection(db, 'referralClaims');
    const [count, snap] = await Promise.all([getCount(col), getDocs(query(col, orderBy('createdAt', 'desc'), limit(LIMIT)))]);
    const claims: Claim[] = snap.docs.map(d => {
      const v = d.data() as {referrerUid?: unknown; code?: unknown; createdAt?: {toMillis?: () => number}};
      return {newUserUid: d.id, referrerUid: typeof v.referrerUid === 'string' ? v.referrerUid : '', code: typeof v.code === 'string' ? v.code : '', createdAtMs: v.createdAt?.toMillis?.() ?? 0};
    });
    return {total: count.data().count, claims, capped: snap.size === LIMIT};
  }, []);
  const tree = useMemo(() => (data.data ? buildTree(data.data.claims) : null), [data.data]);
  const top = useMemo(() => (tree ? leaders(tree, 50) : []), [tree]);
  const [focus, setFocus] = useState<string | null>(null);
  const [search, setSearch] = useState(''), [searchError, setSearchError] = useState(''), [busy, setBusy] = useState(false);
  const topLabels = useLabels(focus ? [] : [...new Set(top.flatMap(t => [t.uid, tree?.parentOf.get(t.uid)?.referrerUid ?? '']).filter(Boolean))], pii);

  const find = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tree) return;
    setSearchError('');
    const q = classifyUserSearch(search);
    if (q.kind === 'invalid') {setSearchError('Enter an invite code (GZXXXXXX), a user ID or an e-mail address.'); return;}
    setBusy(true);
    try {
      let uid: string | null = null;
      if (q.kind === 'referral') {
        const ref = await getDoc(doc(db, 'referrals', q.code)).catch(() => null);
        uid = (ref?.exists() && typeof ref.get('uid') === 'string' ? ref.get('uid') as string : null)
          ?? [...tree.children.keys(), ...tree.parentOf.keys()].find(id => referralCodeForUid(id) === q.code) ?? null;
      } else if (q.kind === 'email') {
        if (!pii) {setSearchError('Your role cannot search by e-mail. Use the invite code or user ID.'); return;}
        const snap = await getDocs(query(collection(db, 'directory'), where('email', '>=', q.prefix), where('email', '<=', q.prefix + ''), limit(2)));
        if (snap.size > 1) {setSearchError('More than one account starts with that e-mail. Type the full address.'); return;}
        uid = snap.docs[0]?.id ?? null;
      } else uid = q.id;
      if (!uid) {setSearchError('No account found.'); return;}
      setFocus(uid);
    } catch (err) {setSearchError(errorMessage(err));}
    finally {setBusy(false);}
  };

  if (data.loading) return <Card title="Referrals"><Skeleton rows={6} /></Card>;
  if (data.error || !data.data || !tree) return <Card title="Referrals"><Notice kind="error">{errorMessage(data.error)}</Notice><button className="btn" onClick={data.reload}>Retry</button></Card>;
  const d = data.data;

  return <>
    <Stats>
      <Stat label="Referred sign-ups" num={d.total} hint="accounts created with an invite code" tint="green" />
      <Stat label="Lead users" num={tree.children.size} hint="invited at least one person" tint="blue" />
      <Stat label="Biggest chain" num={top[0]?.total ?? 0} hint={top[0] ? `${top[0].direct} direct · ${top[0].depth} level${top[0].depth === 1 ? '' : 's'}` : 'no referrals yet'} tint="amber" />
    </Stats>
    <Card title="Find a user's chain" subtitle="Search by invite code (GZXXXXXX), user ID, or e-mail (roles that can see e-mails).">
      <form className="row wrap" onSubmit={e => void find(e)}>
        <input className="grow" aria-label="Invite code, user ID or e-mail" placeholder={pii ? 'GZXXXXXX, user ID or e-mail' : 'GZXXXXXX or user ID'} value={search} onChange={e => setSearch(e.target.value)} />
        <button className="btn primary" disabled={busy || !search.trim()}>{busy ? 'Searching…' : 'Show chain'}</button>
        {focus && <button type="button" className="btn" onClick={() => setFocus(null)}>← All lead users</button>}
        <button type="button" className="btn ghost" onClick={data.reload} title="Reload referral data">↻ Refresh</button>
      </form>
      {searchError && <Notice kind="error">{searchError}</Notice>}
      {d.capped && <p className="small muted">Showing chains from the {fmt(LIMIT)} most recent referral sign-ups; the total above is exact.</p>}
    </Card>
    {focus ? <Chain tree={tree} uid={focus} pii={pii} onFocus={setFocus} /> :
    <Card title="Lead users" subtitle="Ranked by whole chain: everyone who joined through them, at every level. Click a row to see the chain.">
      {!top.length ? <p className="muted">No one has joined with an invite code yet.</p> :
      <div className="table-wrap"><table><thead><tr><th>#</th><th>Lead user</th><th>Joined via</th><th>Direct invites</th><th>Whole chain</th><th>Levels</th><th>Last join</th></tr></thead>
        <tbody>{top.map((t, i) => <tr key={t.uid} className="clickable" tabIndex={0} onClick={() => setFocus(t.uid)} onKeyDown={e => e.key === 'Enter' && setFocus(t.uid)}>
          <td>{i + 1}</td><td><Who uid={t.uid} label={topLabels[t.uid]} /></td><td>{(() => {const by = tree.parentOf.get(t.uid)?.referrerUid; return by ? <span className="small">via {nameOf(by, topLabels[by])}</span> : <Pill tone="good">Started the chain</Pill>;})()}</td><td><strong>{fmt(t.direct)}</strong></td><td>{fmt(t.total)}</td><td>{t.depth}</td><td className="small">{when(t.lastJoinMs)}</td>
        </tr>)}</tbody></table></div>}
    </Card>}
  </>;
}

function Chain({tree, uid, pii, onFocus}: {tree: ReferralTree; uid: string; pii: boolean; onFocus: (uid: string) => void}) {
  const stats = useMemo(() => chainStats(tree, uid), [tree, uid]);
  const up = useMemo(() => uplineOf(tree, uid), [tree, uid]);
  const labels = useLabels([uid, ...up.map(u => u.referrerUid)], pii);
  const [exporting, setExporting] = useState(false), [error, setError] = useState('');
  const exportCsv = async () => {
    setExporting(true); setError('');
    try {
      const rows = chainRows(tree, uid);
      const names = new Map<string, Label>();
      for (let i = 0; i < rows.length; i += 25) {
        const part = rows.slice(i, i + 25);
        (await Promise.all(part.map(async r => [r.uid, await labelFor(r.uid, pii)] as const))).forEach(([id, l]) => names.set(id, l));
      }
      const lines = [['Level', 'User ID', 'Name', ...(pii ? ['E-mail'] : []), 'Own invite code', 'Invited by (user ID)', 'Code used', 'Joined'].join(',')];
      for (const r of rows) {
        const l = names.get(r.uid);
        lines.push([r.level, r.uid, l?.name ?? '', ...(pii ? [l?.email ?? ''] : []), referralCodeForUid(r.uid), r.invitedBy, r.code, r.joinedMs ? new Date(r.joinedMs).toISOString() : ''].map(csvCell).join(','));
      }
      download(`referral-chain-${referralCodeForUid(uid)}.csv`, 'text/csv', lines.join('\n'));
    } catch (e) {setError(errorMessage(e));}
    finally {setExporting(false);}
  };
  return <Card title="Referral chain" subtitle="Everyone who joined through this user. Expand a person to see who they invited." actions={stats.total ? <button className="btn" disabled={exporting} onClick={() => void exportCsv()}>{exporting ? 'Preparing…' : '⬇ Download CSV'}</button> : undefined}>
    <div className="ref-head">
      <Who uid={uid} label={labels[uid]} />
      <div className="muted small">User ID {uid}</div>
      {up.length ? <div className="row wrap small"><span className="muted">Invited by:</span>{up.map((u, i) => <React.Fragment key={u.referrerUid}>{i > 0 && <span className="muted">←</span>}<button className="btn ghost" onClick={() => onFocus(u.referrerUid)}>{nameOf(u.referrerUid, labels[u.referrerUid])}</button></React.Fragment>)}{up.length > 0 && <Pill tone="info">lead user: {nameOf(up[up.length - 1]!.referrerUid, labels[up[up.length - 1]!.referrerUid])}</Pill>}</div>
        : <div className="small"><Pill tone="good">Lead user</Pill> <span className="muted">joined without an invite code</span></div>}
    </div>
    <Stats>
      <Stat label="Direct invites" num={stats.direct} hint="signed up with this user's code" tint="green" />
      <Stat label="Whole chain" num={stats.total} hint="all levels below this user" tint="blue" />
      <Stat label="Levels deep" num={stats.depth} hint={stats.levels.map((n, i) => `L${i + 1}: ${n}`).join(' · ') || '—'} tint="amber" />
    </Stats>
    {error && <Notice kind="error">{error}</Notice>}
    {stats.total ? <Branch tree={tree} parent={uid} level={1} pii={pii} onFocus={onFocus} /> : <p className="muted">No one has joined with this user's code yet.</p>}
  </Card>;
}

function Branch({tree, parent, level, pii, onFocus}: {tree: ReferralTree; parent: string; level: number; pii: boolean; onFocus: (uid: string) => void}) {
  const kids = tree.children.get(parent) ?? [];
  const [shown, setShown] = useState(PAGE);
  const [open, setOpen] = useState<Set<string>>(new Set());
  const list = kids.slice(0, shown);
  const labels = useLabels(list.map(c => c.newUserUid), pii);
  const toggle = (id: string) => setOpen(prev => {const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next;});
  return <ul className="ref-tree" aria-label={`Level ${level}`}>
    {list.map(c => {
      const st = chainStats(tree, c.newUserUid), isOpen = open.has(c.newUserUid);
      return <li key={c.newUserUid}>
        <div className="ref-row">
          {st.direct ? <button className="ref-toggle" aria-expanded={isOpen} aria-label={isOpen ? 'Hide their invites' : 'Show their invites'} onClick={() => toggle(c.newUserUid)}>{isOpen ? '▾' : '▸'}</button> : <span className="ref-dot" aria-hidden="true" />}
          <Pill tone="neutral">L{level}</Pill>
          <Who uid={c.newUserUid} label={labels[c.newUserUid]} />
          <span className="muted small">joined {when(c.createdAtMs)}</span>
          {st.direct > 0 && <Pill tone="info">{st.direct} invited · {st.total} in chain</Pill>}
          {st.direct > 0 && <button className="btn ghost" onClick={() => onFocus(c.newUserUid)}>Open chain</button>}
        </div>
        {isOpen && <Branch tree={tree} parent={c.newUserUid} level={level + 1} pii={pii} onFocus={onFocus} />}
      </li>;
    })}
    {kids.length > shown && <li><button className="btn" onClick={() => setShown(n => n + PAGE)}>Show more ({fmt(kids.length - shown)} left)</button></li>}
  </ul>;
}
