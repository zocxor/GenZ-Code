/**
 * Follow Us / Stay connected: official social channels and Help & Support email.
 * Only the fixed https URLs in shared/brand.ts are opened (no user- or server-supplied
 * links), in the system browser or the installed app. If nothing can open a link, it is
 * copied instead so the user is never stuck. No rewards are offered for following
 * (Google Play: no incentivised social actions).
 */
import React,{useState} from 'react';
import {FontAwesome} from '@expo/vector-icons';
import {Linking,Pressable,StyleSheet,Text,View} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {LinearGradient} from 'expo-linear-gradient';
import {C,Icon,type IconName} from './ui';
import {SOCIAL_LINKS,SUPPORT_EMAIL,supportMailto} from '../shared/brand';

// Each network's own colours and shape: Instagram's rounded-square gradient, Facebook's blue circle
// with the white "f", WhatsApp's green circle, and a red e-mail badge. Glyphs come from the icon font.
type Look={glyph:React.ComponentProps<typeof FontAwesome>['name'];colors:string[];locations?:number[];square?:boolean;size:number};
const LOOK:Record<string,Look>={
  instagram:{glyph:'instagram',colors:['#FEDA75','#FA7E1E','#D62976','#962FBF','#4F5BD5'],locations:[0,.25,.5,.75,1],square:true,size:27},
  facebook:{glyph:'facebook',colors:['#1877F2','#1877F2'],size:25},
  whatsapp:{glyph:'whatsapp',colors:['#25D366','#25D366'],size:28},
  email:{glyph:'envelope',colors:['#EA4335','#D93025'],size:21},
};
function BrandIcon({id,dim}:{id:string;dim:number}){
  const l=LOOK[id]!;
  return <LinearGradient colors={l.colors as [string,string,...string[]]} locations={l.locations as [number,number,...number[]]|undefined} start={{x:0,y:1}} end={{x:1,y:0}}
    style={{width:dim,height:dim,borderRadius:l.square?dim*.28:dim/2,alignItems:'center',justifyContent:'center',shadowColor:'#0B1530',shadowOpacity:.18,shadowRadius:5,shadowOffset:{width:0,height:2},elevation:3}}>
    <FontAwesome name={l.glyph} size={l.size*dim/48} color="#fff" style={id==='facebook'?{marginTop:dim*.12}:undefined}/>
  </LinearGradient>;
}
const allowed=new Set<string>([...SOCIAL_LINKS.map(l=>l.url)]);

async function openLink(url:string,fallback:string,setNote:(m:string)=>void){
  setNote('');
  if(!allowed.has(url)&&!url.startsWith(`mailto:${SUPPORT_EMAIL}`))return;
  try{await Linking.openURL(url);}
  catch{await Clipboard.setStringAsync(fallback).catch(()=>{});setNote(`Couldn’t open it on this device, so ${fallback} was copied.`);}
}
/** Compact horizontal "Follow us" icons for the main profile page. */
export function FollowUsRow(){
  const [note,setNote]=useState('');
  const items=[...SOCIAL_LINKS.map(l=>({id:l.id as string,label:l.id==='whatsapp'?'WhatsApp':l.label,url:l.url as string,fallback:l.url as string})),{id:'email',label:'Email us',url:supportMailto('GenZ Codebook – help request'),fallback:SUPPORT_EMAIL}];
  return <View style={s.rowCard}>
    <Text accessibilityRole="header" style={s.rowTitle}>Follow us</Text>
    <View style={s.iconRow}>{items.map(i=>{return <Pressable key={i.id} accessibilityRole="link" accessibilityLabel={`${i.label}. Opens outside the app.`} hitSlop={4} onPress={()=>void openLink(i.url,i.fallback,setNote)} style={({pressed})=>[s.iconItem,pressed&&{opacity:.8,transform:[{scale:.95}]}]}>
      <BrandIcon id={i.id} dim={50}/>
      <Text style={s.iconLabel} numberOfLines={1}>{i.label}</Text>
    </Pressable>;})}</View>
    {!!note&&<Text accessibilityRole="alert" style={s.sub}>{note}</Text>}
  </View>;
}

export default function FollowUs(){
  const [note,setNote]=useState('');
  const open=(url:string,fallback:string)=>openLink(url,fallback,setNote);
  const rows=[...SOCIAL_LINKS.map(l=>({id:l.id,label:l.label,sub:l.handle,url:l.url as string,fallback:l.url as string})),
    {id:'email',label:'Help & Support',sub:SUPPORT_EMAIL,url:supportMailto('GenZ Codebook – help request'),fallback:SUPPORT_EMAIL}];
  return <View style={s.card}>
    <Text accessibilityRole="header" style={s.title}>Stay connected</Text>
    <Text style={s.sub}>New codes, Daily Code picks and updates.</Text>
    <View style={s.grid}>{rows.map(r=>{return <Pressable key={r.id} accessibilityRole="link" accessibilityLabel={`${r.label}, ${r.sub}. Opens outside the app.`} onPress={()=>void open(r.url,r.fallback)} style={({pressed})=>[s.item,pressed&&{opacity:.8,transform:[{scale:.98}]}]}>
      <BrandIcon id={r.id} dim={42}/>
      <View style={{flex:1,minWidth:0}}><Text style={s.label} numberOfLines={1}>{r.label}</Text><Text style={s.handle} numberOfLines={1}>{r.sub}</Text></View>
      <Icon name="open-outline" size={15} color={C.muted}/>
    </Pressable>;})}</View>
    {!!note&&<Text accessibilityRole="alert" style={s.sub}>{note}</Text>}
  </View>;
}
const s=StyleSheet.create({
  card:{backgroundColor:'#fff',borderRadius:20,padding:14,gap:8,borderWidth:1,borderColor:'#E2E8F5'},
  title:{fontSize:17,fontWeight:'900',color:C.ink},sub:{fontSize:13,color:C.muted,lineHeight:18},
  grid:{gap:8,marginTop:2},item:{flexDirection:'row',alignItems:'center',gap:10,minHeight:52,paddingHorizontal:10,borderRadius:14,backgroundColor:'#F5F7FE'},
  icon:{width:36,height:36,borderRadius:11,alignItems:'center',justifyContent:'center'},
  label:{fontSize:14.5,fontWeight:'800',color:C.ink},handle:{fontSize:12,color:C.muted},
  rowCard:{backgroundColor:'#fff',borderRadius:20,paddingVertical:12,paddingHorizontal:10,gap:8,borderWidth:1,borderColor:'#E2E8F5'},rowTitle:{fontSize:15,fontWeight:'900',color:C.ink,paddingHorizontal:4},
  iconRow:{flexDirection:'row',justifyContent:'space-around'},iconItem:{alignItems:'center',gap:5,minWidth:64},circle:{width:48,height:48,borderRadius:24,alignItems:'center',justifyContent:'center'},iconLabel:{fontSize:11.5,fontWeight:'700',color:C.ink},
});
