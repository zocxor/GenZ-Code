/** Game levels by XP (shown on the profile and the public leaderboard). */
export const RANKS: [number, string][] = [[0, 'Rookie'], [100, 'Decoder'], [250, 'Code Cracker'], [500, 'Lingo Pro'], [900, 'Internet Linguist'], [1400, 'Code Legend']];
export function rankFor(xp: number) {
  let i = 0;
  while (i + 1 < RANKS.length && xp >= RANKS[i + 1]![0]) i++;
  const [floor, name] = RANKS[i]!;
  const next = RANKS[i + 1];
  return {level: i + 1, name, floor, next: next ? {xp: next[0], name: next[1]} : null, progress: next ? (xp - floor) / (next[0] - floor) : 1};
}
