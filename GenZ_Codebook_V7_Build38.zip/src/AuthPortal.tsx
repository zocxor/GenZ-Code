/**
 * Futuristic sign-in / sign-up controls for the account sheet.
 *  - AuthPortal: a dark "holo" panel with a neon gradient frame and a slow light sweep.
 *    Google keeps its OFFICIAL button (Google's branding rules; the owner asked for its original
 *    colours) inside a neon ring; the e-mail option is a matching neon tile.
 *  - NeonButton: the glowing gradient button for Sign in / Create account / Send reset.
 *  - NeonSwitch: the outlined pill that switches between Sign in and Create account.
 * The light sweep respects the system "reduce motion" setting.
 */
import React, {useEffect, useRef} from 'react';
import {Animated, Easing, Pressable, StyleSheet, Text, View} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {GoogleSigninButton} from '@react-native-google-signin/google-signin';
import {Icon, type IconName} from './ui';
import {useReducedMotion} from './motion';

const NEON = ['#22D3EE', '#6366F1', '#A855F7', '#EC4899'] as const;
const DEEP = ['#070B1F', '#111737', '#1B1145'] as const;

/** Dark panel with the two sign-in options side by side. */
export function AuthPortal({mode, busy, onGoogle, onEmail}: {mode: 'signin' | 'create'; busy: boolean; onGoogle: () => void; onEmail: () => void}) {
  const reduced = useReducedMotion();
  const sweep = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (reduced) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(sweep, {toValue: 1, duration: 2600, easing: Easing.inOut(Easing.quad), useNativeDriver: true}),
      Animated.delay(1800),
      Animated.timing(sweep, {toValue: 0, duration: 0, useNativeDriver: true}),
    ]));
    loop.start();
    return () => loop.stop();
  }, [reduced, sweep]);
  const create = mode === 'create';
  return <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.frame}>
    <LinearGradient colors={DEEP} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.panel}>
      {!reduced && <Animated.View pointerEvents="none" style={[p.sweep, {transform: [{translateX: sweep.interpolate({inputRange: [0, 1], outputRange: [-140, 420]})}, {rotate: '18deg'}]}]}>
        <LinearGradient colors={['rgba(255,255,255,0)', 'rgba(165,243,252,.16)', 'rgba(255,255,255,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={StyleSheet.absoluteFill} />
      </Animated.View>}
      <View style={p.head}>
        <View style={p.dot} />
        <Text style={p.eyebrow}>{create ? 'JOIN WITH' : 'SIGN IN WITH'}</Text>
        <View style={{flex: 1}} />
        <Icon name="shield-checkmark" size={13} color="#A5B4FC" />
        <Text style={p.secure}>SECURE</Text>
      </View>
      <Text style={p.title}>{create ? 'Create your account in seconds' : 'Welcome back'}</Text>
      <View style={p.row}>
        <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.ring}>
          <GoogleSigninButton accessibilityLabel={create ? 'Sign up with Google' : 'Sign in with Google'} style={{width: '100%', height: 48}} size={GoogleSigninButton.Size.Standard} color={GoogleSigninButton.Color.Light} disabled={busy} onPress={onGoogle} />
        </LinearGradient>
        <Pressable accessibilityRole="button" accessibilityLabel={create ? 'Sign up with your e-mail address' : 'Sign in with your e-mail address'} disabled={busy} onPress={onEmail} style={({pressed}) => [{flex: 1}, pressed && {transform: [{scale: .97}]}]}>
          <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={[p.ring, {flex: 0}]}>
            <LinearGradient colors={['#1E1B4B', '#312E81']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.emailTile}>
              <LinearGradient colors={['#22D3EE', '#A855F7']} style={p.emailIcon}><Icon name="mail" size={15} color="#fff" /></LinearGradient>
              <Text style={p.emailText}>E-mail</Text>
            </LinearGradient>
          </LinearGradient>
        </Pressable>
      </View>
      <View style={p.orRow}>
        <LinearGradient colors={['rgba(34,211,238,0)', 'rgba(34,211,238,.7)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={p.orLine} />
        <Text style={p.orText}>or type your e-mail below</Text>
        <LinearGradient colors={['rgba(168,85,247,.7)', 'rgba(168,85,247,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={p.orLine} />
      </View>
    </LinearGradient>
  </LinearGradient>;
}

/** Glowing gradient action button (Sign in with e-mail / Create account / Send reset). */
export function NeonButton({title, icon, disabled = false, onPress}: {title: string; icon: IconName; disabled?: boolean; onPress: () => void}) {
  return <Pressable accessibilityRole="button" accessibilityState={{disabled}} disabled={disabled} onPress={onPress} style={({pressed}) => [p.glow, disabled && {shadowOpacity: 0, elevation: 0}, pressed && {transform: [{scale: .98}]}]}>
    <LinearGradient colors={disabled ? ['#CBD5E1', '#CBD5E1'] : ['#06B6D4', '#6366F1', '#A855F7']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={p.neonButton}>
      <LinearGradient colors={['rgba(255,255,255,.28)', 'rgba(255,255,255,0)']} style={p.shine} pointerEvents="none" />
      <Icon name={icon} size={20} color="#fff" />
      <Text style={p.neonText}>{title}</Text>
      <View style={p.arrow}><Icon name="arrow-forward" size={16} color="#fff" /></View>
    </LinearGradient>
  </Pressable>;
}

/** Outlined neon pill that switches between Sign in and Create account. */
export function NeonSwitch({prompt, action, disabled = false, onPress}: {prompt: string; action: string; disabled?: boolean; onPress: () => void}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={`${prompt} ${action}`} disabled={disabled} onPress={onPress} style={({pressed}) => [{alignSelf: 'stretch'}, pressed && {opacity: .85}]}>
    <LinearGradient colors={NEON} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={p.switchRing}>
      <View style={p.switchInner}>
        <Text style={p.switchPrompt}>{prompt} </Text><Text style={p.switchAction}>{action}</Text>
        <Icon name="chevron-forward" size={15} color="#7C3AED" />
      </View>
    </LinearGradient>
  </Pressable>;
}

const p = StyleSheet.create({
  frame: {borderRadius: 20, padding: 1.5},
  panel: {borderRadius: 18.5, padding: 14, gap: 12, overflow: 'hidden'},
  sweep: {position: 'absolute', top: -40, bottom: -40, width: 70, left: 0},
  head: {flexDirection: 'row', alignItems: 'center', gap: 7},
  dot: {width: 8, height: 8, borderRadius: 4, backgroundColor: '#22D3EE', shadowColor: '#22D3EE', shadowOpacity: .9, shadowRadius: 6, shadowOffset: {width: 0, height: 0}, elevation: 4},
  eyebrow: {fontSize: 11, fontWeight: '900', letterSpacing: 2, color: '#67E8F9'},
  secure: {fontSize: 10, fontWeight: '900', letterSpacing: 1.4, color: '#A5B4FC'},
  title: {fontSize: 18, fontWeight: '900', color: '#F8FAFC', letterSpacing: -.2},
  row: {flexDirection: 'row', gap: 10, alignItems: 'center'},
  ring: {flex: 1, borderRadius: 10, padding: 2},
  emailTile: {height: 48, borderRadius: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9},
  emailIcon: {width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center'},
  emailText: {fontSize: 15, fontWeight: '800', color: '#fff', letterSpacing: .3},
  orRow: {flexDirection: 'row', alignItems: 'center', gap: 8},
  orLine: {flex: 1, height: 1.5, borderRadius: 1},
  orText: {fontSize: 11.5, fontWeight: '700', color: '#C7D2FE', letterSpacing: .3},
  glow: {borderRadius: 16, shadowColor: '#7C3AED', shadowOpacity: .45, shadowRadius: 14, shadowOffset: {width: 0, height: 6}, elevation: 8},
  neonButton: {minHeight: 56, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, paddingHorizontal: 48, overflow: 'hidden'},
  shine: {position: 'absolute', left: 0, right: 0, top: 0, height: '50%'},
  neonText: {fontSize: 16.5, fontWeight: '900', color: '#fff', letterSpacing: .3, flexShrink: 1},
  arrow: {position: 'absolute', right: 12, width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,.22)'},
  switchRing: {borderRadius: 999, padding: 1.5},
  switchInner: {minHeight: 46, borderRadius: 999, backgroundColor: '#fff', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 14},
  switchPrompt: {fontSize: 14, color: '#475569', fontWeight: '600'},
  switchAction: {fontSize: 14, color: '#6D28D9', fontWeight: '900'},
});
