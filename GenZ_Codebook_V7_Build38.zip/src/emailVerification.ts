/**
 * E-mail verification helpers.
 * Unverified accounts can't chat, post, comment, add words, use Credits or open the admin portal:
 * the Firestore rules and the server check the verified e-mail on every request. These helpers
 * only make the flow clear for the user: send (in the phone's language, returning to our site),
 * and re-check after the user taps the link.
 */
import type {User} from 'firebase/auth';

const CONTINUE_URL = 'https://gen-z-code-55caf.web.app/?verified=1';

/** Send the verification e-mail. Returns a message for the user. */
export async function sendVerificationEmail(user: User): Promise<{ok: boolean; message: string}> {
  const [{sendEmailVerification}, {accountAuth}] = await Promise.all([import('firebase/auth'), import('./firebase/app')]);
  try {
    accountAuth.useDeviceLanguage();
    try {await sendEmailVerification(user, {url: CONTINUE_URL, handleCodeInApp: false});}
    catch (e) {
      // If the continue address isn't on the authorised domains list, send the plain e-mail instead.
      if ((e as {code?: string}).code === 'auth/unauthorized-continue-uri' || (e as {code?: string}).code === 'auth/invalid-continue-uri') await sendEmailVerification(user);
      else throw e;
    }
    return {ok: true, message: `New verification link sent to ${user.email}. Open the newest e-mail. If you can’t find it, check Spam or Promotions.`};
  } catch (e) {
    const code = (e as {code?: string}).code;
    if (code === 'auth/too-many-requests') return {ok: false, message: 'An e-mail was sent recently. Please wait a few minutes before asking for another one, and check Spam or Promotions.'};
    return {ok: false, message: 'Couldn’t send the e-mail right now. Check your connection and try again in a minute.'};
  }
}

/** Reload the account; when it's now verified, refresh the sign-in token so the server sees it at once. */
export async function refreshVerified(user: User): Promise<boolean> {
  const {reload} = await import('firebase/auth');
  try {
    await reload(user);
    if (!user.emailVerified) return false;
    await user.getIdToken(true);
    return true;
  } catch {return user.emailVerified;}
}
