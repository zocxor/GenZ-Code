/**
 * Staff check: is this signed-in account an admin or moderator?
 *
 * Staff roles live in the `admins/{uid}` collection (see firebase/firestore.rules
 * `match /admins/{adminId}`): a user may read their OWN record, so this read is
 * allowed for every signed-in user and simply returns "no document" for a
 * regular account. Staff suggest words for free (see shared/tokens.ts
 * suggestCost); everyone else pays 20 tokens, earned by watching ads, playing
 * quizzes, or buying a package.
 */
import type {Firestore} from 'firebase/firestore/lite';

export async function fetchIsStaff(uid: string): Promise<boolean> {
  try {
    const [{doc, getDoc}, {cloudDb: dbFn}] = await Promise.all([
      import('firebase/firestore/lite'),
      import('./firebase/app'),
    ]);
    const db: Firestore = dbFn();
    const snap = await getDoc(doc(db, 'admins', uid));
    return snap.exists();
  } catch {
    return false;
  }
}

/** The active staff role of this account ('super_admin', 'content_manager', …), or null. */
export async function fetchStaffRole(uid: string): Promise<string | null> {
  try {
    const [{doc, getDoc}, {cloudDb: dbFn}] = await Promise.all([
      import('firebase/firestore/lite'),
      import('./firebase/app'),
    ]);
    const snap = await getDoc(doc(dbFn(), 'admins', uid));
    const data = snap.data();
    return data && data.active === true && typeof data.role === 'string' ? data.role : null;
  } catch {
    return null;
  }
}
/** Roles the server allows to manage Daily Codes (functions/src/communityFeatures.ts `editorial`). */
export const DAILY_EDITORS = ['super_admin', 'content_manager'];
