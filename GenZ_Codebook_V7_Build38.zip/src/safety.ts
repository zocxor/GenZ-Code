/**
 * Community safety (Google Play User Generated Content policy):
 *  - Block users: hides a person's chat messages, posts and comments for you. The list is kept on
 *    this device for the signed-in account and can be managed in Settings → Blocked users.
 *  - Community rules: everyone agrees to the rules once before their first chat message, post,
 *    comment or new word.
 * Reporting (with reasons) already sends content to the moderators in the admin portal.
 */
import {useSyncExternalStore} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {confirmAction} from './ui';
import {CONTENT_NOTICE} from '../shared/publishing';

const BLOCK_KEY = 'genz.blocked.v1';
const RULES_KEY = 'genz.communityRules.v1';
export type BlockedUser = {uid: string; name: string; at: number};

let blocked: Record<string, BlockedUser> = {};
let loaded = false;
let set: ReadonlySet<string> = new Set();
const listeners = new Set<() => void>();
const emit = () => {set = new Set(Object.keys(blocked)); listeners.forEach(f => f());};
const save = () => void AsyncStorage.setItem(BLOCK_KEY, JSON.stringify(blocked)).catch(() => {});
function load() {
  if (loaded) return;
  loaded = true;
  void AsyncStorage.getItem(BLOCK_KEY).then(raw => {
    const v = raw ? JSON.parse(raw) : null;
    if (v && typeof v === 'object') {
      for (const [uid, b] of Object.entries(v as Record<string, BlockedUser>)) {
        if (typeof uid === 'string' && b && typeof b.name === 'string') blocked[uid] = {uid, name: b.name.slice(0, 40), at: Number(b.at) || 0};
      }
      emit();
    }
  }).catch(() => {});
}
const subscribe = (f: () => void) => {load(); listeners.add(f); return () => {listeners.delete(f);};};

/** IDs of the people you've blocked (live). */
export const useBlocked = () => useSyncExternalStore(subscribe, () => set);
export const blockedList = (): BlockedUser[] => Object.values(blocked).sort((a, b) => b.at - a.at);
export function useBlockedList(): BlockedUser[] {useBlocked(); return blockedList();}

export function unblockUser(uid: string) {
  if (!blocked[uid]) return;
  delete blocked[uid];
  emit(); save();
}
/** Ask, then block. Calls onDone(true) when blocked. */
export function blockUser(uid: string, name: string, onDone?: (blockedNow: boolean) => void) {
  if (!uid) return;
  confirmAction(`Block ${name}?`, 'You won’t see their chat messages, posts or comments. They aren’t told. You can unblock them in Settings → Blocked users.', () => {
    blocked = {...blocked, [uid]: {uid, name: name.slice(0, 40) || 'User', at: Date.now()}};
    emit(); save();
    onDone?.(true);
  }, 'Block', () => onDone?.(false));
}

let rulesAccepted: boolean | null = null;
/** Resolves true once the user has agreed to the community rules (asks only the first time). */
export async function ensureCommunityRules(): Promise<boolean> {
  if (rulesAccepted === null) rulesAccepted = (await AsyncStorage.getItem(RULES_KEY).catch(() => null)) === 'yes';
  if (rulesAccepted) return true;
  return new Promise(resolve => {
    confirmAction('Community rules', `${CONTENT_NOTICE}\n\nYou can report content and block users. Moderators review reports and remove content that breaks the rules.\n\nBy continuing you agree to these rules and the Terms of Use (You → Settings → About).`, () => {
      rulesAccepted = true;
      void AsyncStorage.setItem(RULES_KEY, 'yes').catch(() => {});
      resolve(true);
    }, 'I agree', () => resolve(false));
  });
}
