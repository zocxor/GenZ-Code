/**
 * User submissions: new words, content reports and app feedback.
 *
 * New words go live instantly as community words (communityWords/{id}) when the owner's switch
 * allows it and the word filter does not flag them; otherwise they wait for moderators
 * (submissions). Every write is batched with a rate-limit stamp (users/{uid}/limits/ugc);
 * Firestore rules reject writes less than 60 s apart, unknown fields, oversize text, links,
 * spoofed owner IDs, unverified e-mail (for instant publishing) and restricted accounts.
 * Before writing, the same conditions are checked here so people get a specific reason
 * instead of a generic failure.
 */
import {publishingMode} from '../shared/publishing';
import {SPARK_MODE} from '../shared/deployment';
import {Platform} from 'react-native';
import type {User} from 'firebase/auth';
import {cleanText, validateEntry, CONTENT_CATEGORIES} from '../shared/contentSchema';
import {communityId, screenWord} from '../shared/community';
import {APP_VERSION} from './secure/config';
import {findExistingTerm, addLocalCommunityWord} from './contentSync';

export const REPORT_REASONS = ['Wrong meaning', 'Offensive or harmful', 'Outdated', 'Spelling or formatting', 'Other'] as const;
export type UgcResult =
  | {ok: true; live?: boolean; termId?: string}
  | {ok: false; message: string; needsVerification?: boolean; existingId?: string};
type Fail = Extract<UgcResult, {ok: false}>;
const fail = (message: string, extra: Partial<Fail> = {}): Fail => ({ok: false, message, ...extra});

const libs = () => Promise.all([import('firebase/firestore/lite'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

/** Specific, honest messages; unknown failures include the backend code for support. */
function errorText(e: unknown, CloudError: typeof import('./sync/engine').CloudError): string {
  if (e instanceof CloudError) {
    if (e.code === 'server-setup' && e.raw === 'rules-outdated') return 'The GenZ Codebook server is running older security rules that don’t include community words yet. Publish the latest rules, then try again. (code: rules-outdated)';
    if (e.code === 'server-setup') return 'The GenZ Codebook server isn’t set up yet: its security rules haven’t been published, so the database refuses every request. Publish the rules, then try again. (code: rules-missing)';
    if (e.code === 'permission-denied' && e.raw.startsWith('refused:')) return `The server refused this word. ${e.message} (code: ${e.raw})`;
    if (e.code === 'offline') return 'You’re offline. Connect to the internet and try again.';
    if (e.code === 'unauthenticated') return 'Your session expired. Sign in again, then try once more.';
    if (e.code === 'permission-denied') return 'The server didn’t accept this. If you just verified your e-mail, wait a minute and try again. (code: permission-denied)';
    return `Couldn’t send that right now. Please try again. (code: ${e.raw || e.code})`;
  }
  return 'Couldn’t send that right now. Please try again.';
}

/** Turn a refusal on a read that the rules always allow into a precise server-setup error. */
async function readOrExplain<T>(read: () => Promise<T>, meaning: 'rules-missing' | 'rules-outdated'): Promise<T> {
  const [, , {toCloudError}, {CloudError}] = await libs();
  try {return await read();} catch (e) {
    const ce = toCloudError(e);
    throw ce.code === 'permission-denied' ? new CloudError('server-setup', undefined, meaning) : ce;
  }
}

/** After the server refuses the final write, find out which rule condition failed. */
async function explainRefusal(user: User): Promise<Error> {
  const [{doc, getDoc}, {cloudDb}, , {CloudError}] = await libs();
  const refused = (why: string, code: string) => new CloudError('permission-denied', why, 'refused:' + code);
  try {
    if ((await user.getIdTokenResult(true)).claims.email_verified !== true) return refused('Your e-mail isn’t verified yet on the server. Open the verification link, then try again.', 'email');
    const account = await getDoc(doc(cloudDb(), 'users', user.uid));
    if (!account.exists() || account.data().status !== 'active') return refused('Your account record isn’t active.', 'account');
    const stamp = await getDoc(doc(cloudDb(), 'users', user.uid, 'limits', 'ugc'));
    const last = stamp.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
    if (last && Date.now() - last < 90_000) return refused('You added something less than a minute ago. Wait a minute, then try again.', 'wait');
    const config = await getDoc(doc(cloudDb(), 'config', 'app'));
    if (config.exists() && (config.data().ugcEnabled === false || config.data().communityWordsEnabled === false)) return refused('Instant publishing was switched off by the GenZ Codebook team.', 'switched-off');
  } catch {/* fall through */}
  return refused('Check the word has no links, e-mail addresses or phone numbers, then try again.', 'word');
}

/** Signed-in, active account with no recent submission. Returns the user or a reason. */
async function prepare(): Promise<{user: User; wait: number} | Fail> {
  const [{doc, getDoc}, {cloudDb, accountAuth}, {firestoreCloud}] = await libs();
  const user = accountAuth.currentUser;
  if (!user) return fail('Sign in to send this. It helps us prevent spam.');
  const status = await firestoreCloud.ensureAccount(user.uid, {appVersion: APP_VERSION, platform: Platform.OS});
  if (status === 'suspended') return fail('Your account is restricted, so it can’t send this. Contact support if you think this is a mistake.');
  if (status === 'deleted') return fail('This account is being deleted.');
  const stamp = await getDoc(doc(cloudDb(), 'users', user.uid, 'limits', 'ugc'));
  const last = stamp.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
  return {user, wait: Math.min(60, Math.ceil((last + 61_000 - Date.now()) / 1000))};
}

/** Rules read the e-mail_verified claim from the ID token, so refresh it after verifying. */
async function emailVerified(user: User): Promise<boolean> {
  const {reload} = await import('firebase/auth');
  if (!user.emailVerified) {await reload(user); if (!user.emailVerified) return false;}
  if ((await user.getIdTokenResult()).claims.email_verified === true) return true;
  return (await user.getIdTokenResult(true)).claims.email_verified === true;
}

async function submit(collectionName: 'submissions' | 'reports' | 'feedback' | 'chatReports', body: Record<string, unknown>): Promise<UgcResult> {
  const [{doc, collection, writeBatch, serverTimestamp}, {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    const ready = await prepare();
    if ('ok' in ready) return ready;
    if (ready.wait > 0) return fail(`Please wait ${ready.wait} s before sending another one.`);
    const db = cloudDb(), batch = writeBatch(db);
    batch.set(doc(db, 'users', ready.user.uid, 'limits', 'ugc'), {last: serverTimestamp()});
    batch.set(doc(collection(db, collectionName)), {...body, uid: ready.user.uid, status: collectionName === 'feedback' ? 'new' : collectionName === 'submissions' ? 'pending' : 'open', createdAt: serverTimestamp()});
    await batch.commit();
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}

/** Add a word. Live for everyone immediately unless the owner turned that off or the filter flags it. */
export async function suggestWord(input: {term: string; meaning: string; example: string; category: string; requireReview?: boolean}): Promise<UgcResult> {
  if(SPARK_MODE){
    const [{doc,getDoc,writeBatch,serverTimestamp},{cloudDb},{toCloudError},{CloudError}]=await libs();
    try{
      const ready=await prepare();if('ok' in ready)return ready;
      if(ready.wait>0)return fail(`Please wait ${ready.wait} s before submitting again.`);
      if(!await emailVerified(ready.user))return fail('Verify your email before submitting a word.',{needsVerification:true});
      const validation=validateEntry({...input,id:'suggestion',full:input.term,language:'English',subcategory:'',variations:[],tags:[],region:'Global',sensitivity:'None'});
      if(!validation.ok)return fail(validation.errors.join(' '));
      const term=cleanText(input.term,60).trim(),meaning=cleanText(input.meaning,500).trim(),example=cleanText(input.example,300).trim();
      const screening=screenWord({term,meaning,example});if(!screening.ok)return fail(screening.message);
      const db=cloudDb(),config=await getDoc(doc(db,'config','app'));
      const mode=publishingMode(config.exists()?config.data():{},'code');
      if(mode==='paused')return fail('Creating codes is paused by the administrator.');
      const found=await findExistingTerm(term);if(found)return fail('This word already exists in Codes.',{existingId:found.id});
      const id=communityId(term), live=mode==='open'&&!screening.review;
      const word=doc(db,'communityWords',id),submission=doc(db,'submissions',id);
      const [existing,pending]=await Promise.all([getDoc(word),getDoc(submission)]);
      if(existing.exists()||pending.exists())return fail('This word already exists or has already been submitted.');
      const batch=writeBatch(db),fields={term,meaning,example,category:input.category,uid:ready.user.uid,createdAt:serverTimestamp()};
      batch.set(doc(db,'users',ready.user.uid,'limits','ugc'),{last:serverTimestamp()});
      if(live)batch.set(word,{...fields,id,status:'live',schema:3,payment:'free',fee:0,updatedAt:serverTimestamp()});
      else batch.set(submission,{...fields,status:'pending',schema:3,payment:'free',fee:0});
      await batch.commit();
      if(live)await addLocalCommunityWord(id,{term,meaning,example,category:input.category}).catch(()=>{});
      return {ok:true,live,termId:live?id:undefined};
    }catch(e){return fail(errorText(toCloudError(e),CloudError));}
  }
  try {
    const {feature,requestKey}=await import('./communityFeatures');
    const result=await feature('create-code',{...input,requestId:requestKey()});
    return {ok:true,live:result.live===true,termId:result.termId};
  }catch(e){const {errorOf}=await import('./communityFeatures');return fail(errorOf(e));}
}

export function reportEntry(termId: string, reason: string, note: string): Promise<UgcResult> {
  if (!(REPORT_REASONS as readonly string[]).includes(reason)) return Promise.resolve(fail('Choose a reason.'));
  return submit('reports', {termId, reason, note: cleanText(note, 300)});
}
/** Report one community chat message. Same reasons and rate limit as entry reports. */
export function reportChatMessage(messageId: string, reason: string, note: string): Promise<UgcResult> {
  if (!(REPORT_REASONS as readonly string[]).includes(reason)) return Promise.resolve(fail('Choose a reason.'));
  if (typeof messageId !== 'string' || !messageId) return Promise.resolve(fail('That message no longer exists.'));
  return submit('chatReports', {messageId, reason, note: cleanText(note, 300)});
}
export function sendFeedback(rating: number, message: string): Promise<UgcResult> {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) return Promise.resolve(fail('Choose a rating from 1 to 5.'));
  return submit('feedback', {rating, message: cleanText(message, 1000), appVersion: APP_VERSION, platform: Platform.OS});
}
/** Resend the verification e-mail for the signed-in account. */
export async function resendVerification(): Promise<string> {
  const [{accountAuth}, {sendVerificationEmail}] = await Promise.all([import('./firebase/app'), import('./emailVerification')]);
  const user = accountAuth.currentUser;
  if (!user?.email) return 'Sign in first.';
  const r = await sendVerificationEmail(user);
  return r.ok ? `${r.message} Then tap “I’ve verified”.` : r.message;
}
