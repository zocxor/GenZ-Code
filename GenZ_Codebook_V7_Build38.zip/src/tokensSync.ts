/**
 * Code Tokens, server side: the accepted-word bonus and the public leaderboard.
 *
 * - Accepted-word bonus: a suggested word that goes to moderators (submissions,
 *   status 'pending') pays +20 when a moderator accepts it (status 'accepted').
 *   This checks the user's own submissions and credits each accepted one once;
 *   the paid keys live in the local tokens state, so a re-check never pays twice.
 *   Words published instantly (live) pay nothing — the publication itself is the
 *   reward, and paying for it would make suggesting free in net terms.
 * - Leaderboard: opt-in only. When opted in, the app publishes {name, tokens}
 *   to leaderboard/{uid} — nickname and tokens, nothing else — and anyone can
 *   read the top 20. Leaving deletes the entry. Best-effort and throttled; a
 *   failure never blocks the app. Tokens are client-reported, like the synced
 *   quiz scores: a determined user could inflate them, so the board is for fun,
 *   not a competition with prizes.
 */
import {accountAuth} from './firebase/app';

import {rankFor} from './ranks';
export type LeaderboardRow = {uid: string; name: string; tokens: number; xp: number; level: number; rank: string};
/** What the board shows for you: game XP (ranking) and Credits (shown beside it). */
export type LeaderStats = {xp: number; credits: number};

const libs = () => Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);

let lastPublishAt = 0;
let lastPublishedPoints = -1;

/** Credit +20 per accepted submission not yet paid. Returns the keys to credit (empty when nothing is new). */
export async function creditAcceptedWords(): Promise<string[]> {
  try {
    const user = accountAuth.currentUser;
    if (!user) return [];
    const [{collection, query, where, getDocs}, {cloudDb: dbFn}] = await libs();
    const snap = await getDocs(query(collection(dbFn(), 'submissions'), where('uid', '==', user.uid)));
    return snap.docs.filter(d => d.data().status === 'accepted').map(d => `sub:${d.id}`);
  } catch {return [];}
}

/** Publish (or refresh) this user's leaderboard entry. Throttled to once a minute and skipped when the balance is unchanged. */
export async function publishLeaderboard(name: string, stats: LeaderStats): Promise<void> {
  try {
    const user = accountAuth.currentUser;
    if (!user) return;
    const xp = Math.max(0, Math.min(10_000_000, Math.floor(stats.xp || 0)));
    const credits = Math.max(0, Math.min(1_000_000, Math.floor(stats.credits || 0)));
    const key = `${name}|${xp}|${credits}`;
    const now = Date.now();
    if (key === lastPublishedKey && now - lastPublishAt < 60_000) return;
    const r = rankFor(xp);
    const [{doc, setDoc, serverTimestamp}, {cloudDb: dbFn}] = await libs();
    await setDoc(doc(dbFn(), 'leaderboard', user.uid), {name: name.slice(0, 24) || 'Code Explorer', tokens: credits, xp, level: r.level, rank: r.name, updatedAt: serverTimestamp()});
    lastPublishAt = now;
    lastPublishedKey = key;
  } catch {/* leaderboard is best-effort; never block the app */}
}
let lastPublishedKey = '';

/** Remove this user's leaderboard entry (opting out, or account deletion). */
export async function leaveLeaderboard(): Promise<void> {
  try {
    const user = accountAuth.currentUser;
    if (!user) return;
    const [{doc, deleteDoc}, {cloudDb: dbFn}] = await libs();
    await deleteDoc(doc(dbFn(), 'leaderboard', user.uid));
    lastPublishedKey = '';
  } catch {/* ignore */}
}

/** Top 20 by game XP (level), highest first. Public read; no sign-in needed. */
export async function fetchLeaderboard(): Promise<LeaderboardRow[]> {
  try {
    const [{collection, query, orderBy, limit, getDocs}, {cloudDb: dbFn}] = await libs();
    const snap = await getDocs(query(collection(dbFn(), 'leaderboard'), orderBy('xp', 'desc'), limit(20)));
    return snap.docs.map(d => {
      const data = d.data();
      const xp = typeof data.xp === 'number' ? Math.floor(data.xp) : 0, r = rankFor(xp);
      return {uid: d.id, name: typeof data.name === 'string' && data.name ? data.name.slice(0, 24) : 'Code Explorer', tokens: typeof data.tokens === 'number' ? Math.floor(data.tokens) : 0, xp, level: r.level, rank: r.name};
    });
  } catch {return [];}
}
