/**
 * Creator leaderboards, counted from public content: live community words per author, and
 * approved, visible community posts per author (with their likes). Refreshed at most every
 * 5 minutes; counts the latest 1,000 of each.
 */
export type CreatorRow = {uid: string; name: string; count: number; likes: number};
let cache: {at: number; words: CreatorRow[]; posts: CreatorRow[]} | null = null;

function rank(rows: Map<string, CreatorRow>): CreatorRow[] {
  return [...rows.values()].sort((a, b) => b.count - a.count || b.likes - a.likes || a.uid.localeCompare(b.uid)).slice(0, 20);
}

export async function fetchCreatorBoards(force = false): Promise<{words: CreatorRow[]; posts: CreatorRow[]}> {
  if (!force && cache && Date.now() - cache.at < 5 * 60_000) return cache;
  const [{collection, query, where, limit, getDocs}, {cloudDb}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
  const db = cloudDb();
  const [w, p] = await Promise.all([
    getDocs(query(collection(db, 'communityWords'), where('status', '==', 'live'), limit(1000))).catch(() => null),
    getDocs(query(collection(db, 'communityPosts'), where('hidden', '==', false), where('status', '==', 'approved'), limit(1000))).catch(() => null),
  ]);
  const words = new Map<string, CreatorRow>(), posts = new Map<string, CreatorRow>();
  for (const d of w?.docs ?? []) {
    const uid = d.get('uid');
    if (typeof uid !== 'string' || !uid) continue;
    const row = words.get(uid) ?? {uid, name: '', count: 0, likes: 0};
    row.count++;
    words.set(uid, row);
  }
  for (const d of p?.docs ?? []) {
    const uid = d.get('uid');
    if (typeof uid !== 'string' || !uid) continue;
    const row = posts.get(uid) ?? {uid, name: '', count: 0, likes: 0};
    row.count++;
    row.likes += Math.max(0, Number(d.get('likeCount')) || 0);
    const name = d.get('name');
    if (!row.name && typeof name === 'string') row.name = name.slice(0, 24);
    posts.set(uid, row);
  }
  cache = {at: Date.now(), words: rank(words), posts: rank(posts)};
  return cache;
}
