import {test} from 'node:test';
import assert from 'node:assert/strict';
import {addBonus, remaining, spendFree, today, type ConvState} from '../src/conversionQuota';
import {parseFees} from '../src/appConfig';

const s0: ConvState = {day: '2026-11-12', used: {encode: 0, decode: 0}, bonus: {encode: 0, decode: 0}};
test('encode and decode each have their own free daily allowance', () => {
  let s = s0;
  for (let i = 0; i < 10; i++) s = spendFree(s, 'encode', '2026-11-12');
  assert.equal(remaining(s, 'encode', 10, '2026-11-12'), 0);
  assert.equal(remaining(s, 'decode', 10, '2026-11-12'), 10);
});
test('the allowance resets on a new day and an ad adds +5', () => {
  let s = s0; for (let i = 0; i < 10; i++) s = spendFree(s, 'decode', '2026-11-12');
  assert.equal(remaining(addBonus(s, 'decode', '2026-11-12'), 'decode', 10, '2026-11-12'), 5);
  assert.equal(remaining(s, 'decode', 10, '2026-11-13'), 10);
  assert.equal(today(s, '2026-11-13').used.decode, 0);
});
test('admin prices override defaults; invalid values fall back', () => {
  assert.deepEqual(parseFees({}), {chat: 30, post: 50, code: 100, daily: 100, verification: 5000, encode: 5, decode: 5});
  const f = parseFees({chatDay: 40, post: 0, encode: 0, decode: 2, dailyCode: 'x'});
  assert.equal(f.chat, 40); assert.equal(f.post, 50, 'community prices must be at least 1'); assert.equal(f.encode, 0, '0 = unlimited free'); assert.equal(f.decode, 2); assert.equal(f.daily, 100);
});
