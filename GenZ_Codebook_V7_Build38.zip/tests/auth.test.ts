import {test} from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {accountError,validateCredentials,secureStorageKey,validatePasswordChange,hasPasswordProvider,passwordResetSentMessage,isResetEnumerationError,MIN_NEW_PASSWORD_LENGTH} from '../src/auth/policy';import config from '../src/auth/firebaseConfig.json';
test('Firebase public client configuration belongs to the supplied project and contains no admin secrets',()=>{assert.equal(config.projectId,'gen-z-code-55caf');assert(config.apiKey.startsWith('AIza'));assert.deepEqual(Object.keys(config).sort(),['apiKey','projectId']);});
test('credential validation permits existing short passwords but requires stronger new passwords',()=>{assert.equal(validateCredentials('person@example.com','old123'),null);assert(validateCredentials('person@example.com','old123',true));assert.equal(validateCredentials('person@example.com','longer-passphrase',true),null);assert(validateCredentials('broken','longer-passphrase'));assert(validateCredentials('person@example.com',''));});
test('UI never exposes raw Firebase errors, tokens or account-existence details',()=>{for(const code of ['auth/user-not-found','auth/wrong-password','auth/invalid-credential'])assert.equal(accountError({code,message:'secret-token person@example.com'}),'The email or password is incorrect.');assert(!accountError({code:'unknown',message:'secret-token'}).includes('secret-token'));assert(accountError({code:'auth/operation-not-allowed'}).includes('project owner'));});
test('encrypted-storage key encoding preserves identity without invalid native characters',()=>{const inputs=['firebase:authUser:key:GenZCodeAccount','firebase_authUser_key_GenZCodeAccount','a.b','a_b','a:b','a%3Ab','_3a_'];const keys=inputs.map(secureStorageKey);assert.equal(new Set(keys).size,inputs.length);for(const key of keys)assert(/^[a-zA-Z0-9._-]+$/.test(key));});

test('Google sign-in is wired: native flow exchanges an ID token for a Firebase credential, and the button is real', () => {
  const googleAuth = readFileSync('src/googleAuth.ts', 'utf8');
  // The flow: configure with the web client ID, check Play services, sign in
  // with Google, exchange the ID token for a Firebase credential.
  assert.ok(googleAuth.includes("GoogleSignin.configure({webClientId: GOOGLE_WEB_CLIENT_ID})"), 'configure with web client ID');
  assert.ok(googleAuth.includes('GoogleSignin.hasPlayServices()'), 'Play services check');
  assert.ok(googleAuth.includes('GoogleSignin.signIn()'), 'native Google sign-in');
  assert.ok(googleAuth.includes('GoogleAuthProvider.credential(idToken)'), 'ID token exchanged for Firebase credential');
  assert.ok(googleAuth.includes('signInWithCredential(accountAuth,'), 'Firebase sign-in with the credential');
  // Without a web client ID the flow returns a clear setup message, never a
  // cryptic native error and never a fake success.
  assert.ok(googleAuth.includes("if (!GOOGLE_WEB_CLIENT_ID)"), 'missing web client ID is handled');
  assert.ok(googleAuth.includes('not set up yet'), 'setup message');
  // The account screen has a real Continue with Google button when the web
  // client ID is set, and a setup note when it is not — not a dead label.
  const account = readFileSync('src/AccountScreen.tsx', 'utf8');
  assert.ok(account.includes("import {signInWithGoogle, isGoogleSignInConfigured} from './googleAuth'"), 'account screen imports the Google flow');
  const portal = readFileSync('src/AuthPortal.tsx', 'utf8');
  assert.ok(portal.includes('<GoogleSigninButton') && portal.includes('GoogleSigninButton.Color.Light') && portal.includes('onPress={onGoogle}'), 'Google keeps its official (light) button inside the neon panel');
  assert.ok(account.includes('onGoogle={googleSignIn}') && account.includes('signInWithGoogle()'), 'the official Google button is wired to the real flow');
  assert.ok(portal.includes('useReducedMotion()'), 'the light sweep respects reduce motion');
  assert.ok(account.includes('isGoogleSignInConfigured()'), 'button gated on configuration');
  assert.ok(!account.includes('Not configured</Text>'), 'no dead Not configured label');
});

test('password change validation: 8+ characters, different from current, confirmation must match', () => {
  assert.equal(MIN_NEW_PASSWORD_LENGTH, 8);
  assert.deepEqual(validatePasswordChange('old-password', 'new-password-1', 'new-password-1'), {});
  assert.equal(validatePasswordChange('old-password', 'short', 'short').next, 'Use at least 8 characters for your new password.');
  assert.equal(validatePasswordChange('old-password', 'old-password', 'old-password').next, 'Your new password must be different from your current password.');
  assert.equal(validatePasswordChange('old-password', 'new-password-1', 'different').confirm, 'The new passwords do not match.');
  assert.equal(validatePasswordChange('old-password', 'new-password-1', '').confirm, 'The new passwords do not match.');
  assert.equal(validatePasswordChange('', 'new-password-1', 'new-password-1').current, 'Enter your current password.');
  assert.equal(validatePasswordChange('old-password', 'a'.repeat(4097), 'a'.repeat(4097)).next, 'This password is too long.');
});

test('password reset response never reveals whether the address has an account', () => {
  assert.equal(passwordResetSentMessage('person@example.com'), 'Reset link sent to person@example.com — check your inbox (and spam folder).');
  assert.equal(passwordResetSentMessage('  person@example.com  '), 'Reset link sent to person@example.com — check your inbox (and spam folder).');
  assert.equal(isResetEnumerationError('auth/user-not-found'), true);
  assert.equal(isResetEnumerationError('auth/too-many-requests'), false, 'throttling still surfaces');
  assert.equal(isResetEnumerationError('auth/network-request-failed'), false, 'network errors still surface');
  const account = readFileSync('src/AccountScreen.tsx', 'utf8');
  assert.ok(account.includes('isResetEnumerationError(codeOf(e))'), 'reset branch swallows user-not-found');
  assert.ok(account.includes('passwordResetSentMessage(address)'), 'reset notice uses the generic message');
  assert.ok(account.includes('Forgot password?'), 'forgot-password link exists on the sign-in form');
  assert.ok(account.includes('sendPasswordResetEmail(accountAuth, address)'), 'reset uses Firebase sendPasswordResetEmail');
});

test('change password: Google-only accounts have no password to change; email accounts re-auth then update', () => {
  assert.equal(hasPasswordProvider([{providerId: 'google.com'}]), false);
  assert.equal(hasPasswordProvider([{providerId: 'password'}]), true);
  assert.equal(hasPasswordProvider([{providerId: 'google.com'}, {providerId: 'password'}]), true);
  assert.equal(hasPasswordProvider([]), false);
  const account = readFileSync('src/AccountScreen.tsx', 'utf8');
  assert.ok(account.includes('title="Change password"'), 'change-password button in the signed-in view');
  assert.ok(account.includes('hasPasswordProvider(user.providerData)'), 'change panel checks the sign-in provider');
  assert.ok(account.includes('You signed in with Google — your password is managed by Google.'), 'Google-only accounts see the Google message, not the form');
  assert.ok(account.includes('reauthenticateWithCredential(current, EmailAuthProvider.credential(current.email, currentPw))'), 'current password re-authenticates first');
  assert.ok(account.includes('updatePassword(current, newPw)'), 'new password is set with updatePassword');
  assert.ok(account.includes("codeOf(e) === 'auth/requires-recent-login'"), 'stale sessions are sent back to sign-in');
  assert.ok(account.includes("'Your password was changed.'"), 'success confirmation');
});
