/**
 * Subscription entitlement tests (pure logic in shared/subscriptions.ts).
 *
 * These cover the client-side premium decision: a subscription is premium
 * while the backend-recorded state is ACTIVE, CANCELED (keeps access until
 * the paid period ends) or IN_GRACE_PERIOD and the expiry time is in the
 * future. The entitlement itself is written only by the backend
 * (verifySubscription + the RTDN handler); the client only reads it, and
 * the Firestore rules (firebase/rules-tests/rules.test.mjs) enforce that.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {SUBSCRIPTION_PRODUCTS, subscriptionForProduct, isSubscriptionProduct, isPremiumActive, type SubscriptionDoc} from '../shared/subscriptions';

const base: SubscriptionDoc = {
  productId: 'premium_monthly',
  basePlanId: 'monthly',
  purchaseToken: 'sub-token-1',
  state: 'SUBSCRIPTION_STATE_ACTIVE',
  expiryTime: new Date(Date.now() + 30 * 86400_000).toISOString(),
  autoRenewing: true,
  acknowledged: true,
  lastOrderId: 'GPA.2',
  lastTokenGrantOrderId: 'GPA.2',
  updatedAt: null,
};

test('subscriptions: the catalog has exactly the two Premium products with their base plans and token grants', () => {
  assert.equal(SUBSCRIPTION_PRODUCTS.length, 2);
  const monthly = subscriptionForProduct('premium_monthly');
  assert.equal(monthly?.basePlanId, 'monthly');
  assert.equal(monthly?.tokensPerPeriod, 10000);
  const yearly = subscriptionForProduct('premium_yearly');
  assert.equal(yearly?.basePlanId, 'yearly');
  assert.equal(yearly?.tokensPerPeriod, 200000);
  assert.equal(subscriptionForProduct('tokens_1000'), null);
  assert.equal(isSubscriptionProduct('premium_monthly'), true);
  assert.equal(isSubscriptionProduct('tokens_1000'), false);
});

test('subscriptions: ACTIVE and IN_GRACE_PERIOD are premium while unexpired', () => {
  assert.equal(isPremiumActive(base), true);
  assert.equal(isPremiumActive({...base, state: 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'}), true);
});

test('subscriptions: CANCELED keeps premium until the paid period ends', () => {
  assert.equal(isPremiumActive({...base, state: 'SUBSCRIPTION_STATE_CANCELED'}), true);
  assert.equal(
    isPremiumActive({...base, state: 'SUBSCRIPTION_STATE_CANCELED', expiryTime: new Date(Date.now() - 1000).toISOString()}),
    false,
  );
});

test('subscriptions: expired, on-hold, paused, pending and pending-canceled are not premium', () => {
  for (const state of [
    'SUBSCRIPTION_STATE_EXPIRED',
    'SUBSCRIPTION_STATE_ON_HOLD',
    'SUBSCRIPTION_STATE_PAUSED',
    'SUBSCRIPTION_STATE_PENDING',
    'SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED',
    'SUBSCRIPTION_STATE_UNSPECIFIED',
  ] as const) {
    assert.equal(isPremiumActive({...base, state}), false);
  }
  assert.equal(isPremiumActive({...base, expiryTime: new Date(Date.now() - 1000).toISOString()}), false);
  assert.equal(isPremiumActive(null), false);
});

test('subscriptions: credit packs stay one-time; Premium is sold only behind checkout + server verification', () => {
  const shop = readFileSync('src/TokenShopScreen.tsx', 'utf8');
  const wallet = readFileSync('src/WalletScreen.tsx', 'utf8');
  assert.match(shop, /one-time purchase/);
  assert.match(shop, /const subCheckout=checkout&&isSubscriptionPurchaseEnabled\(\);/);
  assert.match(shop, /if\(busy\.current\|\|!subCheckout\)return;/);
  assert.match(shop, /Credit packs do not remove ads/);
  assert.match(wallet, /Manage in Google Play/);
  assert.match(wallet, /reconcileSubscriptions/);
  const sub = readFileSync('src/subscription.ts', 'utf8');
  assert.match(sub, /if \(!SUBSCRIPTION_VERIFY_URL\) \{/);
});

test('Build 37: Google Play checkout is on, and Credit packs and Premium share one switch', () => {
  const config = JSON.parse(readFileSync('shared/backend.json', 'utf8'));
  assert.equal(config.tokenPurchasesEnabled, true);
  assert.match(config.url, /^https:\/\/us-central1-gen-z-code-55caf\.cloudfunctions\.net$/);
  const sub = readFileSync('src/subscription.ts', 'utf8');
  const gate = sub.slice(sub.indexOf('export function isSubscriptionPurchaseEnabled'), sub.indexOf('export type SubscriptionProduct'));
  assert.match(gate, /return TOKEN_CHECKOUT_ENABLED && SUBSCRIPTION_VERIFY_URL\.length > 0;/);
  assert.doesNotMatch(sub, /import \{SPARK_MODE\}|if\s*\(\s*SPARK_MODE/, 'Premium no longer depends on the free-community switch');
  const shop = readFileSync('src/TokenShopScreen.tsx', 'utf8');
  assert.doesNotMatch(shop, /Ad-free|Ads are off/, 'Premium promises only what it does: no pop-up ads');
  assert.match(shop, /Renews automatically until you cancel in Google Play/);
});

test('token checkout checks verification before requesting a Google Play purchase', () => {
  const billing = readFileSync('src/billing.ts', 'utf8');
  const checkout = billing.slice(billing.indexOf('export async function buyTokens('));
  const gate = checkout.indexOf('if (!isTokenPurchaseEnabled())');
  assert.ok(gate >= 0 && gate < checkout.indexOf('await requestPurchase('));
  assert.doesNotMatch(billing, /p\.displayPrice \|\| catalog\.price/);
});
