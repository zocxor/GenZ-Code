// Firestore security-rules tests. Run against the OFFICIAL emulator (requires Java 21+):
//   npm run test:rules
// These tests were written alongside the rules but could not be executed in the build
// environment (the emulator binary could not be downloaded there). Run them before deploying.
import {test, before, after, beforeEach} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {initializeTestEnvironment, assertFails, assertSucceeds} from '@firebase/rules-unit-testing';
import {doc, getDoc, setDoc, updateDoc, deleteDoc, getDocs, collection, collectionGroup, query, where, writeBatch, runTransaction, serverTimestamp, Timestamp} from 'firebase/firestore';

let env;
const MFA = {firebase: {sign_in_provider: 'password', sign_in_second_factor: 'totp'}};
const NO_MFA = {firebase: {sign_in_provider: 'password'}};
const day = () => new Date().toISOString().slice(0, 10);
const stats = {saved: 0, quizzes: 0, levels: 0, reviewed: 0, streak: 0, xp: 0};
const account = () => ({status: 'active', createdAt: serverTimestamp(), updatedAt: serverTimestamp(), lastActiveAt: serverTimestamp(), lastActiveDay: day(), appVersion: '0.8.0', platform: 'android', stats, schema: 1});
const user = (uid, email = `${uid}@example.com`) => env.authenticatedContext(uid, {email}).firestore();
const admin = (uid, mfa = true, verified = true) => env.authenticatedContext(uid, {email: `${uid}@staff.test`, email_verified: verified, ...(mfa ? MFA : NO_MFA)}).firestore();
const seed = fn => env.withSecurityRulesDisabled(ctx => fn(ctx.firestore()));
const audit = (db, actor, role, action, target) => {
  const ref = doc(collection(db, 'auditLogs'));
  return {ref, data: {actor, role, action, target, summary: 'test', at: serverTimestamp(), expireAt: Timestamp.fromMillis(Date.now() + 365 * 86400_000)}};
};

before(async () => {
  env = await initializeTestEnvironment({projectId: 'demo-genz-code', firestore: {rules: readFileSync(new URL('../firestore.rules', import.meta.url), 'utf8')}});
});
after(async () => {await env.cleanup();});
beforeEach(async () => {
  await env.clearFirestore();
  await seed(async db => {
    for (const [uid, role] of [['super1', 'super_admin'], ['super2', 'super_admin'], ['editor', 'content_manager'], ['mod', 'moderator'], ['support', 'support_admin'], ['analyst', 'analyst']])
      await setDoc(doc(db, 'admins', uid), {role, active: true, email: `${uid}@staff.test`, updatedAt: Timestamp.now(), updatedBy: 'seed', lastAuditId: 'seed'});
    await setDoc(doc(db, 'users', 'bob'), {...account(), createdAt: Timestamp.fromMillis(Date.now() - 60_000), updatedAt: Timestamp.fromMillis(Date.now() - 60_000), lastActiveAt: Timestamp.now()});
    await setDoc(doc(db, 'users', 'bob', 'sync', 'saved'), {items: {idk: {u: 1}}, v: 3, updatedAt: Timestamp.fromMillis(Date.now() - 60_000)});
    await setDoc(doc(db, 'directory', 'bob'), {email: 'bob@example.com', createdAt: Timestamp.now()});
    await setDoc(doc(db, 'users', 'sue'), {...account(), status: 'suspended', createdAt: Timestamp.now(), updatedAt: Timestamp.now(), lastActiveAt: Timestamp.now()});
  });
});

// ---------- accounts & ownership ----------
test('unauthenticated clients can read no private data', async () => {
  const anon = env.unauthenticatedContext().firestore();
  await assertFails(getDoc(doc(anon, 'users/bob')));
  await assertFails(getDoc(doc(anon, 'users/bob/sync/saved')));
  await assertFails(getDoc(doc(anon, 'directory/bob')));
  await assertFails(getDocs(collection(anon, 'users')));
});
test('a user can create only their own active account record', async () => {
  const alice = user('alice');
  await assertSucceeds(setDoc(doc(alice, 'users/alice'), account()));
  await assertFails(setDoc(doc(alice, 'users/mallory'), account()));
  await assertFails(setDoc(doc(user('carol'), 'users/carol'), {...account(), status: 'suspended'}));
  await assertFails(setDoc(doc(user('dave'), 'users/dave'), {...account(), role: 'super_admin'}));
});
test('users cannot change their own status (no self-reactivation)', async () => {
  await assertFails(updateDoc(doc(user('sue'), 'users/sue'), {status: 'active', updatedAt: serverTimestamp()}));
  await assertFails(updateDoc(doc(user('bob'), 'users/bob'), {status: 'suspended', updatedAt: serverTimestamp()}));
});
test('owners read/write their learning data; other users cannot (no IDOR)', async () => {
  const bob = user('bob'), eve = user('eve');
  await assertSucceeds(getDoc(doc(bob, 'users/bob/sync/saved')));
  await assertFails(getDoc(doc(eve, 'users/bob/sync/saved')));
  await assertFails(setDoc(doc(eve, 'users/bob/sync/saved'), {items: {}, v: 3, updatedAt: serverTimestamp()}));
  await assertSucceeds(setDoc(doc(bob, 'users/bob/sync/saved'), {items: {idk: {u: 2}}, v: 3, updatedAt: serverTimestamp()}));
});
test('sync writes are schema-checked and rate-limited', async () => {
  const bob = user('bob');
  await assertFails(setDoc(doc(bob, 'users/bob/sync/saved'), {items: {}, v: 3, updatedAt: serverTimestamp(), extra: true}));
  await assertFails(setDoc(doc(bob, 'users/bob/sync/admin'), {items: {}, v: 3, updatedAt: serverTimestamp()}));
  await assertSucceeds(setDoc(doc(bob, 'users/bob/sync/progress'), {items: {}, resetAt: 0, v: 3, updatedAt: serverTimestamp()}));
  await assertFails(setDoc(doc(bob, 'users/bob/sync/progress'), {items: {}, resetAt: 1, v: 3, updatedAt: serverTimestamp()}));
});
test('profile sync accepts every one of the 12 avatars (0–11), nothing outside', async () => {
  const bob = user('bob');
  const profile = avatar => ({profile: {name: 'Bob', avatar, u: 1}, prefs: {language: 'English', quizCategory: 'Chat', u: 1}, v: 3, updatedAt: serverTimestamp()});
  await assertSucceeds(setDoc(doc(bob, 'users/bob/sync/profile'), profile(8)));
  await env.withSecurityRulesDisabled(async ctx => {await setDoc(doc(ctx.firestore(), 'users/bob/sync/profile'), {...profile(0), updatedAt: Timestamp.fromMillis(Date.now() - 60_000)});});
  await assertSucceeds(setDoc(doc(bob, 'users/bob/sync/profile'), profile(11)));
  await env.withSecurityRulesDisabled(async ctx => {await setDoc(doc(ctx.firestore(), 'users/bob/sync/profile'), {...profile(0), updatedAt: Timestamp.fromMillis(Date.now() - 60_000)});});
  await assertFails(setDoc(doc(bob, 'users/bob/sync/profile'), profile(12)));
});
test('suspended accounts cannot sync', async () => {
  await assertFails(setDoc(doc(user('sue'), 'users/sue/sync/saved'), {items: {}, v: 3, updatedAt: serverTimestamp()}));
});
test('directory e-mail must match the verified token e-mail', async () => {
  await assertSucceeds(setDoc(doc(user('alice'), 'directory/alice'), {email: 'alice@example.com', createdAt: serverTimestamp()}));
  await assertFails(setDoc(doc(user('carl'), 'directory/carl'), {email: 'ceo@example.com', createdAt: serverTimestamp()}));
});
test('self-deletion: tombstone + data removal in one batch; data cannot be deleted otherwise', async () => {
  const bob = user('bob');
  await assertFails(deleteDoc(doc(bob, 'users/bob/sync/saved')));
  const b = writeBatch(bob);
  b.set(doc(bob, 'users/bob'), {status: 'deleted', deletedAt: serverTimestamp(), updatedAt: serverTimestamp()});
  b.delete(doc(bob, 'users/bob/sync/saved'));
  b.delete(doc(bob, 'directory/bob'));
  await assertSucceeds(b.commit());
  await assertFails(setDoc(doc(bob, 'users/bob/sync/saved'), {items: {}, v: 3, updatedAt: serverTimestamp()}));
});

// ---------- administration ----------
test('admin access requires an admin record and a verified e-mail; MFA only when switched on', async () => {
  await assertSucceeds(getDocs(collection(admin('analyst'), 'users')));
  await assertSucceeds(getDocs(collection(admin('analyst', false), 'users')));
  await assertFails(getDocs(collection(admin('analyst', false, false), 'users')));
  await assertFails(getDocs(collection(user('bob'), 'users')));
  await assertFails(getDocs(collection(env.authenticatedContext('bob', {email: 'bob@example.com', email_verified: true, ...MFA}).firestore(), 'users')));
  // Owner switches two-step verification on (console write): password-only admin sessions are refused.
  await seed(db => setDoc(doc(db, 'config/security'), {adminMfaRequired: true}));
  await assertFails(getDocs(collection(admin('analyst', false), 'users')));
  await assertSucceeds(getDocs(collection(admin('analyst'), 'users')));
  // Nobody can change that switch from an app or the portal.
  await assertFails(setDoc(doc(admin('super1'), 'config/security'), {adminMfaRequired: false}));
});
test('least privilege: analysts cannot see e-mails or learning data; support can', async () => {
  await assertFails(getDoc(doc(admin('analyst'), 'directory/bob')));
  await assertFails(getDoc(doc(admin('analyst'), 'users/bob/sync/saved')));
  await assertSucceeds(getDoc(doc(admin('support'), 'directory/bob')));
  await assertSucceeds(getDoc(doc(admin('support'), 'users/bob/sync/saved')));
});
test('suspension requires a matching audit entry in the same batch', async () => {
  const mod = admin('mod');
  await assertFails(updateDoc(doc(mod, 'users/bob'), {status: 'suspended', statusReason: 'spam', statusUpdatedAt: serverTimestamp(), statusUpdatedBy: 'mod', updatedAt: serverTimestamp(), lastAuditId: 'missing'}));
  const a = audit(mod, 'mod', 'moderator', 'user.suspend', 'users/bob');
  const b = writeBatch(mod);
  b.set(a.ref, a.data);
  b.update(doc(mod, 'users/bob'), {status: 'suspended', statusReason: 'spam', statusUpdatedAt: serverTimestamp(), statusUpdatedBy: 'mod', updatedAt: serverTimestamp(), lastAuditId: a.ref.id});
  await assertSucceeds(b.commit());
  const analyst = admin('analyst');
  const a2 = audit(analyst, 'analyst', 'analyst', 'user.reactivate', 'users/bob');
  const b2 = writeBatch(analyst);
  b2.set(a2.ref, a2.data);
  b2.update(doc(analyst, 'users/bob'), {status: 'active', statusReason: 'x', statusUpdatedAt: serverTimestamp(), statusUpdatedBy: 'analyst', updatedAt: serverTimestamp(), lastAuditId: a2.ref.id});
  await assertFails(b2.commit());
});
test('audit logs are append-only and cannot be forged', async () => {
  const mod = admin('mod');
  const forged = audit(mod, 'super1', 'super_admin', 'user.suspend', 'users/bob');
  await assertFails(setDoc(forged.ref, forged.data));
  const ok = audit(mod, 'mod', 'moderator', 'admin.login', 'admins/mod');
  await assertSucceeds(setDoc(ok.ref, ok.data));
  await assertFails(updateDoc(doc(admin('super1'), 'auditLogs', ok.ref.id), {summary: 'edited'}));
  await assertFails(deleteDoc(doc(admin('super1'), 'auditLogs', ok.ref.id)));
  await assertFails(getDoc(doc(mod, 'auditLogs', ok.ref.id)));
});
test('super admins cannot change their own role; other roles cannot grant roles', async () => {
  const s1 = admin('super1');
  const a = audit(s1, 'super1', 'super_admin', 'admin.role.set', 'admins/super1');
  const b = writeBatch(s1);
  b.set(a.ref, a.data);
  b.set(doc(s1, 'admins/super1'), {role: 'super_admin', active: false, email: 'x@y.z', updatedAt: serverTimestamp(), updatedBy: 'super1', lastAuditId: a.ref.id});
  await assertFails(b.commit());
  const ed = admin('editor');
  const a2 = audit(ed, 'editor', 'content_manager', 'admin.role.set', 'admins/bob');
  const b2 = writeBatch(ed);
  b2.set(a2.ref, a2.data);
  b2.set(doc(ed, 'admins/bob'), {role: 'super_admin', active: true, email: 'bob@example.com', updatedAt: serverTimestamp(), updatedBy: 'editor', lastAuditId: a2.ref.id});
  await assertFails(b2.commit());
});

// ---------- content ----------
const entry = (id, status, version) => ({id, term: 'delulu', full: 'Delusional', meaning: 'Playfully unrealistic hopes.', example: '', category: 'Social', subcategory: '', variations: [], region: 'Online', tone: 'Playful', language: 'English', sensitivity: 'None', caution: 'Context matters.', status, version});
async function writeContent(db, uid, role, id, status, version, action, extra = b => {}) {
  const a = audit(db, uid, role, `content.${action}`, `content/${id}`);
  const b = writeBatch(db);
  b.set(a.ref, a.data);
  const data = {...entry(id, status, version), createdAt: version === 1 ? serverTimestamp() : Timestamp.fromMillis(0), updatedAt: serverTimestamp(), updatedBy: uid, lastAuditId: a.ref.id};
  b.set(doc(db, 'content', id), data);
  b.set(doc(db, 'content', id, 'versions', String(version)), {snapshot: entry(id, status, version), by: uid, at: serverTimestamp(), action: action === 'submit_review' ? 'submit_review' : action});
  extra(b);
  return b.commit();
}
test('content workflow: draft → review → publish, with history and audit', async () => {
  const ed = admin('editor');
  await assertSucceeds(writeContent(ed, 'editor', 'content_manager', 'cms-delulu', 'draft', 1, 'create'));
  // Publishing straight from draft is denied.
  await assertFails(writeContent(ed, 'editor', 'content_manager', 'cms-delulu', 'published', 2, 'publish', b => b.set(doc(ed, 'publishedContent/cms-delulu'), {...entry('cms-delulu', 'published', 2), updatedAt: serverTimestamp()})));
  await seed(db => updateDoc(doc(db, 'content/cms-delulu'), {createdAt: Timestamp.fromMillis(0)}));
  await assertSucceeds(writeContent(ed, 'editor', 'content_manager', 'cms-delulu', 'in_review', 2, 'submit_review'));
  await assertSucceeds(writeContent(ed, 'editor', 'content_manager', 'cms-delulu', 'published', 3, 'publish', b => b.set(doc(ed, 'publishedContent/cms-delulu'), {...entry('cms-delulu', 'published', 3), updatedAt: serverTimestamp()})));
  const anon = env.unauthenticatedContext().firestore();
  await assertSucceeds(getDoc(doc(anon, 'publishedContent/cms-delulu')));
  await assertFails(getDoc(doc(anon, 'content/cms-delulu')));
  await assertFails(updateDoc(doc(ed, 'content/cms-delulu/versions/1'), {action: 'update'}));
});
test('moderators and analysts cannot edit content; invalid content is rejected', async () => {
  await assertFails(writeContent(admin('mod'), 'mod', 'moderator', 'cms-x', 'draft', 1, 'create'));
  const ed = admin('editor');
  const a = audit(ed, 'editor', 'content_manager', 'content.create', 'content/cms-bad');
  const b = writeBatch(ed);
  b.set(a.ref, a.data);
  b.set(doc(ed, 'content/cms-bad'), {...entry('cms-bad', 'draft', 1), term: 'x'.repeat(61), createdAt: serverTimestamp(), updatedAt: serverTimestamp(), updatedBy: 'editor', lastAuditId: a.ref.id});
  b.set(doc(ed, 'content/cms-bad/versions/1'), {snapshot: {}, by: 'editor', at: serverTimestamp(), action: 'create'});
  await assertFails(b.commit());
});

// ---------- user submissions & security events ----------
test('submissions need an active account and are rate-limited server-side', async () => {
  const bob = user('bob');
  const submit = () => {const b = writeBatch(bob); b.set(doc(bob, 'users/bob/limits/ugc'), {last: serverTimestamp()}); b.set(doc(collection(bob, 'submissions')), {term: 'delulu', meaning: 'Unrealistic.', example: '', category: 'Social', uid: 'bob', status: 'pending', createdAt: serverTimestamp()}); return b.commit();};
  await assertFails(submit());
  await assertFails(submit());
  await assertFails(setDoc(doc(collection(bob, 'submissions')), {term: 'x', meaning: 'y', example: '', category: 'Social', uid: 'bob', status: 'pending', createdAt: serverTimestamp()}));
  const sue = user('sue');
  const b = writeBatch(sue); b.set(doc(sue, 'users/sue/limits/ugc'), {last: serverTimestamp()}); b.set(doc(collection(sue, 'submissions')), {term: 'a', meaning: 'b', example: '', category: 'Chat', uid: 'sue', status: 'pending', createdAt: serverTimestamp()});
  await assertFails(b.commit());
});
test('submissions: the owner may edit a pending suggestion; no one else may', async () => {
  const bob = user('bob');
  const ref = doc(bob, 'submissions', 'sub-delulu');
  const create = () => {const b = writeBatch(bob); b.set(doc(bob, 'users/bob/limits/ugc'), {last: serverTimestamp()}); b.set(ref, {term: 'delulu', meaning: 'Unrealistic.', example: '', category: 'Social', uid: 'bob', status: 'pending', createdAt: serverTimestamp()}); return b.commit();};
  await assertFails(create());
  await seed(db=>setDoc(doc(db,'submissions/sub-delulu'),{term:'delulu',meaning:'Unrealistic.',example:'',category:'Social',uid:'bob',status:'pending',createdAt:Timestamp.now()}));
  const edit = (db, patch) => updateDoc(doc(db, 'submissions/sub-delulu'), {...patch, updatedAt: serverTimestamp()});
  // The owner edits the text while it is pending (the 250-token edit in the app).
  await assertSucceeds(edit(bob, {meaning: 'Unrealistic or delusional.'}));
  // A different user cannot edit it.
  await assertFails(edit(user('amy'), {meaning: 'Changed by amy.'}));
  // The owner cannot change the status, the owner, the category to an invalid
  // value, or sneak in a link.
  await assertFails(edit(bob, {status: 'accepted'}));
  await assertFails(edit(bob, {uid: 'amy'}));
  await assertFails(edit(bob, {category: 'Spam'}));
  await assertFails(edit(bob, {meaning: 'see https://spam.example'}));
  // Once a moderator accepts it, the owner can no longer edit it.
  const s1 = admin('super1'), b = writeBatch(s1);
  const a = audit(s1, 'super1', 'super_admin', 'submission.accept', 'submissions/sub-delulu');
  b.set(a.ref, a.data);
  b.update(doc(s1, 'submissions/sub-delulu'), {status: 'accepted', reviewedBy: 'super1', reviewedAt: serverTimestamp(), contentId: 'c-delulu', lastAuditId: a.ref.id});
  await assertSucceeds(b.commit());
  await assertFails(edit(bob, {meaning: 'Too late to change.'}));
});
test('security events: allow-listed, owner-stamped, rate-limited, readable only by super admins', async () => {
  const bob = user('bob');
  const ev = type => {const b = writeBatch(bob); b.set(doc(bob, 'users/bob/limits/sec'), {last: serverTimestamp()}); const ref = doc(collection(bob, 'securityEvents')); b.set(ref, {uid: 'bob', type, detail: '', platform: 'android', appVersion: '0.8.0', at: serverTimestamp(), expireAt: Timestamp.fromMillis(Date.now() + 90 * 86400_000)}); return b.commit().then(() => ref);};
  const ref = await assertSucceeds(ev('session_expired'));
  await assertFails(ev('session_expired'));
  await assertFails(getDocs(query(collection(admin('mod'), 'securityEvents'), where('type', '==', 'session_expired'))));
  await assertSucceeds(getDoc(doc(admin('super1'), 'securityEvents', ref.id)));
});
test('drafts and staff collections are never public', async () => {
  const anon = env.unauthenticatedContext().firestore();
  for (const c of ['content', 'auditLogs', 'securityEvents', 'admins', 'submissions', 'reports', 'chatReports', 'feedback']) await assertFails(getDocs(collection(anon, c)));
  await assertSucceeds(getDoc(doc(anon, 'config/app')));
});

// ---------- community words (published instantly, 0.8.3) ----------
const vuser = (uid, verified = true) => env.authenticatedContext(uid, {email: `${uid}@example.com`, email_verified: verified}).firestore();
const word = (uid, id, extra = {}) => ({id, term: 'skibidi', meaning: 'A nonsense word used for fun.', example: '', category: 'Social', uid, status: 'live', createdAt: serverTimestamp(), updatedAt: serverTimestamp(), ...extra});
const publish = (db, uid, id, extra) => {const b = writeBatch(db); b.set(doc(db, `users/${uid}/limits/ugc`), {last: serverTimestamp()}); b.set(doc(db, `communityWords/${id}`), word(uid, id, extra)); return b.commit();};
const seedActive = uid => seed(db => setDoc(doc(db, 'users', uid), {...account(), createdAt: Timestamp.fromMillis(Date.now() - 60_000), updatedAt: Timestamp.fromMillis(Date.now() - 60_000), lastActiveAt: Timestamp.now()}));

test('community words: verified active users publish instantly and anyone can read them', async () => {
  await seed(db=>setDoc(doc(db,'communityWords/c-skibidi'),word('bob','c-skibidi')));
  const anon = env.unauthenticatedContext().firestore();
  await assertSucceeds(getDoc(doc(anon, 'communityWords/c-skibidi')));
  await assertSucceeds(getDocs(collection(anon, 'communityWords')));
});
test('community words: unverified, suspended, spoofed and rate-limited writes are refused', async () => {
  await assertFails(publish(vuser('bob', false), 'bob', 'c-skibidi'));
  await assertFails(publish(vuser('sue'), 'sue', 'c-skibidi'));
  await assertFails(publish(vuser('nobody'), 'nobody', 'c-skibidi')); // no account record
  const bob = vuser('bob');
  const spoof = writeBatch(bob); spoof.set(doc(bob, 'users/bob/limits/ugc'), {last: serverTimestamp()}); spoof.set(doc(bob, 'communityWords/c-skibidi'), word('eve', 'c-skibidi'));
  await assertFails(spoof.commit());
  await assertFails(setDoc(doc(bob, 'communityWords/c-skibidi'), word('bob', 'c-skibidi'))); // no rate-limit stamp
  await seed(db=>setDoc(doc(db,'communityWords/c-skibidi'),word('bob','c-skibidi')));
  await assertFails(publish(bob, 'bob', 'c-rizzler')); // within 60 s
});
test('community words: validated, one per word, no links, e-mails or phone numbers', async () => {
  const bob = vuser('bob');
  await assertFails(publish(bob, 'bob', 'c-x', {meaning: 'see https://spam.example'}));
  await assertFails(publish(bob, 'bob', 'c-x', {example: 'go to www.spam.example'}));
  await assertFails(publish(bob, 'bob', 'c-x', {meaning: 'mail me@spam.io'}));
  await assertFails(publish(bob, 'bob', 'c-x', {meaning: 'call 0300 1234567'}));
  await assertFails(publish(bob, 'bob', 'c-x', {meaning: 'ok\nhttps://hidden.example'}));
  await assertFails(publish(bob, 'bob', 'c-x', {category: 'Spam'}));
  await assertFails(publish(bob, 'bob', 'c-x', {meaning: 'x'}));
  await assertFails(publish(bob, 'bob', 'c-x', {admin: true}));
  await assertFails(publish(bob, 'bob', 'c-x', {status: 'hidden'}));
  await assertFails(publish(bob, 'bob', 'c-x', {id: 'c-y'}));
  await assertFails(publish(bob, 'bob', 'not-community'));
  await seed(db=>setDoc(doc(db,'communityWords/c-x'),word('bob','c-x',{meaning: '143 means I love you'})));
  await seedActive('amy');
  await assertFails(publish(vuser('amy'), 'amy', 'c-x', {meaning: 'Something else entirely.'}));
  // The owner may edit their own live word (250-token edit in the app); anyone
  // else may not. A non-moderator still cannot delete it.
  await assertSucceeds(updateDoc(doc(bob, 'communityWords/c-x'), {meaning: '143 means I love you, for real.', updatedAt: serverTimestamp()}));
  await assertFails(updateDoc(doc(vuser('amy'), 'communityWords/c-x'), {meaning: 'changed by amy', updatedAt: serverTimestamp()}));
  await assertFails(updateDoc(doc(bob, 'communityWords/c-x'), {meaning: 'see https://spam.example', updatedAt: serverTimestamp()}));
  await assertFails(updateDoc(doc(bob, 'communityWords/c-x'), {status: 'hidden', updatedAt: serverTimestamp()}));
  await assertFails(deleteDoc(doc(bob, 'communityWords/c-x')));
});
test('community words: moderators hide and restore with an audit entry; analysts cannot', async () => {
  await seed(db=>setDoc(doc(db,'communityWords/c-skibidi'),word('bob','c-skibidi')));
  const moderate = (uid, role, status, withAudit = true) => {
    const db = admin(uid), b = writeBatch(db);
    const a = audit(db, uid, role, status === 'hidden' ? 'community.hide' : 'community.restore', 'communityWords/c-skibidi');
    if (withAudit) b.set(a.ref, a.data);
    b.update(doc(db, 'communityWords/c-skibidi'), {status, updatedAt: serverTimestamp(), lastAuditId: a.ref.id});
    return b.commit();
  };
  await assertFails(moderate('analyst', 'analyst', 'hidden'));
  await assertFails(moderate('mod', 'moderator', 'hidden', false));
  await assertSucceeds(moderate('mod', 'moderator', 'hidden'));
  await assertSucceeds(moderate('editor', 'content_manager', 'live'));
});
test('community words: moderators edit and delete with an audit entry; analysts cannot', async () => {
  await seed(db=>setDoc(doc(db,'communityWords/c-skibidi'),word('bob','c-skibidi')));
  const edit = (uid, role, patch, withAudit = true) => {
    const db = admin(uid), b = writeBatch(db);
    const a = audit(db, uid, role, 'community.edit', 'communityWords/c-skibidi');
    if (withAudit) b.set(a.ref, a.data);
    b.update(doc(db, 'communityWords/c-skibidi'), {...patch, updatedAt: serverTimestamp(), lastAuditId: a.ref.id});
    return b.commit();
  };
  await assertFails(edit('analyst', 'analyst', {meaning: 'Edited by an analyst.'}));
  await assertFails(edit('mod', 'moderator', {meaning: 'Edited without an audit entry.'}, false));
  await assertFails(edit('mod', 'moderator', {meaning: 'see https://spam.example'}));
  await assertFails(edit('mod', 'moderator', {category: 'Spam'}));
  await assertSucceeds(edit('mod', 'moderator', {meaning: 'Edited by a moderator.', example: 'No cap.'}));
  await assertSucceeds(edit('editor', 'content_manager', {category: 'Chat'}));
  // Delete: a moderator may delete; a regular user and an analyst may not. The
  // portal writes the 'community.delete' audit entry in the same batch, but the
  // rules cannot verify it on a delete (request.resource is null), so the role
  // gate is the enforcement here.
  const del = uid => {const db = admin(uid), b = writeBatch(db); const a = audit(db, uid, uid === 'mod' ? 'moderator' : 'analyst', 'community.delete', 'communityWords/c-skibidi'); b.set(a.ref, a.data); b.delete(doc(db, 'communityWords/c-skibidi')); return b.commit();};
  await assertFails(del('analyst'));
  await assertSucceeds(del('mod'));
});
test('community words: the kill switch stops instant publishing', async () => {
  await seed(db => setDoc(doc(db, 'config/app'), {ugcEnabled: true, contentUpdatesEnabled: true, communityWordsEnabled: false, chatEnabled: true, minSupportedVersion: '0.8.0', updatedAt: Timestamp.now(), updatedBy: 'seed', lastAuditId: 'seed'}));
  await assertFails(publish(vuser('bob'), 'bob', 'c-skibidi'));
  const s1 = admin('super1'), b = writeBatch(s1);
  const a = audit(s1, 'super1', 'super_admin', 'config.update', 'config/app');
  b.set(a.ref, a.data);
  b.set(doc(s1, 'config/app'), {ugcEnabled: true, contentUpdatesEnabled: true, communityWordsEnabled: true, chatEnabled: true, minSupportedVersion: '0.8.3', updatedAt: serverTimestamp(), updatedBy: 'super1', lastAuditId: a.ref.id});
  await assertSucceeds(b.commit());
  await seed(db=>setDoc(doc(db,'communityWords/c-skibidi'),word('bob','c-skibidi')));
});
test('community words: account deletion scrubs the contributor’s words', async () => {
  const bob = vuser('bob');
  await seed(db=>setDoc(doc(db,'communityWords/c-skibidi'),word('bob','c-skibidi')));
  const scrub = () => setDoc(doc(bob, 'communityWords/c-skibidi'), {id: 'c-skibidi', status: 'removed', updatedAt: serverTimestamp()});
  await assertFails(scrub());
  await assertSucceeds(setDoc(doc(bob, 'users/bob'), {status: 'deleted', deletedAt: serverTimestamp(), updatedAt: serverTimestamp()}));
  await assertSucceeds(scrub());
});

// ---------- community chat (one room, 0.9.0) ----------
const message = (uid, extra = {}) => ({uid, name: 'Code Explorer', text: 'no cap, that was funny', status: 'live', createdAt: serverTimestamp(), ...extra});
const post = async (db, uid, extra = {}) => {
  if(uid==='bob')await seed(trusted=>setDoc(doc(trusted,'chatPasses/bob'),{uid:'bob',expiresAt:Timestamp.fromMillis(Date.now()+3600000)}));
  const b = writeBatch(db);
  b.set(doc(db, `users/${uid}/limits/chat`), {last: serverTimestamp()});
  const ref = doc(collection(db, 'communityMessages'));
  b.set(ref, message(uid, extra));
  return b.commit().then(() => ref);
};

test('community chat: verified active users can post, anyone can read live messages', async () => {
  const ref = await assertSucceeds(post(vuser('bob'), 'bob'));
  const anon = env.unauthenticatedContext().firestore();
  await assertSucceeds(getDoc(doc(anon, 'communityMessages', ref.id)));
  // The app reads with where('status', '==', 'live') (see src/chat.ts subscribeChat).
  // Firestore rules are not filters: a list whose rule reads resource.data.status
  // is only allowed when the query itself filters on status, so an unfiltered
  // list is refused ("Property status is undefined on object") — by design,
  // hidden and removed messages must never be listable.
  await assertSucceeds(getDocs(query(collection(anon, 'communityMessages'), where('status', '==', 'live'))));
  await assertFails(getDocs(collection(anon, 'communityMessages')));
});

test('community chat: unverified, suspended, spoofed and rate-limited writes are refused', async () => {
  await assertFails(post(vuser('bob', false), 'bob'));
  await assertFails(post(vuser('sue'), 'sue'));
  await assertFails(post(vuser('nobody'), 'nobody')); // no account record
  const bob = vuser('bob');
  const spoof = writeBatch(bob);
  spoof.set(doc(bob, 'users/bob/limits/chat'), {last: serverTimestamp()});
  spoof.set(doc(collection(bob, 'communityMessages')), message('eve'));
  await assertFails(spoof.commit());
  await assertFails(setDoc(doc(collection(bob, 'communityMessages')), message('bob'))); // no rate-limit stamp
  await assertSucceeds(post(bob, 'bob'));
  await assertFails(post(bob, 'bob')); // within 10 s
});

test('community chat: validated — no links, e-mails, phone numbers, blank or oversize text', async () => {
  const bob = vuser('bob');
  await assertFails(post(bob, 'bob', {text: 'see https://spam.example'}));
  await assertFails(post(bob, 'bob', {text: 'mail me@spam.io'}));
  await assertFails(post(bob, 'bob', {text: 'call 0300 1234567'}));
  await assertFails(post(bob, 'bob', {text: '   '}));
  await assertFails(post(bob, 'bob', {text: 'x'.repeat(501)}));
  await assertFails(post(bob, 'bob', {name: 'x'.repeat(25)}));
  await assertFails(post(bob, 'bob', {status: 'hidden'}));
  await assertFails(post(bob, 'bob', {admin: true}));
  await assertSucceeds(post(bob, 'bob', {text: '143 means I love you'}));
});

test('community chat: moderators hide and restore with an audit entry; analysts cannot; owners delete their own message', async () => {
  const ref = await assertSucceeds(post(vuser('bob'), 'bob'));
  const anon = env.unauthenticatedContext().firestore();
  const moderate = (uid, role, status, withAudit = true) => {
    const db = admin(uid), b = writeBatch(db);
    const a = audit(db, uid, role, status === 'hidden' ? 'chat.hide' : 'chat.restore', `communityMessages/${ref.id}`);
    if (withAudit) b.set(a.ref, a.data);
    b.update(doc(db, 'communityMessages', ref.id), {status, updatedAt: serverTimestamp(), lastAuditId: a.ref.id});
    return b.commit();
  };
  await assertFails(moderate('analyst', 'analyst', 'hidden'));
  await assertFails(moderate('mod', 'moderator', 'hidden', false));
  await assertSucceeds(moderate('mod', 'moderator', 'hidden'));
  await assertFails(getDoc(doc(anon, 'communityMessages', ref.id)));
  await assertSucceeds(getDoc(doc(admin('mod'), 'communityMessages', ref.id)));
  await assertSucceeds(moderate('editor', 'content_manager', 'live'));
  await assertSucceeds(getDoc(doc(anon, 'communityMessages', ref.id)));
  await assertFails(deleteDoc(doc(vuser('amy'), 'communityMessages', ref.id)));
  await assertSucceeds(deleteDoc(doc(vuser('bob'), 'communityMessages', ref.id)));
});

test('chat reports: users can report a message; moderators resolve with an audit entry', async () => {
  const ref = await assertSucceeds(post(vuser('bob'), 'bob'));
  await seedActive('amy');
  const report = (db, uid) => {
    const b = writeBatch(db);
    b.set(doc(db, `users/${uid}/limits/ugc`), {last: serverTimestamp()});
    const r = doc(collection(db, 'chatReports'));
    b.set(r, {messageId: ref.id, reason: 'Offensive or harmful', note: '', uid, status: 'open', createdAt: serverTimestamp()});
    return b.commit().then(() => r);
  };
  const rep = await assertSucceeds(report(vuser('amy'), 'amy'));
  const anon = env.unauthenticatedContext().firestore();
  await assertFails(getDocs(collection(anon, 'chatReports')));
  await assertSucceeds(getDoc(doc(vuser('amy'), 'chatReports', rep.id)));
  const resolve = (uid, role, status, withAudit = true) => {
    const db = admin(uid), b = writeBatch(db);
    const a = audit(db, uid, role, status === 'resolved' ? 'chat.report.resolve' : 'chat.report.dismiss', `chatReports/${rep.id}`);
    if (withAudit) b.set(a.ref, a.data);
    b.update(doc(db, 'chatReports', rep.id), {status, resolvedBy: uid, resolvedAt: serverTimestamp(), resolution: 'hidden', lastAuditId: a.ref.id});
    return b.commit();
  };
  await assertFails(resolve('analyst', 'analyst', 'resolved'));
  await assertFails(resolve('mod', 'moderator', 'resolved', false));
  await assertSucceeds(resolve('mod', 'moderator', 'resolved'));
});

test('community chat: the kill switch stops posting', async () => {
  await seed(db => setDoc(doc(db, 'config/app'), {ugcEnabled: true, contentUpdatesEnabled: true, communityWordsEnabled: true, chatEnabled: false, minSupportedVersion: '0.9.0', updatedAt: Timestamp.now(), updatedBy: 'seed', lastAuditId: 'seed'}));
  await assertFails(post(vuser('bob'), 'bob'));
  const s1 = admin('super1'), b = writeBatch(s1);
  const a = audit(s1, 'super1', 'super_admin', 'config.update', 'config/app');
  b.set(a.ref, a.data);
  b.set(doc(s1, 'config/app'), {ugcEnabled: true, contentUpdatesEnabled: true, communityWordsEnabled: true, chatEnabled: true, minSupportedVersion: '0.9.0', updatedAt: serverTimestamp(), updatedBy: 'super1', lastAuditId: a.ref.id});
  await assertSucceeds(b.commit());
  await assertSucceeds(post(vuser('bob'), 'bob'));
});

test('community chat: account deletion scrubs the contributor’s messages', async () => {
  const ref = await assertSucceeds(post(vuser('bob'), 'bob'));
  const bob = vuser('bob');
  const scrub = () => setDoc(doc(bob, 'communityMessages', ref.id), {status: 'removed', text: '', name: '', updatedAt: serverTimestamp()});
  await assertFails(scrub());
  await assertSucceeds(setDoc(doc(bob, 'users/bob'), {status: 'deleted', deletedAt: serverTimestamp(), updatedAt: serverTimestamp()}));
  await assertSucceeds(scrub());
  await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), 'communityMessages', ref.id)));
});

// ---------- reviewed community posts and protected feature data ----------
const seedPost = async (id, status) => {
  await seed(db => setDoc(doc(db, 'communityPosts', id), {uid: 'bob', name: 'Code Explorer', text: 'A new term',
    status, schema: 2, hidden: status !== 'approved', likeCount: 0, commentCount: 0, createdAt: Timestamp.now()}));
  return {id};
};
test('reviewed posts: only approved entries are public; pending and rejected stay private', async () => {
  const anon=env.unauthenticatedContext().firestore(), bob=vuser('bob'), sue=vuser('sue');
  for (const status of ['pending','approved','rejected']) {
    await seedPost(status,status);
    const read = db => getDoc(doc(db,'communityPosts',status));
    await assertSucceeds(read(bob));
    await assertSucceeds(read(admin('mod')));
    await (status==='approved'?assertSucceeds:assertFails)(read(anon));
    if(status!=='approved') await assertFails(read(sue));
  }
  await assertSucceeds(getDocs(query(collection(anon,'communityPosts'),where('hidden','==',false),where('status','==','approved'))));
  await assertFails(getDocs(query(collection(anon,'communityPosts'),where('hidden','==',false))));
});

test('reviewed posts and balances: clients cannot bypass callable fees, approval or engagement', async () => {
  await seedPost('pending','pending');
  await seedPost('approved','approved');
  const bob=vuser('bob');
  await assertFails(setDoc(doc(bob,'communityPosts/forged'),{uid:'bob',hidden:false,status:'approved'}));
  await assertFails(updateDoc(doc(bob,'communityPosts/pending'),{hidden:false,status:'approved'}));
  await assertFails(updateDoc(doc(admin('mod'),'communityPosts/pending'),{hidden:false,status:'approved'}));
  await assertFails(updateDoc(doc(bob,'communityPosts/approved'),{likeCount:9}));
  await assertFails(setDoc(doc(bob,'communityPostLikes/approved_bob'),{uid:'bob',postId:'approved'}));
  await assertFails(setDoc(doc(bob,'communityPosts/approved/comments/fake'),{text:'hello',uid:'bob'}));
  await assertFails(setDoc(doc(bob,'users/bob/tokenLedger/fake'),{type:'feature_refund',amount:250,balanceAfter:250,createdAt:serverTimestamp()}));
  await assertFails(setDoc(doc(bob,'users/bob/tokenLedger/fake-proof'),{type:'migration',amount:250,balanceAfter:250,verifiedForFeatures:true,createdAt:serverTimestamp()}));
});

test('Daily Code and badge applications are private and server-controlled', async () => {
  await seed(async db => {
    await setDoc(doc(db,'dailyCodeApplications/one'),{uid:'bob',status:'pending'});
    await setDoc(doc(db,'verificationApplications/one'),{uid:'bob',status:'pending'});
    await setDoc(doc(db,'verifiedContributors/bob'),{verified:true});
  });
  const bob=vuser('bob'), other=vuser('sue');
  for (const name of ['dailyCodeApplications','verificationApplications']) {
    await assertSucceeds(getDoc(doc(bob,name,'one')));
    await assertFails(getDoc(doc(other,name,'one')));
    await assertFails(updateDoc(doc(bob,name,'one'),{status:'approved'}));
  }
  await assertSucceeds(getDoc(doc(other,'verifiedContributors/bob')));
  await assertFails(setDoc(doc(bob,'verifiedContributors/sue'),{verified:true}));
  await assertFails(setDoc(doc(bob,'dailyCodeDates/2027-01-01'),{status:'scheduled'}));
});

test('post reports: users can report a post; moderators resolve with an audit entry', async () => {
  const ref = await seedPost('reported','approved');
  await seedActive('amy');
  const report = (db, uid) => {
    const b = writeBatch(db);
    b.set(doc(db, `users/${uid}/limits/ugc`), {last: serverTimestamp()});
    const r = doc(collection(db, 'postReports'));
    b.set(r, {postId: ref.id, reason: 'Offensive or harmful', note: '', uid, status: 'open', createdAt: serverTimestamp()});
    return b.commit().then(() => r);
  };
  const rep = await assertSucceeds(report(vuser('amy'), 'amy'));
  const anon = env.unauthenticatedContext().firestore();
  await assertFails(getDocs(collection(anon, 'postReports')));
  await assertSucceeds(getDoc(doc(vuser('amy'), 'postReports', rep.id)));
  const resolve = (uid, role, status, withAudit = true) => {
    const db = admin(uid), b = writeBatch(db);
    const a = audit(db, uid, role, status === 'resolved' ? 'report.resolve' : 'report.dismiss', `postReports/${rep.id}`);
    if (withAudit) b.set(a.ref, a.data);
    b.update(doc(db, 'postReports', rep.id), {status, resolvedBy: uid, resolvedAt: serverTimestamp(), resolution: 'hidden', lastAuditId: a.ref.id});
    return b.commit();
  };
  await assertFails(resolve('analyst', 'analyst', 'resolved'));
  await assertFails(resolve('mod', 'moderator', 'resolved', false));
  await assertSucceeds(resolve('mod', 'moderator', 'resolved'));
});

// ---------- retention without TTL (Spark plan, 0.8.6) ----------
test('retention: only Super Admins delete audit logs and security events, and only after they expire', async () => {
  const past = Timestamp.fromMillis(Date.now() - 1000), future = Timestamp.fromMillis(Date.now() + 86400_000);
  await seed(async db => {
    await setDoc(doc(db, 'auditLogs/old'), {actor: 'mod', role: 'moderator', action: 'admin.login', target: 'admins/mod', summary: '', at: Timestamp.fromMillis(0), expireAt: past});
    await setDoc(doc(db, 'auditLogs/new'), {actor: 'mod', role: 'moderator', action: 'admin.login', target: 'admins/mod', summary: '', at: Timestamp.now(), expireAt: future});
    await setDoc(doc(db, 'securityEvents/old'), {uid: 'bob', type: 'session_expired', detail: '', platform: 'android', appVersion: '0.8.0', at: Timestamp.fromMillis(0), expireAt: past});
  });
  await assertFails(deleteDoc(doc(admin('mod'), 'auditLogs/old')));
  await assertFails(deleteDoc(doc(admin('super1'), 'auditLogs/new')));
  await assertSucceeds(getDocs(query(collection(admin('super1'), 'auditLogs'), where('expireAt', '<', Timestamp.now()))));
  await assertSucceeds(deleteDoc(doc(admin('super1'), 'auditLogs/old')));
  await assertSucceeds(deleteDoc(doc(admin('super1'), 'securityEvents/old')));
  const a = audit(admin('super1'), 'super1', 'super_admin', 'logs.purge', 'auditLogs');
  await assertSucceeds(setDoc(a.ref, a.data));
});

test('leaderboard: anyone can read the board; only the owner writes their own row, with validated fields', async () => {
  await seedActive('amy');
  await seedActive('bob');
  const anon = env.unauthenticatedContext().firestore();
  const row = {name: 'Amy', tokens: 120, updatedAt: serverTimestamp()};
  await assertSucceeds(getDocs(collection(anon, 'leaderboard')));
  await assertFails(setDoc(doc(anon, 'leaderboard', 'amy'), row));
  await assertFails(setDoc(doc(vuser('bob'), 'leaderboard', 'amy'), row));
  await assertSucceeds(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), row));
  await assertSucceeds(getDoc(doc(anon, 'leaderboard', 'amy')));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, tokens: -5}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, tokens: 1000001}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, name: ''}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, extra: 1}));
  // Game level ranking fields (Build 36): optional, bounded.
  await assertSucceeds(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, xp: 420, level: 3, rank: 'Code Cracker'}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, xp: -1, level: 1, rank: 'Rookie'}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, xp: 10, level: 0, rank: 'Rookie'}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, xp: 10, level: 1, rank: ''}));
  await assertFails(setDoc(doc(vuser('amy'), 'leaderboard', 'amy'), {...row, xp: 1.5, level: 1, rank: 'Rookie'}));
  await assertSucceeds(deleteDoc(doc(vuser('amy'), 'leaderboard', 'amy')));
});

test('token ledger: purchases credit exactly the catalog amount, once per order; other writes are refused', async () => {
  await seedActive('amy');
  await seedActive('bob');
  const db = vuser('amy');
  const purchase = {type: 'purchase', amount: 1000, balanceAfter: 1000, ref: 'GPA.1234-5678', productId: 'tokens_1000', purchaseToken: 'tok-abc', createdAt: serverTimestamp()};
  // Valid purchase, keyed by its order ID.
  await assertSucceeds(setDoc(doc(db, 'users/amy/tokenLedger/order-GPA.1234-5678'), purchase));
  // The same order ID again is refused (create-only; a setDoc on an existing doc is an update).
  await assertFails(setDoc(doc(db, 'users/amy/tokenLedger/order-GPA.1234-5678'), purchase));
  // Wrong amount for the product is refused.
  await assertFails(setDoc(doc(db, 'users/amy/tokenLedger/order-GPA.9999'), {...purchase, ref: 'GPA.9999', amount: 999}));
  // Unknown product is refused.
  await assertFails(setDoc(doc(db, 'users/amy/tokenLedger/order-GPA.9998'), {...purchase, ref: 'GPA.9998', productId: 'tokens_999', amount: 999}));
  // The document ID must be the order ID.
  await assertFails(setDoc(doc(db, 'users/amy/tokenLedger/order-wrong'), purchase));
  // Another user cannot write my ledger.
  await assertFails(setDoc(doc(vuser('bob'), 'users/amy/tokenLedger/order-GPA.7777'), {...purchase, ref: 'GPA.7777'}));
  // Suspended users cannot write.
  await assertFails(setDoc(doc(vuser('sue'), 'users/sue/tokenLedger/order-GPA.1111'), {...purchase, ref: 'GPA.1111'}));
  // Ledger entries can never be updated.
  await assertFails(updateDoc(doc(db, 'users/amy/tokenLedger/order-GPA.1234-5678'), {amount: 5000}));
  // A migration opening balance is allowed once, under its fixed ID.
  await assertSucceeds(setDoc(doc(db, 'users/amy/tokenLedger/migration-v1'), {type: 'migration', amount: 120, balanceAfter: 120, ref: 'v1-migration', createdAt: serverTimestamp()}));
  // Reading my own ledger works; strangers cannot.
  await assertSucceeds(getDocs(collection(db, 'users/amy/tokenLedger')));
  await assertFails(getDocs(collection(vuser('bob'), 'users/amy/tokenLedger')));
});

test('token grant: a Super Admin can send tokens to an active user (audited); others cannot', async () => {
  await seedActive('amy');
  await seedActive('bob');
  const s1 = admin('super1');
  const wallet = {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()};
  // Seed amy's wallet as the owner first, so the grant builds on a real balance.
  await assertSucceeds(setDoc(doc(vuser('amy'), 'users/amy/tokenWallet/wallet'), wallet));
  // Super Admin grant: ledger entry + wallet update + audit log, one batch.
  const a = audit(s1, 'super1', 'super_admin', 'tokens.send', 'users/amy');
  const b = writeBatch(s1);
  b.set(a.ref, a.data);
  b.set(doc(collection(s1, 'users/amy/tokenLedger')), {type: 'adjustment', amount: 250, balanceAfter: 350, ref: 'admin-grant', note: 'Test grant', createdAt: serverTimestamp(), lastAuditId: a.ref.id});
  b.set(doc(s1, 'users/amy/tokenWallet/wallet'), {balance: 350, earnedTotal: 350, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  await assertSucceeds(b.commit());
  // The grant is in the ledger and the wallet reflects it.
  const txns = await getDocs(collection(s1, 'users/amy/tokenLedger'));
  assert.equal(txns.docs.length, 1);
  assert.equal(txns.docs[0].data().amount, 250);
  assert.equal(txns.docs[0].data().type, 'adjustment');
  const w = await getDoc(doc(s1, 'users/amy/tokenWallet/wallet'));
  assert.equal(w.data().balance, 350);
  // A grant without the audit log is refused.
  const b2 = writeBatch(s1);
  b2.set(doc(collection(s1, 'users/amy/tokenLedger')), {type: 'adjustment', amount: 10, balanceAfter: 360, ref: 'admin-grant', note: 'No audit', createdAt: serverTimestamp()});
  await assertFails(b2.commit());
  // A negative grant (taking tokens) is refused.
  const a3 = audit(s1, 'super1', 'super_admin', 'tokens.send', 'users/amy');
  const b3 = writeBatch(s1);
  b3.set(a3.ref, a3.data);
  b3.set(doc(collection(s1, 'users/amy/tokenLedger')), {type: 'adjustment', amount: -50, balanceAfter: 300, ref: 'admin-grant', note: 'Take back', createdAt: serverTimestamp(), lastAuditId: a3.ref.id});
  await assertFails(b3.commit());
  // Over the 100,000 per-grant cap is refused.
  const a4 = audit(s1, 'super1', 'super_admin', 'tokens.send', 'users/amy');
  const b4 = writeBatch(s1);
  b4.set(a4.ref, a4.data);
  b4.set(doc(collection(s1, 'users/amy/tokenLedger')), {type: 'adjustment', amount: 100001, balanceAfter: 100351, ref: 'admin-grant', note: 'Too much', createdAt: serverTimestamp(), lastAuditId: a4.ref.id});
  await assertFails(b4.commit());
  // A moderator (not a Super Admin) cannot grant tokens.
  const mod = admin('mod');
  const a5 = audit(mod, 'mod', 'moderator', 'tokens.send', 'users/amy');
  const b5 = writeBatch(mod);
  b5.set(a5.ref, a5.data);
  b5.set(doc(collection(mod, 'users/amy/tokenLedger')), {type: 'adjustment', amount: 10, balanceAfter: 360, ref: 'admin-grant', note: 'Mod grant', createdAt: serverTimestamp(), lastAuditId: a5.ref.id});
  await assertFails(b5.commit());
  // A Super Admin cannot grant to a suspended user.
  const a6 = audit(s1, 'super1', 'super_admin', 'tokens.send', 'users/sue');
  const b6 = writeBatch(s1);
  b6.set(a6.ref, a6.data);
  b6.set(doc(collection(s1, 'users/sue/tokenLedger')), {type: 'adjustment', amount: 10, balanceAfter: 10, ref: 'admin-grant', note: 'Suspended', createdAt: serverTimestamp(), lastAuditId: a6.ref.id});
  await assertFails(b6.commit());
  // A Super Admin cannot write a purchase entry for someone else.
  const a7 = audit(s1, 'super1', 'super_admin', 'tokens.send', 'users/amy');
  const b7 = writeBatch(s1);
  b7.set(a7.ref, a7.data);
  b7.set(doc(s1, 'users/amy/tokenLedger/order-GPA.1'), {type: 'purchase', amount: 1000, balanceAfter: 1350, ref: 'GPA.1', productId: 'tokens_1000', purchaseToken: 'tok', createdAt: serverTimestamp(), lastAuditId: a7.ref.id});
  await assertFails(b7.commit());
});

test('token wallet: owner maintains a bounded cache; strangers cannot write it', async () => {
  await seedActive('amy');
  const db = vuser('amy');
  const wallet = {balance: 1000, earnedTotal: 0, purchasedTotal: 1000, spentTotal: 0, updatedAt: serverTimestamp()};
  await assertSucceeds(setDoc(doc(db, 'users/amy/tokenWallet/wallet'), wallet));
  await assertSucceeds(setDoc(doc(db, 'users/amy/tokenWallet/wallet'), {...wallet, balance: 1500, purchasedTotal: 1500}));
  await assertFails(setDoc(doc(db, 'users/amy/tokenWallet/wallet'), {...wallet, balance: -1}));
  await assertFails(setDoc(doc(db, 'users/amy/tokenWallet/wallet'), {...wallet, balance: 1000001}));
  await assertFails(setDoc(doc(db, 'users/amy/tokenWallet/wallet'), {...wallet, extra: 1}));
  await assertFails(setDoc(doc(vuser('bob'), 'users/amy/tokenWallet/wallet'), wallet));
  await assertSucceeds(getDoc(doc(db, 'users/amy/tokenWallet/wallet')));
});

test('processedTokens: no client can read or write a processed purchase token (backend-only)', async () => {
  await seedActive('amy');
  const db = vuser('amy');
  const tokenDoc = {uid: 'amy', orderId: 'GPA.1', productId: 'tokens_1000', tokens: 1000, balanceAfter: 1000, createdAt: serverTimestamp()};
  await assertFails(setDoc(doc(db, 'processedTokens/some-play-token'), tokenDoc));
  await assertFails(getDoc(doc(db, 'processedTokens/some-play-token')));
  await assertFails(setDoc(doc(vuser('root'), 'processedTokens/some-play-token'), tokenDoc));
  await assertFails(getDoc(doc(vuser('root'), 'processedTokens/some-play-token')));
});

test('subscription: owner can read their own entitlement but no client can write it (backend-only)', async () => {
  await seedActive('amy');
  const subDoc = {productId: 'premium_monthly', basePlanId: 'monthly', purchaseToken: 'sub-token-1', state: 'SUBSCRIPTION_STATE_ACTIVE', expiryTime: new Date(Date.now() + 30 * 86400_000).toISOString(), autoRenewing: true, acknowledged: true, lastOrderId: 'GPA.2', lastTokenGrantOrderId: 'GPA.2', updatedAt: Timestamp.now()};
  await seed(db => setDoc(doc(db, 'users/amy/subscription/current'), subDoc));
  const db = vuser('amy');
  await assertSucceeds(getDoc(doc(db, 'users/amy/subscription/current')));
  await assertFails(setDoc(doc(db, 'users/amy/subscription/current'), subDoc));
  await assertFails(updateDoc(doc(db, 'users/amy/subscription/current'), {state: 'SUBSCRIPTION_STATE_EXPIRED'}));
  await assertFails(deleteDoc(doc(db, 'users/amy/subscription/current')));
  // Another user cannot read it, and not even an admin 'root' user can write it.
  await assertFails(getDoc(doc(vuser('bob'), 'users/amy/subscription/current')));
  await assertFails(setDoc(doc(vuser('root'), 'users/amy/subscription/current'), subDoc));
});

test('subscriptionTokens: no client can read or write a subscription purchase-token mapping (backend-only)', async () => {
  await seedActive('amy');
  const db = vuser('amy');
  const tokenDoc = {uid: 'amy', productId: 'premium_monthly', updatedAt: Timestamp.now()};
  await assertFails(setDoc(doc(db, 'subscriptionTokens/sub-token-1'), tokenDoc));
  await assertFails(getDoc(doc(db, 'subscriptionTokens/sub-token-1')));
  await assertFails(setDoc(doc(vuser('root'), 'subscriptionTokens/sub-token-1'), tokenDoc));
  await assertFails(getDoc(doc(vuser('root'), 'subscriptionTokens/sub-token-1')));
});

// ---------- referrals (100 tokens to each user, once) ----------
test('referral: a user registers their own code; others cannot take it or read the map', async () => {
  await seedActive('amy');
  await seedActive('bob');
  // The owner registers their own code.
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  // The same code cannot be taken by someone else (create-only).
  await assertFails(setDoc(doc(vuser('bob'), 'referrals/GZABC123'), {uid: 'bob', createdAt: serverTimestamp()}));
  // A code cannot be registered under someone else's UID.
  await assertFails(setDoc(doc(vuser('bob'), 'referrals/GZDEF456'), {uid: 'amy', createdAt: serverTimestamp()}));
  // Malformed codes are refused.
  await assertFails(setDoc(doc(vuser('bob'), 'referrals/BAD'), {uid: 'bob', createdAt: serverTimestamp()}));
  await assertFails(setDoc(doc(vuser('bob'), 'referrals/gzabc123'), {uid: 'bob', createdAt: serverTimestamp()}));
  // A code cannot be changed or deleted.
  await assertFails(updateDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'bob'}));
  await assertFails(deleteDoc(doc(vuser('amy'), 'referrals/GZABC123')));
  // Any signed-in user can resolve a code; anonymous users and list queries cannot.
  await assertSucceeds(getDoc(doc(vuser('bob'), 'referrals/GZABC123')));
  await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), 'referrals/GZABC123')));
  await assertFails(getDocs(collection(vuser('amy'), 'referrals')));
});

test('referral: a valid claim credits both users 100 tokens in one batch', async () => {
  await seedActive('amy');
  await seedActive('bob');
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  const db = vuser('bob');
  const b = writeBatch(db);
  b.set(doc(db, 'referralClaims/bob'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'bob', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenWallet/wallet'), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  b.set(doc(db, 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'bob', createdAt: serverTimestamp()});
  await assertSucceeds(b.commit());
  // The claim and both ledger entries are readable by their owners.
  const claim = await getDoc(doc(db, 'referralClaims/bob'));
  assert.equal(claim.data().referrerUid, 'amy');
  const own = await getDoc(doc(db, 'users/bob/tokenLedger/referral-GZABC123'));
  assert.equal(own.data().amount, 100);
  const ref = await getDoc(doc(vuser('amy'), 'users/amy/tokenLedger/referral-bob'));
  assert.equal(ref.data().amount, 100);
  const wallet = await getDoc(doc(db, 'users/bob/tokenWallet/wallet'));
  assert.equal(wallet.data().balance, 100);
  // The referrer can count their referrals; another user cannot list them.
  const mine = await getDocs(query(collection(vuser('amy'), 'referralClaims'), where('referrerUid', '==', 'amy')));
  assert.equal(mine.docs.length, 1);
  await assertFails(getDocs(query(collection(vuser('bob'), 'referralClaims'), where('referrerUid', '==', 'amy'))));
});

test('referral: invalid code, self-referral and double claim are all refused', async () => {
  await seedActive('amy');
  await seedActive('bob');
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  const claimBatch = (db, code, referrerUid, newUserUid) => {
    const b = writeBatch(db);
    b.set(doc(db, `referralClaims/${newUserUid}`), {code, referrerUid, newUserUid, createdAt: serverTimestamp()});
    b.set(doc(db, `users/${newUserUid}/tokenLedger/referral-${code}`), {type: 'referral', amount: 100, balanceAfter: 100, ref: code, createdAt: serverTimestamp()});
    b.set(doc(db, `users/${newUserUid}/tokenWallet/wallet`), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
    b.set(doc(db, `users/${referrerUid}/tokenLedger/referral-${newUserUid}`), {type: 'referral', amount: 100, balanceAfter: 100, ref: newUserUid, createdAt: serverTimestamp()});
    return b.commit();
  };
  // Unknown code (never registered).
  await assertFails(claimBatch(vuser('bob'), 'GZXXXXXX', 'amy', 'bob'));
  // Self-referral: amy claims her own code.
  await assertFails(claimBatch(vuser('amy'), 'GZABC123', 'amy', 'amy'));
  // A code that resolves to a different referrer than the one named.
  await assertFails(claimBatch(vuser('bob'), 'GZABC123', 'carol', 'bob'));
  // A valid claim succeeds…
  await assertSucceeds(claimBatch(vuser('bob'), 'GZABC123', 'amy', 'bob'));
  // …and a second claim by the same user is refused (one claim per user).
  await assertFails(claimBatch(vuser('bob'), 'GZABC123', 'amy', 'bob'));
});

test('referral: a ledger entry without a matching claim is refused (no forged credits)', async () => {
  await seedActive('amy');
  await seedActive('bob');
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  // No claim exists yet: neither the new user's own entry nor the referrer's
  // entry can be written, and neither can a wrong-amount entry.
  await assertFails(setDoc(doc(vuser('bob'), 'users/bob/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()}));
  await assertFails(setDoc(doc(vuser('bob'), 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'bob', createdAt: serverTimestamp()}));
  await assertFails(setDoc(doc(vuser('bob'), 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 200, balanceAfter: 200, ref: 'bob', createdAt: serverTimestamp()}));
  // A real claim lands, then a second entry for a different friend or a
  // different code is still refused — the claim only ever pays once, for
  // that code and that friend.
  const db = vuser('bob');
  const b = writeBatch(db);
  b.set(doc(db, 'referralClaims/bob'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'bob', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenWallet/wallet'), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  b.set(doc(db, 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'bob', createdAt: serverTimestamp()});
  await assertSucceeds(b.commit());
  // A referral entry naming a different friend (ref is not the writer).
  await assertFails(setDoc(doc(db, 'users/amy/tokenLedger/referral-carol'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'carol', createdAt: serverTimestamp()}));
  // A referral entry for a different code than the one claimed.
  await assertFails(setDoc(doc(db, 'users/bob/tokenLedger/referral-GZDEF456'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZDEF456', createdAt: serverTimestamp()}));
  // A claim whose referrer entry pays the wrong amount is refused as a
  // whole — and the failed batch credits nobody.
  await seedActive('carol');
  const cdb = vuser('carol');
  const cb = writeBatch(cdb);
  cb.set(doc(cdb, 'referralClaims/carol'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'carol', createdAt: serverTimestamp()});
  cb.set(doc(cdb, 'users/carol/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()});
  cb.set(doc(cdb, 'users/carol/tokenWallet/wallet'), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  cb.set(doc(cdb, 'users/amy/tokenLedger/referral-carol'), {type: 'referral', amount: 200, balanceAfter: 200, ref: 'carol', createdAt: serverTimestamp()});
  await assertFails(cb.commit());
  const noClaim = await getDoc(doc(cdb, 'referralClaims/carol'));
  assert.equal(noClaim.exists(), false);
});

test('referral: admins with the user-read role can read claims for reporting; content managers cannot', async () => {
  await seedActive('amy');
  await seedActive('bob');
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  const db = vuser('bob');
  const b = writeBatch(db);
  b.set(doc(db, 'referralClaims/bob'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'bob', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenWallet/wallet'), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  b.set(doc(db, 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'bob', createdAt: serverTimestamp()});
  await assertSucceeds(b.commit());
  // Every user-read role (super_admin, moderator, support_admin, analyst)
  // can get one claim and list claims — the Users page "Referred by" /
  // "Referrals" columns and the Dashboard referral overview depend on it.
  for (const role of ['super1', 'mod', 'support', 'analyst']) {
    await assertSucceeds(getDoc(doc(admin(role), 'referralClaims/bob')));
    const all = await getDocs(collection(admin(role), 'referralClaims'));
    assert.equal(all.docs.length, 1);
  }
  // Content managers have no user-read permission, so they cannot.
  await assertFails(getDoc(doc(admin('editor'), 'referralClaims/bob')));
  await assertFails(getDocs(collection(admin('editor'), 'referralClaims')));
  // A claim still cannot be written or changed by an admin.
  await assertFails(setDoc(doc(admin('super1'), 'referralClaims/bob'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'bob', createdAt: serverTimestamp()}));
});

test('referral: a user cannot read another user’s claim or synced profile (name resolution is public-only)', async () => {
  await seedActive('amy');
  await seedActive('bob');
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  const db = vuser('bob');
  const b = writeBatch(db);
  b.set(doc(db, 'referralClaims/bob'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'bob', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenWallet/wallet'), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  b.set(doc(db, 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'bob', createdAt: serverTimestamp()});
  await assertSucceeds(b.commit());
  // Amy's synced profile (display name + preferences).
  await seed(db2 => setDoc(doc(db2, 'users/amy/sync/profile'), {profile: {name: 'Amy', avatar: 1, u: 1}, prefs: {language: 'English', quizCategory: 'Chat', u: 1}, v: 3, updatedAt: Timestamp.now()}));
  // Bob is the referred user: he may read his OWN claim, but not Amy's
  // profile — so the app resolves her name from public sources only and
  // falls back to "Referred by a user" when none resolves.
  await assertSucceeds(getDoc(doc(vuser('bob'), 'referralClaims/bob')));
  await assertFails(getDoc(doc(vuser('bob'), 'users/amy/sync/profile')));
  // A third user can read neither the claim nor the profile.
  await assertFails(getDoc(doc(vuser('carol'), 'referralClaims/bob')));
  await assertFails(getDoc(doc(vuser('carol'), 'users/amy/sync/profile')));
  // An analyst (no PII role) cannot read the profile either; support can.
  await assertFails(getDoc(doc(admin('analyst'), 'users/amy/sync/profile')));
  await assertSucceeds(getDoc(doc(admin('support'), 'users/amy/sync/profile')));
});

test('referral: referral ledger entries are readable only by the owner or a PII admin (tokens-paid aggregation)', async () => {
  await seedActive('amy');
  await seedActive('bob');
  await assertSucceeds(setDoc(doc(vuser('amy'), 'referrals/GZABC123'), {uid: 'amy', createdAt: serverTimestamp()}));
  const db = vuser('bob');
  const b = writeBatch(db);
  b.set(doc(db, 'referralClaims/bob'), {code: 'GZABC123', referrerUid: 'amy', newUserUid: 'bob', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenLedger/referral-GZABC123'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'GZABC123', createdAt: serverTimestamp()});
  b.set(doc(db, 'users/bob/tokenWallet/wallet'), {balance: 100, earnedTotal: 100, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp()});
  b.set(doc(db, 'users/amy/tokenLedger/referral-bob'), {type: 'referral', amount: 100, balanceAfter: 100, ref: 'bob', createdAt: serverTimestamp()});
  await assertSucceeds(b.commit());
  // Owners read their own entries; a PII admin reads any entry for the
  // Dashboard "tokens paid" total; other roles cannot — the ledger holds
  // balances, so the overview falls back to the claims-derived figure for
  // them instead.
  await assertSucceeds(getDoc(doc(vuser('bob'), 'users/bob/tokenLedger/referral-GZABC123')));
  await assertSucceeds(getDoc(doc(vuser('amy'), 'users/amy/tokenLedger/referral-bob')));
  await assertSucceeds(getDoc(doc(admin('support'), 'users/bob/tokenLedger/referral-GZABC123')));
  await assertSucceeds(getDoc(doc(admin('super1'), 'users/amy/tokenLedger/referral-bob')));
  await assertFails(getDoc(doc(admin('analyst'), 'users/bob/tokenLedger/referral-GZABC123')));
  await assertFails(getDoc(doc(admin('mod'), 'users/amy/tokenLedger/referral-bob')));
  await assertFails(getDoc(doc(vuser('carol'), 'users/bob/tokenLedger/referral-GZABC123')));
});

test('Spark free chat does not grant users access to paid wallet receipts or pass grants',async()=>{
  const bob=vuser('bob');
  await assertFails(setDoc(doc(bob,'chatPasses/bob'),{uid:'bob',expiresAt:Timestamp.fromMillis(Date.now()+86400000)}));
  await assertFails(setDoc(doc(bob,'users/bob/tokenLedger/forged-ad'),{type:'feature_reward',amount:1000,createdAt:serverTimestamp()}));
  const batch=writeBatch(bob);batch.set(doc(bob,'users/bob/limits/chat'),{last:serverTimestamp()});batch.set(doc(collection(bob,'communityMessages')),message('bob'));
  await assertSucceeds(batch.commit());
});

const freePost=(uid,extra={})=>({schema:3,uid,name:'Code Learner',term:'Freshcode',meaning:'An original expression.',example:'',category:'Slang',status:'approved',hidden:false,payment:'free',fee:0,createdAt:serverTimestamp(),updatedAt:serverTimestamp(),publishedAt:serverTimestamp(),likeCount:0,commentCount:0,engagementScore:0,...extra});
const createFreePost=(db,uid,id,extra={})=>{const b=writeBatch(db);b.set(doc(db,`users/${uid}/limits/post`),{last:serverTimestamp()});b.set(doc(db,'communityPosts',id),freePost(uid,extra));return b.commit();};
test('Spark: free word publication is validated, rate limited and blocked in review/paused modes',async()=>{
 const bob=vuser('bob');
 await assertSucceeds(publish(bob,'bob','c-freeword',{schema:3,payment:'free',fee:0}));
 await assertFails(publish(bob,'bob','c-second',{schema:3,payment:'free',fee:0}));
 await seed(db=>setDoc(doc(db,'users/bob/limits/ugc'),{last:Timestamp.fromMillis(Date.now()-120000)}));
 await seed(db=>setDoc(doc(db,'config/app'),{dictionaryPostingMode:'review'}));
 await assertFails(publish(bob,'bob','c-reviewed',{schema:3,payment:'free',fee:0}));
 const batch=writeBatch(bob);batch.set(doc(bob,'users/bob/limits/ugc'),{last:serverTimestamp()});batch.set(doc(bob,'submissions/c-reviewed'),{term:'Reviewed',meaning:'An original word.',example:'',category:'Chat',uid:'bob',status:'pending',schema:3,payment:'free',fee:0,createdAt:serverTimestamp()});
 await assertSucceeds(batch.commit());
 await assertFails(updateDoc(doc(bob,'submissions/c-reviewed'),{status:'accepted'}));
 await seed(db=>setDoc(doc(db,'config/app'),{dictionaryPostingMode:'paused'}));
 await assertFails(publish(bob,'bob','c-paused',{schema:3,payment:'free',fee:0}));
});
test('Spark: public free posts never spend tokens and cannot spoof fees, owners, review mode or counts',async()=>{
 const bob=vuser('bob');
 await assertFails(createFreePost(bob,'bob','fee',{fee:25}));
 await assertFails(createFreePost(bob,'bob','counts',{likeCount:100}));
 await assertFails(createFreePost(vuser('bob',false),'bob','unverified'));
 await assertSucceeds(createFreePost(bob,'bob','free'));
 await assertFails(createFreePost(bob,'bob','spam'));
 await assertFails(updateDoc(doc(bob,'communityPosts/free'),{fee:-100}));
 await seed(db=>setDoc(doc(db,'users/bob/limits/post'),{last:Timestamp.fromMillis(Date.now()-20000)}));
 await seed(db=>setDoc(doc(db,'config/app'),{postPostingMode:'review'}));
 await assertFails(createFreePost(bob,'bob','bypass'));
 await assertSucceeds(createFreePost(bob,'bob','pending-free',{status:'pending',hidden:true}));
 await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(),'communityPosts/pending-free')));
 await assertFails(updateDoc(doc(bob,'communityPosts/pending-free'),{status:'approved',hidden:false}));
});
test('Spark: atomic likes, unlike, comments and saves cannot forge engagement',async()=>{
 const bob=vuser('bob');await assertSucceeds(createFreePost(bob,'bob','engage'));
 const ref=doc(bob,'communityPosts/engage'),like=doc(bob,'communityPostLikes/engage_bob');
 await assertFails(updateDoc(ref,{likeCount:1,engagementScore:1}));
 const b=writeBatch(bob);b.set(like,{uid:'bob',postId:'engage',createdAt:serverTimestamp()});b.update(ref,{likeCount:1,engagementScore:1});await assertSucceeds(b.commit());
 await assertFails(setDoc(like,{uid:'bob',postId:'engage',createdAt:serverTimestamp()}));
 const unlike=writeBatch(bob);unlike.delete(like);unlike.update(ref,{likeCount:0,engagementScore:0});await assertSucceeds(unlike.commit());
 await seed(db=>setDoc(doc(db,'users/bob/limits/post'),{last:Timestamp.fromMillis(Date.now()-20000)}));
 const comment=doc(bob,'communityPosts/engage/comments/comment-1');
 const c=writeBatch(bob);c.set(doc(bob,'users/bob/limits/post'),{last:serverTimestamp()});c.set(comment,{uid:'bob',name:'Learner',text:'Useful code.',status:'approved',createdAt:serverTimestamp()});c.update(ref,{commentCount:1,engagementScore:1,lastCommentId:'comment-1'});await assertSucceeds(c.commit());
 await assertFails(updateDoc(ref,{commentCount:50,engagementScore:50}));
 const saved=doc(bob,'users/bob/savedCommunityPosts/engage');await assertSucceeds(setDoc(saved,{postId:'engage',createdAt:serverTimestamp()}));await assertSucceeds(deleteDoc(saved));
 await assertFails(updateDoc(ref,{uid:'sue'}));
 await assertSucceeds(updateDoc(ref,{status:'removed',hidden:true,updatedAt:serverTimestamp()}));
 await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(),'communityPosts/engage')));
});
test('Spark: moderator actions on free posts require audit, user approval remains forbidden',async()=>{
 await seed(db=>setDoc(doc(db,'communityPosts/mod-free'),freePost('bob',{status:'pending',hidden:true})));
 const mod=admin('mod'),ref=doc(mod,'communityPosts/mod-free');
 await assertFails(updateDoc(ref,{status:'approved',hidden:false,updatedAt:serverTimestamp()}));
 const a=audit(mod,'mod','moderator','community.restore',ref.path),b=writeBatch(mod);b.set(a.ref,a.data);b.update(ref,{status:'approved',hidden:false,publishedAt:serverTimestamp(),updatedAt:serverTimestamp(),lastAuditId:a.ref.id});await assertSucceeds(b.commit());
 await assertSucceeds(getDoc(doc(env.unauthenticatedContext().firestore(),'communityPosts/mod-free')));
});
test('Spark: audited admin schedules a future daily entry; users cannot schedule or award badges',async()=>{
 const db=admin('editor'),date='2027-01-01',publication=doc(db,'dailyCodePublic',date),slot=doc(db,'dailyCodeDates',date);
 const a=audit(db,'editor','content_manager','content.publish',publication.path),b=audit(db,'editor','content_manager','content.publish',slot.path),batch=writeBatch(db);
 batch.set(a.ref,a.data);batch.set(b.ref,b.data);batch.set(publication,{term:'HDOT',meaning:'A selected dictionary code.',category:'Chat',date,schema:3,publishedAt:serverTimestamp(),lastAuditId:a.ref.id});batch.set(slot,{term:'HDOT',meaning:'A selected dictionary code.',category:'Chat',status:'scheduled',schema:3,wordSource:'community',wordId:'c-hdot',createdAt:serverTimestamp(),lastAuditId:b.ref.id});await assertSucceeds(batch.commit());
 await assertFails(setDoc(doc(vuser('bob'),'verifiedContributors/bob'),{verified:true}));
 const root=admin('super1'),badge=doc(root,'verifiedContributors/bob'),log=audit(root,'super1','super_admin','community.edit',badge.path),grant=writeBatch(root);grant.set(log.ref,log.data);grant.set(badge,{verified:true,updatedAt:serverTimestamp(),updatedBy:'super1',lastAuditId:log.ref.id});await assertSucceeds(grant.commit());
});
test('Spark: account deletion scrubs free posts and the users comments without a server function',async()=>{
 await seed(db=>setDoc(doc(db,'communityPosts/deleted-free'),freePost('bob')));
 await seed(db=>setDoc(doc(db,'communityPosts/deleted-free/comments/one'),{uid:'bob',name:'Learner',text:'Hello',status:'approved',createdAt:Timestamp.now()}));
 await seed(db=>setDoc(doc(db,'users/bob'),{status:'deleted'}));
 const db=vuser('bob');await assertSucceeds(setDoc(doc(db,'communityPosts/deleted-free'),{status:'removed',hidden:true,updatedAt:serverTimestamp()}));
 const own=await assertSucceeds(getDocs(query(collectionGroup(db,'comments'),where('uid','==','bob'))));assert.equal(own.size,1);
 const c=doc(db,'communityPosts/deleted-free/comments/one'),before=await assertSucceeds(getDoc(c));
 await assertSucceeds(setDoc(c,{uid:'',name:'',text:'Comment removed',status:'removed',createdAt:before.get('createdAt'),updatedAt:serverTimestamp()}));
});

test('Spark: real client create transactions can read missing IDs while another users pending content stays private',async()=>{
 const bob=vuser('bob');
 await assertSucceeds(getDoc(doc(bob,'submissions/c-new-code')));
 await assertSucceeds(runTransaction(bob,async tx=>{
   const ref=doc(bob,'communityPosts/client-transaction');
   const old=await tx.get(ref);assert.equal(old.exists(),false);
   tx.set(doc(bob,'users/bob/limits/post'),{last:serverTimestamp()});tx.set(ref,freePost('bob'));
 }));
 await seed(db=>setDoc(doc(db,'submissions/private-code'),{uid:'sue',status:'pending'}));
 await assertFails(getDoc(doc(bob,'submissions/private-code')));
 await seed(db=>setDoc(doc(db,'communityPosts/private-post'),freePost('sue',{status:'pending',hidden:true})));
 await assertFails(getDoc(doc(bob,'communityPosts/private-post')));
});


test('Hybrid: clients cannot forge or inspect VPS reward intents, allowance, scheduler locks or cleanup receipts',async()=>{
 const bob=user('bob');
 for(const path of ['adRewardIntents/forged','users/bob/adAllowance/2026-11-11','serviceLocks/scheduler','serviceCleanup/bob','adRewardReceipts/forged']){
  await assertFails(setDoc(doc(bob,path),{uid:'bob',used:false,starts:0}));
  await seed(db=>setDoc(doc(db,path),{uid:'bob',used:false,starts:0}));
  await assertFails(getDoc(doc(bob,path)));
 }
});
