import test from 'node:test';
import assert from 'node:assert/strict';
import {TOKENS, TOKEN_PRODUCTS, tokensForProduct, purchaseTxnId, MIGRATION_TXN_ID, levelFor, emptyTokens, parseTokens, suggestCost, canSuggest, canUnlockLevel} from '../shared/tokens';
import {emptyState, localDayOf} from '../src/profile';
import {recordAnswer, recordRound, resetScores, earnTokens, collectDailyReward, spendTokens, unlockLevelWithTokens, creditAccepted, setLeaderboardOptIn, setTokenBalance} from '../src/learning';

test('tokens: levels rise at 100 / 250 / 500 / 900 / 1500 with progress to the next one', () => {
  assert.deepEqual([levelFor(0).name, levelFor(99).name, levelFor(100).name, levelFor(250).name, levelFor(500).name, levelFor(900).name, levelFor(1500).name],
    ['Rookie', 'Rookie', 'Chatter', 'Word Explorer', 'Slang Star', 'Code Master', 'Code Legend']);
  assert.equal(levelFor(100).level, 2);
  assert.equal(levelFor(150).progress, 50 / 150);
  assert.equal(levelFor(1500).next, null);
  assert.equal(levelFor(1500).progress, 1);
});

test('tokens: every suggestion costs 150 (including staff), and the balance gates them', () => {
  const p = emptyTokens();
  assert.equal(suggestCost(p), TOKENS.SUGGEST_COST);
  assert.equal(canSuggest(p), false);
  assert.equal(canSuggest({...p, balance: 19}), false);
  assert.equal(canSuggest({...p, balance: 150}), true);
  assert.equal(suggestCost(p, true), 150);
  assert.equal(canSuggest(p, true), false);
  assert.equal(canUnlockLevel(p, 'emoji'), false);
  assert.equal(canUnlockLevel({...p, balance: 50}, 'emoji'), true);
  assert.equal(canUnlockLevel({...p, balance: 50, unlockedLevels: ['emoji']}, 'emoji'), false);
  // Generated level ids are valid stage ids, so they survive storage and can be unlocked early.
  assert.equal(canUnlockLevel({...p, balance: 50}, 'chat-1'), true);
  assert.equal(canUnlockLevel({...p, balance: 50}, 'numbers-10'), true);
});

test('tokens: stored tokens are validated, never negative, and the credited list is bounded', () => {
  assert.deepEqual(parseTokens(null), emptyTokens());
  assert.deepEqual(parseTokens({balance: -5, credited: ['sub:abc', 'junk', 42], unlockedLevels: ['chat', 'nope!']}).balance, 0);
  const p = parseTokens({balance: 42.9, lastDaily: '2026-11-07', lastDailyFive: 'tomorrow', credited: ['sub:a1', 'sub:b2'], unlockedLevels: ['chat', 'emoji', 'chat', 'chat-1', 'emoji-3', 'numbers-10', 'nope!'], leaderboard: 1, u: -3});
  assert.equal(p.balance, 42);
  assert.equal(p.lastDaily, '2026-11-07');
  assert.equal(p.lastDailyFive, '');
  assert.deepEqual(p.credited, ['sub:a1', 'sub:b2']);
  assert.deepEqual(p.unlockedLevels, ['chat', 'emoji', 'chat-1', 'emoji-3', 'numbers-10']);
  assert.equal(p.leaderboard, false);
  assert.equal(p.u, 0);
  const many = parseTokens({credited: Array.from({length: 500}, (_, i) => `sub:k${i}`)});
  assert.equal(many.credited.length, TOKENS.CREDITED_LIMIT);
  assert.equal(many.credited[0], 'sub:k100');
});

test('tokens: the first answer of a new day pays +5, and the 7th day of a streak pays +25 more', () => {
  const now = new Date('2026-11-07T12:00:00').getTime();
  const s = emptyState();
  const afterFirst = recordAnswer(undefined, true)(s, now);
  assert.equal(afterFirst.tokens.balance, TOKENS.DAILY_VISIT);
  assert.equal(afterFirst.tokens.lastDaily, '2026-11-07');
  const afterSecond = recordAnswer(undefined, false)(afterFirst, now + 1000);
  assert.equal(afterSecond.tokens.balance, TOKENS.DAILY_VISIT);
  // Six days already played, today is the 7th in a row: +5 daily + 25 streak bonus.
  const days: Record<string, number> = {};
  for (let i = 1; i <= 6; i++) days[localDayOf(now - i * 86_400_000)] = 1;
  const streakState = {...emptyState(), days};
  const week = recordAnswer(undefined, true)(streakState, now);
  assert.equal(week.tokens.balance, TOKENS.DAILY_VISIT + TOKENS.STREAK_WEEK_BONUS);
});

test('tokens: quiz rounds pay for improvement, a perfect round, and the Daily Five once a day', () => {
  const now = Date.now();
  const s = {...emptyState(), best: {chat: {v: 60, u: 1}}};
  const improved = recordRound('chat', 4, 5, 'a-1')(s, now);
  assert.equal(improved.tokens.balance, 20, 'best 60 -> 80 pays 20');
  const perfect = recordRound('chat', 5, 5, 'a-2')(improved, now + 1);
  assert.equal(perfect.tokens.balance, 20 + 20 + TOKENS.PERFECT_ROUND, 'best 80 -> 100 pays 20 more, plus the perfect-round bonus');
  const daily = recordRound('daily-2026-11-07', 3, 5, 'a-3')(perfect, now + 2);
  assert.equal(daily.tokens.balance, perfect.tokens.balance + TOKENS.DAILY_FIVE);
  const dailyAgain = recordRound('daily-2026-11-07', 3, 5, 'a-4')(daily, now + 3);
  assert.equal(dailyAgain.tokens.balance, daily.tokens.balance, 'Daily Five pays once per day');
  const sameAttempt = recordRound('chat', 5, 5, 'a-2')(perfect, now + 4);
  assert.equal(sameAttempt, perfect, 'replaying an attempt id is a no-op');
});

test('tokens: spending, unlocking a level, and crediting accepted words', () => {
  const now = Date.now();
  const rich = {...emptyState(), tokens: {...emptyTokens(), balance: 60}};
  assert.equal(spendTokens(70)(rich, now), rich, 'cannot spend more than the balance');
  const spent = spendTokens(20)(rich, now);
  assert.equal(spent.tokens.balance, 40);
  const unlocked = unlockLevelWithTokens('emoji')(spent, now);
  assert.equal(unlocked.tokens.balance, 40, '50 is needed to unlock, 40 is not enough');
  const unlocked2 = unlockLevelWithTokens('emoji')({...rich, tokens: {...rich.tokens, balance: 50}}, now);
  assert.equal(unlocked2.tokens.balance, 0);
  assert.deepEqual(unlocked2.tokens.unlockedLevels, ['emoji']);
  assert.equal(unlockLevelWithTokens('emoji')(unlocked2, now), unlocked2, 'already unlocked');
  const credited = creditAccepted(['sub:x1', 'sub:x2'])(unlocked2, now);
  assert.equal(credited.tokens.balance, 2 * TOKENS.ACCEPTED_WORD);
  assert.equal(creditAccepted(['sub:x1'])(credited, now), credited, 'already-paid words never pay twice');
  const earned = earnTokens(10)(credited, now);
  assert.equal(earned.tokens.balance, 2 * TOKENS.ACCEPTED_WORD + 10);
  const capped = earnTokens(1000)({...emptyState(), tokens: {...emptyTokens(), balance: TOKENS.MAX_BALANCE - 5}}, now);
  assert.equal(capped.tokens.balance, TOKENS.MAX_BALANCE);
  assert.throws(() => earnTokens(0)(rich, now), RangeError);
});

test('tokens: leaderboard opt-in is a one-way toggle until opted out', () => {
  const now = Date.now();
  const s = emptyState();
  const joined = setLeaderboardOptIn(true)(s, now);
  assert.equal(joined.tokens.leaderboard, true);
  assert.equal(setLeaderboardOptIn(true)(joined, now), joined);
  assert.equal(setLeaderboardOptIn(false)(joined, now).tokens.leaderboard, false);
});

test('tokens: the balance is stored on this device only — resetting scores leaves it alone', () => {
  const now = Date.now();
  const s = {...emptyState(), tokens: {...emptyTokens(), balance: 123}, best: {chat: {v: 80, u: 1}}, days: {'2026-11-07': 3}};
  const reset = resetScores(s, now);
  assert.equal(reset.tokens.balance, 123);
  assert.deepEqual(reset.best, {});
  assert.deepEqual(reset.days, {});
});

test('tokens: the Play catalog is exactly the seven packages, with the right amounts', () => {
  assert.deepEqual(TOKEN_PRODUCTS.map(p => p.id), ['tokens_1000', 'tokens_2500', 'tokens_5000', 'tokens_10000', 'tokens_25000', 'tokens_50000', 'tokens_100000']);
  assert.deepEqual(TOKEN_PRODUCTS.map(p => p.tokens), [1000, 2500, 5000, 10000, 25000, 50000, 100000]);
  assert.equal(tokensForProduct('tokens_5000'), 5000);
  assert.equal(tokensForProduct('tokens_100000'), 100000);
  assert.equal(tokensForProduct('tokens_999'), null);
  assert.equal(tokensForProduct(''), null);
});

test('tokens: purchase ledger IDs are one document per Play order ID', () => {
  assert.equal(purchaseTxnId('GPA.1234-5678'), 'order-GPA.1234-5678');
  assert.notEqual(purchaseTxnId('GPA.1234-5678'), purchaseTxnId('GPA.1234-5679'));
  assert.equal(MIGRATION_TXN_ID, 'migration-v1');
});

test('tokens: large purchase credits are accepted, and the server balance wins on sync', () => {
  const now = Date.now();
  const s = emptyState();
  const credited = earnTokens(100000)(s, now);
  assert.equal(credited.tokens.balance, 100000);
  const synced = setTokenBalance(100000)(credited, now);
  assert.equal(synced, credited); // already equal: no-op
  assert.equal(setTokenBalance(99950)(credited, now).tokens.balance, 99950);
  assert.equal(setTokenBalance(0)(credited, now).tokens.balance, 0);
  assert.throws(() => setTokenBalance(-1)(s, now));
  assert.throws(() => setTokenBalance(1000001)(s, now));
});

test('tokens: daily reward collects +10 once a day, then is a no-op until tomorrow', () => {
  const now = new Date('2026-11-09T08:00:00+05:00').getTime();
  const day = localDayOf(now);
  const s = emptyState();
  const first = collectDailyReward(s, now);
  assert.equal(first.tokens.balance, TOKENS.DAILY_COLLECT);
  assert.equal(first.tokens.lastDailyCollect, day);
  const again = collectDailyReward(first, now + 60_000);
  assert.equal(again, first); // same day: no-op, same state object
  assert.equal(again.tokens.balance, TOKENS.DAILY_COLLECT);
  const tomorrow = collectDailyReward(first, now + 86_400_000);
  assert.equal(tomorrow.tokens.balance, TOKENS.DAILY_COLLECT * 2);
  assert.equal(tomorrow.tokens.lastDailyCollect, localDayOf(now + 86_400_000));
  // The collect date survives storage, so a reload cannot re-collect the same day.
  assert.equal(parseTokens({balance: 10, lastDailyCollect: day}).lastDailyCollect, day);
  assert.equal(parseTokens({lastDailyCollect: 'not-a-day'}).lastDailyCollect, '');
});

test('tokens: chat is free per message with a daily pass and a Community post is 25 tokens', () => {
  assert.equal(TOKENS.CHAT_MESSAGE_COST, 0);
  assert.equal(TOKENS.POST_COST, 25);
  assert.equal(TOKENS.CHAT_DAILY_COST, 30);
});
