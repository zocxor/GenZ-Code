// Community chat filter + AdMob configuration.
// The filter is the first moderation layer: anything sexual, abusive, hateful,
// threatening or encouraging self-harm is refused before it is sent. The server
// rules re-check length, links and the rate limit, and moderators hide reported
// messages from the admin portal.
// The ads wiring is checked as source text: src/ads.tsx imports react-native, which
// cannot load in Node (same reason the app tests never import UI modules).
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {screenMessage, toChatMessage, CHAT_MAX_LENGTH, CHAT_RATE_LIMIT_SECONDS} from '../shared/chat';

test('chat filter: ordinary messages pass, empty and oversize messages are refused', () => {
  assert.deepEqual(screenMessage('no cap, that was funny'), {ok: true});
  assert.deepEqual(screenMessage('  hello everyone  '), {ok: true});
  assert.equal(screenMessage('').ok, false);
  assert.equal(screenMessage('   ').ok, false);
  assert.equal(screenMessage('x'.repeat(CHAT_MAX_LENGTH + 1)).ok, false);
  assert.equal(screenMessage('x'.repeat(CHAT_MAX_LENGTH)).ok, true);
});

test('chat filter: sexual content, abuse, hate and threats are blocked, including leet-speak', () => {
  for (const bad of [
    'check out this porn link', 'you are a stupid slut', 'fuck you',
    'i hate you, nigger', 'you retard', 'send nudes pls',
    'kys', 'kill yourself', 'go die', 'i will kill you',
    'sh!t happens', 'b!tch please', 'sh1t happens', 'bhenchod', 'g4ndu',
  ]) {
    assert.equal(screenMessage(bad).ok, false, bad);
  }
  // The dictionary may explain a sensitive word; the chat room may not carry it.
  assert.equal(screenMessage('what does rizz mean?').ok, true);
  assert.equal(screenMessage('that fit is fire, no cap').ok, true);
});

test('chat filter: links, e-mail addresses and phone numbers are refused', () => {
  for (const bad of ['see https://x.example', 'visit www.spam.example', 'mail me@spam.io', 'call 0300 1234567']) {
    assert.equal(screenMessage(bad).ok, false, bad);
  }
  assert.equal(screenMessage('my number is 143').ok, true);
});

test('chat messages are validated before they are shown', () => {
  const at = {toMillis: () => 1780000000000};
  assert.deepEqual(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'hi', createdAt: at}), {id: 'm1', uid: 'u1', name: 'Aya', text: 'hi', at: 1780000000000});
  assert.equal(toChatMessage('m1', {status: 'hidden', uid: 'u1', name: 'Aya', text: 'hi', createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: '<script>alert(1)</script>', createdAt: at})?.text, '<script>alert(1)</script>');
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'x'.repeat(25), text: 'hi', createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'x'.repeat(CHAT_MAX_LENGTH + 1), createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'hi'}), null);
  assert.equal(toChatMessage('m1', null), null);
  assert.equal(CHAT_RATE_LIMIT_SECONDS, 10);
});

test('ads: token-based model — rewarded ads opt-in, interstitial at completed activities, no banner', () => {
  const appId = 'ca-app-pub-9776667186789824~9376759074';
  const rewardedId = 'ca-app-pub-9776667186789824/4151797642';
  const interstitialId = 'ca-app-pub-9776667186789824/4760116398';
  const rewardedInterstitialId = 'ca-app-pub-9776667186789824/6311057124';
  const ads = readFileSync('src/ads.tsx', 'utf8');
  assert.ok(ads.includes(`ADMOB_APP_ID = '${appId}'`), 'app ID constant');
  assert.ok(ads.includes(`REWARDED_AD_UNIT_ID = '${rewardedId}'`), 'rewarded ad unit ID constant');
  assert.ok(ads.includes(`REWARDED_INTERSTITIAL_AD_UNIT_ID = '${rewardedInterstitialId}'`), 'rewarded interstitial ID recorded for a future button');
  assert.ok(!ads.includes(`REWARDED_AD_UNIT_ID = ''`), 'no empty rewarded placeholder');
  assert.ok(ads.includes('TestIds.REWARDED'), 'test rewarded ad in dev');
  assert.ok(ads.includes('requestNonPersonalizedAdsOnly: true'), 'non-personalised ads');
  assert.ok(ads.includes('EARNED_REWARD'), 'reward only on EARNED_REWARD');
  // Interstitial: restored — preloaded at boot, shown on Suggest/Community,
  // at most once a minute, never gating a feature.
  assert.ok(ads.includes(`INTERSTITIAL_AD_UNIT_ID = '${interstitialId}'`), 'interstitial ad unit ID constant');
  assert.ok(ads.includes('TestIds.INTERSTITIAL'), 'test interstitial ad in dev');
  assert.ok(ads.includes('INTERSTITIAL_COOLDOWN_MS = 120_000'), 'interstitial cooldown is two minutes');
  assert.ok(ads.includes('preloadInterstitial'), 'interstitial preload');
  assert.ok(ads.includes('showInterstitialIfReady'), 'interstitial show function');
  assert.ok(ads.includes('void MobileAds().initialize().catch(() => undefined);\n  preloadInterstitial();'), 'interstitial preloaded at boot');
  // No banner anywhere in the ad module.
  assert.ok(!ads.includes("export const BANNER_AD_UNIT_ID"), 'no banner ad unit ID');
  assert.ok(!ads.includes('AdBanner'), 'no banner component');
  assert.ok(!ads.includes('ANCHORED_ADAPTIVE_BANNER'), 'no banner size');
  // The app ID reaches the SDK through the config plugin, the bare-workflow key, and the manifest.
  const appJson = JSON.parse(readFileSync('app.json', 'utf8'));
  const plugin = appJson.expo.plugins.find((p: unknown) => Array.isArray(p) && p[0] === 'react-native-google-mobile-ads');
  assert.equal(plugin?.[1]?.androidAppId, appId, 'config plugin androidAppId');
  assert.equal(appJson['react-native-google-mobile-ads']?.android_app_id, appId, 'bare-workflow android_app_id');
  const manifest = readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');
  assert.ok(manifest.includes(`com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}"`), 'manifest APPLICATION_ID');
  // The interstitial is triggered in App.tsx only — when the Suggest sheet
  // opens and when the Community tab opens — and it is never awaited, so it
  // can never gate the feature. No banner is rendered anywhere.
  const app = readFileSync('App.tsx', 'utf8');
  assert.ok(!app.includes('AdBanner'), 'no banner in App');
  assert.ok(app.includes('setFinished(true);showInterstitialIfReady();'), 'interstitial at the end of a round');
  assert.ok(!app.includes("if(t==='Community')showInterstitialIfReady()"), 'chat entry is uninterrupted');
  assert.ok(!app.includes('await showInterstitialIfReady'), 'interstitial never awaited — never gates');
  const community = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.ok(!community.includes('AdBanner'), 'no banner on the Community screen');
  assert.ok(!community.includes('showInterstitialIfReady'), 'no interstitial trigger inside Community');
  // Rewarded ads are opt-in only: the only callers are the voluntary earn buttons.
  assert.ok(community.includes('watchRewardedAd'), 'Community earn button uses rewarded ad');
  const wallet = readFileSync('src/WalletScreen.tsx', 'utf8');
  assert.ok(wallet.includes('watchRewardedAd'), 'Wallet earn button uses rewarded ad');
  const rewardButton = readFileSync('src/AdRewardButton.tsx', 'utf8');
  assert.ok(rewardButton.includes('watchRewardedAd'), 'shared earn button uses rewarded ad');
});

test('header: wordmark and token pill fit in standard and compact layouts', () => {
  const app = readFileSync('App.tsx', 'utf8');
  assert.ok(app.includes("const compactHeader=!!user&&(tab==='Community'||tab==='You')"));
  assert.ok(app.includes('{compactHeader&&headerActions}') && app.includes('{!compactHeader&&headerActions}'));
  // The app name is the wordmark image (it cannot wrap — it is one image),
  // and the caption stays on one line and scales down instead of wrapping.
  assert.ok(app.includes('<BrandWordmark height={compactHeader?26:32}/>'), 'header shows the wordmark image in both layouts');
  assert.ok(app.includes('<Text style={s.headerCaption} numberOfLines={1} adjustsFontSizeToFit>'), 'caption stays on one line');
  const ui = readFileSync('src/ui.tsx', 'utf8');
  assert.ok(ui.includes("require('../assets/brand/genz-code-wordmark-name.png')"), 'header wordmark image exists (name-only, no tagline)');
  assert.ok(ui.includes("width:'100%',maxWidth:Math.round(height*1721/340),height"), 'wordmark is bounded so the header row never grows');
  // The title container can shrink below its content width.
  assert.ok(app.includes('headerBrand:{flex:1,minWidth:0}'), 'title container shrinks');
  // The token pill text stays on one line and scales to fit, inside a pill
  // with a max width, so 100,000+ displays in full.
  assert.ok(app.includes('<Text style={s.tokenPillText} numberOfLines={1} adjustsFontSizeToFit>'), 'token number stays on one line and scales');
  assert.ok(app.includes('maxWidth:220'), 'token pill has a max width');
  // The pill may shrink, the Sign in button never does.
  assert.ok(app.includes('flexShrink:1,minWidth:0'), 'pill wrapper can shrink');
  assert.ok(app.includes('style={[s.headerSignIn,{flexShrink:0}]}'), 'Sign in never squeezes');
});

test('startup: the splash is time-boxed to bootServices, and the Recovery banner only shows on a real read failure', () => {
  const app = readFileSync('App.tsx', 'utf8');
  // Ready as soon as bootServices resolves (its own local-data time budget). The splash
  // used to also wait for the stored data to finish loading, which defeated
  // that time-box — a slow read left the app on the splash for 9s+.
  assert.ok(app.includes('const ready=booted,'), 'ready is booted, not gated on storage health');
  assert.ok(!app.includes("const ready=booted&&health.status!=='loading'"), 'ready no longer waits for storage health');
  // The Recovery banner must only appear when storage actually failed
  // (read-only/error). While it is still loading the app opens and the data
  // catches up in the background; showing "couldn't be read" then would be a lie.
  assert.ok(app.includes("health.status==='read-only'||health.status==='error'"), 'Recovery banner only on a real read failure');
  assert.ok(!app.includes('ready&&!storageReady&&<View'), 'Recovery banner is not shown merely because storage is not ready yet');
  // Local learning data may briefly delay the first screen; other reads may not.
  const services = readFileSync('src/services.ts', 'utf8');
  assert.ok(services.includes('setTimeout(resolve,850)'), 'bootServices has a bounded local startup delay');
});


test('Daily Code shares one published entry on Decode and Dictionary', () => {
  const app = readFileSync('App.tsx', 'utf8');
  const dictionary = readFileSync('src/DictionaryScreen.tsx', 'utf8');
  assert.match(app, /<DailyCodeBanner entry=\{dailyCode\}\/>/);
  assert.match(app, /dailyCode=\{<DailyCodeBanner entry=\{dailyCode\} compact onApply=/);
  assert.match(dictionary, /ListHeaderComponent=[\s\S]*?\{dailyCode\}/);
});
