export function communityError(error:unknown) {
  const value=error as {code?:string;message?:string}|null;
  const code=value?.code;
  const message=value?.message?.trim();
  if (code==='functions/not-found' && (!message || /^(?:not-found|not found)(?:\s*\[404\])?$/i.test(message))) {
    return 'The Community service is unavailable. Posting and account token checks will work after the service is deployed.';
  }
  if(code==='functions/internal'&&/^internal(?:\s*\[0\])?$/i.test(message??''))return 'The Community service could not be reached. Please reconnect and retry.';
  if (code==='functions/unavailable' || code==='functions/deadline-exceeded') return 'Could not reach the Community service. Check your connection and try again.';
  return message && !/^internal(?:\s*\[500\])?$/i.test(message) ? message : 'The request could not be completed. Please retry.';
}
