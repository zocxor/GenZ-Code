import {createHash,verify} from 'node:crypto';
import {getFirestore,FieldValue} from 'firebase-admin/firestore';
import {onRequest} from 'firebase-functions/v2/https';
import {error} from 'firebase-functions/logger';
import {wallet as readWallet} from './communityFeatures';
import policy from './communityPolicy.json';

const unit='ca-app-pub-9776667186789824/4151797642';
let cached:{at:number;keys:Map<string,string>}|undefined;
export function verifyRewardQuery(query:string,keys:Map<string,string>) {
  const match=query.match(/^(.*)&signature=([^&]+)&key_id=(\d+)$/);
  if(!match)throw new Error('Invalid reward signature fields');
  const [,content,signature,keyId]=match;
  const key=keys.get(keyId!);
  if(!key||!verify('sha256',Buffer.from(content!,'utf8'),key,Buffer.from(decodeURIComponent(signature!),'base64url')))throw new Error('Invalid reward signature');
  const data=new URLSearchParams(content);
  for(const key of new Set(data.keys()))if(data.getAll(key).length!==1)throw new Error('Duplicate reward field');
  return data;
}
export async function creditAdReward(db:FirebaseFirestore.Firestore,data:URLSearchParams) {
  const uid=data.get('user_id'),transaction=data.get('transaction_id');
  if(!uid||uid.includes('/')||uid.length>128||!transaction||transaction.length>256||![unit,unit.split('/')[1]].includes(data.get('ad_unit')??''))throw new Error('Invalid reward recipient or ad unit');
  const receipt=db.doc('adRewardReceipts/'+createHash('sha256').update(transaction).digest('hex'));
  return db.runTransaction(async tx=>{
    const [prior,user,wallet]=await Promise.all([tx.get(receipt),tx.get(db.doc('users/'+uid)),readWallet(db,tx,uid)]);
    if(prior.exists)return;
    if(user.get('status')!=='active')return;
    const w=wallet.legacy,base=Number.isSafeInteger(w.balance)?w.balance:0;
    const amount=Math.min(policy.rewardedAd,Math.max(0,1_000_000-wallet.balance));
    tx.create(receipt,{uid,transaction,amount,createdAt:FieldValue.serverTimestamp()});
    tx.set(wallet.ref,{...w,balance:Math.min(1_000_000,base+amount),earnedTotal:(Number.isSafeInteger(w.earnedTotal)?w.earnedTotal:0)+amount,updatedAt:FieldValue.serverTimestamp()});
    tx.create(db.doc('users/'+uid+'/tokenLedger/ad-'+receipt.id),{type:'feature_reward',amount,ref:receipt.id,note:'Verified rewarded ad',createdAt:FieldValue.serverTimestamp()});
  });
}
export const admobReward=onRequest({region:'us-central1',invoker:'public'},async(req,res)=>{
  if(req.method!=='GET'){res.sendStatus(405);return;}
  try{
    const raw=req.originalUrl.split('?')[1]??'';
    const requestedKey=raw.match(/&key_id=(\d+)$/)?.[1]??'';
    if(!cached||Date.now()-cached.at>3_600_000||!cached.keys.has(requestedKey)){
      const response=await fetch('https://www.gstatic.com/admob/reward/verifier-keys.json',{signal:AbortSignal.timeout(8000)});
      if(!response.ok)throw new Error('Reward signing keys unavailable');
      const body=await response.json() as {keys:{keyId:number;pem:string}[]};
      cached={at:Date.now(),keys:new Map(body.keys.map(k=>[String(k.keyId),k.pem]))};
    }
    const data=verifyRewardQuery(raw,cached.keys);
    await creditAdReward(getFirestore(),data);
    res.status(200).send('OK');
  }catch(cause){error('admobReward verification failed',cause);res.status(400).send('Reward not verified');}
});
