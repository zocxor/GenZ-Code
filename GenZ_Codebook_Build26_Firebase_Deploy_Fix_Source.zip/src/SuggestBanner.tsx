/** Highlighted "Suggest a word" entry point (Words, Decode and You tabs). Same blue palette as the app. */
import React from 'react';
import {View, Text, Pressable, StyleSheet} from 'react-native';
import {Icon, LiquidHero} from './ui';

export default function SuggestBanner({onPress, title = 'Add / Create Your Own Code', subtitle = 'Add an original code · 150 account tokens'}: {onPress: () => void; title?: string; subtitle?: string}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={`Suggest a word. ${subtitle}`} onPress={onPress} style={({pressed}) => [s.shadow, {opacity: pressed ? 0.9 : 1, transform: [{translateY: pressed ? 1 : 0}]}]}>
    <LiquidHero style={s.card}>
      <View pointerEvents="none" style={s.orb} />
      <View style={s.icon}><Icon name="add" size={26} color="#245fe9" /></View>
      <View style={{flex: 1, gap: 2}}>
        <Text style={s.title}>{title}</Text>
        <Text style={s.subtitle}>{subtitle}</Text>
      </View>
      <View style={s.pill}><Text style={s.pillText}>Create</Text><Icon name="arrow-forward" size={15} color="#245fe9" /></View>
    </LiquidHero>
  </Pressable>;
}
const s = StyleSheet.create({
  shadow: {borderRadius: 22, shadowColor: '#2347b5', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.22, shadowRadius: 14, elevation: 6},
  card: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, paddingRight: 12, borderRadius: 22, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,.35)'},
  orb: {position: 'absolute', width: 140, height: 140, borderRadius: 70, right: -40, top: -60, backgroundColor: 'rgba(255,255,255,.12)'},
  icon: {width: 42, height: 42, borderRadius: 15, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center'},
  title: {color: '#fff', fontSize: 15, fontWeight: '900', letterSpacing: -0.2},
  subtitle: {color: 'rgba(255,255,255,.88)', fontSize: 12, lineHeight: 17},
  pill: {flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 36, paddingHorizontal: 12, borderRadius: 14, backgroundColor: '#fff'},
  pillText: {color: '#245fe9', fontWeight: '800', fontSize: 13},
});
