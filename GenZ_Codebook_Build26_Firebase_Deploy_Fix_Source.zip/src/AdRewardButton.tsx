import React,{useRef,useState} from 'react';
import {ActivityIndicator,Alert,Platform,Pressable,StyleSheet,Text} from 'react-native';
import {TOKENS} from '../shared/tokens';
import {watchRewardedAd} from './ads';
import {earnTokens} from './learning';
import {repository} from './services';
import {C,Icon} from './ui';

export default function AdRewardButton({compact=false}:{compact?:boolean}) {
  const [busy,setBusy]=useState(false);
  const pending=useRef(false);
  if(Platform.OS!=='android')return null;
  const watch=async()=>{
    if(pending.current)return;
    pending.current=true;
    setBusy(true);
    try {
      if(await watchRewardedAd()){
        await repository.mutate(earnTokens(TOKENS.REWARDED_AD));
        Alert.alert('Reward earned',`+${TOKENS.REWARDED_AD} tokens. Device tokens updated. When signed in, account tokens become available after ad verification.`);
      }else{
        Alert.alert('No reward yet','Watch the full ad to earn tokens. If an ad didn’t load, try again later.');
      }
    }catch{
      Alert.alert('Reward could not be saved','Your device balance could not be updated. Please try again later.');
    }finally{
      pending.current=false;
      setBusy(false);
    }
  };
  return <Pressable accessibilityRole="button" accessibilityLabel={`Watch an ad to earn ${TOKENS.REWARDED_AD} tokens`}
    accessibilityState={{busy,disabled:busy}} disabled={busy} onPress={()=>void watch()}
    style={({pressed})=>[s.button,compact&&s.compact,(pressed||busy)&&{opacity:.72}]}>
    {busy?<ActivityIndicator size="small" color={C.blue}/>:<Icon name="play-circle-outline" size={18} color={C.blue}/>}
    <Text numberOfLines={1} style={s.label}>{compact?`Ad +${TOKENS.REWARDED_AD}`:`Watch ad · +${TOKENS.REWARDED_AD}`}</Text>
  </Pressable>;
}

const s=StyleSheet.create({
  button:{flexDirection:'row',alignItems:'center',justifyContent:'center',alignSelf:'flex-start',gap:4,minHeight:44,paddingHorizontal:8,borderRadius:12,backgroundColor:C.soft,borderWidth:1,borderColor:C.line},
  compact:{paddingHorizontal:5},
  label:{fontSize:12,fontWeight:'800',color:C.blue},
});
