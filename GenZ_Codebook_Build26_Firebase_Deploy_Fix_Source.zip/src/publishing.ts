import {useEffect,useState} from 'react';
import {doc,onSnapshot} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {publishingMode,type PublishingMode} from '../shared/publishing';
export function usePublishingMode(kind:'code'|'post') {
  const [mode,setMode]=useState<PublishingMode|null>(null);
  const [error,setError]=useState('');
  useEffect(()=>onSnapshot(doc(cloudDbLive(),'config/app'),snapshot=>{
    setError('');setMode(publishingMode(snapshot.data()??{},kind));
  },()=>{setMode(null);setError('Publishing settings could not be loaded. Please reconnect.');}),[kind]);
  return {mode,error};
}
