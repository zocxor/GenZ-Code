// Community chat filter + AdMob configuration.
// The filter is the first moderation layer: anything sexual, abusive, hateful,
// threatening or encouraging self-harm is refused before it is sent. The server
// rules re-check length, links and the rate limit, and moderators hide reported
// messages from the admin portal.
// The ads wiring is checked as source text: src/ads.tsx imports react-native, which
// cannot load in Node (same reason the app tests never import UI modules).
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {screenMessage, toChatMessage, CHAT_MAX_LENGTH, CHAT_RATE_LIMIT_SECONDS} from '../shared/chat';

test('chat filter: ordinary messages pass, empty and oversize messages are refused', () => {
  assert.deepEqual(screenMessage('no cap, that was funny'), {ok: true});
  assert.deepEqual(screenMessage('  hello everyone  '), {ok: true});
  assert.equal(screenMessage('').ok, false);
  assert.equal(screenMessage('   ').ok, false);
  assert.equal(screenMessage('x'.repeat(CHAT_MAX_LENGTH + 1)).ok, false);
  assert.equal(screenMessage('x'.repeat(CHAT_MAX_LENGTH)).ok, true);
});

test('chat filter: sexual content, abuse, hate and threats are blocked, including leet-speak', () => {
  for (const bad of [
    'check out this porn link', 'you are a stupid slut', 'fuck you',
    'i hate you, nigger', 'you retard', 'send nudes pls',
    'kys', 'kill yourself', 'go die', 'i will kill you',
    'sh!t happens', 'b!tch please', 'sh1t happens', 'bhenchod', 'g4ndu',
  ]) {
    assert.equal(screenMessage(bad).ok, false, bad);
  }
  // The dictionary may explain a sensitive word; the chat room may not carry it.
  assert.equal(screenMessage('what does rizz mean?').ok, true);
  assert.equal(screenMessage('that fit is fire, no cap').ok, true);
});

test('chat filter: links, e-mail addresses and phone numbers are refused', () => {
  for (const bad of ['see https://x.example', 'visit www.spam.example', 'mail me@spam.io', 'call 0300 1234567']) {
    assert.equal(screenMessage(bad).ok, false, bad);
  }
  assert.equal(screenMessage('my number is 143').ok, true);
});

test('chat messages are validated before they are shown', () => {
  const at = {toMillis: () => 1780000000000};
  assert.deepEqual(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'hi', createdAt: at}), {id: 'm1', uid: 'u1', name: 'Aya', text: 'hi', at: 1780000000000});
  assert.equal(toChatMessage('m1', {status: 'hidden', uid: 'u1', name: 'Aya', text: 'hi', createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: '<script>alert(1)</script>', createdAt: at})?.text, '<script>alert(1)</script>');
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'x'.repeat(25), text: 'hi', createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'x'.repeat(CHAT_MAX_LENGTH + 1), createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'hi'}), null);
  assert.equal(toChatMessage('m1', null), null);
  assert.equal(CHAT_RATE_LIMIT_SECONDS, 10);
});

test('ads: token-based model — rewarded ads only, no banner, no interstitial, no automatic triggers', () => {
  const appId = 'ca-app-pub-9776667186789824~9376759074';
  const rewardedId = 'ca-app-pub-9776667186789824/4151797642';
  const rewardedInterstitialId = 'ca-app-pub-9776667186789824/6311057124';
  const ads = readFileSync('src/ads.tsx', 'utf8');
  assert.ok(ads.includes(`ADMOB_APP_ID = '${appId}'`), 'app ID constant');
  assert.ok(ads.includes(`REWARDED_AD_UNIT_ID = '${rewardedId}'`), 'rewarded ad unit ID constant');
  assert.ok(ads.includes(`REWARDED_INTERSTITIAL_AD_UNIT_ID = '${rewardedInterstitialId}'`), 'rewarded interstitial ID recorded for a future button');
  assert.ok(!ads.includes(`REWARDED_AD_UNIT_ID = ''`), 'no empty rewarded placeholder');
  assert.ok(ads.includes('TestIds.REWARDED'), 'test rewarded ad in dev');
  assert.ok(ads.includes('requestNonPersonalizedAdsOnly: true'), 'non-personalised ads');
  assert.ok(ads.includes('EARNED_REWARD'), 'reward only on EARNED_REWARD');
  // No banner, no interstitial, no automatic triggers anywhere in the ad module.
  // (The REWARDED_INTERSTITIAL constant is a different name — check the plain
  // interstitial constant, not the substring.)
  assert.ok(!ads.includes("export const BANNER_AD_UNIT_ID"), 'no banner ad unit ID');
  assert.ok(!ads.includes("export const INTERSTITIAL_AD_UNIT_ID"), 'no interstitial ad unit ID');
  assert.ok(!ads.includes('showInterstitialIfReady'), 'no interstitial show function');
  assert.ok(!ads.includes('AdBanner'), 'no banner component');
  assert.ok(!ads.includes('ANCHORED_ADAPTIVE_BANNER'), 'no banner size');
  assert.ok(!ads.includes('INTERSTITIAL_COOLDOWN_MS'), 'no interstitial cooldown');
  assert.ok(!ads.includes('preloadInterstitial'), 'no interstitial preload');
  // The app ID reaches the SDK through the config plugin, the bare-workflow key, and the manifest.
  const appJson = JSON.parse(readFileSync('app.json', 'utf8'));
  const plugin = appJson.expo.plugins.find((p: unknown) => Array.isArray(p) && p[0] === 'react-native-google-mobile-ads');
  assert.equal(plugin?.[1]?.androidAppId, appId, 'config plugin androidAppId');
  assert.equal(appJson['react-native-google-mobile-ads']?.android_app_id, appId, 'bare-workflow android_app_id');
  const manifest = readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');
  assert.ok(manifest.includes(`com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}"`), 'manifest APPLICATION_ID');
  // No banner is rendered anywhere, and no interstitial is triggered on any tab or sheet.
  const app = readFileSync('App.tsx', 'utf8');
  assert.ok(!app.includes('AdBanner'), 'no banner in App');
  assert.ok(!app.includes('showInterstitialIfReady'), 'no interstitial trigger in App');
  const community = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.ok(!community.includes('AdBanner'), 'no banner on the Community screen');
  assert.ok(!community.includes('showInterstitialIfReady'), 'no interstitial trigger on Community');
  // Rewarded ads are opt-in only: the only callers are the voluntary earn buttons.
  assert.ok(community.includes('watchRewardedAd'), 'Community earn button uses rewarded ad');
  const wallet = readFileSync('src/WalletScreen.tsx', 'utf8');
  assert.ok(wallet.includes('watchRewardedAd'), 'Wallet earn button uses rewarded ad');
  const forms = readFileSync('src/SubmitForms.tsx', 'utf8');
  assert.ok(forms.includes('watchRewardedAd'), 'Suggest earn button uses rewarded ad');
});

test('header: two-row layout so the app name never wraps and the token pill fits large balances', () => {
  const app = readFileSync('App.tsx', 'utf8');
  // The header is a column of two rows: title + avatar on top, token pill +
  // Sign in below. A single crowded row squeezed the title into three lines
  // and the pill too small for balances over 1,000.
  assert.ok(app.includes("header:{paddingHorizontal:20,paddingTop:13,paddingBottom:14,flexDirection:'column'"), 'header is a column');
  assert.ok(app.includes("headerRow:{flexDirection:'row',alignItems:'center',gap:10}"), 'header rows exist');
  // The app name is the wordmark image (it cannot wrap — it is one image),
  // and the caption stays on one line and scales down instead of wrapping.
  assert.ok(app.includes('<BrandWordmark/>'), 'header shows the wordmark image, not wrapped text');
  assert.ok(app.includes('<Text style={s.headerCaption} numberOfLines={1} adjustsFontSizeToFit>'), 'caption stays on one line');
  const ui = readFileSync('src/ui.tsx', 'utf8');
  assert.ok(ui.includes("require('../assets/brand/genz-code-wordmark.png')"), 'wordmark image exists');
  assert.ok(ui.includes('maxWidth:250,height:28'), 'wordmark is bounded so the header row never grows');
  // The title container can shrink below its content width.
  assert.ok(app.includes('<View style={{flex:1,minWidth:0}}>'), 'title container shrinks');
  // The token pill text stays on one line and scales to fit, inside a pill
  // with a max width, so 100,000+ displays in full.
  assert.ok(app.includes('<Text style={s.tokenPillText} numberOfLines={1} adjustsFontSizeToFit>'), 'token number stays on one line and scales');
  assert.ok(app.includes('maxWidth:220'), 'token pill has a max width');
  // The pill may shrink, the Sign in button never does.
  assert.ok(app.includes('flexShrink:1,minWidth:0'), 'pill wrapper can shrink');
  assert.ok(app.includes('style={[s.headerSignIn,{flexShrink:0}]}'), 'Sign in never squeezes');
});
