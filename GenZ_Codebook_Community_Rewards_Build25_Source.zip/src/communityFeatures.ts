import {getFunctions, connectFunctionsEmulator, httpsCallable} from 'firebase/functions';
import {collection, doc, documentId, endAt, getDoc, getDocs, limit, onSnapshot, orderBy, query, startAt, where} from 'firebase/firestore';
import {firebaseApp, cloudDbLive, accountAuth} from './firebase/app';
import {EMULATOR_HOST} from './secure/config';
import policy from '../functions/src/communityPolicy.json';
import {communityError} from '../shared/communityErrors';
export {policy};

const functions = getFunctions(firebaseApp, 'us-central1');
if (EMULATOR_HOST) connectFunctionsEmulator(functions, EMULATOR_HOST, 5001);
const invoke = httpsCallable<Record<string, unknown>, {id?: string;balance?: number;duplicate?: boolean;liked?: boolean}>(functions, 'communityFeature');

export async function feature(action: string, data: Record<string, unknown> = {}) {
  const user = accountAuth.currentUser;
  if (user && (await user.getIdTokenResult()).claims.email_verified !== true) await user.getIdToken(true);
  return (await invoke({action,...data})).data;
}
export const requestKey = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
export const errorOf = communityError;
export const utcDate = (time=Date.now()) => new Date(time).toISOString().slice(0,10);
export const datesAhead = (count=policy.bookingDays, now=Date.now()) => Array.from({length:count},(_,i)=>utcDate(now+(i+1)*86_400_000));
export const ms = (value: unknown) => typeof value === 'number' ? value : typeof (value as {toMillis?: unknown} | null)?.toMillis === 'function' ? (value as {toMillis:()=>number}).toMillis() : 0;
export type FeatureRow = {id:string;uid:string;term?:string;name?:string;meaning?:string;example?:string;category?:string;text?:string;status:string;createdAt?:unknown;updatedAt?:unknown;requestedDate?:string;publicationDate?:string;reservedDate?:string;payment?:string;reason?:string;fee?:number;likeCount?:number;commentCount?:number};
export async function myRows(name: string, uid: string): Promise<FeatureRow[]> {
  const snap = await getDocs(query(collection(cloudDbLive(),name),where('uid','==',uid),orderBy('createdAt','desc'),limit(100)));
  return snap.docs.map(d=>{
    const data=d.data();
    return {...data,id:d.id,status:data.status??(data.hidden?'removed':'pending')} as FeatureRow;
  });
}
export async function slots(from: string, to: string) {
  const snap = await getDocs(query(collection(cloudDbLive(),'dailyCodeDates'),orderBy(documentId()),startAt(from),endAt(to)));
  return Object.fromEntries(snap.docs.map(d=>[d.id,String(d.get('status'))]));
}
export type DailyEntry = {term:string;meaning:string;category:string;date:string};
export function watchDaily(date: string, onValue:(entry:DailyEntry|null)=>void) {
  return onSnapshot(doc(cloudDbLive(),'dailyCodePublic',date),s=>onValue(s.exists()?s.data() as DailyEntry:null),()=>onValue(null));
}
export type FeedFilter = 'Latest'|'Trending'|'Code Words'|'Slangs';
export function watchPosts(filter:FeedFilter, onValue:(rows:FeatureRow[])=>void, onError:()=>void) {
  const constraints = [where('hidden','==',false),where('status','==','approved')];
  if (filter === 'Code Words' || filter === 'Slangs') constraints.push(where('category','==',filter==='Code Words'?'Code Word':'Slang'));
  return onSnapshot(query(collection(cloudDbLive(),'communityPosts'),...constraints,orderBy(filter==='Trending'?'engagementScore':'publishedAt','desc'),limit(50)),
    s=>onValue(s.docs.map(d=>({...d.data(),id:d.id}) as FeatureRow)),onError);
}
export async function interactions(uid:string) {
  const [likes,saved] = await Promise.all([
    getDocs(query(collection(cloudDbLive(),'communityPostLikes'),where('uid','==',uid))),
    getDocs(collection(cloudDbLive(),'users',uid,'savedCommunityPosts')),
  ]);
  return {liked:new Set(likes.docs.map(d=>String(d.get('postId')))),saved:new Set(saved.docs.map(d=>d.id))};
}
export async function savedPosts(ids: Iterable<string>) {
  const found = await Promise.all([...ids].map(async id=>{
    try {
      const post = await getDoc(doc(cloudDbLive(),'communityPosts',id));
      return post.exists() && post.get('status')==='approved' && post.get('hidden')===false ? {...post.data(),id} as FeatureRow : null;
    } catch {return null;}
  }));
  return found.filter((row):row is FeatureRow=>row!==null);
}
export function watchComments(id:string,onValue:(rows:FeatureRow[])=>void,onError:()=>void) {
  return onSnapshot(query(collection(cloudDbLive(),'communityPosts',id,'comments'),orderBy('createdAt','desc'),limit(50)),
    s=>onValue(s.docs.map(d=>({...d.data(),id:d.id}) as FeatureRow)),onError);
}
