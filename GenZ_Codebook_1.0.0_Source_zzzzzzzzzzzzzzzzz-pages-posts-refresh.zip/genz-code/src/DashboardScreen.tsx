/**
 * Learning Dashboard: the real learning picture, from the saved state.
 *
 * Every number comes from `state` + `profile` — XP and rank, day streak,
 * mastered words, quiz rounds, cleared levels, words due for review and the
 * 7-day activity strip. The computations are the same ones ProfileDashboard
 * ("You" tab) uses. There is NO "Community Posts" row: the communityPosts
 * collection does not exist yet, so that number has no real source and is
 * omitted rather than invented.
 */
import React, {useMemo} from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Button, Icon, IconName} from './ui';
import type {LearningState, Profile} from './profile';
import {totalXP, streak, localDayOf} from './profile';
import {rankFor} from './ProfileDashboard';
import {computeBadges} from './achievements';
import {stages} from './games';
import {dueTerms} from './reviewQueue';

export default function DashboardScreen({state, profile: p, onClose, onPlay, onReview}: {state: LearningState; profile: Profile; onClose: () => void; onPlay: () => void; onReview: () => void}) {
  const now = Date.now();
  const d = useMemo(() => {
    const xp = totalXP(p.best);
    const rank = rankFor(xp);
    const st = streak(state.days, now);
    const mastered = Object.values(p.progress).filter(r => r.mastery >= 80).length;
    const reviewing = Object.keys(p.progress).length;
    const progress = reviewing > 0 ? mastered / reviewing : 0;
    const due = dueTerms(p, now).length;
    const week = Array.from({length: 7}, (_, i) => {const t = new Date(now); t.setHours(12, 0, 0, 0); t.setDate(t.getDate() - (6 - i)); const key = localDayOf(t.getTime()); return {key, label: t.toLocaleDateString('en', {weekday: 'narrow'}), count: state.days[key] ?? 0, today: i === 6};});
    const weekMax = Math.max(1, ...week.map(w => w.count));
    const attempts = Object.values(state.attempts).length;
    const cleared = stages.filter(g => (p.best[g.id] ?? 0) >= 60).length;
    const earnedBadges = computeBadges(state, p).filter(b => b.earned).length;
    return {xp, rank, st, mastered, reviewing, progress, due, week, weekMax, attempts, cleared, earnedBadges, weekAnswers: week.reduce((a, w) => a + w.count, 0), weekDays: week.filter(w => w.count > 0).length};
  }, [state, p, now - (now % 60_000)]);

  return (
    <ScrollView contentContainerStyle={s.content}>
      <View style={s.grid}>
        <Stat icon="flash" tint={C.blue} bg="#e3ecff" value={d.xp.toLocaleString()} label="Total XP" sub={`Level ${d.rank.level} · ${d.rank.name}`} />
        <Stat icon="flame" tint="#d9631e" bg="#ffeedd" value={String(d.st.current)} label="Day streak" sub={d.st.activeToday ? `Best ${d.st.best} · today done` : d.st.current ? 'Play today to keep it' : `Best ${d.st.best} days`} />
        <Stat icon="ribbon" tint="#7a3fc4" bg="#efe5ff" value={`${d.earnedBadges} / 6`} label="Achievements" sub="Badges earned so far" />
      </View>

      <Glass>
        <View style={s.between}><View><Text style={s.eyebrow}>LEARNING PROGRESS</Text><Text style={s.cardTitle}>{d.reviewing ? `${Math.round(d.progress * 100)}% mastered` : 'Nothing in review yet'}</Text></View><Icon name="trending-up-outline" color={C.blue} size={24} /></View>
        <View style={s.track} accessibilityRole="progressbar" accessibilityValue={{min: 0, max: 100, now: Math.round(d.progress * 100)}}><View style={[s.fill, {width: `${Math.max(4, d.progress * 100)}%`}]} /></View>
        <Text style={s.caption}>{d.reviewing ? `${d.mastered} of ${d.reviewing} words you are learning are mastered (80% or better).` : 'Answer a quiz question and the words you practise start counting here.'}</Text>
        <View style={s.reviewRow}>
          <View style={s.reviewIcon}><Icon name="repeat" color={C.teal} size={20} /></View>
          <View style={{flex: 1}}><Text style={s.rowTitle}>{d.due ? `${d.due} ${d.due === 1 ? 'word is' : 'words are'} ready to review` : 'Reviews are scheduled'}</Text><Text style={s.caption}>Spaced repetition brings words back when they are due.</Text></View>
          {d.due > 0 && <Pressable accessibilityRole="button" onPress={onReview} style={s.smallCta}><Text style={s.smallCtaText}>Review</Text></Pressable>}
        </View>
      </Glass>

      <Glass style={{padding: 8}}>
        <StatRow icon="book-outline" title="Words learned" value={String(d.mastered)} sub="Mastered at 80% or better" />
        <StatRow icon="game-controller-outline" title="Quiz rounds played" value={String(d.attempts)} sub="Rounds recorded on this device" />
        <StatRow icon="trophy-outline" title="Levels cleared" value={`${d.cleared} of ${stages.length}`} sub="Cleared at 60% or better" last />
      </Glass>

      <Glass>
        <View style={s.between}><View><Text style={s.eyebrow}>THIS WEEK</Text><Text style={s.cardTitle}>{d.weekAnswers ? `${d.weekAnswers} answers · ${d.weekDays} of 7 days` : 'A fresh week'}</Text></View><Icon name="pulse-outline" color={C.blue} /></View>
        <View style={s.bars} accessible accessibilityLabel={`Activity in the last 7 days: ${d.week.map(w => w.count).join(', ')} answers`}>
          {d.week.map(w => <View key={w.key} style={s.barCol}>
            <View style={s.barSlot}><LinearGradient colors={w.today ? ['#6d8dff', '#245ee6'] : ['#b9cdf5', '#8eaeea']} style={[s.bar, {height: w.count ? `${Math.max(12, (w.count / d.weekMax) * 100)}%` : 4, opacity: w.count ? 1 : 0.5}]} /></View>
            <Text style={[s.barLabel, w.today && {color: C.blue, fontWeight: '900'}]}>{w.label}</Text>
          </View>)}
        </View>
        {!d.weekAnswers && <Text style={s.caption}>Answer one quiz question to start a streak. Streaks count days you practise, in your local time.</Text>}
      </Glass>

      <Button title="Play a level" icon="game-controller-outline" onPress={onPlay} />
      <Pressable accessibilityRole="button" onPress={onClose} style={s.done}><Text style={s.doneText}>Done</Text></Pressable>
    </ScrollView>
  );
}

function Stat({icon, tint, bg, value, label, sub}: {icon: IconName; tint: string; bg: string; value: string; label: string; sub: string}) {
  return <View accessible accessibilityLabel={`${label}: ${value}. ${sub}`} style={s.stat}>
    <View style={s.statTop}><View style={[s.statIcon, {backgroundColor: bg}]}><Icon name={icon} color={tint} size={19} /></View><Text style={s.statValue} numberOfLines={1}>{value}</Text></View>
    <Text style={s.statLabel}>{label}</Text><Text style={s.fine} numberOfLines={1}>{sub}</Text>
  </View>;
}

function StatRow({icon, title, value, sub, last}: {icon: IconName; title: string; value: string; sub: string; last?: boolean}) {
  return (
    <View style={[s.statRow, last && {borderBottomWidth: 0}]}>
      <View style={s.miniIcon}><Icon name={icon} color={C.blue} /></View>
      <View style={{flex: 1, gap: 2}}><Text style={s.rowTitle}>{title}</Text><Text style={s.caption}>{sub}</Text></View>
      <Text style={s.statRowValue}>{value}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  grid: {flexDirection: 'row', flexWrap: 'wrap', gap: 12},
  stat: {flexBasis: '30%', flexGrow: 1, backgroundColor: 'rgba(255,255,255,.72)', borderRadius: 22, paddingVertical: 14, paddingHorizontal: 12, gap: 2, borderWidth: 1.5, borderColor: '#fff', shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.08, shadowRadius: 12, elevation: 2},
  statTop: {flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6},
  statIcon: {width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center'},
  statValue: {flex: 1, fontSize: 20, fontWeight: '900', color: C.ink, letterSpacing: -0.5},
  statLabel: {fontSize: 12, fontWeight: '800', color: C.ink},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10},
  eyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.6, color: C.blue},
  cardTitle: {fontSize: 18, fontWeight: '800', color: C.ink, letterSpacing: -0.3, marginTop: 3},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 16, color: '#5c7189'},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.ink},
  track: {height: 9, borderRadius: 9, backgroundColor: '#d7e3f5', overflow: 'hidden', marginTop: 12},
  fill: {height: 9, borderRadius: 9, backgroundColor: C.blue},
  reviewRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 18, backgroundColor: '#eef6f8', marginTop: 12},
  reviewIcon: {width: 38, height: 38, borderRadius: 13, backgroundColor: '#d9f0ef', alignItems: 'center', justifyContent: 'center'},
  smallCta: {minHeight: 40, paddingHorizontal: 14, borderRadius: 14, backgroundColor: C.blue, justifyContent: 'center', borderBottomWidth: 2, borderBottomColor: '#1647bd'},
  smallCtaText: {color: '#fff', fontWeight: '800', fontSize: 13},
  statRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderBottomWidth: 1, borderBottomColor: '#e3eefb'},
  miniIcon: {width: 40, height: 40, borderRadius: 14, backgroundColor: '#e3eeff', alignItems: 'center', justifyContent: 'center', borderTopWidth: 1, borderTopColor: '#fff'},
  statRowValue: {fontSize: 17, fontWeight: '900', color: C.ink},
  bars: {flexDirection: 'row', gap: 8, height: 112, alignItems: 'flex-end', marginTop: 12},
  barCol: {flex: 1, alignItems: 'center', gap: 6, height: '100%'},
  barSlot: {flex: 1, width: '100%', justifyContent: 'flex-end', alignItems: 'center'},
  bar: {width: '72%', maxWidth: 30, borderRadius: 9},
  barLabel: {fontSize: 11, color: C.muted, fontWeight: '700'},
  done: {minHeight: 48, borderRadius: 16, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center'},
  doneText: {color: '#fff', fontSize: 16, fontWeight: '800'},
});
