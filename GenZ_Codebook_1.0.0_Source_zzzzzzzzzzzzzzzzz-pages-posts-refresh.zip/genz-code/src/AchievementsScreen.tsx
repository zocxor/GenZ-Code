/**
 * Achievements: the six badges, with progress hints.
 *
 * The badge list and rules are the SAME computation ProfileDashboard ("You"
 * tab) uses for "Your little wins" — see src/achievements.ts. Nothing here
 * is a separate badge system; this page just shows the same badges as full
 * cards, so earning one on the profile and seeing it here can never disagree.
 */
import React, {useMemo} from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Icon} from './ui';
import type {LearningState, Profile} from './profile';
import {computeBadges, type Badge} from './achievements';

export default function AchievementsScreen({state, profile, onClose}: {state: LearningState; profile: Profile; onClose: () => void}) {
  const badges = useMemo(() => computeBadges(state, profile), [state, profile]);
  const earned = badges.filter(b => b.earned).length;

  return (
    <ScrollView contentContainerStyle={s.content}>
      <Glass>
        <View style={s.between}>
          <View style={{flex: 1}}>
            <Text style={s.eyebrow}>YOUR ACHIEVEMENTS</Text>
            <Text style={s.cardTitle}>{earned} of {badges.length} earned</Text>
            <Text style={s.caption}>Complete goals, earn badges and show your progress.</Text>
          </View>
          <View style={s.trophy}><Icon name="trophy" size={30} color="#b17a23" /></View>
        </View>
        <View style={s.track} accessibilityRole="progressbar" accessibilityValue={{min: 0, max: badges.length, now: earned}}><View style={[s.fill, {width: `${Math.max(4, (earned / badges.length) * 100)}%`}]} /></View>
      </Glass>

      {badges.map(b => <BadgeCard key={b.label} badge={b} />)}

      <Text style={s.fine}>Badges are earned from your saved learning on this device — playing levels, saving words, keeping streaks and mastering words.</Text>
      <Pressable accessibilityRole="button" onPress={onClose} style={s.done}><Text style={s.doneText}>Done</Text></Pressable>
    </ScrollView>
  );
}

function BadgeCard({badge: b}: {badge: Badge}) {
  return (
    <Glass>
      <View style={s.row}>
        <LinearGradient colors={b.earned ? ['#fff4d6', '#ffe1a3'] : ['#f1f5fa', '#e3eaf3']} style={s.medal}>
          <Icon name={b.earned ? b.icon : (`${b.icon}-outline` as typeof b.icon)} size={26} color={b.earned ? '#a2681a' : C.muted} />
        </LinearGradient>
        <View style={{flex: 1, gap: 3}}>
          <Text style={s.rowTitle}>{b.label}</Text>
          <Text style={s.caption}>{b.earned ? 'Earned — nice work.' : b.hint}</Text>
        </View>
        {b.earned && <View style={s.earnedPill}><Icon name="checkmark" size={14} color="#13684a" /><Text style={s.earnedText}>Earned</Text></View>}
      </View>
    </Glass>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10},
  eyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.6, color: C.blue},
  cardTitle: {fontSize: 20, fontWeight: '800', color: C.ink, letterSpacing: -0.4, marginTop: 3},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  rowTitle: {fontSize: 16, fontWeight: '800', color: C.ink},
  trophy: {height: 64, width: 64, borderRadius: 22, backgroundColor: '#fff0c5', borderWidth: 2, borderColor: '#fff9e8', alignItems: 'center', justifyContent: 'center'},
  track: {height: 9, borderRadius: 9, backgroundColor: '#d7e3f5', overflow: 'hidden', marginTop: 14},
  fill: {height: 9, borderRadius: 9, backgroundColor: '#c38a1d'},
  row: {flexDirection: 'row', alignItems: 'center', gap: 14},
  medal: {width: 56, height: 56, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: '#fff'},
  earnedPill: {flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#e1f5e9', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5},
  earnedText: {fontSize: 12, fontWeight: '800', color: '#13684a'},
  done: {minHeight: 48, borderRadius: 16, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center'},
  doneText: {color: '#fff', fontSize: 16, fontWeight: '800'},
});
