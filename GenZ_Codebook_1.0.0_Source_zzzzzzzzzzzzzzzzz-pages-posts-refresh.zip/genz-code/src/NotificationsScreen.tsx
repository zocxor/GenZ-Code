/**
 * Notifications: a feed of real recent activity, newest first.
 *
 * Everything here is something the app genuinely records — token ledger
 * entries (purchases, subscription grants, admin grants, migration), accepted
 * word submissions (a moderator's reviewedAt stamp), the daily reward, best
 * quiz scores and day-streak milestones. Nothing is simulated: if there is
 * no recorded event, the feed is empty and says so. Ledger and submission
 * entries need a signed-in account; the local events (daily reward, best
 * scores, streaks) show even when signed out.
 */
import React, {useEffect, useMemo, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, ActivityIndicator, Pressable} from 'react-native';
import {C, Glass, Chip, Icon} from './ui';
import {useAccountUser} from './services';
import {fetchTokenTxns, currentUid, type TokenTxnRow} from './tokenLedger';
import {buildNotifications, fmtWhen, type AcceptedWord, type NotificationKind, type NotificationItem} from './notifications';
import type {LearningState} from './profile';
import {stages} from './games';

const stageName = (id: string) => stages.find(s => s.id === id)?.name ?? (id === 'review' ? 'Daily review' : id.startsWith('daily-') ? 'Daily five' : id.startsWith('shuffle-') ? 'Shuffle: ' + id.slice(8, 9).toUpperCase() + id.slice(9) : id);

const KIND_LABEL: Record<NotificationKind, string> = {tokens: 'Tokens', learning: 'Learning', community: 'Community'};

/** The user's accepted word submissions, with the moderator's reviewedAt stamp. */
async function fetchAcceptedWords(uid: string): Promise<AcceptedWord[]> {
  try {
    const [{collection, query, where, getDocs, limit}, {cloudDb: dbFn}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    // Single-field query (uid only) so no composite index is needed; the
    // accepted-only filter runs here, on the user's own small submission list.
    const snap = await getDocs(query(collection(dbFn(), 'submissions'), where('uid', '==', uid), limit(50)));
    const out: AcceptedWord[] = [];
    for (const d of snap.docs) {
      const data = d.data();
      if (data.status !== 'accepted' || typeof data.term !== 'string') continue;
      const at = typeof data.reviewedAt?.toMillis === 'function' ? data.reviewedAt.toMillis()
        : typeof data.createdAt?.toMillis === 'function' ? data.createdAt.toMillis() : 0;
      if (at > 0) out.push({id: d.id, term: data.term, reviewedAt: at});
    }
    return out;
  } catch {return [];}
}

export default function NotificationsScreen({state, onClose}: {state: LearningState; onClose: () => void}) {
  const user = useAccountUser();
  const [txns, setTxns] = useState<TokenTxnRow[]>([]);
  const [accepted, setAccepted] = useState<AcceptedWord[]>([]);
  const [loading, setLoading] = useState(!!user);
  const [filter, setFilter] = useState<'all' | NotificationKind>('all');

  useEffect(() => {
    const uid = currentUid();
    if (!uid) {setLoading(false); return;}
    let live = true;
    void Promise.all([fetchTokenTxns(uid, 25), fetchAcceptedWords(uid)]).then(([t, a]) => {
      if (!live) return;
      setTxns(t); setAccepted(a); setLoading(false);
    });
    return () => {live = false;};
  }, []);

  const items = useMemo(() => buildNotifications({
    txns, accepted,
    lastDailyCollect: state.tokens.lastDailyCollect,
    best: state.best,
    days: state.days,
    stageName,
  }), [txns, accepted, state.tokens.lastDailyCollect, state.best, state.days]);

  const kinds = useMemo(() => (['tokens', 'learning', 'community'] as NotificationKind[]).filter(k => items.some(i => i.kind === k)), [items]);
  const shown = filter === 'all' ? items : items.filter(i => i.kind === filter);
  const now = Date.now();

  return (
    <ScrollView contentContainerStyle={s.content}>
      <Text style={s.body}>Purchases, rewards and milestones — only things the app actually records.</Text>
      {kinds.length > 1 && (
        <View style={s.wrap} accessible accessibilityLabel="Filter notifications">
          <Chip label="All" selected={filter === 'all'} onPress={() => setFilter('all')} />
          {kinds.map(k => <Chip key={k} label={KIND_LABEL[k]} selected={filter === k} onPress={() => setFilter(k)} />)}
        </View>
      )}
      {loading ? (
        <Glass><ActivityIndicator color={C.blue} /><Text style={s.body}>Loading your activity…</Text></Glass>
      ) : shown.length === 0 ? (
        <Glass>
          <Icon name="notifications-outline" size={30} color={C.blue} />
          <Text style={s.rowTitle}>Nothing yet.</Text>
          <Text style={s.body}>{user ? 'Your purchases, rewards and milestones will show up here as they happen.' : 'Sign in to also see purchases and accepted words. Your daily rewards, best scores and streaks on this device already show here once you have any.'}</Text>
        </Glass>
      ) : (
        <Glass style={{padding: 8}}>
          {shown.map((item, i) => <NotificationRow key={item.id} item={item} now={now} last={i === shown.length - 1} />)}
        </Glass>
      )}
      {!user && items.length > 0 && <Text style={s.fine}>Showing activity from this device only. Sign in to also see purchases and accepted words from your account.</Text>}
      <Pressable accessibilityRole="button" onPress={onClose} style={s.done}><Text style={s.doneText}>Done</Text></Pressable>
    </ScrollView>
  );
}

function NotificationRow({item, now, last}: {item: NotificationItem; now: number; last: boolean}) {
  return (
    <View style={[s.row, last && {borderBottomWidth: 0}]}>
      <View style={s.iconWrap}><Icon name={item.icon} size={20} color={C.blue} /></View>
      <View style={{flex: 1, gap: 2}}>
        <Text style={s.rowTitle}>{item.title}</Text>
        <Text style={s.caption}>{item.subtitle}</Text>
      </View>
      <Text style={s.when}>{fmtWhen(item.at, now)}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.ink},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  row: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderBottomWidth: 1, borderBottomColor: '#e3eefb'},
  iconWrap: {width: 38, height: 38, borderRadius: 13, backgroundColor: '#e3eeff', alignItems: 'center', justifyContent: 'center'},
  when: {fontSize: 11, color: C.muted, fontWeight: '700'},
  done: {minHeight: 48, borderRadius: 16, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center'},
  doneText: {color: '#fff', fontSize: 16, fontWeight: '800'},
});
