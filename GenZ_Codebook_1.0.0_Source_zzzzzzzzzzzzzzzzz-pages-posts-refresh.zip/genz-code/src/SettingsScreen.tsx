/**
 * Settings: only rows that do something real.
 *
 * Account opens the account sheet, language changes the dictionary language
 * (the same LANGUAGES list and setLanguage action the Words tab uses),
 * Privacy & Security opens Threat Shield, Help & Support opens the feedback
 * form, Rate the App opens the real Play Store listing, and About opens the
 * About page. There is deliberately NO notifications toggle or any other
 * setting with no real effect behind it.
 */
import React from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet, Linking} from 'react-native';
import {C, Glass, Chip, Icon, IconName} from './ui';
import {LANGUAGES} from './profile';

const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.genzmode.app';

export default function SettingsScreen({onClose, onOpen, onAccount, onOpenAbout, signedInEmail, language, onLanguageChange}: {
  onClose: () => void;
  onOpen: (sheet: 'login' | 'privacy' | 'feedback') => void;
  onAccount: (mode: 'signin' | 'create') => void;
  onOpenAbout: () => void;
  signedInEmail: string | null;
  language: string;
  onLanguageChange: (language: string) => void;
}) {
  return (
    <ScrollView contentContainerStyle={s.content}>
      <Glass style={{padding: 8}}>
        <Row icon="person-circle-outline" title="Account" description={signedInEmail ? `Signed in as ${signedInEmail}` : 'Sign in or create an account'} onPress={() => (signedInEmail ? onOpen('login') : onAccount('signin'))} />
        <Row icon="shield-checkmark-outline" title="Privacy & Security" description="Your data, Threat Shield and account deletion" onPress={() => onOpen('privacy')} />
        <Row icon="chatbubble-ellipses-outline" title="Help & Support" description="FAQs and contact us" onPress={() => onOpen('feedback')} />
        <Row icon="star-outline" title="Rate the App" description="Share your feedback on Google Play" onPress={() => void Linking.openURL(PLAY_STORE_URL).catch(() => {})} />
        <Row icon="information-circle-outline" title="About" description="Version, terms and licences" onPress={onOpenAbout} last />
      </Glass>

      <Glass>
        <Text style={s.sectionTitle}>App Preferences</Text>
        <Text style={s.body}>Dictionary language</Text>
        <View style={s.wrap}>
          {LANGUAGES.map(l => <Chip key={l} label={l} selected={language === l} onPress={() => onLanguageChange(l)} />)}
        </View>
        <Text style={s.caption}>The language filter on the Words tab follows this choice.</Text>
      </Glass>

      <Text style={s.fine}>GenZ Codebook stores your learning on this device, and backs it up to your Firebase account only when you sign in. Tokens live on this device only.</Text>
      <Pressable accessibilityRole="button" onPress={onClose} style={s.done}><Text style={s.doneText}>Done</Text></Pressable>
    </ScrollView>
  );
}

function Row({icon, title, description, onPress, last}: {icon: IconName; title: string; description: string; onPress: () => void; last?: boolean}) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={[s.settingRow, last && {borderBottomWidth: 0}]}>
      <View style={s.miniIcon}><Icon name={icon} color={C.blue} /></View>
      <View style={{flex: 1, gap: 3}}><Text style={s.rowTitle}>{title}</Text><Text style={s.caption} numberOfLines={1}>{description}</Text></View>
      <Icon name="chevron-forward" size={17} color={C.muted} />
    </Pressable>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  sectionTitle: {fontSize: 20, fontWeight: '800', letterSpacing: -0.4, color: C.ink},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.ink},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  settingRow: {padding: 14, minHeight: 66, flexDirection: 'row', alignItems: 'center', gap: 13, borderBottomWidth: 1, borderBottomColor: '#e3eefb'},
  miniIcon: {width: 40, height: 40, borderRadius: 14, backgroundColor: '#e3eeff', alignItems: 'center', justifyContent: 'center', borderTopWidth: 1, borderTopColor: '#fff'},
  done: {minHeight: 48, borderRadius: 16, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center'},
  doneText: {color: '#fff', fontSize: 16, fontWeight: '800'},
});
