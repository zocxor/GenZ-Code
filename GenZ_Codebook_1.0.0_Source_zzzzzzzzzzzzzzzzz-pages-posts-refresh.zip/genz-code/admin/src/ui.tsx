/** Small admin UI kit. All text is rendered by React (escaped); no HTML injection paths.
 * Motion (the library formerly known as Framer Motion) animates only presentation:
 * every number shown is still the live Firestore value, counted up from zero. */
import React, {useEffect, useState} from 'react';
import {motion, animate, useReducedMotion} from 'motion/react';

const EASE = [0.22, 1, 0.36, 1] as const;

export function Card({title, subtitle, actions, children, index = 0}: {title?: string; subtitle?: string; actions?: React.ReactNode; children: React.ReactNode; index?: number}) {
  const reduced = useReducedMotion();
  return <motion.section className="card" initial={reduced ? false : {opacity: 0, y: 14}} animate={{opacity: 1, y: 0}} transition={{duration: 0.45, delay: index * 0.07, ease: EASE}}>{(title || actions) && <header className="card-head"><div>{title && <h2>{title}</h2>}{subtitle && <p className="muted">{subtitle}</p>}</div>{actions && <div className="row">{actions}</div>}</header>}{children}</motion.section>;
}
/** Count-up for a live number. Null/NaN renders the same '—' as fmt(). Reduced motion shows the final value at once. */
export function AnimatedNumber({value, digits = 0}: {value: number | null | undefined; digits?: number}) {
  const reduced = useReducedMotion();
  const [shown, setShown] = useState(0);
  useEffect(() => {
    if (value === null || value === undefined || Number.isNaN(value)) return;
    if (reduced) {setShown(value); return;}
    const c = animate(0, value, {duration: 0.9, ease: 'easeOut', onUpdate: v => setShown(v)});
    return () => c.stop();
  }, [value, reduced]);
  if (value === null || value === undefined || Number.isNaN(value)) return <span>—</span>;
  return <span>{shown.toLocaleString(undefined, {maximumFractionDigits: digits})}</span>;
}
export function Stat({label, value, hint, num, digits}: {label: string; value?: React.ReactNode; hint?: string; num?: number | null; digits?: number}) {
  return <motion.div className="stat" variants={statVariants}><span className="stat-label">{label}</span><strong className="stat-value">{num !== undefined ? <AnimatedNumber value={num} digits={digits} /> : value}</strong>{hint && <span className="stat-hint">{hint}</span>}</motion.div>;
}
/** Staggered stat grid: stats fade/slide in one after another whenever the grid
 * mounts — on page open and again after a Refresh (the section re-renders its
 * content when new data arrives). Outside a <Stats> parent, a <Stat> renders
 * normally with no animation (variant labels only propagate from a parent
 * that sets them). Reduced motion shows everything at once. */
const statVariants = {hidden: {opacity: 0, y: 10}, show: {opacity: 1, y: 0, transition: {duration: 0.35, ease: EASE}}};
const statsVariants = {hidden: {}, show: {transition: {staggerChildren: 0.05}}};
export function Stats({children}: {children: React.ReactNode}) {
  const reduced = useReducedMotion();
  return <motion.div className="stats" variants={statsVariants} initial={reduced ? false : 'hidden'} animate="show">{children}</motion.div>;
}
/** Animated share bar. `fraction` is a 0..1 share of a live figure (retention rate, version share) — never invented data. */
export function Bar({label, fraction, display, hint}: {label: string; fraction: number; display: string; hint?: string}) {
  const reduced = useReducedMotion();
  const w = `${Math.max(0, Math.min(100, fraction * 100))}%`;
  return <div className="bar-row"><div className="bar-head"><span>{label}</span><strong>{display}</strong></div><div className="bar"><motion.div className="bar-fill" initial={reduced ? false : {width: 0}} animate={{width: w}} transition={{duration: 0.8, ease: EASE}} /></div>{hint && <span className="bar-hint">{hint}</span>}</div>;
}
export function Skeleton({rows = 4}: {rows?: number}) {
  return <div className="skeleton-grid" aria-label="Loading live data">{Array.from({length: rows}).map((_, i) => <div key={i} className="skeleton" />)}</div>;
}
export function Pill({tone = 'neutral', children}: {tone?: 'neutral' | 'good' | 'warn' | 'bad' | 'info'; children: React.ReactNode}) {
  return <span className={`pill pill-${tone}`}>{children}</span>;
}
/** Only Firebase console links (e.g. "create this index") become clickable; all other text stays plain. */
function linkify(children: React.ReactNode): React.ReactNode {
  if (typeof children !== 'string') return children;
  const parts = children.split(/(https:\/\/console\.firebase\.google\.com\/[^\s"'<>]+)/);
  return parts.length === 1 ? children : parts.map((p, i) => i % 2 ? <a key={i} href={p} target="_blank" rel="noopener noreferrer">this link</a> : p);
}
export function Notice({kind, children, onClose}: {kind: 'error' | 'ok' | 'info'; children: React.ReactNode; onClose?: () => void}) {
  return <div role={kind === 'error' ? 'alert' : 'status'} className={`notice notice-${kind}`}><span>{linkify(children)}</span>{onClose && <button className="link" onClick={onClose} aria-label="Dismiss">✕</button>}</div>;
}
export function Field({label, children, hint}: {label: string; children: React.ReactNode; hint?: string}) {
  return <label className="field"><span>{label}</span>{children}{hint && <small className="muted">{hint}</small>}</label>;
}
/** Async loader with error + retry; avoids stale updates after unmount. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [state, set] = useState<{data: T | null; error: unknown; loading: boolean}>({data: null, error: null, loading: true});
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    set(s => ({...s, loading: true, error: null}));
    fn().then(data => live && set({data, error: null, loading: false}), error => live && set({data: null, error, loading: false}));
    return () => {live = false;};
  }, [...deps, tick]);
  return {...state, reload: () => setTick(t => t + 1)};
}
/** Destructive actions require typing a confirmation word. */
export function ConfirmButton({label, word, onConfirm, disabled, danger = true}: {label: string; word: string; onConfirm: () => void; disabled?: boolean; danger?: boolean}) {
  const [open, setOpen] = useState(false), [typed, setTyped] = useState('');
  if (!open) return <button className={danger ? 'btn danger' : 'btn'} disabled={disabled} onClick={() => setOpen(true)}>{label}</button>;
  return <span className="confirm">
    <input aria-label={`Type ${word} to confirm`} placeholder={`Type ${word}`} value={typed} onChange={e => setTyped(e.target.value)} autoFocus />
    <button className="btn danger" disabled={typed !== word || disabled} onClick={() => {setOpen(false); setTyped(''); onConfirm();}}>Confirm</button>
    <button className="btn ghost" onClick={() => {setOpen(false); setTyped('');}}>Cancel</button>
  </span>;
}
export const fmt = (n: number | null | undefined, digits = 0) => (n === null || n === undefined || Number.isNaN(n) ? '—' : n.toLocaleString(undefined, {maximumFractionDigits: digits}));
export const pct = (r: number | null) => (r === null ? '—' : `${(r * 100).toFixed(1)}%`);
export const when = (t: {toMillis?: () => number} | number | null | undefined) => {
  const ms = typeof t === 'number' ? t : t?.toMillis?.();
  return ms ? new Date(ms).toLocaleString() : '—';
};
export function download(name: string, mime: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], {type: mime}));
  const a = document.createElement('a');
  a.href = url; a.download = name; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
