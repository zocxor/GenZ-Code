import React from 'react';
import {motion, useReducedMotion} from 'motion/react';
import {useSession} from '../App';
import {can} from '../rbac';
import {Card, Stat, Stats, Bar, Skeleton, Notice, useLoad, fmt, pct} from '../ui';
import {errorMessage} from '../firebase';
import {userMetrics, retentionMetrics, versionMetrics, contentMetrics, moderationMetrics, securityMetrics} from '../lib/metrics';

/**
 * Dashboard v5 (brand refresh): same live Firestore figures as before, new
 * presentation. Cards stagger in (Motion), numbers count up, stats inside a
 * card stagger in whenever the card's data arrives — on open and again after
 * a Refresh — and the retention/version bars animate to the same live values.
 * Gradients now use the app's flat GZ brand (navy #102B59 → blue #1769F5 →
 * light blue #2E9BFF, token gold #F5B82E). Nothing here is a trend or an
 * estimate — there is no historical data to chart, so none is invented.
 */
function Section<T>({title, subtitle, load, render, index}: {title: string; subtitle: string; load: () => Promise<T>; render: (d: T) => React.ReactNode; index: number}) {
  const {data, error, loading, reload} = useLoad(load, []);
  return <Card title={title} subtitle={subtitle} index={index} actions={<button className="btn ghost" onClick={reload} disabled={loading}><span className={loading ? 'spin' : ''} aria-hidden="true">↻</span> Refresh</button>}>
    {loading ? <Skeleton rows={4} /> : error ? <Notice kind="error">{errorMessage(error)}</Notice> : data ? render(data) : null}
  </Card>;
}

export default function Dashboard() {
  const {role} = useSession();
  const reduced = useReducedMotion();
  const [bundled, setBundled] = React.useState<number | null>(null);
  React.useEffect(() => {fetch('/admin/library-index.json').then(r => r.json()).then((l: unknown[]) => setBundled(l.length)).catch(() => setBundled(null));}, []);
  let i = 0;
  return <div className="stack">
    <motion.header className="page-head" initial={reduced ? false : {opacity: 0, y: -6}} animate={{opacity: 1, y: 0}} transition={{duration: 0.4, ease: [0.22, 1, 0.36, 1]}}><h1>Dashboard</h1><p className="muted">Live figures queried from Firestore when you open or refresh a card. No figure on this page is estimated or simulated.</p></motion.header>
    {can(role, 'users.read') && <Section index={i++} title="Users" subtitle="Accounts with a cloud profile (signed-in users). Guests who never sign in are not counted — the app has no analytics SDK." load={() => userMetrics()} render={d => <>
      <Stats>
        <Stat label="Registered users" num={d.total} hint="active + suspended" />
        <Stat label="Daily active" num={d.dau} hint="synced in last 24 h (incl. suspended)" />
        <Stat label="Weekly active" num={d.wau} hint="last 7 days" />
        <Stat label="Monthly active" num={d.mau} hint="last 30 days" />
        <Stat label="New (7 days)" num={d.new7} />
        <Stat label="New (30 days)" num={d.new30} />
        <Stat label="Suspended" num={d.suspended} />
      </Stats>
      <h3>Learning activity</h3>
      <Stats>
        <Stat label="Quiz rounds completed" num={d.quizzes} hint="sum of users’ saved round history (last 200 each)" />
        <Stat label="Saved words" num={d.saved} hint="sum across users" />
        <Stat label="Words in review" num={d.reviewed} />
        <Stat label="Avg. levels played" num={d.avgLevels} digits={2} hint="of 4" />
        <Stat label="Avg. current streak" num={d.avgStreak} digits={2} hint="days" />
      </Stats>
      <p className="small muted">Activity figures come from each account’s last sync. Active = last sync time, so users who learn offline appear when they next connect.</p>
    </>} />}
    {can(role, 'users.read') && <Section index={i++} title="Retention" subtitle="“Still active after N days”: of users who signed up in the last 90 days and are old enough, the share whose last activity is at least N days after sign-up." load={() => retentionMetrics()} render={d => <>
      <div className="bar-grid">{d.rows.map(r => <Bar key={r.day} label={`Day ${r.day}`} fraction={r.rate ?? 0} display={pct(r.rate)} hint={`${fmt(r.retained)} of ${fmt(r.eligible)} eligible`} />)}</div>
      <p className="small muted">Computed from {fmt(d.sample)} sign-ups (maximum 2,000 most recent). For full cohort analysis export Firestore to BigQuery.</p>
    </>} />}
    {can(role, 'users.read') && <Section index={i++} title="App versions" subtitle="Reported by the 500 most recently active accounts." load={() => versionMetrics()} render={d => d.rows.length ? <table><thead><tr><th>Version</th><th>Accounts</th><th>Share</th></tr></thead><tbody>{d.rows.map(r => <tr key={r.version}><td>{r.version}</td><td>{fmt(r.count)}</td><td><span className="share-cell"><span className="bar"><span className="bar-fill" style={{display: 'block', width: `${Math.max(0, Math.min(100, (r.count / d.sample) * 100))}%`}} /></span><span>{pct(r.count / d.sample)}</span></span></td></tr>)}</tbody></table> : <p className="muted">No active accounts yet.</p>} />}
    {can(role, 'content.read') && <Section index={i++} title="Slang database" subtitle="Bundled entries ship inside the app; CMS entries are working copies managed here." load={() => contentMetrics()} render={d => <Stats>
      <Stat label="Bundled in app" num={bundled} hint="read-only baseline" />
      <Stat label="Live CMS entries" num={d.live} hint="delivered without an app update" />
      <Stat label="Drafts" num={d.draft} />
      <Stat label="In review" num={d.review} />
      <Stat label="Archived" num={d.archived} />
    </Stats>} />}
    {(can(role, 'reports.moderate') || can(role, 'feedback.read')) && <Section index={i++} title="Reports & feedback" subtitle="Submitted by signed-in users from the app." load={() => moderationMetrics()} render={d => <Stats>
      {can(role, 'submissions.review') && <Stat label="Pending suggestions" num={d.pending} />}
      {can(role, 'reports.moderate') && <Stat label="Open content reports" num={d.openReports} />}
      {can(role, 'reports.moderate') && <Stat label="Open chat reports" num={d.openChatReports} />}
      {can(role, 'feedback.read') && <><Stat label="Feedback (new)" num={d.feedbackNew} /><Stat label="Feedback (total)" num={d.feedbackTotal} /><Stat label="Avg. rating" value={d.avgRating === null ? '—' : `${d.avgRating.toFixed(2)} / 5`} /></>}
    </Stats>} />}
    {can(role, 'security.read') && <Section index={i++} title="Security events (7 days)" subtitle="Events reported by signed-in clients and the portal. Server-side rule denials are not logged by Firestore itself." load={() => securityMetrics()} render={d => d.total ? <table><thead><tr><th>Type</th><th>Count</th></tr></thead><tbody>{d.byType.map(([t, n]) => <tr key={t}><td>{t}</td><td>{fmt(n)}</td></tr>)}</tbody></table> : <p className="muted">No security events in the last 7 days.{d.capped ? ' (capped at 1,000)' : ''}</p>} />}
  </div>;
}
