import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, Pressable, StyleSheet, AppState, Platform, Linking, Switch} from 'react-native';
import {signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail, sendEmailVerification, reload, signOut, deleteUser, EmailAuthProvider, reauthenticateWithCredential} from 'firebase/auth';
import {accountAuth} from './auth/client';
import {accountError, validateCredentials} from './auth/policy';
import {signInWithGoogle, isGoogleSignInConfigured} from './googleAuth';
import {C, Button, FadeIn, Icon, IconTile, SectionHeader, Mark} from './ui';
import {startCloud, useAccountUser, useSyncStatus, useLearningState, loginGuard, securityLog, repository} from './services';
import {isDirty} from './profile';
import {ago} from './shield/status';
import {ACCOUNT_DELETION_URL} from './secure/config';

type Mode = 'signin' | 'create' | 'reset';
type Panel = null | 'signout' | 'delete';
const CREDENTIAL_FAILURES = new Set(['auth/invalid-credential', 'auth/wrong-password', 'auth/user-not-found', 'auth/invalid-login-credentials', 'auth/too-many-requests']);
const codeOf = (e: unknown) => (e && typeof e === 'object' && 'code' in e ? String((e as {code: unknown}).code) : '');

export default function AccountScreen({onContinue, initialMode = 'signin'}: {onContinue: () => void; initialMode?: Mode}) {
  const user = useAccountUser(), sync = useSyncStatus(), state = useLearningState();
  const [ready, setReady] = useState(false), [busy, setBusy] = useState(false), [mode, setMode] = useState<Mode>(initialMode), [panel, setPanel] = useState<Panel>(null);
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [confirmation, setConfirmation] = useState(''), [notice, setNotice] = useState(''), [error, setError] = useState(''), [verified, setVerified] = useState(false);
  const [removeLocal, setRemoveLocal] = useState(false), [waitMs, setWaitMs] = useState(loginGuard.waitMs());
  useEffect(() => {startCloud().then(() => setReady(true)).catch(() => {setReady(true); setError('Couldn’t start account services. You can still learn offline.');});}, []);
  const wasSignedIn = useRef(!!user);
  useEffect(() => {
    setVerified(user?.emailVerified ?? false);
    if (!user && wasSignedIn.current) {setMode('signin'); setConfirmation('');} // after sign-out, returning users see Sign in
    wasSignedIn.current = !!user;
  }, [user]);
  useEffect(() => {const sub = AppState.addEventListener('change', s => {if (s !== 'active') {setPassword(''); setConfirmation('');}}); return () => sub.remove();}, []);
  useEffect(() => {if (!waitMs) return; const t = setInterval(() => setWaitMs(loginGuard.waitMs()), 1000); return () => clearInterval(t);}, [waitMs > 0]);
  const engine = () => startCloud().then(c => c.engine);
  const changeMode = (value: Mode) => {setMode(value); setPassword(''); setConfirmation(''); setError(''); setNotice('');};
  const run = async (action: () => Promise<void>) => {if (busy) return; setBusy(true); setError(''); setNotice(''); try {await action();} catch (e) {setError(accountError(e));} finally {setPassword(''); setConfirmation(''); setBusy(false);}};

  const submit = () => {
    const wait = loginGuard.waitMs();
    if (mode !== 'reset' && wait) {setWaitMs(wait); setError(`Too many attempts on this device. Try again in ${Math.ceil(wait / 1000)} s.`); return;}
    const invalid = validateCredentials(email, password, mode === 'create');
    if (mode !== 'reset' && invalid) {setError(invalid); return;}
    if (mode === 'reset' && validateCredentials(email, 'not-empty')) {setError('Enter a valid email address.'); return;}
    if (mode === 'create' && password !== confirmation) {setError('The passwords do not match.'); return;}
    void run(async () => {
      const address = email.trim();
      if (mode === 'reset') {await sendPasswordResetEmail(accountAuth, address); setNotice('If this address can receive a reset email, check its inbox and spam folder.'); return;}
      let verificationSent = false;
      try {
        if (mode === 'create') {
          const cred = await createUserWithEmailAndPassword(accountAuth, address, password);
          try {await sendEmailVerification(cred.user); verificationSent = true;} catch {/* can be re-sent from the account screen */}
        } else await signInWithEmailAndPassword(accountAuth, address, password);
      } catch (e) {
        if (mode === 'create' && codeOf(e) === 'auth/email-already-in-use') {
          setMode('signin');
          throw Object.assign(new Error('exists'), {code: 'genz/email-exists'});
        }
        if (mode === 'signin' && CREDENTIAL_FAILURES.has(codeOf(e))) {
          void securityLog.record('login_failed', codeOf(e));
          const lock = await loginGuard.failed();
          if (lock) {void securityLog.record('login_throttled', `failures:${loginGuard.failures}`); setWaitMs(lock);}
        }
        throw e;
      }
      const prior = await loginGuard.succeeded();
      setWaitMs(0);
      if (prior >= 3) void securityLog.record('login_succeeded_after_failures', `count:${prior}`);
      setNotice(mode === 'create' ? `Account created. ${verificationSent ? `We sent a verification link to ${address} — open it, then tap “Check verification status”.` : 'Send a verification email below.'} Your learning on this device is now backed up.` : 'You’re signed in. Your learning syncs automatically.');
    });
  };

  const finishSignOut = (remove: boolean) => void run(async () => {
    await signOut(accountAuth);
    if (remove) await repository.clear();
    setPanel(null); setEmail('');
    setNotice(remove ? 'Signed out and removed learning data from this device. Your cloud copy is safe in your account.' : 'Signed out. Your learning stays on this device and resumes syncing when you sign in again.');
  });
  const beginSignOut = () => void run(async () => {
    const clean = await (await engine()).flush();
    setPanel('signout');
    if (!clean) setError('Some recent changes haven’t synced yet (you may be offline). If you remove data from this device now, those changes will be lost.');
  });

  const deleteAccount = () => void run(async () => {
    const current = accountAuth.currentUser;
    if (!current?.email) return;
    try {await reauthenticateWithCredential(current, EmailAuthProvider.credential(current.email, password));}
    catch (e) {void securityLog.record('reauth_failed', codeOf(e)); throw e;}
    void securityLog.record('account_deletion_started');
    const sync = await engine();
    try {await sync.deleteCloudData();}
    catch {throw Object.assign(new Error('cloud'), {code: 'genz/cloud-deletion-failed'});}
    try {await deleteUser(current);}
    catch {throw Object.assign(new Error('auth'), {code: 'genz/auth-deletion-incomplete'});}
    void securityLog.record('account_deleted');
    if (removeLocal) await repository.clear();
    setPanel(null); setEmail('');
    setNotice(removeLocal ? 'Your account, its cloud data and this device’s learning data were deleted.' : 'Your account and its cloud data were deleted. Learning on this device was kept as a guest profile.');
  });

  if (!ready) return <View style={s.card}><Text accessibilityLiveRegion="polite" style={s.body}>Checking your account…</Text></View>;
  const dirty = isDirty(state);
  return <View style={s.page}>
    <FadeIn>
      <View style={s.center}><Mark large /><Text accessibilityRole="header" style={s.title}>{user ? 'Your corner of the internet.' : mode === 'create' ? 'Stay curious. Join in.' : mode === 'reset' ? 'Let’s get you back.' : 'Welcome to GenZ Codebook.'}</Text></View>
    </FadeIn>
    {!!error && <Text accessibilityRole="alert" style={s.error}>{error}</Text>}
    {!!notice && <Text accessibilityLiveRegion="polite" style={s.notice}>{notice}</Text>}
    {user ? <>
      <FadeIn delay={60}>
        <View style={s.card}>
          <View style={s.identity}>
            <IconTile icon="person" from={C.accent} to={C.purple} size={36} iconSize={18} />
            <View style={{flex: 1, gap: 6}}>
              <Text selectable style={s.email}>{user.email}</Text>
              <View style={[s.pill, verified ? s.pillOk : s.pillWarn]}><Icon name={verified ? 'checkmark-circle' : 'alert-circle-outline'} size={15} color={verified ? '#13805a' : '#a35a12'} /><Text style={[s.pillText, {color: verified ? '#13805a' : '#a35a12'}]}>{verified ? 'Email verified' : 'Email not verified'}</Text></View>
            </View>
          </View>
          {!verified && <><Button title="Send verification email" icon="mail-outline" disabled={busy} onPress={() => void run(async () => {await sendEmailVerification(user); setNotice('Verification email sent. Open the link in your inbox, then check your status here.');})} /><Button title="Check verification status" icon="checkmark-circle-outline" light disabled={busy} onPress={() => void run(async () => {await reload(user); setVerified(user.emailVerified); setNotice(user.emailVerified ? 'Your email is verified.' : 'Not verified yet. Open the verification link first.');})} /></>}
        </View>
      </FadeIn>
      <FadeIn delay={120}>
        <View style={s.card}>
          <SectionHeader eyebrow="CLOUD SYNC" title="Cloud sync" />
          <View style={s.syncRow}>
            <IconTile icon={sync.phase === 'idle' && !dirty ? 'cloud-done-outline' : sync.phase === 'offline' ? 'cloud-offline-outline' : 'cloud-upload-outline'} from={C.accent} to="#2E9BFF" size={36} iconSize={18} />
            <Text style={[s.body, {flex: 1}]}>{sync.phase === 'syncing' ? 'Syncing now…' : sync.phase === 'idle' ? (dirty ? 'Recent changes are saved on this device and will upload shortly.' : `Up to date${sync.lastSyncAt ? ` · last synced ${ago(Date.now() - sync.lastSyncAt)}` : ''}.`) : sync.lastError ?? 'Sync is paused.'}</Text>
          </View>
          {sync.phase === 'account-mismatch' ? <>
            <Text style={s.small}>This device’s learning belongs to a different account. Choose “Use this account here” to replace it with {user.email}’s cloud copy.{dirty ? ' Unsynced changes from the other account will be removed from this device.' : ''}</Text>
            <Button title="Use this account here" icon="swap-horizontal-outline" disabled={busy} onPress={() => void run(async () => {await (await engine()).adoptSignedInAccount(); setNotice('This device now shows your account’s learning.');})} />
          </> : <Button light title="Sync now" icon="sync-outline" disabled={busy || sync.phase === 'syncing' || sync.phase === 'blocked'} onPress={() => void run(async () => {const st = await (await engine()).syncNow(); if (st.phase === 'idle') setNotice('Sync complete.');})} />}
        </View>
      </FadeIn>
      {panel === 'signout' ? <FadeIn><View style={s.card}>
        <SectionHeader eyebrow="SIGN OUT" title="Keep your learning on this device?" />
        <Text style={s.small}>Your account’s cloud copy is unaffected either way.</Text>
        <Button title="Sign out, keep data on this device" icon="log-out-outline" disabled={busy} onPress={() => finishSignOut(false)} />
        <Button light title="Sign out and remove it from this device" icon="trash-outline" disabled={busy} onPress={() => finishSignOut(true)} />
        <Button light title="Cancel" icon="close-outline" disabled={busy} onPress={() => {setPanel(null); setError('');}} />
      </View></FadeIn> : panel === 'delete' ? <FadeIn><View style={s.card}>
        <SectionHeader eyebrow="DELETE ACCOUNT" title="Delete your account permanently" />
        <Text style={s.small}>This deletes your synced learning data, suggestions, reports and account. It can’t be undone.</Text>
        <Text style={s.label}>Confirm your password</Text>
        <TextInput accessibilityLabel="Password to confirm deletion" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="current-password" maxLength={4096} editable={!busy} style={s.input} placeholder="Your password" placeholderTextColor={C.muted} />
        <View style={s.toggle}><Text style={[s.small, {flex: 1}]}>Also delete learning data on this device</Text><Switch accessibilityLabel="Also delete learning data on this device" value={removeLocal} onValueChange={setRemoveLocal} /></View>
        <Button title={busy ? 'Deleting…' : 'Delete my account'} icon="trash-bin-outline" disabled={busy || !password} onPress={deleteAccount} />
        <Button light title="Cancel" icon="close-outline" disabled={busy} onPress={() => {setPanel(null); setPassword('');}} />
      </View></FadeIn> : <FadeIn><View style={s.card}>
        <Button light title="Sign out" icon="log-out-outline" disabled={busy} onPress={beginSignOut} />
        <Button light title="Delete account and cloud data" icon="trash-bin-outline" disabled={busy} onPress={() => {setPanel('delete'); setError(''); setNotice('');}} />
        <Pressable accessibilityRole="link" onPress={() => void Linking.openURL(ACCOUNT_DELETION_URL)} style={s.linkButton}><Text style={s.link}>Request deletion from the web instead</Text></Pressable>
      </View></FadeIn>}
    </> : <FadeIn delay={60}>
      <View style={s.card}>
        <SectionHeader eyebrow={mode === 'create' ? 'CREATE ACCOUNT' : mode === 'reset' ? 'RESET PASSWORD' : 'SIGN IN'} title={mode === 'create' ? 'Create your account' : mode === 'reset' ? 'Reset your password' : 'Sign in with email'} />
        <Text style={s.label}>Email address</Text>
        <TextInput accessibilityLabel="Account email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} autoComplete="email" textContentType="emailAddress" maxLength={254} editable={!busy} style={s.input} placeholder="you@example.com" placeholderTextColor={C.muted} />
        {mode !== 'reset' && <><Text style={s.label}>Password{mode === 'create' ? ' · 12+ characters' : ''}</Text><TextInput accessibilityLabel="Account password" value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete={mode === 'create' ? 'new-password' : 'current-password'} textContentType={mode === 'create' ? 'newPassword' : 'password'} maxLength={4096} editable={!busy} style={s.input} placeholder="Your password" placeholderTextColor={C.muted} /></>}
        {mode === 'create' && <><Text style={s.label}>Confirm password</Text><TextInput accessibilityLabel="Confirm account password" value={confirmation} onChangeText={setConfirmation} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="new-password" maxLength={4096} editable={!busy} style={s.input} /><Text style={s.small}>Your saved words and progress are then backed up to your account.</Text></>}
        {waitMs > 0 && mode !== 'reset' && <Text accessibilityLiveRegion="polite" style={s.small}>Sign-in paused on this device for {Math.ceil(waitMs / 1000)} s after repeated failed attempts.</Text>}
        <Button title={busy ? 'Please wait…' : mode === 'create' ? 'Create account' : mode === 'reset' ? 'Send password reset' : 'Sign in with email'} icon={mode === 'reset' ? 'mail-outline' : 'log-in-outline'} disabled={busy || (mode !== 'reset' && waitMs > 0)} onPress={submit} />
        <View style={s.links}>{mode !== 'signin' && <Pressable disabled={busy} accessibilityRole="button" onPress={() => changeMode('signin')} style={s.linkButton}><Text style={s.link}>Back to sign in</Text></Pressable>}{mode === 'signin' && <><Pressable disabled={busy} accessibilityRole="button" onPress={() => changeMode('create')} style={s.linkButton}><Text style={s.link}>Create an account</Text></Pressable><Pressable disabled={busy} accessibilityRole="button" onPress={() => changeMode('reset')} style={s.linkButton}><Text style={s.link}>Forgot password?</Text></Pressable></>}</View>
      </View>
    </FadeIn>}
    {!user && <FadeIn delay={120}>
      <View style={s.card}>
        <View style={s.google}><IconTile icon="logo-google" from={C.accent} to={C.purple} size={36} iconSize={18} /><Text style={s.cardTitle}>Google sign-in</Text></View>
        {isGoogleSignInConfigured() ? <Button title={busy ? 'Please wait…' : 'Continue with Google'} icon="logo-google" disabled={busy} onPress={() => void run(async () => {const r = await signInWithGoogle(); if (r.ok) setNotice('You’re signed in with Google. Your learning syncs automatically.'); else setError(r.message);})} /> : <Text style={s.small}>Not set up yet. Google sign-in needs the app’s SHA-1 fingerprint and OAuth configuration in Firebase. Email sign-in works separately.</Text>}
      </View>
    </FadeIn>}
    <Button light title="Continue learning" icon="book-outline" disabled={busy} onPress={onContinue} />
    <Text style={s.small}>{Platform.OS === 'web' ? 'Web sessions are memory-only and end on page reload.' : 'Account sessions use encrypted device storage when available.'} Passwords are never saved by GenZ Codebook. Without an account, uninstalling deletes your learning data.</Text>
  </View>;
}
const s = StyleSheet.create({
  page: {gap: 14},
  center: {alignItems: 'center', gap: 10},
  title: {fontSize: 26, lineHeight: 32, fontWeight: '900', color: C.navy, textAlign: 'center', letterSpacing: -0.4},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  cardTitle: {fontSize: 17, fontWeight: '800', color: C.navy},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  label: {fontSize: 13, fontWeight: '800', letterSpacing: 0.4, color: C.navy},
  email: {fontSize: 16, fontWeight: '800', color: C.navy},
  input: {minHeight: 48, paddingHorizontal: 16, paddingVertical: 14, borderWidth: 1.5, borderColor: '#c6d6e7', borderRadius: 16, backgroundColor: '#f5f9ff', fontSize: 17, color: C.navy},
  small: {fontSize: 12, lineHeight: 19, color: C.muted},
  links: {flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'space-between'},
  linkButton: {minHeight: 48, justifyContent: 'center'},
  link: {fontSize: 14, fontWeight: '700', color: C.accent},
  error: {padding: 15, borderRadius: 16, borderWidth: 1, borderColor: '#f3c1bd', backgroundColor: '#fff0ee', color: '#96383f', fontSize: 14, lineHeight: 22},
  notice: {padding: 15, borderRadius: 16, borderWidth: 1, borderColor: '#bfe6cf', backgroundColor: '#e1f5e9', color: '#175e47', fontSize: 14, lineHeight: 22},
  google: {flexDirection: 'row', alignItems: 'center', gap: 12, flexWrap: 'wrap'},
  inline: {flexDirection: 'row', alignItems: 'center', gap: 8},
  identity: {flexDirection: 'row', alignItems: 'center', gap: 14},
  pill: {flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 5, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4},
  pillOk: {backgroundColor: '#e1f5e9'},
  pillWarn: {backgroundColor: '#fff1dc'},
  pillText: {fontSize: 12, fontWeight: '800'},
  syncRow: {flexDirection: 'row', alignItems: 'center', gap: 12},
  toggle: {flexDirection: 'row', alignItems: 'center', gap: 10},
});
