import {SPARK_MODE} from '../shared/deployment';
import {BACKEND_URL} from './backend';
import React,{useEffect,useMemo,useRef,useState} from 'react';
import {collection,query,orderBy,limit,onSnapshot} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {AppState,Pressable,StyleSheet,Text,TextInput,View} from 'react-native';
import {Button,C,Chip,Glass,LiquidHero,Icon,SectionHeader,confirmAction,type IconName} from './ui';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {fetchDailyOnce,datesAhead,errorOf,feature,ms,myRows,policy,requestKey,slots,utcDate,watchDaily,type DailyEntry,type FeatureRow} from './communityFeatures';
import {useAccountUser,useAuthPhase} from './services';
import {useAppConfig} from './appConfig';
import {terms,bundledTerms,onContentChange,contentRevision} from './content';
import {refreshCommunity} from './contentSync';
import {dailyTerm} from './discovery';
import {VerifiedBadge,useBadges,type BadgeTier} from './VerifiedBadge';

const money = (value:number) => value.toLocaleString();
type SlotState='open'|'reserved'|'pending'|'closed';
/** Calendar colours: approved/scheduled/published reservations are green, pending requests amber. */
export const slotState=(status:string|undefined,isToday:boolean):SlotState=>isToday?'closed':!status?'open':status==='pending'?'pending':'reserved';
const slotLabel:Record<SlotState,string>={open:'Available',reserved:'Reserved',pending:'Pending request',closed:'Unavailable'};
const dayStyle:Record<SlotState,object>={open:{backgroundColor:'#fff',borderColor:'#D6DDF0'},reserved:{backgroundColor:'#DCFCE7',borderColor:'#22C55E'},pending:{backgroundColor:'#FEF3C7',borderColor:'#F59E0B'},closed:{backgroundColor:'#F1F3F8',borderColor:'#E3E7F0'}};
const dayText:Record<SlotState,string>={open:'#0F172A',reserved:'#166534',pending:'#92400E',closed:'#94A3B8'};
const refundPolicy = 'Paid requests are refunded in full if rejected, missed, or cancelled before approval; a free monthly request can be used again. Dates use UTC.';
const reviewPolicy = 'The fee pays for manual review. Approval is discretionary and rejected applications are non-refundable.';
const verifiedCredits = 'Paid activities use Credits. Verified ad rewards appear after confirmation.';

// Today's Daily Code without the old flicker (the offline fallback word used to show for ~3 s
// before the real code). Now: the last code seen for today is shown at once (memory, then
// device storage); one quick read runs alongside the live listener; until one of them answers,
// a short "Loading today's code" placeholder shows. The offline word is used only if neither
// answers within 6 s (no connection) or today has no published code.
const DAILY_CACHE='genz.dailyCode.v1';
let lastDaily:DailyEntry|null=null;
let cacheRead:Promise<void>|null=null;
function readDailyCache(){
  return cacheRead??=AsyncStorage.getItem(DAILY_CACHE).then(raw=>{
    const v=raw?JSON.parse(raw):null;
    if(!lastDaily&&v&&typeof v.date==='string'&&typeof v.term==='string'&&v.term)lastDaily={term:v.term,meaning:String(v.meaning??''),category:String(v.category??''),date:v.date};
  }).catch(()=>{});
}
function rememberDaily(e:DailyEntry){
  if(lastDaily&&lastDaily.date===e.date&&lastDaily.term===e.term&&lastDaily.meaning===e.meaning&&lastDaily.category===e.category)return;
  lastDaily=e;void AsyncStorage.setItem(DAILY_CACHE,JSON.stringify(e)).catch(()=>{});
}
export function useDailyCode(active:boolean):DailyEntry {
  const [day,setDay]=useState(utcDate);
  const [live,setLive]=useState<DailyEntry|null>(()=>lastDaily);
  const [settled,setSettled]=useState(false);
  useEffect(()=>{
    if(!active)return;
    const refresh=()=>setDay(utcDate());
    refresh();
    const timer=setInterval(refresh,15_000);
    const foreground=AppState.addEventListener('change',state=>{if(state==='active')refresh();});
    return ()=>{clearInterval(timer);foreground.remove();};
  },[active]);
  useEffect(()=>{
    if(!active)return;
    let alive=true,fromListener=false;
    setSettled(false);
    void readDailyCache().then(()=>{if(alive&&lastDaily?.date===day)setLive(v=>v?.date===day?v:lastDaily);});
    const accept=(e:DailyEntry|null,listener:boolean)=>{
      if(!alive||(!listener&&fromListener))return;       // the live listener wins over the one-off read
      if(listener)fromListener=true;
      setSettled(true);
      if(e&&e.term){const entry={term:e.term,meaning:e.meaning,category:e.category,date:day};rememberDaily(entry);setLive(entry);}
      else if(listener)setLive(v=>v?.date===day?null:v);  // today's code was removed: fall back
    };
    void fetchDailyOnce(day).then(e=>accept(e,false),()=>{});
    const stop=watchDaily(day,e=>accept(e,true));
    const giveUp=setTimeout(()=>{if(alive)setSettled(true);},6000);
    return ()=>{alive=false;clearTimeout(giveUp);stop();};
  },[active,day]);
  const fallback=useMemo(()=>dailyTerm(day),[day]);
  if(live?.date===day)return live;
  if(!settled)return {term:'',meaning:'',category:'',date:day,loading:true};
  return {term:fallback.expression,meaning:fallback.meaning,category:fallback.category,date:day};
}

/** Home uses the classic blue card; the Codes page passes tone="gold". */
export function DailyCodeBanner({entry,compact=false,onApply,tone}:{entry:DailyEntry;compact?:boolean;onApply?:()=>void;tone?:'gold'}) {
  const gold=tone==='gold';
  return <LiquidHero tone={tone} style={[s.hero,compact&&s.compactHero]}>
    <View style={s.row}><Icon name="calendar-outline" color={gold?'#FFE7A8':'#BCDEFF'} size={19}/><Text style={[s.eyebrow,gold&&{color:'#FFF1C9'}]}>DAILY CODE</Text><Text style={[s.date,gold&&{color:'#FFF1C9'}]}>{entry.date} UTC</Text></View>
    {entry.loading?<View accessible accessibilityLabel="Loading today’s Daily Code" style={{gap:8}}>
      <View style={[s.skeleton,{width:'42%',height:compact?26:34}]}/>
      <View style={[s.skeleton,{width:'86%',height:14}]}/>
      <Text style={[s.meaning,{opacity:.75}]}>Loading today’s code…</Text>
    </View>:<>
    <Text accessibilityRole="header" selectable style={[s.word,compact&&s.compactWord]}>{entry.term}</Text>
    <Text selectable style={s.meaning}>{entry.meaning}</Text></>}
    <View style={[s.row,{justifyContent:'space-between',flexWrap:'wrap'}]}>
      {entry.loading?<View/>:<Text style={[s.category,gold&&{color:'#5C3A00',backgroundColor:'#FFF4D1'}]}>{entry.category}</Text>}
      {onApply&&<Pressable accessibilityRole="button" accessibilityLabel="Apply for Daily Code" onPress={onApply} style={s.apply}>
        <Text style={s.applyText}>Apply</Text><Icon name="chevron-forward" size={15} color="#fff"/>
      </Pressable>}
    </View>
  </LiquidHero>;
}
export function Status({status}:{status:string}) {
  const good=['approved','published','accepted'].includes(status);
  const bad=['rejected','cancelled','revoked','removed'].includes(status);
  return <Text style={[s.status,good?s.good:bad?s.bad:s.wait]}>{status.charAt(0).toUpperCase()+status.slice(1)}</Text>;
}

export function useContributionData(collection:string,uid?:string) {
  const [rows,setRows]=useState<FeatureRow[]>([]);
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(!!uid);
  const [epoch,reload]=useState(0);
  useEffect(()=>{
    let current=true;
    if(!uid){setRows([]);setError('');setLoading(false);return;}
    setLoading(true);setError('');
    void myRows(collection,uid).then(data=>{if(current)setRows(data);},e=>{if(current)setError(errorOf(e));}).finally(()=>{if(current)setLoading(false);});
    return ()=>{current=false;};
  },[uid,collection,epoch]);
  return {rows,error,loading,reload:()=>reload(e=>e+1)};
}

// The last confirmed balance is shown instantly when another screen opens (then refreshed).
let balanceCache:{uid:string;balance:number;free:{code:boolean;daily:boolean}}|null=null;
export function useEligibleBalance(uid?:string) {
  const [balance,setBalance]=useState<number|null>(()=>uid&&balanceCache?.uid===uid?balanceCache.balance:null),[error,setError]=useState('');
  const [free,setFree]=useState<{code:boolean;daily:boolean}|null>(()=>uid&&balanceCache?.uid===uid?balanceCache.free:null);
  const [epoch,setEpoch]=useState(0);
  const lastUid=useRef(uid);
  useEffect(()=>{
    let current=true;
    // Keep showing the last confirmed balance while refreshing; reset only when the account changes.
    if(lastUid.current!==uid){lastUid.current=uid;setBalance(null);}
    setError('');
    if(uid&&BACKEND_URL) void feature('balance').then(r=>{
      const balance=r.balance;
      if(typeof balance!=='number'||!Number.isSafeInteger(balance)||balance<0)throw new Error('Account credits could not be confirmed. Please retry.');
      const f={code:r.freeCode===true,daily:r.freeDaily===true};
      balanceCache={uid,balance,free:f};
      if(current){setBalance(balance);setFree(f);}
    }).catch(e=>{if(current)setError(errorOf(e));});
    return ()=>{current=false;};
  },[uid,epoch]);
  useEffect(()=>{
    if(!uid||!BACKEND_URL)return;
    return onSnapshot(query(collection(cloudDbLive(),'users',uid,'tokenLedger'),orderBy('createdAt','desc'),limit(1)),()=>setEpoch(e=>e+1),()=>{});
  },[uid]);
  return {balance,free,error,reload:()=>setEpoch(e=>e+1),setBalance};
}

/** Why a paid action can't be confirmed yet, in the order the user should fix them. */
export function feeBlockers({fee,balance,missing=[]}:{fee:number;balance:number|null;missing?:string[]}):string[]{
  const reasons=[...missing];
  if(balance===null)reasons.push('Checking your Credit balance…');
  else if(balance<fee)reasons.push(`You need ${money(fee-balance)} more Credits.`);
  return reasons;
}
export function ConfirmFee({fee,balance,summary,onConfirm,disabled=false,missing=[],onGetCredits,freeLabel}:{fee:number;balance:number|null;summary:string;onConfirm:()=>void;disabled?:boolean;missing?:string[];onGetCredits?:()=>void;freeLabel?:string}) {
  const freeUse=fee===0;
  const blockers=freeUse?missing:feeBlockers({fee,balance,missing});
  const short=!freeUse&&balance!==null&&balance<fee;
  return <>
    {freeUse?<View style={[s.fee,{backgroundColor:'#DCFCE7'}]}><Icon name="gift-outline" size={20} color="#15803D"/><Text style={[s.label,{flex:1}]}>{freeLabel??'Free'}</Text></View>
      :<View style={s.fee}><Icon name="wallet-outline" size={20} color={C.goldDeep}/><Text style={s.label}>Cost: {money(fee)} Credits</Text></View>}
    {!freeUse&&<Text style={s.body}>{balance===null?'Checking your Credit balance…':`Credit balance: ${money(balance)}${balance>=fee?` · ${money(balance-fee)} left after this`:''}`}</Text>}
    {blockers.length>0&&<View style={s.blockers} accessibilityLiveRegion="polite">{blockers.map(b=><View key={b} style={s.row}><Icon name="alert-circle-outline" size={16} color="#B45309"/><Text style={[s.body,{flex:1,color:'#7C4A03'}]}>{b}</Text></View>)}</View>}
    {short&&onGetCredits&&<Button light title="Get Credits" icon="add-circle-outline" onPress={onGetCredits}/>}
    <Button title={freeUse?'Confirm · Free':`Confirm · ${money(fee)} Credits`} icon="checkmark-circle-outline" disabled={disabled||blockers.length>0}
      onPress={()=>freeUse?confirmAction('Use your free request?',`${summary}\n\nThis uses your free request. No Credits are charged.`,onConfirm,'Confirm'):confirmAction('Confirm Credit payment',`${summary}\n\nPay ${money(fee)} Credits. Your balance after payment will be ${money(Math.max(0,(balance??0)-fee))}.`,onConfirm,'Pay Credits')}/>
  </>;
}

function RowHistory({rows,kind,cancel}:{rows:FeatureRow[];kind:'daily'|'posts'|'verification';cancel?:(row:FeatureRow)=>void}) {
  const [filter,setFilter]=useState('all');
  const filters=kind==='daily'?['all','pending','approved','scheduled','published','rejected']:kind==='posts'?['all','pending','approved','rejected']:['all'];
  const filtered=rows.filter(row=>filter==='all'||row.status===filter);
  return <>
    {filters.length>1&&<View style={s.wrap}>{filters.map(f=><Chip key={f} label={f.charAt(0).toUpperCase()+f.slice(1)} selected={f===filter} onPress={()=>setFilter(f)}/>)}</View>}
    {!filtered.length&&<Text style={s.body}>No matching submissions.</Text>}
    {filtered.map(row=><Glass key={row.id}>
      <View style={s.row}><Text style={[s.label,{flex:1}]}>{row.term??(kind==='verification'?'Verified Badge application':row.text??'Community post')}</Text><Status status={row.status}/></View>
      {!!row.meaning&&<Text style={s.body}>{row.meaning}</Text>}
      <Text style={s.body}>{ms(row.createdAt)>0?new Date(ms(row.createdAt)).toLocaleDateString():''}{row.fee? ` · ${money(row.fee)} Credits · ${row.payment}`:''}</Text>
      {kind==='daily'&&<Text style={s.body}>Requested {row.requestedDate??'—'} · Confirmed {row.publicationDate??'—'} UTC</Text>}
      {!!row.reason&&<Text style={s.body}>{row.reason}</Text>}
      {cancel&&kind==='daily'&&row.status==='pending'&&<Button light title="Cancel and refund" icon="close-circle-outline" onPress={()=>confirmAction('Cancel this application?',`Your ${policy.dailyFee} Credits will be refunded.`,()=>cancel(row))}/>}
      {cancel&&kind==='posts'&&['pending','approved'].includes(row.status)&&<Button light title="Remove my post" icon="trash-outline" onPress={()=>confirmAction('Remove this post?', SPARK_MODE?'Remove this free post?':'The post fee is non-refundable.',()=>cancel(row))}/>}
    </Glass>)}
  </>;
}

export function ContributionScreen({mode,onSignIn,onSuggest,onGetCredits}:{mode:'daily-apply'|'daily-history'|'verification'|'my-posts';onSignIn:()=>void;onSuggest:()=>void;onGetCredits?:()=>void}) {
  const user=useAccountUser(), uid=user?.uid, phase=useAuthPhase();
  useAppConfig(); // re-render when the admin changes prices
  const kind=mode.startsWith('daily')?'daily':mode==='my-posts'?'posts':'verification';
  const collection=mode==='daily-apply'?'dailyCodeApplications':kind==='daily'?'dailyCodeApplications':kind==='posts'?'communityPosts':'verificationApplications';
  const data=useContributionData(collection,uid);
  const paid=mode==='daily-apply'||mode==='verification';
  const credits=useEligibleBalance(paid?uid:undefined);
  const [word,setWord]=useState(''),[day,setDay]=useState(''),[calendar,setCalendar]=useState<Record<string,string>>({}),[calendarReady,setCalendarReady]=useState(false);
  const [month,setMonth]=useState('');
  const [msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
  const lock=useRef(false), key=useRef(requestKey());
  const today=utcDate(), dates=[today,...datesAhead()], rangeStart=today, rangeEnd=dates.at(-1)!;
  const months=[...new Set(dates.map(d=>d.slice(0,7)))];
  const [search,setSearch]=useState('');
  const [revision,setRevision]=useState(contentRevision);
  useEffect(()=>{if(mode!=='daily-apply')return;void refreshCommunity(true);return onContentChange(()=>setRevision(contentRevision));},[mode]);
  const bundledIds=useMemo(()=>new Set(bundledTerms.map(t=>t.id)),[]);
  const approved=useMemo(()=>terms.filter(t=>t.sensitivity==='None').map(t=>({id:t.id,term:t.expression,meaning:t.meaning,category:t.category,wordSource:t.status==='Community'?'community':bundledIds.has(t.id)?'bundled':'published'})),[revision,bundledIds]);
  const matches=approved.filter(r=>r.term.toLowerCase().includes(search.trim().toLowerCase())).slice(0,search.trim()?20:0);
  const selected=approved.find(r=>r.id===word);
  // An exact search match is selected automatically, so the user isn't left with a
  // disabled Confirm button and no idea that a word chip had to be tapped.
  useEffect(()=>{
    const q=search.trim().toLowerCase();if(!q)return;
    const exact=matches.filter(r=>r.term.toLowerCase()===q);
    if(exact.length===1&&word!==exact[0]!.id){setWord(exact[0]!.id);key.current=requestKey();}
  },[search,matches.length]);
  const reloadDates=()=>{
    setCalendarReady(false);
    return slots(rangeStart,rangeEnd).then(rows=>{setCalendar(rows);setCalendarReady(true);});
  };
  useEffect(()=>{
    if(mode!=='daily-apply'||!uid)return;
    let current=true;
    void slots(rangeStart,rangeEnd).then(rows=>{if(current){setCalendar(rows);setCalendarReady(true);}},e=>{if(current)setMsg(errorOf(e));});
    return ()=>{current=false;};
  },[uid,mode,rangeStart,rangeEnd]);
  const badges=useBadges(mode==='verification'&&uid?[uid]:[]);
  const submit=async(action:string,fields:Record<string,unknown>)=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setMsg('');
    try {
      const result=await feature(action,{...fields,requestId:key.current});
      key.current=requestKey();
      if(typeof result.balance==='number')credits.setBalance(result.balance);
      else if(paid)credits.reload();
      setMsg(action==='cancel-daily'?'Application cancelled. A paid request is refunded to your Wallet; a free one can be used again this month.':action==='delete-post'?'Post removed.':result.free?'Application received. Your free monthly request was used.':'Application received. Your payment is recorded in your Wallet.');
      if(mode==='daily-apply'){setWord('');setDay('');await reloadDates();}
      data.reload();
    } catch(e){
      const next=(e as {details?:{next?:string}})?.details?.next;
      if(next){setDay(next);setMonth(next.slice(0,7));void reloadDates().catch(()=>{});}
      setMsg(errorOf(e)+(next?` Next available: ${next} UTC. Confirm again to reserve it.`:''));
    } finally {lock.current=false;setBusy(false);}
  };
  if(!uid&&phase==='restoring')return <Glass><Text style={s.label}>Checking your account…</Text><Text style={s.body}>Restoring your saved sign-in.</Text></Glass>;
  if(!uid)return <Glass><Text style={s.label}>Sign in to continue</Text><Button title="Sign in" onPress={onSignIn}/></Glass>;
  if(!BACKEND_URL&&(mode==='daily-apply'||mode==='verification'))return <Glass><Text style={s.label}>{mode==='verification'?'Verified Badge':'Daily Code'}</Text><Text style={s.body}>Credit services are not connected yet. Free contributions and games remain available.</Text></Glass>;
  return <>
    {mode!=='verification'&&<SectionHeader title={mode==='daily-apply'?'Daily Code Display':mode==='daily-history'?'My Daily Code applications':'My posts'} eyebrow="GENZ CODEBOOK"/>}
    {!!msg&&<Text accessibilityRole="alert" style={s.body}>{msg}</Text>}
    {!!data.error&&<Text accessibilityRole="alert" style={s.body}>{data.error}</Text>}
    {(data.loading||data.error)&&<Button light title={data.loading?'Loading…':'Retry'} disabled={data.loading} onPress={()=>data.reload()}/>}
    {mode==='daily-apply'?<>
      <Text style={s.body}>Choose a word from Codes and an available date. Your word appears at the top of Home and Codes on that day.</Text>
      <View style={[s.fee,{backgroundColor:credits.free?.daily?'#DCFCE7':'#FFF0C7'}]}><Icon name={credits.free?.daily?'gift-outline':'calendar-outline'} size={18} color={credits.free?.daily?'#15803D':C.goldDeep}/><Text style={[s.body,{flex:1,color:C.ink,fontWeight:'700'}]}>{credits.free===null?`1 free Daily Code Display every month, then ${money(policy.dailyFee)} Credits.`:credits.free.daily?'Your free Daily Code Display for this month is available.':`This month’s free use is taken. Each extra request is ${money(policy.dailyFee)} Credits.`}</Text></View>
      <Text style={s.step}>1 · Choose your word</Text>
      <TextInput accessibilityLabel="Search dictionary codes" placeholder="Search a word, e.g. HDOT" value={search} onChangeText={setSearch} autoCapitalize="none" autoCorrect={false} style={{minHeight:44,borderWidth:1,borderColor:C.line,borderRadius:12,padding:10,color:C.ink,backgroundColor:'#fff'}}/>
      {!!search.trim()&&!matches.length&&<Text style={s.body}>No matching code. Try a different spelling, or create it first from Codes.</Text>}
      {!!matches.length&&<Text style={s.fine}>Tap a word to select it.</Text>}
      <View style={s.wrap}>{matches.map(r=><Chip key={r.id} label={(word===r.id?'✓ ':'')+r.term} selected={word===r.id} onPress={()=>{setWord(r.id);key.current=requestKey();}}/>)}</View>
      {selected&&<Glass><View style={s.row}><Icon name="checkmark-circle" size={20} color="#16A34A"/><Text style={[s.label,{flex:1}]}>{selected.term} · {selected.category}</Text><Pressable accessibilityRole="button" accessibilityLabel="Change word" onPress={()=>setWord('')}><Text style={s.link}>Change</Text></Pressable></View><Text style={s.body}>{selected.meaning}</Text></Glass>}
      <Text style={s.step}>2 · Choose a date (UTC)</Text>
      {!calendarReady&&<Button light title="Load available dates" onPress={()=>void reloadDates().catch(e=>setMsg(errorOf(e)))}/>}
      {calendarReady&&<>
        <View style={s.wrap}>{months.map(m=><Chip key={m} label={m} selected={(month||months[0])===m} onPress={()=>setMonth(m)}/>)}</View>
        <View style={s.calendar}>{dates.filter(d=>d.startsWith(month||months[0]!)).map(d=>{
          const state=slotState(calendar[d],d===today);
          return <Pressable key={d} accessibilityRole="button" accessibilityLabel={`${d} ${slotLabel[state]}`} accessibilityState={{selected:day===d,disabled:state!=='open'}} disabled={state!=='open'} onPress={()=>{setDay(d);key.current=requestKey();}} style={[s.day,dayStyle[state],day===d&&{backgroundColor:C.accent,borderColor:C.accent}]}>
            <Text style={{fontWeight:'800',color:day===d?'#fff':dayText[state]}}>{d.slice(-2)}</Text>
          </Pressable>;})}</View>
        <View style={[s.wrap,{gap:12}]}>{(['open','reserved','pending','closed'] as SlotState[]).map(k=><View key={k} style={s.row}><View style={[s.dot,dayStyle[k]]}/><Text style={s.fine}>{slotLabel[k]}</Text></View>)}</View>
      </>}
      <Text style={s.body}>{day? `Selected date: ${day} UTC`:'Select an available date.'}</Text>
      <Text style={s.fine}>{refundPolicy}</Text>
      {!!credits.error&&<Button light title="Retry balance check" onPress={credits.reload}/>}
      <ConfirmFee fee={credits.free?.daily?0:policy.dailyFee} freeLabel="Free · your monthly Daily Code Display" balance={credits.balance} onGetCredits={onGetCredits} summary={`Apply to feature “${selected?.term??''}” on ${day} UTC. ${refundPolicy}`}
        missing={[...(!selected?['Choose a word in step 1.']:[]),...(!calendarReady?['Load the available dates.']:!day?['Choose a date in step 2.']:calendar[day]?['That date is already taken. Choose another date.']:[])]}
        disabled={busy} onConfirm={()=>void submit('apply-daily',{wordId:word,wordSource:selected?.wordSource,date:day})}/>
    </>:<>
      {mode==='verification'&&(()=>{
        const verified=badges.has(uid), tier=badges.tier(uid);
        const open=data.rows.find(r=>['pending','approved'].includes(r.status));
        return <>
          <LiquidHero tone={verified&&tier==='blue'?'blue':'gold'} style={s.vHero}>
            <View style={s.vSeal}><VerifiedBadge verified tier={verified?tier:'gold'} size={44} halo/></View>
            <Text style={s.vEyebrow}>PREMIUM · VERIFIED</Text>
            <Text accessibilityRole="header" style={s.vTitle}>{verified?'You’re verified':'Get the Verified badge'}</Text>
            <Text style={s.vSub}>{verified?(tier==='gold'?'Gold badge · GenZ Codebook team':'Blue badge · verified member'):'Stand out as a trusted voice in the GenZ Codebook community.'}</Text>
            {!verified&&<View style={s.vPrice}><Icon name="diamond" size={15} color="#7A4E0E"/><Text style={s.vPriceText}>{money(policy.verificationFee)} Credits · one-time review</Text></View>}
          </LiquidHero>
          <View style={{gap:10}}>
            {([['blue','Blue badge','Verified member','For trusted community members. Apply below and our team reviews your account.'],
              ['gold','Gold badge','GenZ Codebook team','For the owner and the official team. Given by the team only; it can’t be bought.']] as [BadgeTier,string,string,string][]).map(([t,title,sub,body])=>
              <View key={t} style={[s.vTier,t==='gold'?s.vTierGold:s.vTierBlue]}>
                <VerifiedBadge verified tier={t} size={30} halo/>
                <View style={{flex:1,gap:3}}><Text style={s.vTierTitle}>{title}</Text><Text style={[s.vTierSub,t==='gold'?{color:'#8A5A00'}:{color:'#1D4ED8'}]}>{sub}</Text><Text style={s.body}>{body}</Text></View>
              </View>)}
          </View>
          <Glass style={{gap:12}}>
            <Text style={s.vSection}>What you get</Text>
            {([['chatbubbles','Your badge beside your name in chat, posts, comments and the leaderboard.'],
              ['person-circle','Your profile card in your badge colour.'],
              ['shield-checkmark','Shows the community your account is real and trusted.']] as [IconName,string][]).map(([icon,text])=>
              <View key={text} style={s.vLine}><View style={s.vLineIcon}><Icon name={icon} size={18} color={C.goldDeep}/></View><Text style={s.vLineText}>{text}</Text></View>)}
          </Glass>
          <Glass style={{gap:12}}>
            <Text style={s.vSection}>How it works</Text>
            {['Pay the one-time review fee with Credits.','Our team reviews your account.','If approved, the blue badge appears next to your name everywhere.'].map((text,i)=>
              <View key={text} style={s.vLine}><View style={s.vStep}><Text style={s.vStepText}>{i+1}</Text></View><Text style={s.vLineText}>{text}</Text></View>)}
          </Glass>
          {verified?null:open?<Glass style={{gap:8}}>
            <View style={s.row}><Text style={[s.vSection,{flex:1}]}>Your application</Text><Status status={open.status}/></View>
            <Text style={s.body}>{open.status==='pending'?'Our team is reviewing your account. Check back here for the result.':'Approved. Your badge appears within a few minutes.'}</Text>
          </Glass>:!data.loading&&!data.error?<Glass style={{gap:10}}>
            <Text style={s.vSection}>Apply for the blue badge</Text>
            <ConfirmFee fee={policy.verificationFee} balance={credits.balance} summary={reviewPolicy} onGetCredits={onGetCredits} disabled={busy} onConfirm={()=>void submit('apply-verification',{})}/>
          </Glass>:null}
          {!!credits.error&&<Text style={s.body}>{credits.error}</Text>}
          <Text style={s.fine}>{reviewPolicy}</Text>
        </>;
      })()}
      {(mode!=='verification'||data.rows.length>0)&&<>
      {mode==='verification'&&<Text style={s.vSection}>Your applications</Text>}
      <Button light title="Refresh status" onPress={data.reload} disabled={data.loading||busy}/>
      <RowHistory rows={data.rows} kind={kind} cancel={mode==='daily-history'?r=>void submit('cancel-daily',{id:r.id}):mode==='my-posts'?r=>void submit('delete-post',{id:r.id}):undefined}/>
      </>}
    </>}
  </>;
}

const s=StyleSheet.create({
  skeleton:{borderRadius:8,backgroundColor:'rgba(255,255,255,.18)'},
  vHero:{padding:20,borderRadius:24,gap:8,alignItems:'center'},vSeal:{marginBottom:4},
  vEyebrow:{color:'rgba(255,255,255,.85)',fontSize:11.5,fontWeight:'900',letterSpacing:1.6},
  vTitle:{color:'#fff',fontSize:24,fontWeight:'900',textAlign:'center'},vSub:{color:'rgba(255,255,255,.92)',fontSize:14.5,lineHeight:20,textAlign:'center'},
  vPrice:{flexDirection:'row',alignItems:'center',gap:6,marginTop:6,paddingHorizontal:14,paddingVertical:8,borderRadius:999,backgroundColor:'#FFF4D1'},vPriceText:{color:'#7A4E0E',fontWeight:'900',fontSize:13.5},
  vTier:{flexDirection:'row',alignItems:'flex-start',gap:12,padding:14,borderRadius:18,borderWidth:1.5},
  vTierBlue:{backgroundColor:'#EFF6FF',borderColor:'#BFDBFE'},vTierGold:{backgroundColor:'#FFFBEB',borderColor:'#F5D67B'},
  vTierTitle:{fontSize:16,fontWeight:'900',color:C.ink},vTierSub:{fontSize:13,fontWeight:'800'},
  vSection:{fontSize:16,fontWeight:'900',color:C.ink},vLine:{flexDirection:'row',alignItems:'flex-start',gap:12},
  vLineIcon:{width:34,height:34,borderRadius:11,backgroundColor:'#FFF4D1',alignItems:'center',justifyContent:'center'},vLineText:{flex:1,fontSize:14.5,lineHeight:21,color:C.ink,paddingTop:6},
  vStep:{width:28,height:28,borderRadius:14,backgroundColor:C.goldDeep,alignItems:'center',justifyContent:'center',marginTop:3},vStepText:{color:'#fff',fontWeight:'900',fontSize:13},
  calendar:{flexDirection:'row',flexWrap:'wrap',gap:5},day:{width:'12.8%',minHeight:38,borderWidth:1,borderColor:C.line,borderRadius:9,alignItems:'center',justifyContent:'center',backgroundColor:'#fff'},
  hero:{padding:16,borderRadius:21,gap:8},compactHero:{padding:11,borderRadius:16,gap:3},compactWord:{fontSize:23},
  apply:{minHeight:42,paddingHorizontal:8,flexDirection:'row',alignItems:'center',gap:4},applyText:{fontSize:13,fontWeight:'800',color:'#fff'},row:{flexDirection:'row',alignItems:'center',gap:8},wrap:{flexDirection:'row',flexWrap:'wrap',gap:8},
  eyebrow:{fontSize:12,letterSpacing:1.4,fontWeight:'900',color:'#E0E9FF',flex:1},
  date:{color:'#E0E9FF',fontSize:11},word:{fontSize:34,fontWeight:'900',color:'#fff'},meaning:{fontSize:16,lineHeight:23,color:'#fff'},
  category:{alignSelf:'flex-start',borderRadius:12,paddingHorizontal:10,paddingVertical:5,color:'#19234B',backgroundColor:'#DFE7FF',fontWeight:'800'},
  label:{fontSize:16,fontWeight:'800',color:C.ink},body:{fontSize:14,lineHeight:20,color:C.muted},fee:{backgroundColor:'#FFF0C7',borderRadius:13,padding:12,flexDirection:'row',alignItems:'center',gap:8},
  unavailable:{backgroundColor:'#E8EDF7',borderRadius:12,padding:9,justifyContent:'center'},status:{paddingHorizontal:8,paddingVertical:4,borderRadius:10,fontSize:12,fontWeight:'800',overflow:'hidden'},
  good:{color:'#09583E',backgroundColor:'#DDF6EA'},bad:{color:'#8E2634',backgroundColor:'#FEE5EB'},wait:{color:'#73501A',backgroundColor:'#FFF0CD'},
  step:{fontSize:15,fontWeight:'900',color:C.ink,marginTop:4},fine:{fontSize:12.5,lineHeight:17,color:C.muted},link:{fontWeight:'800',color:C.accent},
  dot:{width:14,height:14,borderRadius:5,borderWidth:1},blockers:{backgroundColor:'#FFF7E6',borderRadius:12,padding:10,gap:6,borderWidth:1,borderColor:'#FCD9A0'},
});
