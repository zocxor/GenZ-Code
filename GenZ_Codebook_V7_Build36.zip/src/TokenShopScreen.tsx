/** One-time token purchases. All live prices come from Google Play. */
import {SPARK_MODE} from '../shared/deployment';
import {TOKEN_CHECKOUT_ENABLED} from './backend';
import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {C,Button,LiquidHero,Icon,SectionHeader,type IconName} from './ui';
import {useEligibleBalance} from './ContributionScreens';
import {useAppConfig} from './appConfig';
import {SUBSCRIPTION_PRODUCTS} from '../shared/subscriptions';
import {useAccountUser} from './services';
import {buySubscription,getSubscriptionProducts,isSubscriptionPurchaseEnabled,onSubscriptionEvent} from './subscription';
import {isAdsDisabled,onAdsDisabledChange} from './ads';
import {buyTokens,getBillingProducts,getBillingStatus,isTokenPurchaseEnabled,onBillingEvent,retryBilling} from './billing';
import {TOKEN_PRODUCTS,type TokensState} from '../shared/tokens';

export default function TokenShopScreen({tokens,onSignIn,onOpenWallet}:{
  tokens:TokensState;
  onSignIn:()=>void;
  onOpenWallet:()=>void;
}) {
  const user=useAccountUser();
  const [products,setProducts]=useState(getBillingProducts);
  const [status,setStatus]=useState(getBillingStatus);
  const [buying,setBuying]=useState<string|null>(null);
  const [retrying,setRetrying]=useState(false);
  const [message,setMessage]=useState('');
  const busy=useRef(false);
  const checkout=isTokenPurchaseEnabled();
  const subCheckout=checkout&&isSubscriptionPurchaseEnabled();
  const [plans,setPlans]=useState(getSubscriptionProducts);
  const [premium,setPremium]=useState(isAdsDisabled);
  useEffect(()=>{
    const off=onSubscriptionEvent(event=>{
      if(event.kind==='products'||event.kind==='unavailable'){setPlans(getSubscriptionProducts());return;}
      if(event.kind==='restored'){setMessage(event.count?'Your Premium subscription was restored.':'No Premium subscription to restore.');return;}
      busy.current=false;setBuying(null);
      switch(event.kind){
        case 'subscribed':setMessage(`Premium is active: ads are off and ${event.tokens.toLocaleString()} Credits were added.`);break;
        case 'already-subscribed':setMessage('Premium is already active on your account.');break;
        case 'pending':setMessage('Payment is pending in Google Play. Premium starts once it completes.');break;
        case 'failed':setMessage(event.message);break;
        case 'cancelled':setMessage('Subscription cancelled.');break;
        case 'signin-required':setMessage('Sign in to subscribe to Premium.');break;
      }
    });
    const offAds=onAdsDisabledChange(setPremium);
    return ()=>{off();offAds();};
  },[]);
  const subscribe=async(productId:string)=>{
    if(busy.current||!subCheckout)return;
    if(!user){onSignIn();return;}
    busy.current=true;setMessage('');setBuying(productId);
    const result=await buySubscription(productId);
    if(!result.started){busy.current=false;setBuying(null);setMessage(result.error??'Could not start the subscription.');}
  };

  useEffect(()=>{
    const sync=()=>{setProducts(getBillingProducts());setStatus(getBillingStatus());};
    const stop=onBillingEvent(event=>{
      if(event.kind==='products'||event.kind==='unavailable'){sync();return;}
      if(event.kind==='restored'){setMessage(`${event.count} earlier purchases restored.`);return;}
      busy.current=false;
      setBuying(null);
      switch(event.kind){
        case 'credited':setMessage(`${event.tokens.toLocaleString()} Credits added to your wallet.`);break;
        case 'already-credited':setMessage('This purchase is already in your wallet.');break;
        case 'pending':setMessage('Payment is pending in Google Play.');break;
        case 'failed':setMessage(event.message);break;
        case 'cancelled':setMessage('Purchase cancelled.');break;
        case 'signin-required':setMessage('Sign in to buy Credits.');break;
      }
    });
    sync();
    return stop;
  },[]);

  const buy=async(productId:string)=>{
    if(busy.current||!checkout)return;
    busy.current=true;
    setMessage('');setBuying(productId);
    const result=await buyTokens(productId);
    if(!result.started){busy.current=false;setBuying(null);setMessage(result.error??'Could not start checkout.');}
  };
  const retry=async()=>{
    setRetrying(true);setMessage('');
    try {await retryBilling();setProducts(getBillingProducts());setStatus(getBillingStatus());}
    catch {setMessage('Could not refresh Google Play prices. Try again.');}
    finally {setRetrying(false);}
  };

  const credits=useEligibleBalance(user?.uid);
  const cfg=useAppConfig();
  const live=TOKEN_CHECKOUT_ENABLED&&checkout;
  const costs:[IconName,string,string,string][]=[
    ['chatbubbles-outline','Community chat','Unlimited messages for the whole day (UTC)',`${cfg.fees.chat}`],
    ['create-outline','Publish a community post','Share a word or meaning in Posts',`${cfg.fees.post}`],
    ['add-circle-outline','Create a dictionary word','1 free every day, then this price per word',`${cfg.fees.code}`],
    ['calendar-outline','Daily Code Display','Your word on Home and Codes for a day · 1 free every month',`${cfg.fees.daily}`],
    ['shield-checkmark-outline','Verified badge review','Blue badge request, reviewed by our team',`${cfg.fees.verification.toLocaleString()}`],
    ['code-slash-outline','Encode Message',`${cfg.encodeFreeDaily} free a day, then per message`,cfg.fees.encode?`${cfg.fees.encode}`:'Free'],
    ['scan-outline','Decode Message',`${cfg.decodeFreeDaily} free a day, then per message`,cfg.fees.decode?`${cfg.fees.decode}`:'Free'],
  ];
  return <ScrollView contentContainerStyle={s.content}>
    <LiquidHero style={s.hero}>
      <Text style={s.heroEyebrow}>GENZ CODEBOOK CREDITS</Text>
      <Text style={s.heroTitle}>One balance for everything you unlock.</Text>
      <View style={s.balance}><Icon name="star" size={18} color="#FFD45C"/><Text style={s.balanceText}>{user?(credits.balance===null?'—':credits.balance.toLocaleString()):'Sign in'} Credits</Text></View>
    </LiquidHero>
    
    {live&&!status.loaded&&<Text style={s.body}>Loading Google Play prices…</Text>}
    {live&&status.loaded&&!status.available&&<View style={s.soon}><Text style={[s.body,{flex:1}]}>{status.error??'Google Play billing is unavailable on this device.'}</Text><Button light title={retrying?'Refreshing…':'Refresh'} disabled={retrying} onPress={()=>void retry()}/></View>}
    {live&&!user&&<Button light title="Sign in to buy Credits" icon="log-in-outline" onPress={onSignIn}/>}
    {!!message&&<Text accessibilityRole="alert" style={s.notice}>{message}</Text>}

    <SectionHeader eyebrow="PRICES" title="What Credits buy"/>
    <View style={s.list}>{costs.map(([icon,label,detail,value],i)=><View key={label} accessible accessibilityLabel={`${label}: ${value==='Free'?'free':`${value} Credits`}. ${detail}`} style={[s.listRow,i===costs.length-1&&s.listLast]}><View style={s.listIcon}><Icon name={icon} size={19} color={C.accent}/></View><View style={{flex:1}}><Text style={s.listLabel}>{label}</Text><Text style={s.listDetail}>{detail}</Text></View><View style={s.priceTag}><Text style={s.costValue}>{value}</Text>{value!=='Free'&&<Text style={s.priceUnit}>Credits</Text>}</View></View>)}</View>

    <SectionHeader eyebrow="FREE" title="Earn Credits"/>
    <View style={s.list}>
      <View style={s.listRow}><View style={s.listIcon}><Icon name="play-circle" size={20} color="#2F3BEA"/></View><Text style={[s.listLabel,{flex:1}]}>Watch an optional ad</Text><Text style={s.earnValue}>+10</Text></View>
      <View style={s.listRow}><View style={s.listIcon}><Icon name="gift" size={20} color="#D97706"/></View><Text style={[s.listLabel,{flex:1}]}>Daily reward</Text><Text style={s.earnValue}>+10</Text></View>
      <View style={[s.listRow,s.listLast]}><View style={s.listIcon}><Icon name="people" size={20} color="#16A34A"/></View><Text style={[s.listLabel,{flex:1}]}>A friend joins with your code</Text><Text style={s.earnValue}>+100</Text></View>
    </View>

    {/* Packs and Premium appear only when Google Play checkout is switched on, so the app never shows buttons that can't work. */}
    {live&&<>
    <SectionHeader eyebrow="PAY ONCE" title="Credit packs"/>
    <View style={s.catalog}>
      {TOKEN_PRODUCTS.map((pack,i)=>{
        const product=live&&status.available?products.find(p=>p.productId===pack.id):undefined;
        const disabled=!product||!user||buying!==null;
        const tag=i===2?'Popular':i===TOKEN_PRODUCTS.length-1?'Best value':i===0?'Starter':'';
        return <View style={[s.pack,i===2&&s.packFeatured]} key={pack.id}>
          {!!tag&&<Text style={[s.tag,i===2&&s.tagFeatured]}>{tag}</Text>}
          <Icon name="star" size={22} color="#E0A100"/>
          <Text style={s.amount}>{pack.tokens.toLocaleString()}</Text>
          <Text style={s.unit}>Credits</Text>
          <Text style={s.refPrice}>{product?product.localizedPrice:pack.price}</Text>
          <Pressable accessibilityRole="button" accessibilityLabel={product?`Buy ${pack.tokens.toLocaleString()} Credits for ${product.localizedPrice}, one-time purchase`:`${pack.tokens.toLocaleString()} Credits, checkout opens soon`}
            accessibilityState={{disabled,busy:buying===pack.id}} disabled={disabled} onPress={()=>void buy(pack.id)} style={[s.buy,disabled&&s.buyDisabled]}>
            {buying===pack.id?<ActivityIndicator color="#fff"/>:<Text style={[s.buyText,disabled&&{color:C.muted}]}>{product?'Buy':live?'Unavailable':'Opens soon'}</Text>}
          </Pressable>
        </View>;
      })}
    </View>
    <Text style={s.fine}>One-time Google Play payment. Credits are added only after Google Play confirms the purchase, never twice for the same order. Prices shown are the planned US prices; Google Play shows the final price in your currency at checkout. Credit packs do not remove ads.</Text>

    <SectionHeader eyebrow="AD-FREE" title="Premium"/>
    {premium&&<View style={s.active} accessibilityLiveRegion="polite"><Icon name="checkmark-circle" size={20} color="#15803D"/><Text style={[s.body,{flex:1,color:'#14532D',fontWeight:'800'}]}>Premium is active on your account. Ads are off.</Text></View>}
    <View style={s.perks}>
      {([['ban-outline','No ads interrupt you','No full-screen ads anywhere in the app while Premium is active.'],
        ['wallet-outline','Credits every period',`${SUBSCRIPTION_PRODUCTS[0].tokensPerPeriod.toLocaleString()} Credits each month, or ${SUBSCRIPTION_PRODUCTS[1].tokensPerPeriod.toLocaleString()} with the yearly plan.`],
        ['play-circle-outline','Earn even more if you want','Optional reward videos stay available for extra Credits.'],
        ['phone-portrait-outline','On all your devices','Linked to your account and checked by our server.']] as [IconName,string,string][]).map(([icon,title,detail])=>
        <View key={title} style={s.perk}><Icon name={icon} size={19} color="#A16207"/><View style={{flex:1}}><Text style={s.listLabel}>{title}</Text><Text style={s.listDetail}>{detail}</Text></View></View>)}
    </View>
    {SUBSCRIPTION_PRODUCTS.map(plan=>{
      const live=plans.find(p=>p.productId===plan.id), yearly=plan.basePlanId==='yearly', busyHere=buying===plan.id;
      return <View key={plan.id} style={[s.plan,yearly&&s.planBest]}>
        {yearly&&<View style={s.bestTag}><Text style={s.bestTagText}>BEST VALUE · SAVE 33%</Text></View>}
        <View style={{flexDirection:'row',alignItems:'flex-start',gap:10}}>
          <View style={{flex:1,gap:3}}>
            <Text style={s.planTitle}>Premium {yearly?'Yearly':'Monthly'}</Text>
            <Text style={s.body}>Ad-free · +{plan.tokensPerPeriod.toLocaleString()} Credits {plan.periodLabel}</Text>
          </View>
          <View style={{alignItems:'flex-end'}}>
            <Text style={s.planPrice}>{live?.localizedPrice??plan.price}</Text>
            <Text style={s.fine}>{yearly?'per year':'per month'}{live?'':' · planned'}</Text>
          </View>
        </View>
        {subCheckout?<Button title={premium?'Premium active':busyHere?'Opening Google Play…':live?`Subscribe · ${live.localizedPrice}`:'Loading Google Play price…'} icon="diamond-outline" disabled={premium||!!buying||!live} onPress={()=>void subscribe(plan.id)}/>
          :<View style={s.planBadge}><Text style={s.planBadgeText}>Opens with Google Play checkout</Text></View>}
      </View>;
    })}
    <Text style={s.fine}>Renews automatically until you cancel in Google Play (Payments & subscriptions). Premium and its Credits are added only after Google Play confirms the payment on our server. Planned US prices; Google Play shows the final price in your currency.</Text>
    </>}
    <Button light title="View my wallet" icon="wallet-outline" onPress={onOpenWallet}/>
  </ScrollView>;
}

const s=StyleSheet.create({
  content:{padding:16,gap:12,paddingBottom:30},
  hero:{padding:18,borderRadius:22,gap:8},heroEyebrow:{color:'#BFD3FF',fontSize:11,fontWeight:'900',letterSpacing:1.4},
  heroTitle:{color:'#fff',fontSize:22,fontWeight:'900',lineHeight:28},
  balance:{flexDirection:'row',alignItems:'center',gap:6,alignSelf:'flex-start',backgroundColor:'rgba(255,255,255,.14)',borderRadius:16,paddingHorizontal:12,paddingVertical:7,borderWidth:1,borderColor:'rgba(255,255,255,.25)'},
  balanceText:{color:'#fff',fontWeight:'900',fontSize:15},
  soon:{flexDirection:'row',alignItems:'center',gap:10,padding:12,borderRadius:14,backgroundColor:'#FFF7E6',borderWidth:1,borderColor:'#FCD9A0'},
  sectionTitle:{fontSize:18,fontWeight:'900',color:C.ink},body:{fontSize:13.5,lineHeight:19,color:C.muted},fine:{fontSize:12,lineHeight:17,color:C.muted},
  notice:{fontSize:13.5,color:C.ink,backgroundColor:C.soft,padding:10,borderRadius:12},
  costGrid:{flexDirection:'row',flexWrap:'wrap',gap:8},
  list:{backgroundColor:'#fff',borderRadius:18,borderWidth:1,borderColor:'#E2E8F5',paddingHorizontal:12},
  listRow:{flexDirection:'row',alignItems:'center',gap:12,minHeight:56,paddingVertical:11,borderBottomWidth:1,borderBottomColor:'#EEF1F8'},listLast:{borderBottomWidth:0},
  listIcon:{width:36,height:36,borderRadius:12,backgroundColor:'#EEF3FF',alignItems:'center',justifyContent:'center'},
  listLabel:{fontSize:14.5,fontWeight:'800',color:C.ink},listDetail:{fontSize:12.5,color:C.muted,marginTop:2,lineHeight:17},
  priceTag:{alignItems:'flex-end',minWidth:56},priceUnit:{fontSize:11,fontWeight:'700',color:C.muted},
  cost:{flexGrow:1,flexBasis:'45%',minHeight:58,flexDirection:'row',alignItems:'center',gap:8,padding:10,borderRadius:14,backgroundColor:'#fff',borderWidth:1,borderColor:'#E2E8F5'},
  costLabel:{flex:1,fontSize:13,fontWeight:'700',color:C.ink},costValue:{fontSize:14,fontWeight:'900',color:'#B45309'},
  earn:{flexGrow:1,flexBasis:'45%',minHeight:58,flexDirection:'row',alignItems:'center',gap:8,padding:10,borderRadius:14,backgroundColor:'#F3F7FF',borderWidth:1,borderColor:'#DCE6FB'},
  earnValue:{fontSize:15,fontWeight:'900',color:'#16A34A'},
  catalog:{flexDirection:'row',flexWrap:'wrap',gap:10},
  pack:{flexGrow:1,flexBasis:'30%',minWidth:100,alignItems:'center',gap:2,paddingTop:14,paddingBottom:10,paddingHorizontal:8,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#E7E2F7'},
  packFeatured:{borderColor:'#8B5CF6',borderWidth:2,backgroundColor:'#FAF7FF'},
  tag:{position:'absolute',top:-9,fontSize:10.5,fontWeight:'900',color:'#5B21B6',backgroundColor:'#EDE7FF',paddingHorizontal:8,paddingVertical:2,borderRadius:8,overflow:'hidden'},
  tagFeatured:{color:'#fff',backgroundColor:'#7C3AED'},
  refPrice:{fontSize:14,fontWeight:'900',color:'#1E3A8A',marginTop:2},amount:{fontSize:20,fontWeight:'900',color:C.ink,marginTop:4},unit:{fontSize:12,color:C.muted,fontWeight:'700'},
  buy:{marginTop:8,alignSelf:'stretch',minHeight:38,borderRadius:12,backgroundColor:'#2F3BEA',alignItems:'center',justifyContent:'center',paddingHorizontal:6},
  buyDisabled:{backgroundColor:'#EEF1F8'},buyText:{color:'#fff',fontWeight:'900',fontSize:13},
  plan:{gap:10,padding:14,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#F3D27A'},planBest:{borderWidth:2,borderColor:'#E0A100',backgroundColor:'#FFFBEB'},
  bestTag:{alignSelf:'flex-start',backgroundColor:'#E0A100',borderRadius:8,paddingHorizontal:8,paddingVertical:3},bestTagText:{color:'#fff',fontSize:10.5,fontWeight:'900',letterSpacing:.6},
  planPrice:{fontSize:20,fontWeight:'900',color:C.ink},
  perks:{gap:12,padding:14,borderRadius:18,backgroundColor:'#FFFDF5',borderWidth:1,borderColor:'#F3E3B0'},perk:{flexDirection:'row',gap:10,alignItems:'flex-start'},
  active:{flexDirection:'row',alignItems:'center',gap:10,padding:12,borderRadius:14,backgroundColor:'#DCFCE7',borderWidth:1,borderColor:'#86EFAC'},
  planTitle:{fontSize:16,fontWeight:'900',color:C.ink},
  planBadge:{alignSelf:'flex-start',backgroundColor:'#FFF3D1',borderRadius:10,paddingHorizontal:9,paddingVertical:5},planBadgeText:{fontSize:11.5,fontWeight:'900',color:'#8A5A00'},
});
