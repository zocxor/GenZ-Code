import {createHash} from 'node:crypto';
type AuthData={uid:string;token:{email_verified?:boolean;firebase?:unknown;[key:string]:unknown}};
import {HttpsError} from 'firebase-functions/v2/https';
import {FieldPath, FieldValue, Timestamp, type Firestore, type Transaction} from 'firebase-admin/firestore';
import {communityId,screenWord} from './validation/community';
import {normalizeTerm, cleanText,validateEntry} from './validation/contentSchema';
import {publishingMode} from './validation/publishing';
import {screenPost} from './validation/chat';
import dictionary from './validation/dictionary.json';
import policy from './communityPolicy.json';

const {dailyFee, postFee, verificationFee, bookingDays, postCategories} = policy;
const dayMs = 86_400_000;
type Fees = {chat: number; post: number; code: number; daily: number; verification: number; encode: number; decode: number};
/** Live Credit prices: admin-set config/app.prices, else the defaults in communityPolicy.json. */
export function fees(config: FirebaseFirestore.DocumentData = {}): Fees {
  const p = (config.prices && typeof config.prices === 'object' ? config.prices : {}) as Record<string, unknown>;
  const v = (k: string, min: number, max: number, d: number) => Number.isSafeInteger(p[k]) && (p[k] as number) >= min && (p[k] as number) <= max ? p[k] as number : d;
  return {chat: v('chatDay', 1, 100000, policy.chatDailyFee), post: v('post', 1, 100000, postFee), code: v('code', 1, 100000, policy.dictionaryFee),
    daily: v('dailyCode', 1, 100000, dailyFee), verification: v('verification', 1, 100000, verificationFee), encode: v('encode', 0, 1000, 5), decode: v('decode', 0, 1000, 5)};
}
const stamp = FieldValue.serverTimestamp;
/** Server-written free allowances: one dictionary word per UTC day, one Daily Code Display per UTC month. */
const codeAllowance = (db: Firestore, uid: string, now: number) => db.doc(`users/${uid}/allowances/code-${new Date(now).toISOString().slice(0, 10)}`);
const dailyAllowance = (db: Firestore, uid: string, month: string) => db.doc(`users/${uid}/allowances/daily-${month}`);
export const utcDay = (time = Date.now()) => new Date(time).toISOString().slice(0, 10);
const digest = (s: string) => createHash('sha256').update(s).digest('hex');
function generateEntry(date: string) {
  const choices = dictionary.featured;
  const choice = choices[parseInt(digest(date).slice(0,8),16)%choices.length];
  if (choice) return {term:choice.term,meaning:choice.meaning,category:choice.category};
}
const dailyDictionary = new Map(dictionary.selectable.map(entry=>[entry.id,entry]));
const bundled = new Set(dictionary.terms.map(normalizeTerm));
const moderation = ['super_admin', 'content_manager', 'moderator'];
const editorial = ['super_admin', 'content_manager'];
const publicComment = (d: FirebaseFirestore.DocumentData) => ({name: d.name, uid: d.uid, text: d.text, createdAt: d.createdAt});
type Input = Record<string, unknown>;
function id(v: unknown) {
  if (typeof v !== 'string' || !/^[\w-]{1,128}$/.test(v)) throw new HttpsError('invalid-argument', 'Invalid record identifier.');
  return v;
}
function text(v: unknown, max: number, optional = false) {
  if (typeof v !== 'string' || v.trim().length > max) throw new HttpsError('invalid-argument', `Use at most ${max} characters.`);
  const value = cleanText(v, max);
  if (!optional && !value) throw new HttpsError('invalid-argument', 'Complete the required fields.');
  return value;
}
function screened(value: string) {
  if (!value) return value;
  const result = screenPost(value);
  if (!result.ok) throw new HttpsError('invalid-argument', result.message);
  return value;
}
function futureDate(input: unknown, now: number) {
  if (typeof input !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(input)) throw new HttpsError('invalid-argument', 'Choose an available date.');
  const time = Date.parse(input+'T00:00:00Z');
  if (!Number.isFinite(time) || utcDay(time) !== input || input <= utcDay(now) || input > utcDay(now+bookingDays*dayMs)) {
    throw new HttpsError('invalid-argument', `Choose a future UTC date within ${bookingDays} days.`);
  }
  return input;
}
async function selectedDailyWord(db: Firestore, tx: Transaction, source: unknown, wordId: unknown) {
  const key = id(wordId);
  if (source === 'bundled') {
    const overlay=(await tx.get(db.doc('publishedContent/'+key))).data();
    if(overlay?.status==='published'&&overlay.sensitivity==='None')return {term:overlay.term,meaning:overlay.meaning,category:overlay.category};
    if(overlay?.status==='archived')return;
    const entry = dailyDictionary.get(key);
    return entry && {term:entry.term,meaning:entry.meaning,category:entry.category};
  }
  if (source !== 'submission' && source !== 'published' && source !== 'community') throw new HttpsError('invalid-argument','Choose a word from the dictionary.');
  const collection = source === 'submission' ? 'submissions' : source === 'community' ? 'communityWords' : 'publishedContent';
  const data = (await tx.get(db.doc(`${collection}/${key}`))).data();
  if (!data) return;
  if (source === 'submission' && (data.status !== 'accepted' || !data.reviewedBy)) return;
  if (source === 'published' && (data.status !== 'published' || data.sensitivity !== 'None')) return;
  const {term,meaning,category} = data;
  if (![term,meaning,category].every(value=>typeof value === 'string' && value.trim())) return;
  if (source === 'community') {
    if (data.status !== 'live') return;
    const screening = screenWord({term,meaning,example:''});
    if (!screening.ok || screening.review) return;
  }
  return {term,meaning,category};
}
function authRequired(auth: AuthData | undefined) {
  if (!auth) throw new HttpsError('unauthenticated', 'Sign in to continue.');
  if (auth.token.email_verified !== true) throw new HttpsError('permission-denied', 'Verify your email and sign in again.');
  return auth;
}
async function active(db: Firestore, tx: Transaction, uid: string) {
  if ((await tx.get(db.doc(`users/${uid}`))).get('status') !== 'active') throw new HttpsError('permission-denied', 'An active account is required.');
}
async function adminRole(db: Firestore, tx: Transaction, auth: AuthData, roles: string[]) {
  const [staff, config] = await Promise.all([tx.get(db.doc(`admins/${auth.uid}`)),tx.get(db.doc('config/security'))]);
  const role = staff.get('role');
  const secondFactor = (auth.token.firebase as {sign_in_second_factor?: string} | undefined)?.sign_in_second_factor;
  if (staff.get('active') !== true || !roles.includes(role)) {
    throw new HttpsError('permission-denied', `This action requires one of these administrator roles: ${roles.join(', ')}.`);
  }
  if (config.get('adminMfaRequired') === true && !secondFactor) {
    throw new HttpsError('permission-denied', 'Two-step sign-in is required for administrators (config/security.adminMfaRequired). Sign out and sign in again with your second factor.');
  }
  return role as string;
}
function audit(db: Firestore, tx: Transaction, actor: string, role: string, action: string, target: string, summary = '') {
  tx.create(db.collection('auditLogs').doc(), {actor, role, action, target, summary, at: stamp(), expireAt: Timestamp.fromMillis(Date.now()+365*dayMs)});
}
async function nickname(db: Firestore, tx: Transaction, uid: string) {
  const snap = await tx.get(db.doc(`users/${uid}/sync/profile`));
  const data = snap.data();
  const raw = data?.profile?.name ?? data?.name;
  const name = typeof raw === 'string' ? cleanText(raw, 24) : '';
  return name && screenPost(name).ok ? name : 'Code Explorer';
}

type Wallet = {ref: FirebaseFirestore.DocumentReference; balance: number; legacy: FirebaseFirestore.DocumentData; validated: FirebaseFirestore.DocumentReference[]};
const safeAmount = (v: unknown) => Number.isSafeInteger(v) ? Number(v) : 0;
/** The existing balance cache is intentionally writable by legacy clients. Verify the immutable receipts instead. */
export async function wallet(db: Firestore, tx: Transaction, uid: string): Promise<Wallet> {
  const ref = db.doc(`users/${uid}/tokenWallet/wallet`);
  const [cache, ledger] = await Promise.all([
    tx.get(ref), tx.get(ref.parent.parent!.collection('tokenLedger').where('type','in',['purchase','subscription','adjustment','referral','feature_fee','feature_refund','feature_reward','admin_debit'])),
  ]);
  let balance = 0;
  const validated: FirebaseFirestore.DocumentReference[] = [];
  for (const entry of ledger.docs) {
    const d = entry.data(), amount = safeAmount(d.amount);
    // Admin deductions are server-written only (rules reject the type from clients) and can only lower a balance.
    if (d.type === 'admin_debit') {if (amount < 0) balance += amount; continue;}
    if (d.type === 'feature_reward' || d.type === 'feature_fee' || d.type === 'feature_refund' || d.type === 'subscription' || d.verifiedForFeatures === true) {
      balance += amount;
      continue;
    }
    if (amount <= 0) continue;
    if (d.type === 'purchase' && typeof d.purchaseToken === 'string' && /^[^/]{1,500}$/.test(d.purchaseToken)) {
      const proof = (await tx.get(db.doc(`processedTokens/${d.purchaseToken}`))).data();
      if (proof?.uid !== uid || proof.orderId !== d.ref || entry.id !== 'order-'+d.ref || proof.tokens !== amount
          || !proof.createdAt?.isEqual(d.createdAt)) continue;
    } else if (d.type === 'adjustment' && d.ref === 'admin-grant' && typeof d.lastAuditId === 'string' && /^[\w-]{1,128}$/.test(d.lastAuditId)) {
      const proof = (await tx.get(db.doc(`auditLogs/${d.lastAuditId}`))).data();
      if (proof?.action !== 'tokens.send' || proof.role !== 'super_admin' || proof.target !== `users/${uid}`
          || !proof.at?.isEqual(d.createdAt) || !new RegExp(`^Sent ${amount} tokens(?:$| — )`).test(proof.summary)) continue;
    } else if (d.type === 'referral' && amount === 100 && typeof d.ref === 'string' && /^[\w-]{1,128}$/.test(d.ref)) {
      const applicant = /^GZ[A-Z0-9]{6}$/.test(d.ref) ? uid : d.ref;
      const claim = (await tx.get(db.doc(`referralClaims/${applicant}`))).data();
      if (!claim || entry.id !== 'referral-'+d.ref || (applicant === uid ? claim.code !== d.ref : claim.referrerUid !== uid)) continue;
    } else continue;
    balance += amount;
    validated.push(entry.ref);
  }
  return {ref, balance: Math.max(0,balance), legacy: cache.data() ?? {}, validated};
}
function payment(tx: Transaction, w: Wallet, operation: string, amount: number, note: string) {
  if (w.balance + amount < 0) throw new HttpsError('failed-precondition', `You need ${-amount} Credits. Your eligible balance is ${w.balance}.`);
  // Reading and writing this same wallet document serializes payments even when the initial wallet was empty.
  const balance = Math.max(0, Math.min(1_000_000, safeAmount(w.legacy.balance)+amount));
  tx.set(w.ref, {balance, earnedTotal: safeAmount(w.legacy.earnedTotal), purchasedTotal: safeAmount(w.legacy.purchasedTotal),
    spentTotal: Math.max(0,safeAmount(w.legacy.spentTotal)-amount), updatedAt: stamp()});
  for (const ref of w.validated.slice(0, 350)) tx.update(ref, {verifiedForFeatures:true});
  tx.create(w.ref.parent.parent!.collection('tokenLedger').doc(operation), {
    type: amount < 0 ? 'feature_fee' : 'feature_refund', amount, balanceAfter:w.balance+amount, ref:operation, note, createdAt:stamp(),
  });
}

function postFields(d: Input) {
  const term = screened(text(d.term,30));
  const meaning = screened(text(d.meaning,200));
  const example = screened(text(d.example ?? '',200,true));
  screened([term,meaning,example].filter(Boolean).join(' '));
  if (typeof d.category !== 'string' || !postCategories.includes(d.category)) throw new HttpsError('invalid-argument','Choose a post category.');
  return {term,meaning,example,category:d.category,text: `${term}: ${meaning}`};
}
async function claimPost(db: Firestore, tx: Transaction, uid:string, term:string) {
  const ref=db.doc(`communityPostTerms/${digest(uid+':'+normalizeTerm(term))}`);
  if((await tx.get(ref)).exists)throw new HttpsError('already-exists','You have already posted this word.');
  return ref;
}
async function publishedDuplicate(db:Firestore,tx:Transaction,term:string) {
  const key=normalizeTerm(term);
  const slug=key.normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'entry';
  const collection=db.collection('publishedContent'),prefix='cms-'+slug+'-';
  const results=await Promise.all([
    tx.get(collection.where('term','==',term)),tx.get(collection.where('variations','array-contains',term)),
    tx.get(collection.orderBy(FieldPath.documentId()).startAt(prefix).endAt(prefix+'\uf8ff')),
  ]);
  return results.some(snapshot=>snapshot.docs.some(doc=>{
    const data=doc.data();
    return data.status==='published'&&[data.term,...(Array.isArray(data.variations)?data.variations:[])].some(value=>typeof value==='string'&&normalizeTerm(value)===key);
  }));
}
async function readDailyApplication(db: Firestore, tx: Transaction, appId: string) {
  const ref = db.doc(`dailyCodeApplications/${appId}`);
  const snap = await tx.get(ref);
  if (!snap.exists) throw new HttpsError('not-found','Application not found.');
  return {ref, data:snap.data()!};
}
async function resolveDaily(db: Firestore, tx: Transaction, appId: string, status: 'rejected' | 'cancelled', actor: string, role: string, reason: string, keepSlot = false) {
  const {ref,data} = await readDailyApplication(db,tx,appId);
  if (role === 'owner' && data.uid !== actor) throw new HttpsError('permission-denied','This application belongs to a different account.');
  if (data.status === status) return {id:appId};
  if (!['pending','approved','scheduled'].includes(data.status) || (role === 'owner' && data.status !== 'pending')) {
    throw new HttpsError('failed-precondition','This application cannot be closed by this account.');
  }
  const slot = db.doc(`dailyCodeDates/${data.reservedDate}`);
  const freeUse = data.payment === 'free' && typeof data.freeUse === 'string' && /^\d{4}-\d{2}$/.test(data.freeUse) ? dailyAllowance(db,data.uid,data.freeUse) : null;
  const [reservation,w,account,allowance] = await Promise.all([tx.get(slot),wallet(db,tx,data.uid),tx.get(db.doc(`users/${data.uid}`)),freeUse?tx.get(freeUse):Promise.resolve(null)]);
  if (!keepSlot && reservation.get('applicationId') === appId) tx.delete(slot);
  const deleted = account.get('status') === 'deleted';
  // A free monthly use is given back (the user can apply again this month); paid applications get their Credits back.
  if (!deleted && freeUse) {if (allowance?.get('ref') === appId) tx.delete(freeUse);}
  else if (!deleted) payment(tx,w,`daily-refund-${appId}`,Number.isSafeInteger(data.fee)&&data.fee>0?data.fee:dailyFee,'Daily Code application refund');
  tx.update(ref,{status, payment:deleted?'closed':freeUse?'free-restored':'refunded',reason,updatedAt:stamp()});
  tx.delete(db.doc(`dailyCodeWordLocks/${data.wordLock??digest(data.uid+':'+data.wordId)}`));
  audit(db,tx,actor,role,`daily-code.${status}`,ref.path,reason);
  return {id:appId};
}

async function publishDaily(db: Firestore, tx: Transaction, date: string, now: number, actor: string, role: string) {
  if (date !== utcDay(now)) throw new HttpsError('failed-precondition','A Daily Code can be published only on its UTC publication date.');
  const slotRef = db.doc(`dailyCodeDates/${date}`);
  const live = db.doc(`dailyCodePublic/${date}`);
  const [slot,current] = await Promise.all([tx.get(slotRef),tx.get(live)]);
  if (current.exists) return {published:true};
  const data = slot.data();
  const publishFallback = () => {
    const entry = generateEntry(date);
    if (!entry) return {published:false};
    tx.create(live,{...entry,date,publishedAt:stamp()});
    tx.set(slotRef,{status:'published',publishedAt:stamp()});
    audit(db,tx,actor,role,'daily-code.publish-fallback',live.path);
    return {published:true};
  };
  if (!data || data.status !== 'scheduled') {
    if (data?.applicationId) await resolveDaily(db,tx,data.applicationId,'rejected',actor,role,'The word was not scheduled before its publication date.');
    return publishFallback();
  }
  const app = data.applicationId ? await readDailyApplication(db,tx,data.applicationId) : null;
  if (app) {
    const [account, suggestion] = await Promise.all([tx.get(db.doc(`users/${app.data.uid}`)),selectedDailyWord(db,tx,app.data.wordSource??'submission',app.data.wordId)]);
    if (account.get('status') === 'deleted' || !suggestion) {
      await resolveDaily(db,tx,data.applicationId,'rejected',actor,role,'The approved dictionary entry is no longer available.');
      return publishFallback();
    }
  }
  const chosen = data.wordSource ? await selectedDailyWord(db,tx,data.wordSource,data.wordId) : null;
  if (data.wordSource && !chosen && data.edited !== true) return publishFallback();
  if (!data.edited && data.wordSource === 'community' && chosen && (chosen.term !== data.term || chosen.meaning !== data.meaning || chosen.category !== data.category)) {
    return publishFallback();
  }
  // An administrator's edit of a scheduled entry wins over the original word text.
  const entry = data.edited === true ? data : app?.data ?? chosen ?? data;
  tx.create(live,{date,term:entry.term,meaning:entry.meaning,category:entry.category,publishedAt:stamp()});
  tx.set(slotRef,{...data,status:'published',publishedAt:stamp()});
  if (app) tx.update(app.ref,{status:'published',publicationDate:date,updatedAt:stamp()});
  audit(db,tx,actor,role,'daily-code.publish',live.path);
  return {published:true};
}

export async function communityAction(db: Firestore, input: Input, identity: AuthData | undefined, now = Date.now()): Promise<Record<string, unknown>> {
  const auth = authRequired(identity), uid = auth.uid;
  const action = input.action;
  if(action==='post-admin'&&input.command==='delete'){
    const ref=db.doc('communityPosts/'+id(input.id));
    await db.runTransaction(async tx=>{
      const role=await adminRole(db,tx,auth,moderation);
      const snapshot=await tx.get(ref);
      if(!snapshot.exists)return;
      if(snapshot.get('termLock'))tx.delete(db.doc('communityPostTerms/'+snapshot.get('termLock')));
      tx.update(ref,{status:'removed',hidden:true,updatedAt:stamp()});
      audit(db,tx,uid,role,'post.delete',ref.path);
    });
    await db.recursiveDelete(ref);
    return {id:ref.id,deleted:true};
  }
  return db.runTransaction(async tx => {
    if(action==='grant-tokens'){
      const role=await adminRole(db,tx,auth,['super_admin']),target=id(input.uid),amount=Number(input.amount);
      if(!Number.isSafeInteger(amount)||amount<1||amount>100000)throw new HttpsError('invalid-argument','Grant 1 to 100,000 Credits.');
      const receipt=db.doc(`users/${target}/tokenLedger/grant-${digest(uid+':'+id(input.requestId))}`);
      const [old,w]=await Promise.all([tx.get(receipt),wallet(db,tx,target)]);
      if(old.exists)return {id:receipt.id,duplicate:true,balance:w.balance};
      await active(db,tx,target);
      if(w.balance+amount>1000000)throw new HttpsError('failed-precondition','The balance cap would be exceeded.');
      const log=db.collection('auditLogs').doc(),note=text(input.note??'Admin grant',200,true);
      tx.create(log,{actor:uid,role,action:'tokens.send',target:`users/${target}`,summary:`Sent ${amount} tokens${note?' — '+note:''}`,at:stamp(),expireAt:Timestamp.fromMillis(now+365*dayMs)});
      tx.create(receipt,{type:'adjustment',amount,balanceAfter:w.balance+amount,ref:'admin-grant',note,createdAt:stamp(),lastAuditId:log.id,verifiedForFeatures:true});
      tx.set(w.ref,{...w.legacy,balance:w.balance+amount,earnedTotal:safeAmount(w.legacy.earnedTotal)+amount,updatedAt:stamp()});
      return {id:receipt.id,balance:w.balance+amount};
    }
    if(action==='convert-fee'){
      // One paid Encode/Decode conversion after the free daily allowance. Idempotent per requestId.
      await active(db,tx,uid);
      const kind=input.kind==='encode'||input.kind==='decode'?input.kind:null;
      if(!kind)throw new HttpsError('invalid-argument','Choose encode or decode.');
      const cost=fees((await tx.get(db.doc('config/app'))).data()??{})[kind];
      const op=`convert-${kind}-${digest(uid+':'+id(input.requestId)).slice(0,40)}`;
      const receipt=db.doc(`users/${uid}/tokenLedger/${op}`);
      const [prior,w]=await Promise.all([tx.get(receipt),wallet(db,tx,uid)]);
      if(prior.exists)return {id:op,duplicate:true,balance:w.balance};
      if(cost===0)return {id:op,free:true,balance:w.balance};
      payment(tx,w,op,-cost,kind==='encode'?'Encode Message':'Decode Message');
      return {id:op,balance:w.balance-cost};
    }
    if(action==='user-balance'){
      // Admin view of a user's verified Credits (the number the user can actually spend).
      await adminRole(db,tx,auth,['super_admin','support_admin','moderator','analyst']);
      const target=id(input.uid);
      const w=await wallet(db,tx,target);
      return {uid:target,balance:w.balance,cache:safeAmount(w.legacy.balance)};
    }
    if(action==='deduct-tokens'){
      // Super Admin correction. Never takes a balance below zero; idempotent per requestId; audit-logged.
      const role=await adminRole(db,tx,auth,['super_admin']),target=id(input.uid),amount=Number(input.amount);
      if(!Number.isSafeInteger(amount)||amount<1||amount>100000)throw new HttpsError('invalid-argument','Deduct 1 to 100,000 Credits.');
      const receipt=db.doc(`users/${target}/tokenLedger/deduct-${digest(uid+':'+id(input.requestId))}`);
      const [old,w]=await Promise.all([tx.get(receipt),wallet(db,tx,target)]);
      if(old.exists)return {id:receipt.id,duplicate:true,balance:w.balance};
      if(w.balance<amount)throw new HttpsError('failed-precondition',`This user has ${w.balance} Credits; you cannot deduct ${amount}.`);
      const log=db.collection('auditLogs').doc(),note=text(input.note??'Admin correction',200,true);
      tx.create(log,{actor:uid,role,action:'tokens.deduct',target:`users/${target}`,summary:`Deducted ${amount} Credits${note?' — '+note:''}`,at:stamp(),expireAt:Timestamp.fromMillis(now+365*dayMs)});
      tx.create(receipt,{type:'admin_debit',amount:-amount,balanceAfter:w.balance-amount,ref:'admin-deduct',note,createdAt:stamp(),lastAuditId:log.id});
      tx.set(w.ref,{...w.legacy,balance:w.balance-amount,spentTotal:safeAmount(w.legacy.spentTotal)+amount,updatedAt:stamp()});
      return {id:receipt.id,balance:w.balance-amount};
    }
    if(action==='create-code'){
      await active(db,tx,uid);
      const config=(await tx.get(db.doc('config/app'))).data()??{};
      const codeFee=fees(config).code;
      const mode=publishingMode(config,'code');
      if(mode==='paused')throw new HttpsError('failed-precondition','Creating codes is paused by the administrator.');
      const requestId=digest(uid+':code:'+id(input.requestId)).slice(0,40);
      const receipt=db.doc('submissions/'+requestId);
      const prior=await tx.get(receipt);
      if(prior.exists){
        const wordId=prior.get('communityWordId');
        const live=wordId?(await tx.get(db.doc('communityWords/'+wordId))).get('status')==='live':false;
        return {id:requestId,duplicate:true,live,termId:live?wordId:null};
      }
      const validation=validateEntry({...input,language:'English'});
      if(!validation.ok)throw new HttpsError('invalid-argument',validation.errors[0]!);
      const {term,meaning,example,category}=validation.entry;
      const screening=screenWord({term,meaning,example});
      if(!screening.ok||screening.review)throw new HttpsError('invalid-argument',screening.ok?'Please use respectful content.':screening.message);
      const wordRef=db.doc('communityWords/'+communityId(term));
      const existing=await tx.get(wordRef);
      const termLock=db.doc('dictionaryTermLocks/'+digest(normalizeTerm(term)));
      if(existing.exists||bundled.has(normalizeTerm(term))||(await tx.get(termLock)).exists||await publishedDuplicate(db,tx,term))throw new HttpsError('already-exists','This code already exists in the dictionary.');
      const allowance=codeAllowance(db,uid,now);
      const [w,usedToday]=await Promise.all([wallet(db,tx,uid),tx.get(allowance)]);
      const fee=usedToday.exists?codeFee:0;
      if(fee)payment(tx,w,'code-fee-'+requestId,-fee,'Create dictionary code');
      else tx.create(allowance,{kind:'code',ref:requestId,createdAt:stamp()});
      const body={uid,term,meaning,example,category,fee,payment:fee?'paid':'free',createdAt:stamp()};
      tx.create(receipt,{...body,status:mode==='open'?'accepted':'pending',...(mode==='open'?{reviewedBy:'auto-policy',reviewedAt:stamp(),communityWordId:wordRef.id}:{})});
      tx.create(termLock,{submissionId:requestId});
      if(mode==='open')tx.create(wordRef,{id:wordRef.id,uid,term,meaning,example,category,status:'live',createdAt:stamp(),updatedAt:stamp()});
      return {id:requestId,termId:mode==='open'?wordRef.id:null,live:mode==='open',balance:w.balance-fee,free:!fee};
    }
    if(action==='code-admin'){
      const role=await adminRole(db,tx,auth,moderation);
      const ref=db.doc('submissions/'+id(input.id)),snap=await tx.get(ref),data=snap.data();
      if(!data||data.status!=='pending')throw new HttpsError('failed-precondition','This code has already been reviewed.');
      if(input.command==='approve'){
        const wordRef=db.doc('communityWords/'+communityId(data.term));
        if((await tx.get(wordRef)).exists)throw new HttpsError('already-exists','That word already exists.');
        tx.create(wordRef,{id:wordRef.id,uid:data.uid,term:data.term,meaning:data.meaning,category:data.category,example:data.example??'',status:'live',createdAt:stamp(),updatedAt:stamp()});
        tx.update(ref,{status:'accepted',reviewedBy:uid,reviewedAt:stamp(),communityWordId:wordRef.id});
      }else if(input.command==='reject'){
        tx.update(ref,{status:'rejected',reviewedBy:uid,reviewedAt:stamp()});
      }else throw new HttpsError('invalid-argument','Choose approve or reject.');
      audit(db,tx,uid,role,'code.'+input.command,ref.path);
      return {id:ref.id};
    }
    if(action==='chat-pass'||action==='chat-pass-status'){
      await active(db,tx,uid);
      const chatConfig=(await tx.get(db.doc('config/app'))).data()??{};
      if(chatConfig.chatEnabled===false)throw new HttpsError('failed-precondition','Community chat is paused.');
      const chatFee=fees(chatConfig).chat;
      const day=utcDay(now),ref=db.doc('chatPasses/'+uid+'/days/'+day);
      const pass=await tx.get(ref);
      if(pass.exists)return {id:day,active:true,duplicate:true};
      if(action==='chat-pass-status')return {id:day,active:false};
      const w=await wallet(db,tx,uid);
      payment(tx,w,'chat-pass-'+day,-chatFee,'Daily chat pass');
      const passData={uid,date:day,fee:chatFee,createdAt:stamp(),expiresAt:Timestamp.fromMillis(Date.parse(day+'T00:00:00Z')+dayMs)};
      tx.create(ref,passData);
      tx.set(db.doc('chatPasses/'+uid),passData);
      return {id:day,active:true,balance:w.balance-chatFee};
    }
    if (action === 'balance') {
      await active(db,tx,uid);
      const [w,code,daily]=await Promise.all([wallet(db,tx,uid),tx.get(codeAllowance(db,uid,now)),tx.get(dailyAllowance(db,uid,utcDay(now).slice(0,7)))]);
      return {balance:w.balance,freeCode:!code.exists,freeDaily:!daily.exists};
    }
    if (action === 'apply-daily' || action === 'apply-verification' || action === 'create-post') {
      await active(db,tx,uid);
      const config=(await tx.get(db.doc('config/app'))).data()??{};
      const f=fees(config);
      const postMode=publishingMode(config,'post');
      if (action === 'create-post' && postMode === 'paused') {
        throw new HttpsError('failed-precondition','Community submissions are paused.');
      }
      const requestId = digest(uid+':'+id(input.requestId)).slice(0,40);
      const collection = action === 'apply-daily' ? 'dailyCodeApplications' : action === 'apply-verification' ? 'verificationApplications' : 'communityPosts';
      const ref = db.doc(`${collection}/${requestId}`);
      const previous=await tx.get(ref);
      if(previous.exists)return {id:requestId,duplicate:true,status:previous.get('status')};
      const [w,name] = await Promise.all([wallet(db,tx,uid),nickname(db,tx,uid)]);
      const base = {uid,name,createdAt:stamp(),updatedAt:stamp(),status:'pending',payment:'paid'};
      let dailyCharged=f.daily;
      if (action === 'apply-daily') {
        const wordId = id(input.wordId);
        const requestedDate = futureDate(input.date,now);
        const slot = db.doc(`dailyCodeDates/${requestedDate}`);
        const source=input.wordSource??'submission';
        if(source==='submission'&&(await tx.get(db.doc('submissions/'+wordId))).get('uid')!==uid)throw new HttpsError('permission-denied','Choose a public dictionary code or one of your accepted submissions.');
        const wordLock=digest(uid+':'+source+':'+wordId);
        const lock = db.doc(`dailyCodeWordLocks/${wordLock}`);
        const [word,reserved,existing] = await Promise.all([selectedDailyWord(db,tx,source,wordId),tx.get(slot),tx.get(lock)]);
        if (!word) throw new HttpsError('failed-precondition','Choose an available word from Codes.');
        if (existing.exists) throw new HttpsError('already-exists','This word already has a Daily Code application.');
        if (reserved.exists) {
          const end = utcDay(now+bookingDays*dayMs);
          const following = await tx.get(db.collection('dailyCodeDates').orderBy(FieldPath.documentId()).startAfter(requestedDate).endAt(end));
          const dates = new Set(following.docs.map(d=>d.id));
          let next = Date.parse(requestedDate+'T00:00:00Z')+dayMs;
          while (dates.has(utcDay(next))) next += dayMs;
          throw new HttpsError('already-exists','That date is reserved. Choose an available date.',{next:utcDay(next)<=end?utcDay(next):null});
        }
        const month=utcDay(now).slice(0,7), allowance=dailyAllowance(db,uid,month);
        const fee=(await tx.get(allowance)).exists?f.daily:0;
        if(fee)payment(tx,w,`daily-fee-${requestId}`,-fee,'Daily Code Display');
        else tx.create(allowance,{kind:'daily',ref:requestId,createdAt:stamp()});
        dailyCharged=fee;
        tx.create(ref,{...base,payment:fee?'paid':'free',...(fee?{}:{freeUse:month}),wordId,requestedDate,reservedDate:requestedDate,publicationDate:null,fee,
          ...word,wordSource:source,wordLock});
        tx.create(slot,{status:'pending',applicationId:requestId});
        tx.create(lock,{applicationId:requestId});
      } else if (action === 'apply-verification') {
        const current = db.doc(`verificationState/${uid}`);
        const previous = await tx.get(current);
        if (['pending','approved'].includes(previous.get('status'))) throw new HttpsError('already-exists','You already have an application or a verified badge.');
        payment(tx,w,`verification-fee-${requestId}`,-f.verification,'Verified Contributor manual review');
        tx.create(ref,{...base,fee:f.verification});
        tx.set(current,{status:'pending',applicationId:requestId});
      } else {
        const fields = postFields(input);
        const lock = await claimPost(db,tx,uid,fields.term);
        payment(tx,w,`post-fee-${requestId}`,-f.post,'Community post submission');
        tx.create(ref,{...base,...fields,fee:f.post,schema:2,status:postMode==='open'?'approved':'pending',hidden:postMode!=='open',...(postMode==='open'?{publishedAt:stamp()}:{}),likeCount:0,commentCount:0,engagementScore:0,termLock:lock.id});
        tx.create(lock,{postId:requestId});
      }
      return {id:requestId,...(action==='apply-daily'?{free:!dailyCharged}:{}),balance:w.balance-(action==='create-post'?f.post:action==='apply-daily'?dailyCharged:f.verification),...(action==='create-post'?{status:postMode==='open'?'approved':'pending'}:{})};
    }
    if (action === 'cancel-daily') {
      await active(db,tx,uid);
      return resolveDaily(db,tx,id(input.id),'cancelled',uid,'owner','Cancelled before approval.');
    }
    if (action === 'daily-admin') {
      const role = await adminRole(db,tx,auth,editorial);
      if(input.command==='cancel-schedule'){
        const date=futureDate(input.date,now),ref=db.doc('dailyCodeDates/'+date),publication=db.doc('dailyCodePublic/'+date);
        const [slot,pub]=await Promise.all([tx.get(ref),tx.get(publication)]);
        if(!slot.exists)throw new HttpsError('not-found','Schedule not found.');
        if(slot.get('applicationId'))return resolveDaily(db,tx,slot.get('applicationId'),'rejected',uid,role,'The administrator cancelled the publication.');
        tx.delete(ref);if(pub.exists&&pub.get('schema')===3)tx.delete(publication);
        audit(db,tx,uid,role,'daily-code.cancel-schedule',ref.path);return {id:date};
      }
      if (input.command === 'generate' || input.command === 'schedule-word') {
        const date = futureDate(input.date,now), slot = db.doc(`dailyCodeDates/${date}`);
        const [reserved,published] = await Promise.all([tx.get(slot),tx.get(db.doc(`dailyCodePublic/${date}`))]);
        if (reserved.exists || published.exists) throw new HttpsError('already-exists','That date already has a Daily Code reservation or publication.');
        const manual = input.command === 'schedule-word';
        const entry = manual ? await selectedDailyWord(db,tx,input.wordSource,input.wordId) : generateEntry(date);
        if (!entry) throw new HttpsError('failed-precondition',manual?'That word is no longer eligible. Choose another approved entry.':'No dictionary entries are available.');
        const selection = manual ? {wordSource:input.wordSource,wordId:input.wordId} : {};
        tx.create(slot,{status:'scheduled',...entry,...selection,createdAt:stamp()});
        audit(db,tx,uid,role,'daily-code.'+input.command,slot.path,entry.term);
        return {id:date};
      }
      if (input.command === 'publish') return publishDaily(db,tx,String(input.date),now,uid,role);
      if (input.command === 'edit-schedule') {
        // Edit the word shown on a scheduled (not yet published) date.
        const date = futureDate(input.date,now), ref = db.doc(`dailyCodeDates/${date}`), snap = await tx.get(ref);
        if (!snap.exists || !['scheduled','pending'].includes(snap.get('status'))) throw new HttpsError('failed-precondition','Only an upcoming scheduled Daily Code can be edited.');
        const appId = snap.get('applicationId') as string | undefined;
        const current = appId ? (await readDailyApplication(db,tx,appId)).data : snap.data()!;
        const term = input.term === undefined ? String(current.term ?? '') : screened(text(input.term,40));
        const meaning = screened(text(input.meaning,500));
        const category = input.category === undefined ? String(current.category ?? '') : text(input.category,40);
        if (!term || !meaning || !category) throw new HttpsError('invalid-argument','Code, meaning and category are required.');
        tx.set(ref,{term,meaning,category,edited:true,editedBy:uid,editedAt:stamp()},{merge:true});
        if (appId) tx.update(db.doc(`dailyCodeApplications/${appId}`),{meaning,updatedAt:stamp()});
        audit(db,tx,uid,role,'daily-code.edit-schedule',ref.path,term);
        return {id:date};
      }
      if (input.command === 'replace-schedule') {
        // Swap the word on a reserved date in one step. A user's application on that date is refunded in full.
        const date = futureDate(input.date,now), ref = db.doc(`dailyCodeDates/${date}`), snap = await tx.get(ref);
        if (!snap.exists || !['scheduled','pending'].includes(snap.get('status'))) throw new HttpsError('failed-precondition','Choose an upcoming reserved date to replace.');
        const entry = await selectedDailyWord(db,tx,input.wordSource,input.wordId);
        if (!entry) throw new HttpsError('failed-precondition','That word is no longer eligible. Choose another approved entry.');
        const appId = snap.get('applicationId') as string | undefined;
        if (appId) await resolveDaily(db,tx,appId,'rejected',uid,role,'Replaced by the review team. Your Credits were refunded.',true);
        tx.set(ref,{status:'scheduled',...entry,wordSource:input.wordSource,wordId:input.wordId,createdAt:stamp(),replacedBy:uid});
        audit(db,tx,uid,role,'daily-code.replace-schedule',ref.path,entry.term);
        return {id:date};
      }
      const appId = id(input.id);
      if (input.command === 'reject') return resolveDaily(db,tx,appId,'rejected',uid,role,text(input.reason ?? 'Declined by the review team.',200));
      const {ref,data} = await readDailyApplication(db,tx,appId);
      if (!['pending','approved','scheduled'].includes(data.status)) throw new HttpsError('failed-precondition','This application is closed.');
      if (input.command === 'edit') {
        tx.update(ref,{meaning:screened(text(input.meaning,500)),updatedAt:stamp()});
      } else if (input.command === 'approve' && data.status === 'pending' && input.date !== undefined) {
        // One-step "Approve & schedule": approve the request and confirm its publication date.
        const date = futureDate(input.date,now);
        const next = db.doc(`dailyCodeDates/${date}`), previous = db.doc(`dailyCodeDates/${data.reservedDate}`);
        const [nextSnap,oldSnap] = await Promise.all([tx.get(next),tx.get(previous)]);
        if (nextSnap.exists && nextSnap.get('applicationId') !== appId) throw new HttpsError('already-exists','That date is already reserved. Choose another date.');
        if (next.path !== previous.path && oldSnap.get('applicationId') === appId) tx.delete(previous);
        tx.set(next,{status:'scheduled',applicationId:appId});
        tx.update(ref,{status:'scheduled',reservedDate:date,publicationDate:date,approvedBy:uid,updatedAt:stamp()});
      } else if (input.command === 'approve' && data.status === 'pending') {
        tx.update(ref,{status:'approved',updatedAt:stamp()});
      } else if (input.command === 'schedule' && ['approved','scheduled'].includes(data.status)) {
        const date = futureDate(input.date,now);
        const next = db.doc(`dailyCodeDates/${date}`), previous = db.doc(`dailyCodeDates/${data.reservedDate}`);
        const [nextSnap,oldSnap] = await Promise.all([tx.get(next),tx.get(previous)]);
        if (nextSnap.exists && nextSnap.get('applicationId') !== appId) throw new HttpsError('already-exists','That date is already reserved.');
        if (next.path !== previous.path && oldSnap.get('applicationId') === appId) tx.delete(previous);
        tx.set(next,{status:'scheduled',applicationId:appId});
        tx.update(ref,{status:'scheduled',reservedDate:date,publicationDate:date,updatedAt:stamp()});
      } else throw new HttpsError('failed-precondition','That action is not available in this status.');
      audit(db,tx,uid,role,'daily-code.'+input.command,ref.path);
      return {id:appId};
    }
    if (action === 'verification-admin') {
      const role = await adminRole(db,tx,auth,['super_admin']);
      const appId = id(input.id), ref = db.doc(`verificationApplications/${appId}`);
      const data = (await tx.get(ref)).data();
      if (!data) throw new HttpsError('not-found','Application not found.');
      const current = db.doc(`verificationState/${data.uid}`);
      if ((await tx.get(current)).get('applicationId') !== appId) throw new HttpsError('failed-precondition','This is a historical application.');
      const status = input.command;
      if ((status !== 'approved' && status !== 'rejected' || data.status !== 'pending') && (status !== 'revoked' || data.status !== 'approved')) {
        throw new HttpsError('failed-precondition','That decision is not available.');
      }
      if (status === 'approved') {
        await active(db,tx,data.uid);
        tx.set(db.doc(`verifiedContributors/${data.uid}`),{verified:true});
      } else tx.delete(db.doc(`verifiedContributors/${data.uid}`));
      tx.update(ref,{status,updatedAt:stamp()});
      tx.update(current,{status});
      audit(db,tx,uid,role,`verification.${status}`,ref.path);
      return {id:appId};
    }
    if (action === 'resolve-post-report') {
      const role = await adminRole(db,tx,auth,moderation);
      const ref = db.doc(`postReports/${id(input.id)}`);
      const report = (await tx.get(ref)).data();
      if (!report || report.status !== 'open') throw new HttpsError('failed-precondition','This report has already been handled.');
      if (!['dismiss','remove'].includes(String(input.command))) throw new HttpsError('invalid-argument','Choose a report decision.');
      if (input.command === 'remove') {
        const post = db.doc(`communityPosts/${id(report.postId)}`);
        const data = (await tx.get(post)).data();
        if (data?.status === 'approved') {
          if (data.termLock) tx.delete(db.doc(`communityPostTerms/${data.termLock}`));
          tx.update(post,{hidden:true,status:'removed',moderatedBy:uid,updatedAt:stamp()});
          audit(db,tx,uid,role,'post.remove',post.path,'Removed after report');
        }
      }
      const status = input.command === 'remove' ? 'resolved' : 'dismissed';
      tx.update(ref,{status,resolvedBy:uid,resolvedAt:stamp(),resolution:input.command});
      audit(db,tx,uid,role,`report.${input.command === 'remove' ? 'resolve' : 'dismiss'}`,ref.path);
      return {id:ref.id};
    }
    if (action === 'post-admin' || action === 'delete-post' || action === 'like-post' || action === 'comment-post' || action === 'save-post') {
      const postId = id(input.id);
      const role = action === 'post-admin' ? await adminRole(db,tx,auth,moderation) : null;
      if (!role) await active(db,tx,uid);
      const ref = db.doc(`communityPosts/${postId}`);
      const data = (await tx.get(ref)).data();
      if (!data) throw new HttpsError('not-found','Post no longer exists.');
      const status = data.status ?? (data.hidden ? 'removed' : 'pending');
      if (action === 'post-admin' || action === 'delete-post') {
        if (!role && data.uid !== uid) throw new HttpsError('permission-denied','Only the author may remove this post.');
        const command = role ? input.command : 'remove';
        if (command === 'edit' && ['pending','approved'].includes(status) && data.schema===2) {
          const fields = postFields({...input,term:data.term});
          tx.update(ref,{...fields,updatedAt:stamp()});
        } else {
          const next = command === 'approve' && status === 'pending' ? 'approved'
            : command === 'hide' && status === 'approved' ? 'hidden'
            : command === 'restore' && status === 'hidden' ? 'approved'
            : command === 'reject' && status === 'pending' ? 'rejected'
            : command === 'remove' && ['pending','approved'].includes(status) ? 'removed' : null;
          if (!next) throw new HttpsError('failed-precondition','That action is not available in this status.');
          if (data.termLock && ['rejected','removed'].includes(next)) tx.delete(db.doc(`communityPostTerms/${data.termLock}`));
          tx.update(ref,{status:next,hidden:next!=='approved',updatedAt:stamp(),moderatedBy:uid,...(next==='approved'?{publishedAt:stamp(),engagementScore:safeAmount(data.likeCount)+safeAmount(data.commentCount)}:{})});
        }
        audit(db,tx,uid,role ?? 'owner',`post.${command}`,ref.path);
        return {id:postId};
      }
      const saved = db.doc(`users/${uid}/savedCommunityPosts/${postId}`);
      if (action === 'save-post' && input.enabled === false) {tx.delete(saved);return {saved:false};}
      if (data.hidden || status !== 'approved') throw new HttpsError('not-found','This post is not public.');
      if (action === 'save-post') {tx.set(saved,{postId,createdAt:stamp()});return {saved:true};}
      if (action === 'like-post') {
        if (typeof input.enabled !== 'boolean') throw new HttpsError('invalid-argument','Invalid like state.');
        const like = db.doc(`communityPostLikes/${postId}_${uid}`), existing = (await tx.get(like)).exists;
        if (input.enabled !== existing) {
          if (input.enabled) tx.create(like,{postId,uid,createdAt:stamp()}); else tx.delete(like);
          const likeCount = Math.max(0,safeAmount(data.likeCount)+(input.enabled?1:-1));
          tx.update(ref,{likeCount,engagementScore:likeCount+safeAmount(data.commentCount)});
        }
        return {liked:input.enabled};
      }
      if ((await tx.get(db.doc('config/app'))).get('ugcEnabled') === false) throw new HttpsError('failed-precondition','Community submissions are paused.');
      const comment = screened(text(input.text,200));
      const commentRef = ref.collection('comments').doc(digest(uid+':'+normalizeTerm(comment)));
      const [existing,name] = await Promise.all([tx.get(commentRef),nickname(db,tx,uid)]);
      if (existing.exists) return {id:commentRef.id,duplicate:true};
      tx.create(commentRef,publicComment({uid,name,text:comment,createdAt:stamp()}));
      const commentCount = safeAmount(data.commentCount)+1;
      tx.update(ref,{commentCount,engagementScore:commentCount+safeAmount(data.likeCount)});
      return {id:commentRef.id};
    }
    throw new HttpsError('invalid-argument','Unknown action.');
  });
}

/** Overlap/retry safe. Unfulfilled reservations are refunded once through the same transaction. */
export async function runDailySchedule(db: Firestore, now = Date.now()) {
  const day = utcDay(now);
  await db.runTransaction(tx=>publishDaily(db,tx,day,now,'scheduler','system'));
  const expired = await db.collection('dailyCodeDates').where('status','in',['pending','scheduled']).where(FieldPath.documentId(),'<',day).limit(50).get();
  for (const doc of expired.docs) {
    await db.runTransaction(async tx=>{
      const current = await tx.get(doc.ref);
      if (!current.exists || current.get('status')==='published') return;
      const applicationId=current.get('applicationId');
      if (applicationId) await resolveDaily(db,tx,applicationId,'rejected','scheduler','system','The reserved date passed before publication.');
      else tx.delete(doc.ref);
    });
  }
}


/** Remove the public badge and new contributions when the existing account tombstone is written. */
export async function purgeContributions(db: Firestore, uid: string) {
  await db.doc(`verifiedContributors/${uid}`).delete();
  await db.doc(`publicProfiles/${uid}`).delete();
  await db.doc(`verificationState/${uid}`).delete();
  const daily = await db.collection('dailyCodeApplications').where('uid','==',uid).get();
  for (const row of daily.docs) {
    await db.runTransaction(async tx=>{
      const snap=await tx.get(row.ref);
      if (!snap.exists) return;
      const data=snap.data()!;
      if (['pending','approved','scheduled'].includes(data.status)) {
        const slot=db.doc(`dailyCodeDates/${data.reservedDate}`);
        if ((await tx.get(slot)).get('applicationId')===row.id) tx.delete(slot);
      }
      tx.delete(db.doc(`dailyCodeWordLocks/${data.wordLock??digest(uid+':'+data.wordId)}`));
      tx.delete(row.ref);
    });
  }
  const [posts,applications] = await Promise.all([
    db.collection('communityPosts').where('uid','==',uid).get(),
    db.collection('verificationApplications').where('uid','==',uid).get(),
  ]);
  for (const post of posts.docs) {
    const termLock=post.get('termLock');
    await db.runTransaction(async tx=>{
      if (termLock) {
        const ref=db.doc(`communityPostTerms/${termLock}`);
        if ((await tx.get(ref)).get('postId')===post.id) tx.delete(ref);
      }
      tx.set(post.ref,{hidden:true,status:'removed',createdAt:post.get('createdAt')??stamp(),updatedAt:stamp()});
    });
    await db.recursiveDelete(post.ref.collection('comments'));
  }
  for (const app of applications.docs) await app.ref.delete();
  await db.recursiveDelete(db.collection(`users/${uid}/savedCommunityPosts`));
}
