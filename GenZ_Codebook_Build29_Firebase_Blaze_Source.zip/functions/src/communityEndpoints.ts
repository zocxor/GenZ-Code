import {getAuth} from 'firebase-admin/auth';
import {getFirestore} from 'firebase-admin/firestore';
import {HttpsError,onCall} from 'firebase-functions/v2/https';
import {error} from 'firebase-functions/logger';
import {onDocumentUpdated} from 'firebase-functions/v2/firestore';
import {onSchedule} from 'firebase-functions/v2/scheduler';
import {rewardIntent,dailyReward} from './accountRewards';
import {communityAction, runDailySchedule, purgeContributions} from './communityFeatures';

export const communityFeature = onCall({region:'us-central1',cors:true,invoker:'public', minInstances:0,maxInstances:3, timeoutSeconds:60}, async request => {
  try {
    const input=request.data??{},db=getFirestore();
    if(!request.auth)throw new HttpsError('unauthenticated','Sign in to continue.');
    if(request.auth.token.email_verified!==true)throw new HttpsError('permission-denied','Verify your email to use account tokens.');
    if(['create-code','create-post','chat-pass'].includes(input.action))throw new HttpsError('failed-precondition','Code creation, posting and chat are free in the latest app. Please update.');
    if(input.action==='reward-intent')return rewardIntent(db,request.auth.uid);
    if(input.action==='daily-reward')return dailyReward(db,request.auth.uid);
    return await communityAction(db,input,request.auth);
  } catch (cause) {
    if (cause instanceof HttpsError) throw cause;
    error('communityFeature failed',cause);
    throw new HttpsError('internal','The server could not complete this request. Retry or check the communityFeature logs in Firebase.');
  }
});
export const publishDailyCodes = onSchedule({schedule:'every 5 minutes',timeZone:'UTC',region:'us-central1',maxInstances:1,retryCount:3}, async ()=>{
  await runDailySchedule(getFirestore());
});

export const cleanupContributions = onDocumentUpdated({document:'users/{uid}',region:'us-central1',retry:true}, async event=>{
  if(event.data?.after.get('status')==='deleted' && event.data.before.get('status')!=='deleted'){
    await purgeContributions(getFirestore(),event.params.uid);
    try{await getAuth().deleteUser(event.params.uid);}catch(cause){if((cause as {code?:string}).code!=='auth/user-not-found')throw cause;}
  }
});
