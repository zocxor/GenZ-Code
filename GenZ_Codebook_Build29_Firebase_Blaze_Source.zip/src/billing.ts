import {SPARK_MODE} from '../shared/deployment';
import {BACKEND_URL,TOKEN_CHECKOUT_ENABLED} from './backend';
/**
 * Google Play Billing for GenZ Codebook token packages.
 *
 * Uses the official Google Play Billing Library through react-native-iap
 * 15.6.2 (Billing Library 9.1.0 via the OpenIAP google library, from the
 * library's own defaults). Android only: on iOS and web, billing reports
 * unavailable and the shop says so.
 *
 * Two product families share this connection:
 *  - Consumable token packages (this file): verify -> ledger -> credit ->
 *    consume. See the pipeline below.
 *  - Premium subscriptions (src/subscription.ts): verify -> acknowledge,
 *    never consume. Subscription purchases are routed there from
 *    creditPurchase by product ID. Subscription products load alongside the
 *    token packages in loadBilling.
 *
 * The purchase pipeline (never skip a step):
 *  1. Play returns a purchase -> pure local checks (shared/billing.ts):
 *     known product, PURCHASED state, order ID + purchase token. (No
 *     receipt check: react-native-iap 15.x returns an empty
 *     transactionReceipt on Android, so requiring one would reject every
 *     real purchase. The token is the credential the backend verifies.)
 *  2. Server check: if BILLING_VERIFY_URL is set, the purchase is
 *     POSTed to that backend (functions/verifyPurchase) and only credited
 *     on {verified: true}. The backend calls the Play Developer API
 *     (purchases.products.get) with the purchase token and credits exactly
 *     once in an atomic transaction keyed by the purchaseToken. If the URL
 *     is empty, a DEBUG build falls back to local-only verification (step
 *     3); a PRODUCTION build (__DEV__ false: release / beta / internal)
 *     REFUSES to credit and reports that server verification is not
 *     configured. Local verification alone is NOT presented as server
 *     verification anywhere in the app.
 *  3. Ledger write (src/tokenLedger.ts): the credit is recorded under the
 *     Google Play order ID, create-only, for exactly the catalog amount.
 *     A second credit for the same order is refused by the rules.
 *  4. Local balance credit (the caller's onCredit — App dispatches
 *     earnTokens). Only after the ledger write succeeds.
 *  5. Consume (finishTransaction, isConsumable: true) so the same package
 *     can be bought again. If any step before this fails, the purchase is
 *     deliberately NOT consumed: Play keeps it owned, and the next reconcile
 *     (app start, wallet open, Restore button) retries it.
 *
 * Pending purchases are never credited. Cancelled purchases are reported
 * calmly, not as errors. No fake payment screens, no simulated success:
 * tokens only move on a real Play purchase.
 *
 * Android Gradle note: react-native-iap 15.x (Billing Library 9.1.0 via
 * OpenIAP) is a Nitro Modules rewrite with no amazon/play store flavor
 * dimension, so android/app/build.gradle sets no missingDimensionStrategy.
 */
import {Platform} from 'react-native';
import {
  initConnection,
  endConnection,
  fetchProducts,
  requestPurchase,
  finishTransaction,
  getAvailablePurchases,
  purchaseUpdatedListener,
  purchaseErrorListener,
  type Product,
  type Purchase,
  type PurchaseError,
  ErrorCode,
} from 'react-native-iap';
import {verifyPurchaseRecord} from '../shared/billing';
import {TOKEN_PRODUCTS} from '../shared/tokens';
import {isSubscriptionProduct} from '../shared/subscriptions';
import {recordPurchaseTxn, currentUid} from './tokenLedger';
import {handleSubscriptionPurchase, loadSubscriptionProducts} from './subscription';
import {accountAuth} from './firebase/app';

/**
 * Server verification endpoint (layer 2). Empty = not configured: the app
 * verifies locally (layer 1) + the idempotent ledger, and says so honestly.
 * To enable, deploy an endpoint that accepts
 *   POST {productId, orderId, purchaseToken}
 * and returns {verified: true} only after calling the Play Developer API
 * purchases.products.get and confirming purchaseState == 0 (purchased) and
 * the product matches. It needs a Google service account with Play Developer
 * API access (Play Console > Setup > API access).
 */
export const BILLING_VERIFY_URL = BACKEND_URL?BACKEND_URL+'/verifyPurchase':'';

export const isTokenPurchaseEnabled = () => TOKEN_CHECKOUT_ENABLED;
const CHECKOUT_PAUSED = 'Token checkout is temporarily unavailable.';

export type BillingProduct = {
  productId: string;
  tokens: number;
  localizedPrice: string;
  price: string;
  currency: string;
  title: string;
  description: string;
};

export type BillingEvent =
  | {kind: 'products'}
  | {kind: 'credited'; productId: string; tokens: number; balanceAfter: number}
  | {kind: 'already-credited'; productId: string; tokens: number}
  | {kind: 'pending'; productId: string}
  | {kind: 'failed'; message: string}
  | {kind: 'cancelled'}
  | {kind: 'restored'; count: number}
  | {kind: 'signin-required'}
  | {kind: 'unavailable'; message: string};

export type BillingInit = {available: boolean; products: BillingProduct[]; missing: string[]; error?: string};

type Handlers = {onCredit: (amount: number, orderId: string) => void | Promise<void>};

const listeners = new Set<(e: BillingEvent) => void>();
function emit(e: BillingEvent): void {
  listeners.forEach(cb => {
    try {cb(e);} catch {/* a listener must never break billing */}
  });
}
export function onBillingEvent(cb: (e: BillingEvent) => void): () => void {
  listeners.add(cb);
  return () => {listeners.delete(cb);};
}

const PRODUCT_IDS = TOKEN_PRODUCTS.map(p => p.id);

let available = false;
let loaded = false;
let cachedProducts: BillingProduct[] = [];
let cachedMissing: string[] = [...PRODUCT_IDS];
let cachedError: string | undefined;
let updateSub: {remove: () => void} | null = null;
let errorSub: {remove: () => void} | null = null;
let handlers: Handlers | null = null;

function toBillingProduct(p: Product): BillingProduct | null {
  const catalog = TOKEN_PRODUCTS.find(c => c.id === p.id);
  if (!catalog || !p.displayPrice?.trim()) return null;
  return {
    productId: p.id,
    tokens: catalog.tokens,
    localizedPrice: p.displayPrice,
    price: p.price != null ? String(p.price) : '',
    currency: p.currency,
    title: p.title,
    description: p.description,
  };
}

/**
 * Server verification result (functions/src/index.ts). `null` means no
 * backend is configured (BILLING_VERIFY_URL empty) — the caller falls back
 * to the local-only ledger write. A verified result means the backend
 * already wrote the ledger + wallet atomically; the client must not write
 * the ledger itself in that case.
 */
type ServerVerify =
  | {verified: true; duplicate: boolean; tokens: number; balanceAfter: number}
  | {verified: false; reason: string; retryable: boolean};

async function verifyWithServer(p: {productId: string; orderId: string; purchaseToken: string}): Promise<ServerVerify | null> {
  if (!BILLING_VERIFY_URL) return null;
  try {
    const idToken = await accountAuth.currentUser?.getIdToken().catch(() => null);
    if (!idToken) return {verified: false, reason: 'Sign in first — purchases are recorded on your account.', retryable: false};
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch(BILLING_VERIFY_URL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json', Authorization: `Bearer ${idToken}`},
      body: JSON.stringify(p),
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    const body = (await res.json().catch(() => null)) as ServerVerify | null;
    if (!body || typeof body.verified !== 'boolean') {
      return {verified: false, reason: 'Google Play could not verify this purchase. No tokens were credited.', retryable: true};
    }
    return body;
  } catch {
    return {verified: false, reason: 'Google Play could not verify this purchase. No tokens were credited.', retryable: true};
  }
}

/** Run one owned purchase through the pipeline. Returns what happened. */
async function creditPurchase(purchase: Purchase): Promise<'credited' | 'duplicate' | 'pending' | 'failed'> {
  // This app is Android-only for billing; the Android-only fields
  // (purchaseState, packageNameAndroid) exist only on PurchaseAndroid.
  // The `in` check also narrows the union type for TypeScript.
  if (purchase.platform !== 'android' || !('packageNameAndroid' in purchase)) return 'failed';
  // Subscriptions take a different pipeline (verify -> acknowledge, never
  // consume). Route them to the subscription module; it emits its own events.
  if (isSubscriptionProduct(purchase.productId)) {
    const r = await handleSubscriptionPurchase(purchase);
    return r === 'subscribed' ? 'credited' : r;
  }
  const state = purchase.purchaseState;
  if (state === 'pending') {
    emit({kind: 'pending', productId: purchase.productId});
    return 'pending';
  }
  const checked = verifyPurchaseRecord({
    productId: purchase.productId,
    orderId: purchase.id,
    purchaseToken: purchase.purchaseToken,
    purchaseState: state,
    packageName: purchase.packageNameAndroid,
  });
  if (!checked.ok) {
    emit({kind: 'failed', message: checked.reason});
    return 'failed';
  }
  const uid = currentUid();
  if (!uid) {
    emit({kind: 'signin-required'});
    return 'failed';
  }
  // Server verification (when BILLING_VERIFY_URL is set): the backend
  // verifies with Play AND atomically writes the ledger + wallet, so the
  // client must not write the ledger itself. A `duplicate` reply means the
  // backend already credited this purchaseToken — consume it, but do not
  // credit the local balance again (the wallet sync repairs any drift).
  const server = await verifyWithServer({productId: checked.productId, orderId: checked.orderId, purchaseToken: checked.purchaseToken});
  if (server) {
    if (!server.verified) {
      emit({kind: 'failed', message: server.reason});
      return 'failed';
    }
    if (server.duplicate) {
      try {await finishTransaction({purchase, isConsumable: true});} catch {/* reconcile retries */}
      emit({kind: 'already-credited', productId: checked.productId, tokens: server.tokens});
      return 'duplicate';
    }
    try {
      await handlers?.onCredit(server.tokens, checked.orderId);
    } catch {/* the backend ledger is the record; the wallet sync repairs the local balance */}
    try {
      await finishTransaction({purchase, isConsumable: true});
    } catch {
      // Credited + recorded, but not consumed: Play still shows it owned,
      // so the next reconcile sees the duplicate and consumes it then.
    }
    emit({kind: 'credited', productId: checked.productId, tokens: server.tokens, balanceAfter: server.balanceAfter});
    return 'credited';
  }
  // Local-only fallback (no backend configured): the client writes the
  // ledger itself. This is the pre-server behaviour, kept ONLY for debug
  // builds. A production build (release / beta / internal, where __DEV__
  // is false) must NEVER credit a purchase without server verification —
  // the purchase stays owned by Google Play and is retried once the
  // backend is deployed and BILLING_VERIFY_URL is set.
  if (!__DEV__) {
    emit({kind: 'failed', message: 'Server verification is not configured for this build. Purchases cannot be credited — deploy the verification backend and set BILLING_VERIFY_URL first.'});
    return 'failed';
  }
  let recorded: {status: 'recorded' | 'duplicate'; balanceAfter: number};
  try {
    recorded = await recordPurchaseTxn(uid, {
      orderId: checked.orderId,
      productId: checked.productId,
      purchaseToken: checked.purchaseToken,
      tokens: checked.tokens,
    });
  } catch {
    emit({kind: 'failed', message: 'Could not record this purchase. It stays with Google Play and will be retried automatically.'});
    return 'failed';
  }
  if (recorded.status === 'duplicate') {
    // Already paid for: consume so Play stops offering it, but do not credit
    // the local balance again. The wallet sync repairs any drift.
    try {await finishTransaction({purchase, isConsumable: true});} catch {/* reconcile retries */}
    emit({kind: 'already-credited', productId: checked.productId, tokens: checked.tokens});
    return 'duplicate';
  }
  try {
    await handlers?.onCredit(checked.tokens, checked.orderId);
  } catch {/* the ledger is the record; the wallet sync repairs the local balance */}
  try {
    await finishTransaction({purchase, isConsumable: true});
  } catch {
    // Credited + recorded, but not consumed: Play still shows it owned, so
    // the next reconcile sees the duplicate and consumes it then.
  }
  emit({kind: 'credited', productId: checked.productId, tokens: checked.tokens, balanceAfter: recorded.balanceAfter});
  return 'credited';
}

/** Credit every owned (unconsumed) purchase that has not been recorded yet. */
async function reconcileOwnedPurchases(): Promise<number> {
  let restored = 0;
  try {
    const owned = await getAvailablePurchases();
    for (const purchase of owned) {
      try {
        const result = await creditPurchase(purchase);
        if (result === 'credited' || result === 'duplicate') restored += 1;
      } catch {/* one bad purchase must not block the others */}
    }
  } catch {/* billing unavailable or Play unreachable; the shop reports it */}
  return restored;
}

/** Connect to Play, load the seven products, reconcile. Listeners are installed by initBilling. */
async function loadBilling(): Promise<BillingInit> {
  try {
    const connected = await initConnection();
    if (!connected) {
      available = false;
      loaded = true;
      cachedProducts = [];
      cachedMissing = [...PRODUCT_IDS];
      cachedError = 'Could not connect to Google Play. Check your connection and try again.';
      emit({kind: 'unavailable', message: cachedError});
      return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
    }
    available = true;
    cachedError = undefined;
    const all = (await fetchProducts({skus: PRODUCT_IDS, type: 'in-app'})) ?? [];
    // fetchProducts returns a ProductOrSubscription union; keep only the
    // one-time products (type 'in-app') for the token shop.
    const products = all.filter((p): p is Product => p.type === 'in-app');
    cachedProducts = products.map(toBillingProduct).filter((p): p is BillingProduct => p !== null);
    cachedMissing = PRODUCT_IDS.filter(id => !cachedProducts.some(p => p.productId === id));
    loaded = true;
    emit({kind: 'products'});
    // Subscriptions load alongside the token packages (same connection).
    await loadSubscriptionProducts().catch(() => undefined);
    const restored = await reconcileOwnedPurchases();
    if (restored > 0) emit({kind: 'restored', count: restored});
    return {available: true, products: cachedProducts, missing: cachedMissing};
  } catch {
    available = false;
    loaded = true;
    cachedProducts = [];
    cachedMissing = [...PRODUCT_IDS];
    cachedError = 'Google Play billing is not available right now. Try again later.';
    emit({kind: 'unavailable', message: cachedError});
    return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
  }
}

/** Connect to Play, load the seven products, install listeners, reconcile. */
export async function initBilling(h: Handlers): Promise<BillingInit> {
  handlers = h;
  if (Platform.OS !== 'android') {
    available = false;
    loaded = true;
    cachedProducts = [];
    cachedMissing = [...PRODUCT_IDS];
    cachedError = 'Google Play billing is only available on Android.';
    emit({kind: 'unavailable', message: cachedError});
    return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
  }
  if (!updateSub) {
    // Registering the listeners touches the native Play Billing module. If
    // it is not ready this throws synchronously and initBilling rejects —
    // which the call site does not await — so guard it: billing simply stays
    // unavailable instead of crashing the app.
    try {
      updateSub = purchaseUpdatedListener(purchase => {void creditPurchase(purchase);});
      errorSub = purchaseErrorListener((error: PurchaseError) => {
        // Play's USER_CANCELED (responseCode 1) and the library's
        // UserCancelled both mean the user backed out: calm, not an error.
        if (error.code === ErrorCode.UserCancelled || error.responseCode === 1) emit({kind: 'cancelled'});
        else emit({kind: 'failed', message: error.message || 'The purchase failed.'});
      });
    } catch {
      updateSub = null;
      errorSub = null;
    }
  }
  return loadBilling();
}

/** Re-run the connection + product load with the stored handlers (shop Retry). */
export async function retryBilling(): Promise<BillingInit> {
  if (!handlers) return {available: false, products: [], missing: [...PRODUCT_IDS], error: 'Billing was not started.'};
  if (Platform.OS !== 'android') return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
  return loadBilling();
}

export function getBillingProducts(): BillingProduct[] {
  return cachedProducts;
}

export function getBillingStatus(): {available: boolean; loaded: boolean; missing: string[]; error?: string} {
  return {available, loaded, missing: cachedMissing, error: cachedError};
}

export function isBillingAvailable(): boolean {
  return available;
}

/** Launch the official Google Play purchase dialog for one package. */
export async function buyTokens(productId: string): Promise<{started: boolean; error?: string}> {
  if (!isTokenPurchaseEnabled()) return {started: false, error: CHECKOUT_PAUSED};
  if (!currentUid()) {
    emit({kind: 'signin-required'});
    return {started: false, error: 'Sign in first — purchases are recorded on your account.'};
  }
  if (!available) return {started: false, error: 'Google Play billing is not available right now.'};
  if (!PRODUCT_IDS.some(id => id === productId)) return {started: false, error: 'Unknown token package.'};
  try {
    await requestPurchase({request: {android: {skus: [productId]}}, type: 'in-app'});
    return {started: true};
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'The purchase could not be started.';
    if (msg.toLowerCase().includes('cancel')) {
      emit({kind: 'cancelled'});
      return {started: false, error: 'Purchase cancelled.'};
    }
    emit({kind: 'failed', message: msg});
    return {started: false, error: msg};
  }
}

/** Re-run the owned-purchase reconcile (wallet open, Restore button). */
export async function restorePurchases(): Promise<{restored: number}> {
  if (!available) return {restored: 0};
  const restored = await reconcileOwnedPurchases();
  emit({kind: 'restored', count: restored});
  return {restored};
}

export function disposeBilling(): void {
  try {updateSub?.remove();} catch {/* ignore */}
  try {errorSub?.remove();} catch {/* ignore */}
  updateSub = null;
  errorSub = null;
  handlers = null;
  void endConnection().catch(() => {});
}
