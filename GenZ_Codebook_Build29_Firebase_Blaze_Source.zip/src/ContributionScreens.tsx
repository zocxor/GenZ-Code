import {SPARK_MODE} from '../shared/deployment';
import {BACKEND_URL} from './backend';
import React,{useEffect,useMemo,useRef,useState} from 'react';
import {collection,query,orderBy,limit,onSnapshot} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {AppState,Pressable,StyleSheet,Text,TextInput,View} from 'react-native';
import {Button,C,Chip,Glass,LiquidHero,Icon,SectionHeader,confirmAction} from './ui';
import {datesAhead,errorOf,feature,ms,myRows,policy,requestKey,slots,utcDate,watchDaily,type DailyEntry,type FeatureRow} from './communityFeatures';
import {useAccountUser} from './services';
import {terms,bundledTerms,onContentChange,contentRevision} from './content';
import {refreshCommunity} from './contentSync';
import {dailyTerm} from './discovery';
import {VerifiedBadge,useBadges} from './VerifiedBadge';

const money = (value:number) => value.toLocaleString();
const refundPolicy = 'Full refund if rejected, missed, or cancelled before approval. Scheduled dates use UTC.';
const reviewPolicy = 'The fee pays for manual review. Approval is discretionary and rejected applications are non-refundable.';
const verifiedCredits = 'Paid activities use account tokens. Verified ad rewards appear after confirmation.';

export function useDailyCode(active:boolean):DailyEntry {
  const [day,setDay]=useState(utcDate);
  const [live,setLive]=useState<DailyEntry|null>(null);
  useEffect(()=>{
    if(!active)return;
    const refresh=()=>setDay(utcDate());
    refresh();
    const timer=setInterval(refresh,15_000);
    const foreground=AppState.addEventListener('change',state=>{if(state==='active')refresh();});
    return ()=>{clearInterval(timer);foreground.remove();};
  },[active]);
  useEffect(()=>{
    if(!active)return;
    return watchDaily(day,setLive);
  },[active,day]);
  const fallback=useMemo(()=>dailyTerm(day),[day]);
  return live?.date===day?live:{term:fallback.expression,meaning:fallback.meaning,category:fallback.category,date:day};
}

export function DailyCodeBanner({entry,compact=false,onApply}:{entry:DailyEntry;compact?:boolean;onApply?:()=>void}) {
  return <LiquidHero style={[s.hero,compact&&s.compactHero]}>
    <View style={s.row}><Icon name="calendar-outline" color="#BCDEFF" size={19}/><Text style={s.eyebrow}>DAILY CODE</Text><Text style={s.date}>{entry.date} UTC</Text></View>
    <Text accessibilityRole="header" selectable style={[s.word,compact&&s.compactWord]}>{entry.term}</Text>
    <Text selectable style={s.meaning}>{entry.meaning}</Text>
    <View style={[s.row,{justifyContent:'space-between',flexWrap:'wrap'}]}>
      <Text style={s.category}>{entry.category}</Text>
      {onApply&&<Pressable accessibilityRole="button" accessibilityLabel="Apply for Daily Code" onPress={onApply} style={s.apply}>
        <Text style={s.applyText}>Apply</Text><Icon name="chevron-forward" size={15} color="#fff"/>
      </Pressable>}
    </View>
  </LiquidHero>;
}
export function Status({status}:{status:string}) {
  const good=['approved','published','accepted'].includes(status);
  const bad=['rejected','cancelled','revoked','removed'].includes(status);
  return <Text style={[s.status,good?s.good:bad?s.bad:s.wait]}>{status.charAt(0).toUpperCase()+status.slice(1)}</Text>;
}

export function useContributionData(collection:string,uid?:string) {
  const [rows,setRows]=useState<FeatureRow[]>([]);
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(!!uid);
  const [epoch,reload]=useState(0);
  useEffect(()=>{
    let current=true;
    if(!uid){setRows([]);setError('');setLoading(false);return;}
    setLoading(true);setError('');
    void myRows(collection,uid).then(data=>{if(current)setRows(data);},e=>{if(current)setError(errorOf(e));}).finally(()=>{if(current)setLoading(false);});
    return ()=>{current=false;};
  },[uid,collection,epoch]);
  return {rows,error,loading,reload:()=>reload(e=>e+1)};
}

export function useEligibleBalance(uid?:string) {
  const [balance,setBalance]=useState<number|null>(null),[error,setError]=useState('');
  const [epoch,setEpoch]=useState(0);
  useEffect(()=>{
    let current=true;
    setBalance(null);setError('');
    if(uid&&BACKEND_URL) void feature('balance').then(r=>{
      const balance=r.balance;
      if(typeof balance!=='number'||!Number.isSafeInteger(balance)||balance<0)throw new Error('Account credits could not be confirmed. Please retry.');
      if(current)setBalance(balance);
    }).catch(e=>{if(current)setError(errorOf(e));});
    return ()=>{current=false;};
  },[uid,epoch]);
  useEffect(()=>{
    if(!uid||!BACKEND_URL)return;
    return onSnapshot(query(collection(cloudDbLive(),'users',uid,'tokenLedger'),orderBy('createdAt','desc'),limit(1)),()=>setEpoch(e=>e+1),()=>{});
  },[uid]);
  return {balance,error,reload:()=>setEpoch(e=>e+1),setBalance};
}

export function ConfirmFee({fee,balance,summary,onConfirm,disabled=false}:{fee:number;balance:number|null;summary:string;onConfirm:()=>void;disabled?:boolean}) {
  return <>
    <View style={s.fee}><Icon name="wallet-outline" size={20} color={C.goldDeep}/><Text style={s.label}>{money(fee)} tokens</Text></View>
    <Text style={s.body}>{balance===null?'Checking eligible balance…':`Eligible balance: ${money(balance)} tokens${balance>=fee?` · ${money(balance-fee)} remaining after payment`:''}`}</Text>
    <Text style={s.body}>{verifiedCredits}</Text>
    <Button title={`Confirm · ${money(fee)} tokens`} icon="checkmark-circle-outline" disabled={disabled||balance===null||balance<fee}
      onPress={()=>confirmAction('Confirm token payment',`${summary}\n\nPay ${money(fee)} tokens. Your eligible balance after payment will be ${money(Math.max(0,(balance??0)-fee))}.`,onConfirm,'Pay tokens')}/>
  </>;
}

function RowHistory({rows,kind,cancel}:{rows:FeatureRow[];kind:'daily'|'posts'|'verification';cancel?:(row:FeatureRow)=>void}) {
  const [filter,setFilter]=useState('all');
  const filters=kind==='daily'?['all','pending','approved','scheduled','published','rejected']:kind==='posts'?['all','pending','approved','rejected']:['all'];
  const filtered=rows.filter(row=>filter==='all'||row.status===filter);
  return <>
    {filters.length>1&&<View style={s.wrap}>{filters.map(f=><Chip key={f} label={f.charAt(0).toUpperCase()+f.slice(1)} selected={f===filter} onPress={()=>setFilter(f)}/>)}</View>}
    {!filtered.length&&<Text style={s.body}>No matching submissions.</Text>}
    {filtered.map(row=><Glass key={row.id}>
      <View style={s.row}><Text style={[s.label,{flex:1}]}>{row.term??(kind==='verification'?'Verified Badge application':row.text??'Community post')}</Text><Status status={row.status}/></View>
      {!!row.meaning&&<Text style={s.body}>{row.meaning}</Text>}
      <Text style={s.body}>{ms(row.createdAt)>0?new Date(ms(row.createdAt)).toLocaleDateString():''}{row.fee? ` · ${money(row.fee)} tokens · ${row.payment}`:''}</Text>
      {kind==='daily'&&<Text style={s.body}>Requested {row.requestedDate??'—'} · Confirmed {row.publicationDate??'—'} UTC</Text>}
      {!!row.reason&&<Text style={s.body}>{row.reason}</Text>}
      {cancel&&kind==='daily'&&row.status==='pending'&&<Button light title="Cancel and refund" icon="close-circle-outline" onPress={()=>confirmAction('Cancel this application?',`Your ${policy.dailyFee} tokens will be refunded.`,()=>cancel(row))}/>}
      {cancel&&kind==='posts'&&['pending','approved'].includes(row.status)&&<Button light title="Remove my post" icon="trash-outline" onPress={()=>confirmAction('Remove this post?', SPARK_MODE?'Remove this free post?':'The post fee is non-refundable.',()=>cancel(row))}/>}
    </Glass>)}
  </>;
}

export function ContributionScreen({mode,onSignIn,onSuggest}:{mode:'daily-apply'|'daily-history'|'verification'|'my-posts';onSignIn:()=>void;onSuggest:()=>void}) {
  const user=useAccountUser(), uid=user?.uid;
  const kind=mode.startsWith('daily')?'daily':mode==='my-posts'?'posts':'verification';
  const collection=mode==='daily-apply'?'dailyCodeApplications':kind==='daily'?'dailyCodeApplications':kind==='posts'?'communityPosts':'verificationApplications';
  const data=useContributionData(collection,uid);
  const paid=mode==='daily-apply'||mode==='verification';
  const credits=useEligibleBalance(paid?uid:undefined);
  const [word,setWord]=useState(''),[day,setDay]=useState(''),[calendar,setCalendar]=useState<Record<string,string>>({}),[calendarReady,setCalendarReady]=useState(false);
  const [month,setMonth]=useState('');
  const [msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
  const lock=useRef(false), key=useRef(requestKey());
  const today=utcDate(), dates=[today,...datesAhead()], rangeStart=today, rangeEnd=dates.at(-1)!;
  const months=[...new Set(dates.map(d=>d.slice(0,7)))];
  const [search,setSearch]=useState('');
  const [revision,setRevision]=useState(contentRevision);
  useEffect(()=>{if(mode!=='daily-apply')return;void refreshCommunity(true);return onContentChange(()=>setRevision(contentRevision));},[mode]);
  const bundledIds=useMemo(()=>new Set(bundledTerms.map(t=>t.id)),[]);
  const approved=useMemo(()=>terms.filter(t=>t.sensitivity==='None').map(t=>({id:t.id,term:t.expression,meaning:t.meaning,category:t.category,wordSource:t.status==='Community'?'community':bundledIds.has(t.id)?'bundled':'published'})),[revision,bundledIds]);
  const matches=approved.filter(r=>r.term.toLowerCase().includes(search.trim().toLowerCase())).slice(0,search.trim()?20:0);
  const selected=approved.find(r=>r.id===word);
  const reloadDates=()=>{
    setCalendarReady(false);
    return slots(rangeStart,rangeEnd).then(rows=>{setCalendar(rows);setCalendarReady(true);});
  };
  useEffect(()=>{
    if(mode!=='daily-apply'||!uid)return;
    let current=true;
    void slots(rangeStart,rangeEnd).then(rows=>{if(current){setCalendar(rows);setCalendarReady(true);}},e=>{if(current)setMsg(errorOf(e));});
    return ()=>{current=false;};
  },[uid,mode,rangeStart,rangeEnd]);
  const badges=useBadges(mode==='verification'&&uid?[uid]:[]);
  const submit=async(action:string,fields:Record<string,unknown>)=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setMsg('');
    try {
      const result=await feature(action,{...fields,requestId:key.current});
      key.current=requestKey();
      if(typeof result.balance==='number')credits.setBalance(result.balance);
      else if(paid)credits.reload();
      setMsg(action==='cancel-daily'?'Application cancelled. Refund recorded in your Wallet.':action==='delete-post'?'Post removed.':'Application received. Your payment is recorded in your Wallet.');
      if(mode==='daily-apply'){setWord('');setDay('');await reloadDates();}
      data.reload();
    } catch(e){
      const next=(e as {details?:{next?:string}})?.details?.next;
      if(next){setDay(next);setMonth(next.slice(0,7));void reloadDates().catch(()=>{});}
      setMsg(errorOf(e)+(next?` Next available: ${next} UTC. Confirm again to reserve it.`:''));
    } finally {lock.current=false;setBusy(false);}
  };
  if(!uid)return <Glass><Text style={s.label}>Sign in to continue</Text><Button title="Sign in" onPress={onSignIn}/></Glass>;
  if(!BACKEND_URL&&(mode==='daily-apply'||mode==='verification'))return <Glass><Text style={s.label}>{mode==='verification'?'Verified Badge':'Daily Code'}</Text><Text style={s.body}>Account token services are not connected yet. Free contributions and games remain available.</Text></Glass>;
  return <>
    <SectionHeader title={mode==='daily-apply'?'Feature your word':mode==='daily-history'?'My Daily Code applications':mode==='my-posts'?'My posts':'Verified Badge'} eyebrow="GENZ CODEBOOK"/>
    {!!msg&&<Text accessibilityRole="alert" style={s.body}>{msg}</Text>}
    {!!data.error&&<Text accessibilityRole="alert" style={s.body}>{data.error}</Text>}
    {(data.loading||data.error)&&<Button light title={data.loading?'Loading…':'Retry'} disabled={data.loading} onPress={()=>data.reload()}/>}
    {mode==='daily-apply'?<>
      <Text style={s.body}>Search Codes, choose a word and reserve an available date for 250 tokens.</Text>
      <TextInput accessibilityLabel="Search dictionary codes" placeholder="Search a word, e.g. HDOT" value={search} onChangeText={setSearch} style={{minHeight:44,borderWidth:1,borderColor:C.line,borderRadius:12,padding:10,color:C.ink,backgroundColor:'#fff'}}/>
      {!!search.trim()&&!matches.length&&<Text style={s.body}>No matching code. Try a different spelling.</Text>}
      <View style={s.wrap}>{matches.map(r=><Chip key={r.id} label={r.term} selected={word===r.id} onPress={()=>{setWord(r.id);key.current=requestKey();}}/>)}</View>
      {selected&&<Glass><Text style={s.label}>{selected.term} · {selected.category}</Text><Text style={s.body}>{selected.meaning}</Text></Glass>}
      <Text style={s.label}>Choose a publication date (UTC)</Text>
      {!calendarReady&&<Button light title="Load available dates" onPress={()=>void reloadDates().catch(e=>setMsg(errorOf(e)))}/>}
      {calendarReady&&<>
        <View style={s.wrap}>{months.map(m=><Chip key={m} label={m} selected={(month||months[0])===m} onPress={()=>setMonth(m)}/>)}</View>
        <View style={s.calendar}>{dates.filter(d=>d.startsWith(month||months[0]!)).map(d=><Pressable key={d} accessibilityRole="button" accessibilityLabel={d+' '+(calendar[d]??'available')} accessibilityState={{selected:day===d,disabled:!!calendar[d]||d===today}} disabled={!!calendar[d]||d===today} onPress={()=>{setDay(d);key.current=requestKey();}} style={[s.day,day===d&&{backgroundColor:C.accent},(calendar[d]||d===today)&&{opacity:.4}]}><Text style={{fontWeight:'700',color:day===d?'#fff':C.ink}}>{d.slice(-2)}</Text></Pressable>)}</View>

      </>}
      <Text style={s.body}>{day? `Requested date: ${day} UTC`:'Select an available date.'}</Text>
      <Text style={s.body}>{refundPolicy}</Text>
      {!!credits.error&&<Button light title="Retry balance check" onPress={credits.reload}/>}
      <ConfirmFee fee={policy.dailyFee} balance={credits.balance} summary={`Apply to feature “${selected?.term??''}” on ${day} UTC. ${refundPolicy}`}
        disabled={busy||!selected||!day||!calendarReady||!!calendar[day]} onConfirm={()=>void submit('apply-daily',{wordId:word,wordSource:selected?.wordSource,date:day})}/>
    </>:<>
      {mode==='verification'&&<Glass>
        <View style={s.row}><Text style={s.label}>Verified Badge</Text><VerifiedBadge verified={badges.has(uid)}/></View>
        <View style={s.row}><Text style={s.label}>Preview · KBR</Text><VerifiedBadge verified/></View>
        <Text style={s.body}>{reviewPolicy}</Text>
        {!!credits.error&&<Text style={s.body}>{credits.error}</Text>}
        {!data.loading&&!data.error&&!data.rows.some(r=>['pending','approved'].includes(r.status))&&
          <ConfirmFee fee={policy.verificationFee} balance={credits.balance} summary={reviewPolicy} disabled={busy} onConfirm={()=>void submit('apply-verification',{})}/>}
      </Glass>}
      <Button light title="Refresh status" onPress={data.reload} disabled={data.loading||busy}/>
      <RowHistory rows={data.rows} kind={kind} cancel={mode==='daily-history'?r=>void submit('cancel-daily',{id:r.id}):mode==='my-posts'?r=>void submit('delete-post',{id:r.id}):undefined}/>
    </>}
  </>;
}

const s=StyleSheet.create({
  calendar:{flexDirection:'row',flexWrap:'wrap',gap:5},day:{width:'12.8%',minHeight:38,borderWidth:1,borderColor:C.line,borderRadius:9,alignItems:'center',justifyContent:'center',backgroundColor:'#fff'},
  hero:{padding:16,borderRadius:21,gap:8},compactHero:{padding:11,borderRadius:16,gap:3},compactWord:{fontSize:23},
  apply:{minHeight:42,paddingHorizontal:8,flexDirection:'row',alignItems:'center',gap:4},applyText:{fontSize:13,fontWeight:'800',color:'#fff'},row:{flexDirection:'row',alignItems:'center',gap:8},wrap:{flexDirection:'row',flexWrap:'wrap',gap:8},
  eyebrow:{fontSize:12,letterSpacing:1.4,fontWeight:'900',color:'#E0E9FF',flex:1},
  date:{color:'#E0E9FF',fontSize:11},word:{fontSize:34,fontWeight:'900',color:'#fff'},meaning:{fontSize:16,lineHeight:23,color:'#fff'},
  category:{alignSelf:'flex-start',borderRadius:12,paddingHorizontal:10,paddingVertical:5,color:'#19234B',backgroundColor:'#DFE7FF',fontWeight:'800'},
  label:{fontSize:16,fontWeight:'800',color:C.ink},body:{fontSize:14,lineHeight:20,color:C.muted},fee:{backgroundColor:'#FFF0C7',borderRadius:13,padding:12,flexDirection:'row',alignItems:'center',gap:8},
  unavailable:{backgroundColor:'#E8EDF7',borderRadius:12,padding:9,justifyContent:'center'},status:{paddingHorizontal:8,paddingVertical:4,borderRadius:10,fontSize:12,fontWeight:'800',overflow:'hidden'},
  good:{color:'#09583E',backgroundColor:'#DDF6EA'},bad:{color:'#8E2634',backgroundColor:'#FEE5EB'},wait:{color:'#73501A',backgroundColor:'#FFF0CD'},
});
