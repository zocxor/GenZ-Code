/**
 * Settings: only rows that do something real.
 *
 * Account opens the account sheet, language changes the dictionary language
 * (the same LANGUAGES list and setLanguage action the Words tab uses),
 * Privacy & Security opens Threat Shield, Help & Support opens the feedback
 * form, Rate the App opens the real Play Store listing, and About opens the
 * About page. There is deliberately NO notifications toggle or any other
 * setting with no real effect behind it.
 */
import React from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet, Linking} from 'react-native';
import {C, Button, Chip, FadeIn, Icon, IconName, IconTile, SectionHeader} from './ui';
import {LANGUAGES} from './profile';

const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.genzmode.app';

export default function SettingsScreen({onClose, onOpen, onAccount, onOpenAbout, signedInEmail, language, onLanguageChange}: {
  onClose: () => void;
  onOpen: (sheet: 'login' | 'privacy' | 'feedback') => void;
  onAccount: (mode: 'signin' | 'create') => void;
  onOpenAbout: () => void;
  signedInEmail: string | null;
  language: string;
  onLanguageChange: (language: string) => void;
}) {
  return (
    <ScrollView contentContainerStyle={s.content}>
      <FadeIn>
        <SectionHeader eyebrow="ACCOUNT" title="Your account" />
        <View style={s.group}>
          <Row icon="person-circle-outline" tileFrom={C.accent} tileTo={C.purple} title="Account" description={signedInEmail ? `Signed in as ${signedInEmail}` : 'Sign in or create an account'} onPress={() => (signedInEmail ? onOpen('login') : onAccount('signin'))} last />
        </View>
      </FadeIn>

      <FadeIn delay={60}>
        <SectionHeader eyebrow="PREFERENCES" title="Dictionary language" />
        <View style={s.group}>
          <View style={s.pad}>
            <View style={s.wrap}>
              {LANGUAGES.map(l => <Chip key={l} label={l} selected={language === l} onPress={() => onLanguageChange(l)} />)}
            </View>
          </View>
        </View>
      </FadeIn>

      <FadeIn delay={120}>
        <SectionHeader eyebrow="SUPPORT" title="Help & security" />
        <View style={s.group}>
          <Row icon="shield-checkmark-outline" tileFrom={C.accent} tileTo="#2E9BFF" title="Privacy & Security" description="Your data and Threat Shield" onPress={() => onOpen('privacy')} />
          <Row icon="chatbubble-ellipses-outline" tileFrom={C.purple} tileTo="#9B7BFF" title="Help & Support" description="FAQs and contact us" onPress={() => onOpen('feedback')} />
          <Row icon="star-outline" tileFrom={C.gold} tileTo="#F5C94C" title="Rate the App" description="On Google Play" onPress={() => void Linking.openURL(PLAY_STORE_URL).catch(() => {})} last />
        </View>
      </FadeIn>

      <FadeIn delay={180}>
        <SectionHeader eyebrow="ABOUT" title="About the app" />
        <View style={s.group}>
          <Row icon="information-circle-outline" tileFrom={C.navy} tileTo={C.accent} title="About" description="Version, terms and licences" onPress={onOpenAbout} last />
        </View>
      </FadeIn>

      <Text style={s.fine}>Learning stays on this device unless you sign in to back it up.</Text>
      <Button title="Done" icon="checkmark-outline" onPress={onClose} />
    </ScrollView>
  );
}

function Row({icon, tileFrom, tileTo, title, description, onPress, last}: {icon: IconName; tileFrom: string; tileTo: string; title: string; description: string; onPress: () => void; last?: boolean}) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={({pressed}) => [s.settingRow, last && {borderBottomWidth: 0}, pressed && {opacity: 0.7, backgroundColor: C.soft}]}>
      <IconTile icon={icon} from={tileFrom} to={tileTo} size={36} iconSize={18} />
      <View style={{flex: 1, gap: 3}}><Text style={s.rowTitle}>{title}</Text><Text style={s.caption} numberOfLines={1}>{description}</Text></View>
      <Icon name="chevron-forward" size={17} color={C.muted} />
    </Pressable>
  );
}

const s = StyleSheet.create({
  content: {gap: 12, paddingBottom: 8},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.navy},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  group: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, marginTop: 8, paddingHorizontal: 6, paddingVertical: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3, overflow: 'hidden'},
  pad: {padding: 10, gap: 8},
  settingRow: {paddingVertical: 10, paddingHorizontal: 10, minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 13, borderBottomWidth: 1, borderBottomColor: '#e3eefb', borderRadius: 18},
});
