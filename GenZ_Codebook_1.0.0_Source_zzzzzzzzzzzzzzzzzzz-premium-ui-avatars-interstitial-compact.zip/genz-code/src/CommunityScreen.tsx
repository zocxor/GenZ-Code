/**
 * Community: one shared room for everyone, by nickname — chat and posts.
 *
 * The room is for token holders: you need tokens (balance above zero) to get
 * in and use it — earn them by watching an ad, playing quizzes, or buying a
 * package. Every chat message costs 1 token (CHAT_MESSAGE_COST) and every
 * post costs 25 tokens (POST_COST), shown before you send and deducted only
 * after the post or message is accepted; the Send / Post button is disabled
 * when the balance is too low. Once you are in the room this session you stay
 * in it even if your balance drops to zero — you just cannot send more until
 * you earn tokens. Guests can read the room once they hold tokens; only
 * signed-in users can post. Messages and posts are screened on the device
 * before sending (see shared/chat.ts) and again by the server rules. Any
 * message or post can be reported; moderators hide reported items from the
 * admin portal. The room only shows live messages, newest last, capped at the
 * newest 50; posts show newest first, capped at the newest 50.
 *
 * The composer sits in a KeyboardAvoidingView so the keyboard never covers
 * the text box while typing.
 */
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, ScrollView, Pressable, StyleSheet, KeyboardAvoidingView, Keyboard, Platform} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Button, Chip, Icon, IconTile, FadeIn} from './ui';
import {useAccountUser} from './services';
import {subscribeChat, sendChatMessage, deleteOwnMessage} from './chat';
import {subscribePosts, createPost, toggleLike, deleteOwnPost, fetchMyLikedPostIds, reportPost} from './communityPosts';
import {reportChatMessage, REPORT_REASONS} from './ugc';
import {CHAT_MAX_LENGTH, POST_MAX_LENGTH, type ChatMessage, type CommunityPost} from '../shared/chat';
import {watchRewardedAd} from './ads';
import {fetchLeaderboard, publishLeaderboard, leaveLeaderboard, type LeaderboardRow} from './tokensSync';
import {earnTokens, spendTokens, setLeaderboardOptIn, type Action} from './learning';
import {TOKENS, type TokensState} from '../shared/tokens';

const timeOf = (at: number) => new Date(at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
const initialOf = (name: string) => (name.trim().charAt(0) || '?').toUpperCase();

export default function CommunityScreen({active, nickname, onSignIn, onOpenShop, onOpenDaily, onGoToPlay, tokens, onTokensAction}: {active: boolean; nickname: string; onSignIn: () => void; onOpenShop: () => void; onOpenDaily: () => void; onGoToPlay: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  const user = useAccountUser();
  const [view, setView] = useState<'chat' | 'posts'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [earning, setEarning] = useState(false);
  const [earnNote, setEarnNote] = useState('');
  const [joined, setJoined] = useState(false);
  // Entry gate: you need tokens to get in. Once you are in this session you
  // stay in the room even if a message spend drops your balance to zero — you
  // just cannot send more until you earn tokens. (The tab stays mounted, so
  // this survives switching tabs; a fresh app launch re-arms the gate.)
  useEffect(() => { if (active && tokens.balance > 0) setJoined(true); }, [active, tokens.balance]);
  const needsTokens = tokens.balance <= 0 && !joined;
  const [reporting, setReporting] = useState<string | null>(null);
  const [reportingPost, setReportingPost] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportNote, setReportNote] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportSent, setReportSent] = useState('');
  const [board, setBoard] = useState<LeaderboardRow[]>([]);
  const [boardBusy, setBoardBusy] = useState(false);
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [postLoadError, setPostLoadError] = useState('');
  const [postText, setPostText] = useState('');
  const [posting, setPosting] = useState(false);
  const [postError, setPostError] = useState('');
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [liking, setLiking] = useState<Set<string>>(new Set());
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    if (!active) return;
    setLoadError('');
    return subscribeChat(setMessages, setLoadError);
  }, [active]);
  useEffect(() => {
    if (!active || view !== 'posts') return;
    setPostLoadError('');
    return subscribePosts(setPosts, setPostLoadError);
  }, [active, view]);
  useEffect(() => {
    if (!active) return;
    let live = true;
    void fetchLeaderboard().then(rows => {if (live) setBoard(rows);});
    return () => {live = false;};
  }, [active]);
  useEffect(() => {
    if (!active || view !== 'posts' || !user) return;
    let live = true;
    void fetchMyLikedPostIds().then(ids => {if (live) setLikedIds(ids);});
    return () => {live = false;};
  }, [active, view, user]);
  useEffect(() => {
    if (active) scrollRef.current?.scrollToEnd({animated: true});
  }, [messages, active]);
  // When the keyboard opens, scroll the room to the latest message so the
  // composer and the newest message stay visible above it.
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () => {
      setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 120);
    });
    return () => show.remove();
  }, []);

  const send = async () => {
    if (sending || !text.trim()) return;
    if (tokens.balance < TOKENS.CHAT_MESSAGE_COST) {
      setSendError(`You need ${TOKENS.CHAT_MESSAGE_COST} token${TOKENS.CHAT_MESSAGE_COST === 1 ? '' : 's'} to send a message (you have ${tokens.balance}). Watch an ad or collect your daily reward to earn more.`);
      return;
    }
    setSending(true); setSendError('');
    const r = await sendChatMessage(nickname, text);
    setSending(false);
    if (r.ok) {
      // Deduct only after the message is accepted — never twice for one send
      // (the `sending` guard above blocks a second tap while this runs).
      onTokensAction(spendTokens(TOKENS.CHAT_MESSAGE_COST));
      setText('');
    } else setSendError(r.message);
  };

  const post = async () => {
    if (posting || !postText.trim()) return;
    if (tokens.balance < TOKENS.POST_COST) {
      setPostError(`You need ${TOKENS.POST_COST} tokens to post (you have ${tokens.balance}). Watch an ad or collect your daily reward to earn more.`);
      return;
    }
    setPosting(true); setPostError('');
    const r = await createPost(nickname, postText);
    setPosting(false);
    if (r.ok) {
      // Deduct only after the post is accepted — never twice for one post
      // (the `posting` guard above blocks a second tap while this runs).
      onTokensAction(spendTokens(TOKENS.POST_COST));
      setPostText('');
    } else setPostError(r.message);
  };

  const like = async (postId: string) => {
    if (liking.has(postId) || !user) return;
    setLiking(prev => new Set(prev).add(postId));
    const r = await toggleLike(postId);
    setLiking(prev => {
      const next = new Set(prev);
      next.delete(postId);
      return next;
    });
    if (r.ok) {
      setLikedIds(prev => {
        const next = new Set(prev);
        if (r.liked) next.add(postId); else next.delete(postId);
        return next;
      });
      setPosts(prev => prev.map(p => p.id === postId ? {...p, likeCount: Math.max(0, p.likeCount + (r.liked ? 1 : -1))} : p));
    }
  };

  const earn = async () => {
    if (earning) return;
    setEarning(true); setEarnNote('');
    const rewarded = await watchRewardedAd();
    setEarning(false);
    if (rewarded) {onTokensAction(earnTokens(TOKENS.REWARDED_AD)); setEarnNote(`+${TOKENS.REWARDED_AD} tokens earned. Welcome to the room.`);}
    else setEarnNote('No tokens this time — the ad closed early. Try again when you like.');
  };

  const report = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportChatMessage(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this message.'); setReporting(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const reportPostItem = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportPost(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this post.'); setReportingPost(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const remove = async (id: string) => {
    const r = await deleteOwnMessage(id);
    if (!r.ok) setSendError(r.message);
  };

  const removePost = async (id: string) => {
    const r = await deleteOwnPost(id);
    if (!r.ok) setPostError(r.message);
  };

  const toggleBoard = async (on: boolean) => {
    if (boardBusy || !user) return;
    setBoardBusy(true);
    onTokensAction(setLeaderboardOptIn(on));
    if (on) await publishLeaderboard(nickname, tokens.balance);
    else await leaveLeaderboard();
    setBoard(await fetchLeaderboard());
    setBoardBusy(false);
  };

  const gateCard = <FadeIn><View style={s.card}>
    <IconTile icon="chatbubbles-outline" from={C.accent} to={C.purple} size={40} iconSize={20} />
    <Text style={s.rowTitle}>{view === 'posts' ? 'You need tokens to post' : 'You need tokens to join the chat'}</Text>
    <Text style={s.body}>{view === 'posts' ? 'Earn tokens to post — watch an ad, play, or buy.' : 'Earn tokens to join — watch an ad, play, or buy.'}</Text>
    {!!earnNote && <Text accessibilityLiveRegion="polite" style={s.ok}>{earnNote}</Text>}
    <Button title={earning ? 'Showing ad…' : `Watch an ad · +${TOKENS.REWARDED_AD} tokens`} icon="play-circle-outline" disabled={earning} onPress={() => void earn()} />
    <Button title="Daily reward" icon="gift-outline" light onPress={onOpenDaily} />
    <Button title="Premium options" icon="star-outline" light onPress={onOpenShop} />
    <Button title="Play to earn tokens" icon="game-controller-outline" light onPress={onGoToPlay} />
    <Button title="Buy tokens" icon="card-outline" light onPress={onOpenShop} />
    {!user && <Button title="Sign in or create an account" icon="log-in-outline" light onPress={onSignIn} />}
  </View></FadeIn>;

  const reportBox = (title: string, onSubmit: () => void) => <Glass style={s.reportBox}>
    <Text style={s.label}>{title}</Text>
    <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reportReason === r} onPress={() => setReportReason(r)} />)}</View>
    <TextInput accessibilityLabel="Report details" value={reportNote} onChangeText={setReportNote} maxLength={300} multiline style={s.input} placeholder="Details (optional)" placeholderTextColor={C.muted} />
    {!!reportSent && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    <View style={s.reportButtons}>
      <Button title={reportBusy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={reportBusy || !reportReason} onPress={() => void onSubmit()} />
      <Button light title="Cancel" icon="close-outline" onPress={() => {setReporting(null); setReportingPost(null);}} />
    </View>
  </Glass>;

  // 'height' on Android: with Expo SDK 54 + edge-to-edge the window does not
  // resize when the keyboard opens, so the 'padding' behaviour never lifts
  // the composer and the text box hides behind the keyboard. Shrinking the
  // whole view by the keyboard height keeps the composer pinned above it.
  // iOS keeps 'padding', which is reliable there.
  return <KeyboardAvoidingView style={s.fill} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={0}>
  <View style={s.fill}>
    <View style={s.head}>
      <View style={s.headRow}>
        <View style={{flex: 1, minWidth: 0}}>
          <Text style={s.title}>Community</Text>
          <Text style={s.body} numberOfLines={1}>One room. Everyone chatting.</Text>
        </View>
        {user && <Pressable accessibilityRole="button" accessibilityState={{selected: tokens.leaderboard}} onPress={() => void toggleBoard(!tokens.leaderboard)} style={[s.joinChip, tokens.leaderboard && s.joinChipOn]}>
          <Icon name="trophy-outline" size={16} color={tokens.leaderboard ? '#fff' : C.accent} />
          <Text style={[s.joinChipText, tokens.leaderboard && s.joinChipTextOn]}>{boardBusy ? 'Please wait…' : tokens.leaderboard ? 'Leave' : 'Join'}</Text>
        </Pressable>}
      </View>
      <View style={s.switcher}>
        <Chip label="Chat" icon="chatbubbles-outline" selected={view === 'chat'} onPress={() => setView('chat')} />
        <Chip label="Posts" icon="newspaper-outline" selected={view === 'posts'} onPress={() => setView('posts')} />
      </View>
    </View>
    {loadError && view === 'chat' ? <View style={[s.card, s.inlineCard]}><Text accessibilityRole="alert" style={s.err}>{loadError}</Text></View> : null}
    {postLoadError && view === 'posts' ? <View style={[s.card, s.inlineCard]}><Text accessibilityRole="alert" style={s.err}>{postLoadError}</Text></View> : null}
    <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" style={s.scroll} contentContainerStyle={s.list}>
      <FadeIn><View style={s.card}>
        <View style={s.boardHead}>
          <IconTile icon="trophy-outline" from={C.gold} to="#DE8F0E" size={40} iconSize={20} />
          <View style={{flex: 1, gap: 2}}>
            <Text style={s.rowTitle}>Top token earners</Text>
            <Text style={s.body}>Nicknames only.</Text>
          </View>
        </View>
        {board.length === 0 ? <Text style={s.body}>No one yet — be first.</Text> : board.slice(0, 10).map((r, i, arr) => (
          <View key={r.uid} style={[s.boardRow, i === arr.length - 1 && s.boardRowLast]}>
            <View style={[s.rankBadge, i === 0 && s.rankFirst]}><Text style={s.rankText}>{i + 1}</Text></View>
            <Text style={[s.boardName, user && r.uid === user.uid && s.boardMe]} numberOfLines={1}>{user && r.uid === user.uid ? 'You' : r.name}</Text>
            <Text style={s.boardTokens}>{r.tokens.toLocaleString()} tokens</Text>
          </View>
        ))}
        {!user && <Text style={s.body}>Sign in to join.</Text>}
      </View></FadeIn>
      {view === 'chat' ? (needsTokens ? gateCard : <>
      {!messages.length && !loadError ? <FadeIn><View style={s.card}>
        <IconTile icon="chatbubbles-outline" from={C.accent} to={C.purple} size={40} iconSize={20} />
        <Text style={s.rowTitle}>No messages yet.</Text>
        <Text style={s.body}>Say hi — keep it friendly.</Text>
      </View></FadeIn> : null}
      {messages.map(m => {
        const mine = !!user && m.uid === user.uid;
        return <View key={m.id} style={[s.msgWrap, mine && s.msgWrapMine]}>
          <View style={[s.metaRow, mine ? s.metaRowMine : s.metaRowTheirs]}>
            <Text style={s.name}>{mine ? 'You' : m.name}</Text>
            <Text style={s.time}>{timeOf(m.at)}</Text>
          </View>
          <View style={[s.msgLine, mine && s.msgLineMine]}>
            {!mine && <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.avatar}><Text style={s.avatarText}>{initialOf(m.name)}</Text></LinearGradient>}
            {mine ? (
              <LinearGradient colors={['#2F7DF6', C.accent, '#0E4ED6']} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={[s.bubble, s.bubbleMine]}>
                <Text selectable style={[s.text, s.textMine]}>{m.text}</Text>
                <View style={s.actions}>
                  <Pressable accessibilityRole="button" accessibilityLabel="Delete my message" onPress={() => void remove(m.id)} style={s.mini}><Icon name="trash-outline" size={15} color="rgba(255,255,255,.9)" /><Text style={[s.miniText, s.miniTextMine]}>Delete</Text></Pressable>
                </View>
              </LinearGradient>
            ) : (
              <View style={[s.bubble, s.bubbleTheirs]}>
                <Text selectable style={s.text}>{m.text}</Text>
                <View style={s.actions}>
                  <Pressable accessibilityRole="button" accessibilityLabel={`Report message from ${m.name}`} onPress={() => {setReporting(reporting === m.id ? null : m.id); setReportReason(''); setReportNote(''); setReportSent('');}} style={s.mini}><Icon name="flag-outline" size={15} color={C.muted} /><Text style={s.miniText}>Report</Text></Pressable>
                </View>
              </View>
            )}
          </View>
          {reporting === m.id && reportBox('What’s wrong with this message?', () => void report(m.id))}
        </View>;
      })}
      </>) : (needsTokens ? gateCard : <>
      {!posts.length && !postLoadError ? <FadeIn><View style={s.card}>
        <IconTile icon="newspaper-outline" from={C.accent} to={C.purple} size={40} iconSize={20} />
        <Text style={s.rowTitle}>No posts yet.</Text>
        <Text style={s.body}>Be the first to share.</Text>
      </View></FadeIn> : null}
      {posts.map((p, i) => {
        const mine = !!user && p.uid === user.uid;
        const liked = likedIds.has(p.id);
        return <FadeIn key={p.id} delay={Math.min(i * 40, 200)}><View style={s.card}>
          <View style={s.postHead}>
            <LinearGradient colors={[C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.avatar}><Text style={s.avatarText}>{initialOf(mine ? nickname || 'You' : p.name)}</Text></LinearGradient>
            <View style={{flex: 1, gap: 1}}>
              <Text style={s.name}>{mine ? 'You' : p.name}</Text>
              <Text style={s.time}>{timeOf(p.at)}</Text>
            </View>
          </View>
          <Text selectable style={s.text}>{p.text}</Text>
          <View style={s.postActions}>
            <Pressable accessibilityRole="button" accessibilityLabel={liked ? `Unlike this post, ${p.likeCount} likes` : `Like this post, ${p.likeCount} likes`} disabled={!user || liking.has(p.id)} onPress={() => void like(p.id)} style={[s.mini, liked && s.miniLiked]}>
              <Icon name={liked ? 'heart' : 'heart-outline'} size={17} color={liked ? '#d6455a' : C.muted} />
              <Text style={[s.miniText, liked && s.miniTextLiked]}>{p.likeCount}</Text>
            </Pressable>
            {mine
              ? <Pressable accessibilityRole="button" accessibilityLabel="Delete my post" onPress={() => void removePost(p.id)} style={s.mini}><Icon name="trash-outline" size={15} color={C.muted} /><Text style={s.miniText}>Delete</Text></Pressable>
              : <Pressable accessibilityRole="button" accessibilityLabel={`Report post from ${p.name}`} onPress={() => {setReportingPost(reportingPost === p.id ? null : p.id); setReportReason(''); setReportNote(''); setReportSent('');}} style={s.mini}><Icon name="flag-outline" size={15} color={C.muted} /><Text style={s.miniText}>Report</Text></Pressable>}
          </View>
          {reportingPost === p.id && reportBox('What’s wrong with this post?', () => void reportPostItem(p.id))}
        </View></FadeIn>;
      })}
      </>)}
    </ScrollView>
    {!!reportSent && reporting === null && reportingPost === null && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    {needsTokens ? null : user ? (view === 'chat' ? <View style={s.composer}>
      <TextInput accessibilityLabel="Message to the community" value={text} onChangeText={v => {setText(v); setSendError('');}} onFocus={() => setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 300)} maxLength={CHAT_MAX_LENGTH} multiline style={s.input} placeholder={`Chat as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
      <Text style={s.cost}>{TOKENS.CHAT_MESSAGE_COST} token{TOKENS.CHAT_MESSAGE_COST === 1 ? '' : 's'} per message</Text>
      {!!sendError && <Text accessibilityRole="alert" style={s.err}>{sendError}</Text>}
      <View style={s.sendRow}>
        <Text style={s.count}>{text.trim().length}/{CHAT_MAX_LENGTH}</Text>
        <Button title={sending ? 'Sending…' : tokens.balance < TOKENS.CHAT_MESSAGE_COST ? `Need ${TOKENS.CHAT_MESSAGE_COST - tokens.balance} more token${TOKENS.CHAT_MESSAGE_COST - tokens.balance === 1 ? '' : 's'}` : 'Send'} icon="paper-plane-outline" disabled={sending || !text.trim() || tokens.balance < TOKENS.CHAT_MESSAGE_COST} onPress={() => void send()} />
      </View>
    </View> : <View style={s.composer}>
      <TextInput accessibilityLabel="Write a community post" value={postText} onChangeText={v => {setPostText(v); setPostError('');}} maxLength={POST_MAX_LENGTH} multiline style={s.input} placeholder={`Share something as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
      <Text style={s.cost}>{TOKENS.POST_COST} tokens per post</Text>
      {!!postError && <Text accessibilityRole="alert" style={s.err}>{postError}</Text>}
      <View style={s.sendRow}>
        <Text style={s.count}>{postText.trim().length}/{POST_MAX_LENGTH}</Text>
        <Button title={posting ? 'Posting…' : tokens.balance < TOKENS.POST_COST ? `Need ${TOKENS.POST_COST - tokens.balance} more tokens` : `Post · ${TOKENS.POST_COST} tokens`} icon="paper-plane-outline" disabled={posting || !postText.trim() || tokens.balance < TOKENS.POST_COST} onPress={() => void post()} />
      </View>
    </View>) : <View style={[s.card, s.signInCard]}>
      <IconTile icon="person-circle-outline" from={C.accent} to={C.purple} size={40} iconSize={20} />
      <Text style={s.rowTitle}>{view === 'posts' ? 'Sign in to post' : 'Sign in to chat'}</Text>
      <Text style={s.body}>Reading is free.</Text>
      <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
    </View>}
  </View>
  </KeyboardAvoidingView>;
}

const s = StyleSheet.create({
  fill: {flex: 1, backgroundColor: C.bg},
  scroll: {flex: 1},
  head: {paddingHorizontal: 16, paddingTop: 6, paddingBottom: 4, gap: 12},
  headRow: {flexDirection: 'row', alignItems: 'center', gap: 12},
  switcher: {flexDirection: 'row', gap: 8, backgroundColor: C.soft, borderRadius: 18, padding: 4},
  joinChip: {flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 40, paddingHorizontal: 14, borderRadius: 20, backgroundColor: C.soft, borderWidth: 1, borderColor: '#dce8f5'},
  joinChipOn: {backgroundColor: C.accent, borderColor: C.accent},
  joinChipText: {fontSize: 13, fontWeight: '800', color: C.accent},
  joinChipTextOn: {color: '#fff'},
  title: {fontSize: 24, lineHeight: 29, fontWeight: '900', letterSpacing: -0.8, color: C.navy},
  body: {fontSize: 14, lineHeight: 20, color: C.muted},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  inlineCard: {marginHorizontal: 16, marginTop: 8, padding: 14},
  signInCard: {marginHorizontal: 16, marginBottom: 10},
  boardHead: {flexDirection: 'row', alignItems: 'center', gap: 12},
  boardRow: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eef3fa'},
  boardRowLast: {borderBottomWidth: 0, paddingBottom: 0},
  rankBadge: {width: 28, height: 28, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center'},
  rankFirst: {backgroundColor: C.gold},
  rankText: {fontSize: 13, fontWeight: '900', color: C.navy},
  boardName: {flex: 1, fontSize: 15, fontWeight: '700', color: C.navy},
  boardMe: {color: C.accent},
  boardTokens: {fontSize: 14, fontWeight: '800', color: C.goldDeep},
  list: {padding: 12, gap: 10, paddingBottom: 12},
  msgWrap: {alignItems: 'flex-start', gap: 4},
  msgWrapMine: {alignItems: 'flex-end'},
  metaRow: {flexDirection: 'row', gap: 8, alignItems: 'baseline', paddingHorizontal: 4},
  metaRowMine: {},
  metaRowTheirs: {marginLeft: 44},
  msgLine: {flexDirection: 'row', alignItems: 'flex-end', gap: 8, width: '100%'},
  msgLineMine: {justifyContent: 'flex-end'},
  avatar: {width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', flexShrink: 0},
  avatarText: {color: '#fff', fontSize: 15, fontWeight: '900'},
  bubble: {borderRadius: 18, paddingVertical: 12, paddingHorizontal: 14, gap: 6, flexShrink: 1},
  bubbleTheirs: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1, borderBottomLeftRadius: 6},
  bubbleMine: {maxWidth: '88%', borderBottomRightRadius: 6},
  name: {fontSize: 13, fontWeight: '800', color: C.navy},
  time: {fontSize: 11, color: C.muted},
  text: {fontSize: 16, lineHeight: 23, color: C.navy},
  textMine: {color: '#fff'},
  actions: {flexDirection: 'row', gap: 8},
  mini: {flexDirection: 'row', gap: 4, alignItems: 'center', minHeight: 28, paddingHorizontal: 4},
  miniLiked: {backgroundColor: C.soft, borderRadius: 12, paddingHorizontal: 8},
  miniText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  miniTextMine: {color: 'rgba(255,255,255,.9)'},
  miniTextLiked: {color: C.navy},
  reportBox: {width: '100%', marginTop: 8},
  label: {fontSize: 14, color: C.navy, fontWeight: '800'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  reportButtons: {gap: 10},
  ok: {fontSize: 13, lineHeight: 19, color: '#0d6e4a'},
  err: {fontSize: 13, lineHeight: 19, color: '#a23842'},
  composer: {backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#dce8f5', paddingHorizontal: 12, paddingTop: 10, paddingBottom: 10, gap: 6},
  input: {minHeight: 48, borderRadius: 18, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  sendRow: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  count: {fontSize: 12, color: C.muted},
  cost: {fontSize: 12, color: C.muted, fontWeight: '700'},
  rowTitle: {fontSize: 17, fontWeight: '800', color: C.navy},
  postHead: {flexDirection: 'row', alignItems: 'center', gap: 10},
  postActions: {flexDirection: 'row', gap: 8, alignItems: 'center', borderTopWidth: 1, borderTopColor: '#eef3fa', paddingTop: 10},
});
