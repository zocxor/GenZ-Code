/**
 * Code Tokens: the earn-and-spend currency of GenZ Codebook.
 *
 * Pure logic only — no React Native, no Firebase — so the rules are unit-tested
 * in Node. The live balance lives in the learning state (profile.ts) on this
 * device. Earned and spent tokens stay device-local, because a wallet cannot
 * be merged last-writer-wins without losing concurrent earns/spends. PURCHASED
 * tokens are different: every purchase is also written to the account's
 * Firestore ledger (users/{uid}/tokenLedger, src/tokenLedger.ts), keyed by the
 * Google Play order ID, so a purchase can never be credited twice and the
 * history survives logout, reinstall and device change. The public leaderboard
 * (src/tokensSync.ts) mirrors the balance, opt-in only.
 *
 * Earning (all local, all free):
 *  - Rewarded ad, watched by choice: +10
 *  - First activity of a new day: +5, plus +25 every 7th day of a streak
 *  - Daily reward, collected by tap once a day: +10
 *  - Quiz: +1 per point a new personal best improves by; a perfect round: +10
 *  - Daily Five finished: +15, once per day
 *  - A suggested word a moderator accepts: +20
 *  - Buying a token package on Google Play: see TOKEN_PRODUCTS below
 * Spending:
 *  - Suggest a word: 20 — earn them by watching ads, playing quizzes, or
 *    buying a package. Staff (admins and moderators) suggest for free.
 *  - Edit one of your own suggested words: 250 per edit, charged only
 *    after the new wording is saved. Everyone pays, staff included.
 *  - Community message: 10 per message (everyone pays, staff included).
 *  - Unlock a quiz level early: 50 (skips the 60% requirement for one level)
 */
export const TOKENS = {
  REWARDED_AD: 10,
  DAILY_VISIT: 5,
  DAILY_COLLECT: 10,
  STREAK_WEEK_BONUS: 25,
  ACCEPTED_WORD: 20,
  SUGGEST_COST: 20,
  // Editing one of your own suggested words costs 250 tokens per edit (see
  // src/MySuggestionsScreen.tsx). The charge happens only after the new
  // wording is saved to the server, never on a failed save.
  EDIT_SUGGESTION_COST: 250,
  CHAT_MESSAGE_COST: 1,
  // Creating a Community post costs 25 tokens (chat messages are 1 token).
  // The posts feature itself is the next build; this pins the price here so
  // the catalog is the single source of truth for it.
  POST_COST: 25,
  UNLOCK_LEVEL_COST: 50,
  DAILY_FIVE: 15,
  PERFECT_ROUND: 10,
  MAX_BALANCE: 1_000_000,
  CREDITED_LIMIT: 400,
} as const;

/** Tokens levels. Same shape as the XP ranks, different ladder: tokens are a currency, XP is skill. */
export const TOKEN_LEVELS: [number, string][] = [[0, 'Rookie'], [100, 'Chatter'], [250, 'Word Explorer'], [500, 'Slang Star'], [900, 'Code Master'], [1500, 'Code Legend']];
export function levelFor(balance: number): {level: number; name: string; floor: number; next: {tokens: number; name: string} | null; progress: number} {
  let i = 0;
  const b = Math.max(0, Math.floor(balance));
  while (i + 1 < TOKEN_LEVELS.length && b >= TOKEN_LEVELS[i + 1]![0]) i++;
  const [floor, name] = TOKEN_LEVELS[i]!;
  const next = TOKEN_LEVELS[i + 1];
  return {level: i + 1, name, floor, next: next ? {tokens: next[0], name: next[1]} : null, progress: next ? (b - floor) / (next[0] - floor) : 1};
}

export type TokensState = {
  balance: number;
  /** YYYY-MM-DD the daily-visit bonus was last paid, so it pays once per day. */
  lastDaily: string;
  /** YYYY-MM-DD the daily reward was last COLLECTED by tap, so it pays once per day. */
  lastDailyCollect: string;
  /** YYYY-MM-DD the Daily Five bonus was last paid. */
  lastDailyFive: string;
  /** Keys already paid the accepted-word bonus: `sub:<submission doc id>`. */
  credited: string[];
  /** Quiz stage ids unlocked early with tokens. */
  unlockedLevels: string[];
  /** Opted in to the public leaderboard (nickname + tokens, nothing else). */
  leaderboard: boolean;
  /** Update stamp (wall-clock ms). */
  u: number;
};

export function emptyTokens(): TokensState {
  return {balance: 0, lastDaily: '', lastDailyCollect: '', lastDailyFive: '', credited: [], unlockedLevels: [], leaderboard: false, u: 0};
}

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const STAGE_ID = /^(?:chat|emoji|campus|context|shuffle-[a-z]{1,20}|daily-\d{4}-\d{2}-\d{2}|(?:chat|emoji|numbers)-\d{1,2})$/;
const CREDIT_KEY = /^(?:sub|word):[A-Za-z0-9_-]{1,100}$/;
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const num = (v: unknown, min: number = 0, max: number = TOKENS.MAX_BALANCE): v is number => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;

/** Strictly parse stored tokens. Never throws; invalid parts fall back to defaults. */
export function parseTokens(input: unknown): TokensState {
  const p = emptyTokens();
  if (!isObj(input)) return p;
  p.balance = num(input.balance) ? Math.floor(input.balance) : 0;
  p.lastDaily = typeof input.lastDaily === 'string' && DAY.test(input.lastDaily) ? input.lastDaily : '';
  p.lastDailyCollect = typeof input.lastDailyCollect === 'string' && DAY.test(input.lastDailyCollect) ? input.lastDailyCollect : '';
  p.lastDailyFive = typeof input.lastDailyFive === 'string' && DAY.test(input.lastDailyFive) ? input.lastDailyFive : '';
  if (Array.isArray(input.credited)) p.credited = input.credited.filter((k): k is string => typeof k === 'string' && CREDIT_KEY.test(k)).slice(-TOKENS.CREDITED_LIMIT);
  if (Array.isArray(input.unlockedLevels)) p.unlockedLevels = [...new Set(input.unlockedLevels.filter((id): id is string => typeof id === 'string' && STAGE_ID.test(id)))];
  p.leaderboard = input.leaderboard === true;
  p.u = num(input.u, 0, 8.64e15) ? Math.floor(input.u) : 0;
  return p;
}

/** What suggesting a word costs right now: SUGGEST_COST, unless the user is
 *  staff (an admin or moderator), who suggest for free. */
export function suggestCost(_p: TokensState, isStaff = false): number {
  return isStaff ? 0 : TOKENS.SUGGEST_COST;
}
export function canSuggest(p: TokensState, isStaff = false): boolean {
  return p.balance >= suggestCost(p, isStaff);
}
/** What editing one of your own suggested words costs: EDIT_SUGGESTION_COST,
 *  for everyone — there is no staff exception for edits. */
export function editSuggestionCost(_p: TokensState): number {
  return TOKENS.EDIT_SUGGESTION_COST;
}
export function canEditSuggestion(p: TokensState): boolean {
  return p.balance >= TOKENS.EDIT_SUGGESTION_COST;
}
export function canUnlockLevel(p: TokensState, stageId: string): boolean {
  return !p.unlockedLevels.includes(stageId) && p.balance >= TOKENS.UNLOCK_LEVEL_COST;
}

// ---------- Google Play token packages (consumable in-app products) ----------

/** The seven consumable token packages sold through Google Play Billing.
 *  Prices are NOT in code: they live in Play Console (per-country pricing)
 *  and the app shows Play's localized price at runtime. The token counts here
 *  are the single source of truth for crediting — the Firestore rules enforce
 *  the same table, so a ledger entry can only credit the exact amount for its
 *  product. Product IDs must match Play Console exactly. */
export const TOKEN_PRODUCTS = [
  {id: 'tokens_1000', tokens: 1000},
  {id: 'tokens_2500', tokens: 2500},
  {id: 'tokens_5000', tokens: 5000},
  {id: 'tokens_10000', tokens: 10000},
  {id: 'tokens_25000', tokens: 25000},
  {id: 'tokens_50000', tokens: 50000},
  {id: 'tokens_100000', tokens: 100000},
] as const;
export type TokenProductId = (typeof TOKEN_PRODUCTS)[number]['id'];
export function tokensForProduct(productId: string): number | null {
  const found = TOKEN_PRODUCTS.find(p => p.id === productId);
  return found ? found.tokens : null;
}

/** Ledger transaction kinds (users/{uid}/tokenLedger). `purchase` is the only
 *  kind that moves real money; the rest are the local earn/spend history. */
export type TokenTxnType = 'purchase' | 'subscription' | 'daily' | 'ad' | 'game' | 'spend' | 'adjustment' | 'migration';

/** The Firestore document ID for a purchase ledger entry. One document per
 *  Google Play order ID: a second credit for the same order writes the same
 *  ID, and the rules (create-only) refuse it — that is the duplicate guard. */
export function purchaseTxnId(orderId: string): string {
  return `order-${orderId}`;
}
/** The one-time opening-balance entry written when an existing local balance
 *  is first recorded in the ledger (the pre-ledger balance had no history). */
export const MIGRATION_TXN_ID = 'migration-v1';
