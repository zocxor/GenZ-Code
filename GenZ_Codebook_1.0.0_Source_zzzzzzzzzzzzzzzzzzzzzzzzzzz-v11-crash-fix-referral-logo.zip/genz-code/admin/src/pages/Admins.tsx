import React, {useState} from 'react';
import {collection, getDocs, doc, serverTimestamp} from 'firebase/firestore/lite';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {ROLES, ROLE_LABELS, PERMISSIONS, Role} from '../rbac';
import {Card, Stats, Stat, Skeleton, Notice, Pill, Field, ConfirmButton, useLoad, when} from '../ui';

const AdminsIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" /><polyline points="9 12 11 14 15 10" /></svg>;
const ActiveIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg>;
const RevokedIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="4.93" y1="4.93" x2="19.07" y2="19.07" /></svg>;
const RolesIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="15" r="4" /><path d="M10.85 12.15L19 4" /><line x1="15" y1="8" x2="19" y2="4" /><line x1="18" y1="5" x2="21" y2="8" /></svg>;

export default function Admins() {
  const s = useSession();
  const admins = useLoad(async () => (await getDocs(collection(db, 'admins'))).docs.map(d => ({uid: d.id, ...d.data()} as {uid: string; role: Role; active: boolean; email: string; updatedAt?: {toMillis(): number}})), []);
  const [uid, setUid] = useState(''), [email, setEmail] = useState(''), [role, setRole] = useState<Role>('analyst');
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  const write = async (target: string, data: {role: Role; active: boolean; email: string}, summary: string) => {
    setBusy(true); setMsg(null);
    try {
      if (target === s.uid) throw Object.assign(new Error(), {code: 'self'});
      const b = newBatch();
      const lastAuditId = addAudit(b, s.uid, s.role, 'admin.role.set', `admins/${target}`, summary);
      b.set(doc(db, 'admins', target), {...data, updatedAt: serverTimestamp(), updatedBy: s.uid, lastAuditId});
      await b.commit();
      setMsg({kind: 'ok', text: 'Saved. The change applies on the person’s next request.'}); admins.reload();
    } catch (e) {setMsg({kind: 'error', text: (e as {code?: string}).code === 'self' ? 'You cannot change your own role. Ask another Super Admin.' : errorMessage(e)});} finally {setBusy(false);}
  };
  const list = admins.data ?? null;
  return <div className="stack">
    {admins.loading ? <Skeleton rows={4} /> : admins.error ? <Notice kind="error">{errorMessage(admins.error)}</Notice> : <Stats>
      <Stat label="Administrators" num={list ? list.length : null} icon={AdminsIcon} tint="blue" />
      <Stat label="Active admins" num={list ? list.filter(a => a.active === true).length : null} icon={ActiveIcon} tint="green" />
      <Stat label="Revoked" num={list ? list.filter(a => a.active === false).length : null} icon={RevokedIcon} tint="red" />
      <Stat label="Roles" num={ROLES.length} hint="defined in rbac.ts" icon={RolesIcon} tint="purple" />
    </Stats>}
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    <Card title="Grant or change a role" subtitle="Find the user ID in Users. Changes are audited; you cannot edit your own record.">
      <div className="form-grid">
        <Field label="User ID"><input value={uid} onChange={e => setUid(e.target.value.trim())} maxLength={128} /></Field>
        <Field label="E-mail (for display)"><input type="email" value={email} onChange={e => setEmail(e.target.value.trim())} maxLength={254} /></Field>
        <Field label="Role"><select value={role} onChange={e => setRole(e.target.value as Role)}>{ROLES.map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}</select></Field>
      </div>
      <button className="btn primary" disabled={busy || !/^[A-Za-z0-9_-]{6,128}$/.test(uid) || !email.includes('@')} onClick={() => void write(uid, {role, active: true, email}, `grant ${role}`)}>Save role</button>
    </Card>
    <Card title="Administrators">
      {admins.error ? <Notice kind="error">{errorMessage(admins.error)}</Notice> : <div className="table-wrap"><table><thead><tr><th>Admin</th><th>Role</th><th>Status</th><th>Updated</th><th /></tr></thead><tbody>{admins.data?.map(a => <tr key={a.uid}>
        <td>{a.email}<br /><code className="small">{a.uid}</code></td><td>{ROLE_LABELS[a.role] ?? a.role}</td><td><Pill tone={a.active ? 'good' : 'bad'}>{a.active ? 'active' : 'revoked'}</Pill></td><td>{when(a.updatedAt)}</td>
        <td>{a.uid !== s.uid && (a.active ? <ConfirmButton label="Revoke" word="REVOKE" disabled={busy} onConfirm={() => void write(a.uid, {role: a.role, active: false, email: a.email}, 'revoke access')} /> : <button className="btn ghost" disabled={busy} onClick={() => void write(a.uid, {role: a.role, active: true, email: a.email}, 'restore access')}>Restore</button>)}</td>
      </tr>)}</tbody></table></div>}
    </Card>
    <Card title="Role permissions">
      <div className="table-wrap"><table><thead><tr><th>Role</th><th>Permissions</th></tr></thead><tbody>{ROLES.map(r => <tr key={r}><td>{ROLE_LABELS[r]}</td><td className="small">{PERMISSIONS[r].join(' · ')}</td></tr>)}</tbody></table></div>
    </Card>
  </div>;
}
