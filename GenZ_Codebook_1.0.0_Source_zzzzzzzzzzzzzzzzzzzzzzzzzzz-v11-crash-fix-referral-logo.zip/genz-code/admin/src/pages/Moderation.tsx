import React, {useEffect, useMemo, useRef, useState} from 'react';
import {collection, query, where, orderBy, limit, getDocs, doc, getDoc, serverTimestamp} from 'firebase/firestore/lite';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can} from '../rbac';
import {Card, Stats, Stat, Skeleton, Notice, Pill, Field, ConfirmButton, useLoad, when, fmt} from '../ui';
import {moderationMetrics} from '../lib/metrics';
import {validateEntry, CONTENT_CATEGORIES} from '../../../shared/contentSchema';
import {communityId} from '../../../shared/community';
import {slugId} from '../lib/contentOps';

type Sub = {id: string; term: string; meaning: string; example: string; category: string; uid: string; createdAt: {toMillis(): number}};
type Rep = {id: string; termId: string; reason: string; note: string; uid: string; createdAt: {toMillis(): number}};
type ChatRep = {id: string; messageId: string; reason: string; note: string; uid: string; createdAt: {toMillis(): number}};
type ChatMsg = {id: string; uid: string; name: string; text: string; status: 'live' | 'hidden'; createdAt: {toMillis(): number}};
type Fb = {id: string; rating: number; message: string; appVersion: string; platform: string; createdAt: {toMillis(): number}};
type Word = {id: string; term: string; meaning: string; example: string; category: string; uid: string; status: 'live' | 'hidden'; createdAt: {toMillis(): number}};
const list = async <T,>(name: string, status: string) => (await getDocs(query(collection(db, name), where('status', '==', status), orderBy('createdAt', 'desc'), limit(100)))).docs.map(d => ({id: d.id, ...d.data()}) as T);

type Identity = {name: string | null; email: string | null};
/** Resolve contributor UIDs to their nickname (synced profile name) and e-mail.
    The rules gate directory + sync/profile to PII roles (super_admin, support_admin),
    so roles without users.pii never attempt the reads and keep the UID fallback.
    Each UID is fetched once and cached, so the table does not re-read per render. */
function useIdentities(uids: string[], canSeePii: boolean) {
  const [map, setMap] = useState<Record<string, Identity>>({});
  const requested = useRef<Set<string>>(new Set());
  const key = useMemo(() => [...new Set(uids)].sort().join('|'), [uids]);
  useEffect(() => {
    if (!canSeePii) return;
    const missing = [...new Set(uids)].filter(u => u && !requested.current.has(u));
    if (!missing.length) return;
    for (const u of missing) requested.current.add(u);
    void Promise.all(missing.map(async u => {
      try {
        const [dir, prof] = await Promise.all([getDoc(doc(db, 'directory', u)), getDoc(doc(db, 'users', u, 'sync', 'profile'))]);
        const email = dir.exists() ? String((dir.data() as {email?: unknown}).email ?? '') : '';
        const name = prof.exists() ? String(((prof.data() as {profile?: {name?: unknown}}).profile?.name ?? '')) : '';
        return [u, {name: name || null, email: email || null}] as const;
      } catch {return [u, {name: null, email: null}] as const;}
    })).then(entries => setMap(m => ({...m, ...Object.fromEntries(entries)})));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, canSeePii]);
  return map;
}

/** Row-action icons (inline stroke SVGs, same style as the sidebar icons). */
const icoProps = {width: 16, height: 16, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round'} as const;
const icoPencil = <svg {...icoProps}><path d="M17 3a2.8 2.8 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z" /></svg>;
const icoEye = <svg {...icoProps}><path d="M2 12s3-8 10-8 10 8 10 8-3 8-10 8-10-8-10-8Z" /><circle cx="12" cy="12" r="3" /></svg>;
const icoEyeOff = <svg {...icoProps}><path d="M9.9 4.24A9.5 9.5 0 0 1 12 4c7 0 10 8 10 8a17 17 0 0 1-2.16 3.19M6.61 6.61A16.5 16.5 0 0 0 2 12s3 8 10 8a9.6 9.6 0 0 0 5.39-1.61" /><path d="m2 2 20 20" /><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" /></svg>;
const icoTrash = <svg {...icoProps}><path d="M3 6h18" /><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" /><path d="M10 11v6M14 11v6" /></svg>;

/** Stat icons (20px, same stroke style as the row-action icons). */
const statIcoProps = {width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round'} as const;
const icoInbox = <svg {...statIcoProps}><path d="M22 12h-6l-2 3h-4l-2-3H2" /><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11Z" /></svg>;
const icoFlag = <svg {...statIcoProps}><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" /><path d="M4 22v-7" /></svg>;
const icoChat = <svg {...statIcoProps}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z" /></svg>;
const icoStar = <svg {...statIcoProps}><path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01Z" /></svg>;

export default function Moderation({feedbackOnly = false}: {feedbackOnly?: boolean}) {
  const s = useSession();
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  const subs = useLoad(() => (!feedbackOnly && can(s.role, 'submissions.review') ? list<Sub>('submissions', 'pending') : Promise.resolve([])), []);
  const reps = useLoad(() => (!feedbackOnly && can(s.role, 'reports.moderate') ? list<Rep>('reports', 'open') : Promise.resolve([])), []);
  const [wordView, setWordView] = useState<'live' | 'hidden'>('live');
  const words = useLoad(() => (!feedbackOnly && can(s.role, 'submissions.review') ? list<Word>('communityWords', wordView) : Promise.resolve([])), [wordView]);
  const chatReps = useLoad(() => (!feedbackOnly && can(s.role, 'reports.moderate') ? list<ChatRep>('chatReports', 'open') : Promise.resolve([])), []);
  const [chatView, setChatView] = useState<'live' | 'hidden'>('live');
  const chatMsgs = useLoad(() => (!feedbackOnly && can(s.role, 'reports.moderate') ? list<ChatMsg>('communityMessages', chatView) : Promise.resolve([])), [chatView]);
  const fbs = useLoad(() => (can(s.role, 'feedback.read') && (feedbackOnly || s.role === 'super_admin') ? list<Fb>('feedback', 'new') : Promise.resolve([])), []);
  const metrics = useLoad(() => moderationMetrics(), []);
  const [editingWord, setEditingWord] = useState<Word | null>(null), [deletingWord, setDeletingWord] = useState<Word | null>(null);
  const allUids = useMemo(() => [...(words.data ?? []).map(w => w.uid), ...(subs.data ?? []).map(x => x.uid)], [words.data, subs.data]);
  const identities = useIdentities(allUids, can(s.role, 'users.pii'));
  /** Name (bold) + e-mail (small) for the suggester; the truncated UID only when
      neither resolves (or the role may not read PII). Full UID on hover. */
  const byCell = (uid: string) => {
    const id = identities[uid];
    if (id?.name) return <span title={uid}><strong>{id.name}</strong>{id.email ? <><br /><span className="muted small">{id.email}</span></> : null}</span>;
    if (id?.email) return <span title={uid}><strong>{id.email}</strong></span>;
    return <code title={uid}>{uid.slice(0, 8)}…</code>;
  };
  const run = async (fn: () => Promise<void>, ok: string, reload: () => void) => {setBusy(true); setMsg(null); try {await fn(); setMsg({kind: 'ok', text: ok}); reload(); metrics.reload();} catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}};

  /** Accept = one atomic batch: new CMS draft (+version, audited) and the submission update (audited). */
  const accept = (x: Sub) => run(async () => {
    const v = validateEntry({term: x.term, meaning: x.meaning, example: x.example, category: x.category});
    if (!v.ok) throw new Error(v.errors.join(' '));
    const id = slugId(x.term), b = newBatch();
    const contentAudit = addAudit(b, s.uid, s.role, 'content.create', `content/${id}`, `from suggestion ${x.id}`);
    const entry = {...v.entry, id};
    b.set(doc(db, 'content', id), {...entry, status: 'draft', version: 1, createdAt: serverTimestamp(), updatedAt: serverTimestamp(), updatedBy: s.uid, lastAuditId: contentAudit});
    b.set(doc(db, 'content', id, 'versions', '1'), {snapshot: {...entry, status: 'draft'}, by: s.uid, at: serverTimestamp(), action: 'create'});
    const subAudit = addAudit(b, s.uid, s.role, 'submission.accept', `submissions/${x.id}`, x.term);
    b.update(doc(db, 'submissions', x.id), {status: 'accepted', reviewedBy: s.uid, reviewedAt: serverTimestamp(), contentId: id, lastAuditId: subAudit});
    await b.commit();
  }, 'Accepted. A draft was created in Content for editing and review — nothing is published yet.', subs.reload);
  const reject = (x: Sub) => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, 'submission.reject', `submissions/${x.id}`, x.term);
    b.update(doc(db, 'submissions', x.id), {status: 'rejected', reviewedBy: s.uid, reviewedAt: serverTimestamp(), lastAuditId});
    await b.commit();
  }, 'Suggestion rejected.', subs.reload);
  const resolve = (x: Rep, status: 'resolved' | 'dismissed', resolution: string) => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, status === 'resolved' ? 'report.resolve' : 'report.dismiss', `reports/${x.id}`, `${x.termId}: ${resolution}`);
    b.update(doc(db, 'reports', x.id), {status, resolvedBy: s.uid, resolvedAt: serverTimestamp(), resolution: resolution.slice(0, 300), lastAuditId});
    await b.commit();
  }, `Report ${status}.`, reps.reload);
  /** Hide or restore a community word: one audited batch; every app drops/re-adds it on its next refresh. */
  const moderateWord = (x: Word, status: 'live' | 'hidden') => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, status === 'hidden' ? 'community.hide' : 'community.restore', `communityWords/${x.id}`, x.term);
    b.update(doc(db, 'communityWords', x.id), {status, updatedAt: serverTimestamp(), lastAuditId});
    await b.commit();
  }, status === 'hidden' ? `“${x.term}” hidden. Apps remove it within about 10 minutes.` : `“${x.term}” restored.`, words.reload);
  /** Delete a community word: one audited batch (audit entry + delete). The rules
      gate the delete on the moderator role; the audit entry is the trail. */
  const deleteWord = (x: Word) => run(async () => {
    const b = newBatch();
    addAudit(b, s.uid, s.role, 'community.delete', `communityWords/${x.id}`, x.term);
    b.delete(doc(db, 'communityWords', x.id));
    await b.commit();
  }, `“${x.term}” deleted.`, () => {setDeletingWord(null); words.reload();});
  /** Hide or restore a chat message: one audited batch; the room drops/re-adds it live. */
  const moderateChat = (x: ChatMsg, status: 'live' | 'hidden') => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, status === 'hidden' ? 'chat.hide' : 'chat.restore', `communityMessages/${x.id}`, `${x.name}: ${x.text.slice(0, 80)}`);
    b.update(doc(db, 'communityMessages', x.id), {status, updatedAt: serverTimestamp(), lastAuditId});
    await b.commit();
  }, status === 'hidden' ? 'Chat message hidden. It disappears from the room immediately.' : 'Chat message restored.', chatMsgs.reload);
  const resolveChatReport = (x: ChatRep, status: 'resolved' | 'dismissed', resolution: string) => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, status === 'resolved' ? 'chat.report.resolve' : 'chat.report.dismiss', `chatReports/${x.id}`, `${x.messageId}: ${resolution}`);
    b.update(doc(db, 'chatReports', x.id), {status, resolvedBy: s.uid, resolvedAt: serverTimestamp(), resolution: resolution.slice(0, 300), lastAuditId});
    await b.commit();
  }, `Chat report ${status}.`, chatReps.reload);
  const triage = (x: Fb) => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, 'feedback.triage', `feedback/${x.id}`, `rating ${x.rating}`);
    b.update(doc(db, 'feedback', x.id), {status: 'triaged', triagedBy: s.uid, triagedAt: serverTimestamp(), lastAuditId});
    await b.commit();
  }, 'Marked as triaged.', fbs.reload);

  return <div className="stack">
    {!feedbackOnly && (can(s.role, 'submissions.review') || can(s.role, 'reports.moderate') || can(s.role, 'feedback.read')) && (metrics.loading ? <Skeleton /> : metrics.data ? <Stats>
      {can(s.role, 'submissions.review') && <Stat label="Pending suggestions" num={metrics.data.pending} icon={icoInbox} tint="blue" />}
      {can(s.role, 'reports.moderate') && <Stat label="Open content reports" num={metrics.data.openReports} icon={icoFlag} tint="amber" />}
      {can(s.role, 'reports.moderate') && <Stat label="Open chat reports" num={metrics.data.openChatReports} icon={icoChat} tint="purple" />}
      {can(s.role, 'feedback.read') && <Stat label="Feedback new" num={metrics.data.feedbackNew} icon={icoStar} tint="pink" />}
    </Stats> : null)}
    {feedbackOnly && can(s.role, 'feedback.read') && (metrics.loading ? <Skeleton /> : metrics.data ? <Stats>
      <Stat label="Feedback new" num={metrics.data.feedbackNew} icon={icoStar} tint="pink" />
      <Stat label="Feedback total" num={metrics.data.feedbackTotal} icon={icoInbox} tint="blue" />
      <Stat label="Avg. rating" value={metrics.data.avgRating === null ? '—' : `${metrics.data.avgRating.toFixed(2)} / 5`} icon={icoStar} tint="purple" />
    </Stats> : null)}
    {!feedbackOnly && <p className="muted">Community words go live instantly when “Publish suggested words instantly” is on (Settings). Hide anything inappropriate below. Words caught by the app’s word filter, and all words while instant publishing is off, wait under Word suggestions. Chat messages are screened before sending and can be reported by any user; hide a message here and it disappears from the room immediately. Everything here is untrusted and shown as plain text.</p>}
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    {editingWord && <WordEditor word={editingWord} onClose={() => setEditingWord(null)} onSaved={() => {setEditingWord(null); words.reload();}} />}
    {deletingWord && <Card title={`Delete “${deletingWord.term}”`} subtitle="This permanently removes the word from the app for everyone. The deletion is recorded in the audit log (action 'community.delete').">
      <p><strong>{deletingWord.term}</strong> — {deletingWord.meaning}</p>
      <div className="row"><ConfirmButton label="Delete word" word="DELETE" disabled={busy} onConfirm={() => void deleteWord(deletingWord)} /><button className="btn ghost" onClick={() => setDeletingWord(null)}>Cancel</button></div>
    </Card>}
    {!feedbackOnly && can(s.role, 'submissions.review') && <Card title="Community words" subtitle={`${fmt(words.data?.length)} ${wordView} (newest 100)`}>
      <div className="row"><button className={wordView === 'live' ? 'btn' : 'btn ghost'} onClick={() => setWordView('live')}>Live</button><button className={wordView === 'hidden' ? 'btn' : 'btn ghost'} onClick={() => setWordView('hidden')}>Hidden</button></div>
      {words.error ? <Notice kind="error">{errorMessage(words.error)}</Notice> : words.data?.length ? <div className="table-wrap"><table><thead><tr><th>Word</th><th>Meaning / example</th><th>Category</th><th>Added</th><th>By</th><th /></tr></thead><tbody>{words.data.map(x => <tr key={x.id}><td><strong>{x.term}</strong><br /><code className="muted">{x.id}</code></td><td className="clip">{x.meaning}{x.example ? <><br /><em className="muted">“{x.example}”</em></> : null}</td><td>{x.category}</td><td>{when(x.createdAt)}</td><td>{byCell(x.uid)}</td><td><span className="row-actions">
        {can(s.role, 'submissions.review') && <button className="icon-btn" title="Edit word" aria-label={`Edit ${x.term}`} disabled={busy} onClick={() => {setDeletingWord(null); setEditingWord(x);}}>{icoPencil}</button>}
        {x.status === 'live' ? <button className="icon-btn" title="Hide word" aria-label={`Hide ${x.term}`} disabled={busy} onClick={() => void moderateWord(x, 'hidden')}>{icoEyeOff}</button> : <button className="icon-btn" title="Restore word" aria-label={`Restore ${x.term}`} disabled={busy} onClick={() => void moderateWord(x, 'live')}>{icoEye}</button>}
        {can(s.role, 'submissions.review') && <button className="icon-btn danger" title="Delete word" aria-label={`Delete ${x.term}`} disabled={busy} onClick={() => {setEditingWord(null); setDeletingWord(x);}}>{icoTrash}</button>}
      </span></td></tr>)}</tbody></table></div> : <p className="muted">{words.loading ? 'Loading…' : wordView === 'live' ? 'No community words yet.' : 'No hidden words.'}</p>}
    </Card>}
    {!feedbackOnly && can(s.role, 'submissions.review') && <Card title="Word suggestions" subtitle={`${fmt(subs.data?.length)} pending (newest 100)`}>
      {subs.error ? <Notice kind="error">{errorMessage(subs.error)}</Notice> : subs.data?.length ? <div className="table-wrap"><table><thead><tr><th>Term</th><th>Meaning / example</th><th>Category</th><th>Received</th><th>By</th><th /></tr></thead><tbody>{subs.data.map(x => <tr key={x.id}><td><strong>{x.term}</strong></td><td className="clip">{x.meaning}{x.example ? <><br /><em className="muted">“{x.example}”</em></> : null}</td><td>{x.category}</td><td>{when(x.createdAt)}</td><td>{byCell(x.uid)}</td><td className="row"><button className="btn" disabled={busy} onClick={() => void accept(x)}>Accept as draft</button><button className="btn ghost" disabled={busy} onClick={() => void reject(x)}>Reject</button></td></tr>)}</tbody></table></div> : <p className="muted">{subs.loading ? 'Loading…' : 'No pending suggestions.'}</p>}
    </Card>}
    {!feedbackOnly && can(s.role, 'reports.moderate') && <Card title="Community chat" subtitle={`${fmt(chatMsgs.data?.length)} ${chatView} (newest 100)`}>
      <div className="row"><button className={chatView === 'live' ? 'btn' : 'btn ghost'} onClick={() => setChatView('live')}>Live</button><button className={chatView === 'hidden' ? 'btn' : 'btn ghost'} onClick={() => setChatView('hidden')}>Hidden</button></div>
      {chatMsgs.error ? <Notice kind="error">{errorMessage(chatMsgs.error)}</Notice> : chatMsgs.data?.length ? <div className="table-wrap"><table><thead><tr><th>Nickname</th><th>Message</th><th>Sent</th><th>By</th><th /></tr></thead><tbody>{chatMsgs.data.map(x => <tr key={x.id}><td><strong>{x.name}</strong></td><td className="clip">{x.text}</td><td>{when(x.createdAt)}</td><td><code title={x.uid}>{x.uid.slice(0, 8)}…</code></td><td>{x.status === 'live' ? <button className="btn ghost" disabled={busy} onClick={() => void moderateChat(x, 'hidden')}>Hide</button> : <button className="btn" disabled={busy} onClick={() => void moderateChat(x, 'live')}>Restore</button>}</td></tr>)}</tbody></table></div> : <p className="muted">{chatMsgs.loading ? 'Loading…' : chatView === 'live' ? 'No chat messages yet.' : 'No hidden messages.'}</p>}
    </Card>}
    {!feedbackOnly && can(s.role, 'reports.moderate') && <Card title="Chat reports" subtitle={`${fmt(chatReps.data?.length)} open (newest 100)`}>
      {chatReps.error ? <Notice kind="error">{errorMessage(chatReps.error)}</Notice> : chatReps.data?.length ? <div className="table-wrap"><table><thead><tr><th>Message</th><th>Reason</th><th>Note</th><th>Received</th><th /></tr></thead><tbody>{chatReps.data.map(x => <ChatReportRow key={x.id} x={x} busy={busy} onResolve={resolveChatReport} />)}</tbody></table></div> : <p className="muted">{chatReps.loading ? 'Loading…' : 'No open chat reports.'}</p>}
    </Card>}
    {!feedbackOnly && can(s.role, 'reports.moderate') && <Card title="Content reports" subtitle={`${fmt(reps.data?.length)} open (newest 100)`}>
      {reps.error ? <Notice kind="error">{errorMessage(reps.error)}</Notice> : reps.data?.length ? <div className="table-wrap"><table><thead><tr><th>Entry</th><th>Reason</th><th>Note</th><th>Received</th><th /></tr></thead><tbody>{reps.data.map(x => <ReportRow key={x.id} x={x} busy={busy} onResolve={resolve} />)}</tbody></table></div> : <p className="muted">{reps.loading ? 'Loading…' : 'No open reports.'}</p>}
    </Card>}
    {can(s.role, 'feedback.read') && (feedbackOnly || s.role === 'super_admin') && <Card title="App feedback" subtitle={`${fmt(fbs.data?.length)} new (newest 100). Average rating and totals are on the dashboard.`}>
      {fbs.error ? <Notice kind="error">{errorMessage(fbs.error)}</Notice> : fbs.data?.length ? <div className="table-wrap"><table><thead><tr><th>Rating</th><th>Message</th><th>App</th><th>Received</th><th /></tr></thead><tbody>{fbs.data.map(x => <tr key={x.id}><td><Pill tone={x.rating >= 4 ? 'good' : x.rating <= 2 ? 'bad' : 'warn'}>{x.rating} / 5</Pill></td><td className="clip">{x.message || <span className="muted">—</span>}</td><td>{x.appVersion} · {x.platform}</td><td>{when(x.createdAt)}</td><td>{can(s.role, 'feedback.triage') && <button className="btn ghost" disabled={busy} onClick={() => void triage(x)}>Mark triaged</button>}</td></tr>)}</tbody></table></div> : <p className="muted">{fbs.loading ? 'Loading…' : 'No new feedback.'}</p>}
    </Card>}
  </div>;
}

/** Edit a live or hidden community word. The document ID never changes (the rules
    require id == doc id); only the text fields move, and the edit is audited as
    'community.edit'. A changed term must not collide with another live word. */
function WordEditor({word, onClose, onSaved}: {word: Word; onClose: () => void; onSaved: () => void}) {
  const s = useSession();
  const [term, setTerm] = useState(word.term), [meaning, setMeaning] = useState(word.meaning), [example, setExample] = useState(word.example), [category, setCategory] = useState(word.category);
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null);
  const check = validateEntry({term, meaning, example, category});
  const save = async () => {
    if (!check.ok) {setMsg({kind: 'error', text: check.errors.join(' ')}); return;}
    setBusy(true); setMsg(null);
    try {
      const newId = communityId(check.entry.term);
      if (newId !== word.id) {
        const existing = await getDoc(doc(db, 'communityWords', newId));
        if (existing.exists() && (existing.data() as {status?: string}).status === 'live') throw new Error(`“${check.entry.term}” is already a live community word.`);
      }
      const b = newBatch();
      const lastAuditId = addAudit(b, s.uid, s.role, 'community.edit', `communityWords/${word.id}`, word.term);
      b.update(doc(db, 'communityWords', word.id), {term: check.entry.term, meaning: check.entry.meaning, example: check.entry.example, category: check.entry.category, updatedAt: serverTimestamp(), lastAuditId});
      await b.commit();
      onSaved();
    } catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };
  return <Card title={`Edit “${word.term}”`} subtitle="Changes reach the app on its next content refresh (within about 10 minutes). The edit is recorded in the audit log.">
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    <div className="form-grid">
      <Field label="Word (max 60)"><input value={term} onChange={e => setTerm(e.target.value)} maxLength={60} /></Field>
      <Field label="Category"><select value={category} onChange={e => setCategory(e.target.value)}>{CONTENT_CATEGORIES.map(c => <option key={c}>{c}</option>)}</select></Field>
      <Field label="Meaning (max 500)"><textarea rows={3} value={meaning} onChange={e => setMeaning(e.target.value)} maxLength={500} /></Field>
      <Field label="Example (max 300)"><textarea rows={2} value={example} onChange={e => setExample(e.target.value)} maxLength={300} /></Field>
    </div>
    {!check.ok && <Notice kind="error">{check.errors.join(' ')}</Notice>}
    <div className="row"><button className="btn primary" disabled={busy || !check.ok} onClick={() => void save()}>{busy ? 'Saving…' : 'Save word'}</button><button className="btn ghost" disabled={busy} onClick={onClose}>Cancel</button></div>
  </Card>;
}

function ReportRow({x, busy, onResolve}: {x: Rep; busy: boolean; onResolve: (x: Rep, s: 'resolved' | 'dismissed', note: string) => void}) {
  const [note, setNote] = useState('');
  return <tr><td><code>{x.termId}</code></td><td>{x.reason}</td><td className="clip">{x.note || <span className="muted">—</span>}</td><td>{when(x.createdAt)}</td>
    <td><input aria-label="Resolution note" placeholder="Resolution note" value={note} onChange={e => setNote(e.target.value)} maxLength={300} /><div className="row"><button className="btn" disabled={busy} onClick={() => onResolve(x, 'resolved', note)}>Resolve</button><button className="btn ghost" disabled={busy} onClick={() => onResolve(x, 'dismissed', note)}>Dismiss</button></div></td></tr>;
}

/** A reported chat message, with the message text loaded for the moderator. */
function ChatReportRow({x, busy, onResolve}: {x: ChatRep; busy: boolean; onResolve: (x: ChatRep, s: 'resolved' | 'dismissed', note: string) => void}) {
  const [note, setNote] = useState('');
  const [text, setText] = useState<string | null>(null);
  React.useEffect(() => {
    let alive = true;
    void getDoc(doc(db, 'communityMessages', x.messageId)).then(d => {if (alive) setText(d.exists() ? String((d.data() as {text?: unknown}).text ?? '') : '(message deleted)');}).catch(() => {if (alive) setText('(couldn’t load)');});
    return () => {alive = false;};
  }, [x.messageId]);
  return <tr><td className="clip">{text ?? 'Loading…'}{text ? <><br /><code className="muted">{x.messageId}</code></> : null}</td><td>{x.reason}</td><td className="clip">{x.note || <span className="muted">—</span>}</td><td>{when(x.createdAt)}</td>
    <td><input aria-label="Resolution note" placeholder="Resolution note" value={note} onChange={e => setNote(e.target.value)} maxLength={300} /><div className="row"><button className="btn" disabled={busy} onClick={() => onResolve(x, 'resolved', note)}>Resolve</button><button className="btn ghost" disabled={busy} onClick={() => onResolve(x, 'dismissed', note)}>Dismiss</button></div></td></tr>;
}
