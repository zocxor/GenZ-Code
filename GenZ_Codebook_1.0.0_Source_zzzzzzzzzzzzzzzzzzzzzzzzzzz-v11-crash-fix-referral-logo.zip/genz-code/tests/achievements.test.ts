import test from 'node:test';
import assert from 'node:assert/strict';
import {computeBadges} from '../src/achievements';
import {emptyState, type Profile} from '../src/profile';

function profile(over: Partial<Profile> = {}): Profile {
  return {onboarded: true, name: 'Test', avatar: 0, saved: [], progress: {}, language: 'All', best: {}, ...over};
}
const review = (mastery: number) => ({successes: 1, attempts: 1, lastReviewed: 1, nextReview: 2, mastery});

test('achievements: a fresh profile earns nothing and shows every hint', () => {
  const badges = computeBadges(emptyState(), profile());
  assert.equal(badges.length, 6);
  assert.ok(badges.every(b => !b.earned));
  assert.deepEqual(badges.map(b => b.label), ['Code cracker', 'Perfect round', 'Word collector', 'On a roll', 'Week warrior', 'Sharp memory']);
});

test('achievements: playing a level earns Code cracker', () => {
  const badges = computeBadges(emptyState(), profile({best: {chat: 40}}));
  assert.ok(badges.find(b => b.label === 'Code cracker')!.earned);
  assert.ok(!badges.find(b => b.label === 'Perfect round')!.earned);
});

test('achievements: a 100% score earns Perfect round', () => {
  const badges = computeBadges(emptyState(), profile({best: {chat: 100}}));
  assert.ok(badges.find(b => b.label === 'Perfect round')!.earned);
});

test('achievements: saving 5 words earns Word collector', () => {
  const s = emptyState();
  const badges = computeBadges(s, profile({saved: ['a', 'b', 'c', 'd', 'e']}));
  assert.ok(badges.find(b => b.label === 'Word collector')!.earned);
  const four = computeBadges(s, profile({saved: ['a', 'b', 'c', 'd']}));
  assert.ok(!four.find(b => b.label === 'Word collector')!.earned);
});

test('achievements: streaks earn On a roll at 3 days and Week warrior at 7', () => {
  const three = emptyState();
  three.days = {'2026-11-07': 1, '2026-11-08': 1, '2026-11-09': 1};
  const b3 = computeBadges(three, profile());
  assert.ok(b3.find(b => b.label === 'On a roll')!.earned);
  assert.ok(!b3.find(b => b.label === 'Week warrior')!.earned);
  const seven = emptyState();
  seven.days = Object.fromEntries(Array.from({length: 7}, (_, i) => [`2026-11-0${i + 1}`, 1]));
  const b7 = computeBadges(seven, profile());
  assert.ok(b7.find(b => b.label === 'Week warrior')!.earned);
});

test('achievements: mastering 10 words earns Sharp memory', () => {
  const p = profile({progress: Object.fromEntries(Array.from({length: 10}, (_, i) => [`w${i}`, review(85)]))});
  const badges = computeBadges(emptyState(), p);
  assert.ok(badges.find(b => b.label === 'Sharp memory')!.earned);
  const nine = profile({progress: Object.fromEntries(Array.from({length: 9}, (_, i) => [`w${i}`, review(85)]))});
  assert.ok(!computeBadges(emptyState(), nine).find(b => b.label === 'Sharp memory')!.earned);
});
