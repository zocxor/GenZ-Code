import test from 'node:test';
import assert from 'node:assert/strict';
import {TOKENS, parseTokens} from '../shared/tokens';
import {referralCodeForUid, isReferralCode, normaliseReferralCode, referralLink, parseReferralLink, referralShareMessage, referralClaimLedgerId, referralReferrerLedgerId, referralCreditKey, decideReferralClaim} from '../shared/referral';
import {emptyState} from '../src/profile';
import {creditReferrals} from '../src/learning';

test('referral: the reward is exactly 100 tokens for each user, in one place', () => {
  assert.equal(TOKENS.REFERRAL_REWARD, 100);
});

test('referral: codes are "GZ" + 6 uppercase alphanumerics, stable per UID, unique per UID', () => {
  const a = referralCodeForUid('alice-uid-123');
  const b = referralCodeForUid('bob-uid-456');
  assert.match(a, /^GZ[A-Z0-9]{6}$/);
  assert.match(b, /^GZ[A-Z0-9]{6}$/);
  assert.equal(referralCodeForUid('alice-uid-123'), a, 'same UID always yields the same code');
  assert.notEqual(a, b, 'different UIDs yield different codes');
  assert.equal(referralCodeForUid(''), '', 'no code without an account');
  // A spread of UIDs must not collide (36^6 is ~2.2 billion codes).
  const codes = new Set(Array.from({length: 1000}, (_, i) => referralCodeForUid(`user-${i}-abcdefghijklmnopqrstuvwxyz`)));
  assert.equal(codes.size, 1000);
});

test('referral: code validation is strict, normalisation is forgiving', () => {
  assert.equal(isReferralCode('GZABC123'), true);
  assert.equal(isReferralCode('GZ000000'), true);
  assert.equal(isReferralCode('gzabc123'), false, 'lower-case is not a valid code as written');
  assert.equal(isReferralCode('GZABC12'), false, 'too short');
  assert.equal(isReferralCode('GZABC1234'), false, 'too long');
  assert.equal(isReferralCode('GXABC123'), false, 'wrong prefix');
  assert.equal(isReferralCode('GZABC12!'), false, 'punctuation is not allowed');
  assert.equal(isReferralCode(''), false);
  assert.equal(isReferralCode(42), false);
  assert.equal(normaliseReferralCode('  gzabc123 '), 'GZABC123');
  assert.equal(normaliseReferralCode('GZABC123'), 'GZABC123');
});

test('referral: links use the genzcode scheme and parse back to the code', () => {
  const code = 'GZABC123';
  assert.equal(referralLink(code), 'genzcode://referral?code=GZABC123');
  assert.equal(parseReferralLink('genzcode://referral?code=GZABC123'), code);
  assert.equal(parseReferralLink('genzcode://referral/GZABC123'), code, 'path form also works');
  assert.equal(parseReferralLink('genzcode://referral?code=gzabc123'), code, 'lower-case code in a link still resolves');
  assert.equal(parseReferralLink('genzcode://referral?code=GZABC123&utm=share'), code, 'extra query params are ignored');
  assert.equal(parseReferralLink('genzcode://referral'), null, 'no code');
  assert.equal(parseReferralLink('genzcode://referral?code=BAD'), null, 'malformed code');
  assert.equal(parseReferralLink('genzcode://words?code=GZABC123'), null, 'wrong path');
  assert.equal(parseReferralLink('https://word369.com/referral?code=GZABC123'), null, 'wrong scheme');
  assert.equal(parseReferralLink(''), null);
  const msg = referralShareMessage(code);
  assert.ok(msg.includes(code), 'share message names the code');
  assert.ok(msg.includes(referralLink(code)), 'share message carries the link');
  assert.ok(msg.includes('100 tokens'), 'share message states the reward');
});

test('referral: claim validation — invalid code, self-referral, double claim, valid claim', () => {
  // Invalid: malformed code, unknown code (resolves to no UID), empty UID.
  assert.equal(decideReferralClaim('BAD', 'new-uid', 'ref-uid', false), 'invalid');
  assert.equal(decideReferralClaim('GZABC123', 'new-uid', null, false), 'invalid', 'code that belongs to no user');
  assert.equal(decideReferralClaim('', 'new-uid', 'ref-uid', false), 'invalid');
  assert.equal(decideReferralClaim('GZABC123', '', 'ref-uid', false), 'invalid');
  // Self-referral: the code belongs to the new user themselves.
  assert.equal(decideReferralClaim('GZABC123', 'same-uid', 'same-uid', false), 'self');
  // Double claim: the new user already has a claim, even with a valid code.
  assert.equal(decideReferralClaim('GZABC123', 'new-uid', 'ref-uid', true), 'already-claimed');
  // Valid: a real code, a different referrer, no existing claim.
  assert.equal(decideReferralClaim('GZABC123', 'new-uid', 'ref-uid', false), 'claimed');
  assert.equal(decideReferralClaim('  gzabc123 ', 'new-uid', 'ref-uid', false), 'claimed', 'pasted / lower-case code still claims');
});

test('referral: the 100-token reward pays both users, exactly once', () => {
  const now = Date.now();
  const state = emptyState();
  // New user: +100, counted once even if the credit is applied twice.
  const once = creditReferrals(['friend-uid'])(state, now);
  assert.equal(once.tokens.balance, TOKENS.REFERRAL_REWARD);
  assert.ok(once.tokens.credited.includes(referralCreditKey('friend-uid')));
  const twice = creditReferrals(['friend-uid'])(once, now);
  assert.equal(twice, once, 'a second credit for the same friend is a no-op');
  assert.equal(twice.tokens.balance, TOKENS.REFERRAL_REWARD);
  // Referrer: two different friends pay +100 each; the same friend never pays twice.
  const referrer = creditReferrals(['new-1', 'new-2'])(state, now);
  assert.equal(referrer.tokens.balance, 2 * TOKENS.REFERRAL_REWARD);
  const referrerAgain = creditReferrals(['new-1', 'new-3'])(referrer, now);
  assert.equal(referrerAgain.tokens.balance, 3 * TOKENS.REFERRAL_REWARD, 'only the new friend pays again');
  // The referral credit key survives storage validation (it is not dropped
  // by parseTokens like an unknown key would be).
  const parsed = parseTokens({balance: 100, credited: [referralCreditKey('friend-uid'), 'junk']});
  assert.deepEqual(parsed.credited, [referralCreditKey('friend-uid')]);
});

test('referral: ledger document ids are the duplicate guards', () => {
  // New user's own entry: one per claimed code.
  assert.equal(referralClaimLedgerId('GZABC123'), 'referral-GZABC123');
  // Referrer's entry: one per referred friend.
  assert.equal(referralReferrerLedgerId('new-user-uid'), 'referral-new-user-uid');
  // The two entries live in different users' ledgers (the new user's vs the
  // referrer's), so their IDs are in different namespaces — the same suffix
  // can never make them the same document.
  assert.equal(referralCreditKey('new-user-uid'), 'referral:new-user-uid');
});
