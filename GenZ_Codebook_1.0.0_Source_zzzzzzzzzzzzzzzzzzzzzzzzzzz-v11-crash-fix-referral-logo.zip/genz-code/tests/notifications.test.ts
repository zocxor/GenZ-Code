import test from 'node:test';
import assert from 'node:assert/strict';
import {buildNotifications, streakMilestones, dayToMs} from '../src/notifications';
import type {TokenTxnRow} from '../src/tokenLedger';

const stageName = (id: string) => ({chat: 'Chat starter', emoji: 'Emoji detective'}[id] ?? id);
const base = {
  txns: [] as TokenTxnRow[],
  accepted: [] as {id: string; term: string; reviewedAt: number}[],
  lastDailyCollect: '',
  best: {} as Record<string, {v: number; u: number}>,
  days: {} as Record<string, number>,
  stageName,
};

test('notifications: ledger entries sort newest first with signed amounts', () => {
  const txns: TokenTxnRow[] = [
    {id: 'order-a', type: 'purchase', amount: 1000, balanceAfter: 1000, ref: 'GPA.1', createdAt: 1000},
    {id: 'order-b', type: 'purchase', amount: 2500, balanceAfter: 3500, ref: 'GPA.2', createdAt: 3000},
    {id: 'adj-1', type: 'adjustment', amount: 50, balanceAfter: 3550, ref: 'admin-grant', createdAt: 2000},
  ];
  const items = buildNotifications({...base, txns});
  assert.equal(items.length, 3);
  assert.equal(items[0]!.id, 'txn-order-b');
  assert.equal(items[0]!.subtitle, '+2,500 tokens · GPA.2');
  assert.equal(items[1]!.subtitle, '+50 tokens · admin-grant');
  assert.equal(items[2]!.subtitle, '+1,000 tokens · GPA.1');
  assert.ok(items.every(i => i.kind === 'tokens'));
});

test('notifications: ledger entries without a date are dropped', () => {
  const txns: TokenTxnRow[] = [{id: 'x', type: 'purchase', amount: 100, balanceAfter: 100, createdAt: 0}];
  assert.equal(buildNotifications({...base, txns}).length, 0);
});

test('notifications: accepted words use the moderator reviewedAt stamp', () => {
  const items = buildNotifications({...base, accepted: [{id: 's1', term: 'rizz', reviewedAt: 5000}]});
  assert.equal(items.length, 1);
  assert.equal(items[0]!.title, 'Your word “rizz” was accepted');
  assert.equal(items[0]!.subtitle, '+20 tokens');
  assert.equal(items[0]!.kind, 'community');
  assert.equal(items[0]!.at, 5000);
});

test('notifications: daily reward appears only when a collect date is recorded', () => {
  assert.equal(buildNotifications({...base, lastDailyCollect: ''}).length, 0);
  const items = buildNotifications({...base, lastDailyCollect: '2026-11-09'});
  assert.equal(items.length, 1);
  assert.equal(items[0]!.title, 'Daily reward collected');
  assert.equal(items[0]!.subtitle, '+10 tokens');
  assert.equal(items[0]!.at, dayToMs('2026-11-09'));
});

test('notifications: best scores surface perfect rounds and clears, not low scores', () => {
  const best = {
    chat: {v: 100, u: 4000},
    emoji: {v: 80, u: 3000},
    campus: {v: 40, u: 2000},
    context: {v: 0, u: 1000},
  };
  const items = buildNotifications({...base, best});
  assert.deepEqual(items.map(i => i.title), ['Perfect round in Chat starter', 'Cleared Emoji detective']);
  assert.equal(items[0]!.subtitle, 'Scored 5 / 5');
  assert.equal(items[1]!.subtitle, 'Best score 80%');
});

test('notifications: the feed is capped at 25, newest first', () => {
  const txns: TokenTxnRow[] = Array.from({length: 30}, (_, i) => ({id: `t${i}`, type: 'purchase' as const, amount: 10, balanceAfter: 10, createdAt: 1000 + i}));
  const items = buildNotifications({...base, txns});
  assert.equal(items.length, 25);
  assert.equal(items[0]!.at, 1029);
});

test('streakMilestones: no run, short run, 3-day and 7-day runs', () => {
  assert.deepEqual(streakMilestones({}), []);
  assert.deepEqual(streakMilestones({'2026-11-01': 2, '2026-11-02': 1}), []);
  const three = streakMilestones({'2026-11-01': 1, '2026-11-02': 1, '2026-11-03': 1});
  assert.equal(three.length, 1);
  assert.equal(three[0]!.days, 3);
  assert.equal(three[0]!.at, dayToMs('2026-11-03'));
  const seven = streakMilestones(Object.fromEntries(Array.from({length: 7}, (_, i) => [`2026-11-0${i + 1}`, 1])));
  assert.equal(seven.length, 2);
  assert.deepEqual(seven.map(m => m.days), [3, 7]);
  assert.equal(seven[1]!.at, dayToMs('2026-11-07'));
  // A gap breaks the run: only the longest run counts.
  const gapped = streakMilestones({'2026-11-01': 1, '2026-11-02': 1, '2026-11-03': 1, '2026-11-05': 1, '2026-11-06': 1});
  assert.equal(gapped.length, 1);
  assert.equal(gapped[0]!.days, 3);
});
