/**
 * Community chat: one room for everyone (shared by the app and the admin portal).
 *
 * Moderation is three layers, all free (no paid Firebase services, no Cloud Functions):
 *  1. This module — the message is screened on the device before it is sent. Anything
 *     sexual, abusive, hateful, threatening or encouraging self-harm is refused outright
 *     (unlike the dictionary, where a sensitive word can be explained and sent to
 *     moderators). Links, e-mail addresses and phone numbers are refused too.
 *  2. Firestore rules — only signed-in users with a verified e-mail and an active
 *     account can post; messages are length-checked, link-checked and rate-limited
 *     (10 s) server-side, so a tampered client cannot flood the room.
 *  3. People — any signed-in user can report a message; moderators hide it from the
 *     admin portal (audited), and the owner can switch the whole room off in Settings.
 *
 * A determined user can bypass a client-side filter, so this is not a guarantee — the
 * reports and the moderator hide are the backstop, exactly as with community words.
 */
import {CONTACT_PATTERN, PHONE_PATTERN} from './community';
import {cleanText} from './contentSchema';

export const CHAT_MAX_LENGTH = 500;
export const CHAT_RATE_LIMIT_SECONDS = 10;
export const CHAT_PAGE_SIZE = 50;

// Community posts: longer-form than a chat message, same content policy.
// Creating a post costs 25 tokens (TOKENS.POST_COST); chat messages cost 1.
export const POST_MAX_LENGTH = 500;
export const POST_RATE_LIMIT_SECONDS = 10;
export const POST_PAGE_SIZE = 50;

// Words that are never allowed in a chat message. Includes the dictionary's review
// list (shared/community.ts) plus the abuse and sexual terms a chat room attracts.
const BLOCKED_WORDS = new Set([
  'nigger', 'nigga', 'niggas', 'faggot', 'fag', 'fags', 'retard', 'retarded', 'tranny', 'chink', 'spic', 'kike', 'paki', 'coon', 'wetback', 'dyke',
  'cunt', 'whore', 'slut', 'rape', 'rapist', 'raping', 'porn', 'porno', 'xxx', 'nude', 'nudes', 'pedo', 'paedo', 'pedophile', 'incest', 'molest',
  'sex', 'sexy', 'dick', 'pussy', 'cock', 'boobs', 'tits', 'horny', 'cum', 'blowjob', 'handjob', 'orgasm', 'masturbate',
  'fuck', 'fucking', 'fucker', 'motherfucker', 'shit', 'bitch', 'bastard', 'asshole', 'dickhead',
  'bhenchod', 'behenchod', 'madarchod', 'chutiya', 'chutia', 'gandu', 'randi', 'harami', 'haramzada', 'kanjar', 'lund', 'phuddi', 'bhosdi', 'bhosdike', 'kutti',
]);
const BLOCKED_PHRASES = [
  'kill yourself', 'kill urself', 'kill your self', 'go die', 'hang yourself', 'kys',
  'i will kill you', "i'll kill you", 'son of a bitch',
];
// Same leet-speak normalisation as shared/community.ts; keep both in sync.
const unLeet = (w: string) => w.replace(/[@4]/g, 'a').replace(/\$/g, 's').replace(/0/g, 'o').replace(/[!1]/g, 'i').replace(/3/g, 'e').replace(/\*/g, '');

/** Short rules shown at the top of the chat room. */
export const CHAT_RULES = 'Be kind. No sexual content, abuse, hate, threats, links or personal details.';

export type ChatScreening = {ok: true} | {ok: false; message: string};

/** Decide whether a chat message may be sent. */
export function screenMessage(raw: string): ChatScreening {
  const text = cleanText(raw, CHAT_MAX_LENGTH);
  if (!text) return {ok: false, message: 'Type a message first.'};
  if (raw.trim().length > CHAT_MAX_LENGTH) return {ok: false, message: `Keep it under ${CHAT_MAX_LENGTH} characters.`};
  if (CONTACT_PATTERN.test(text)) return {ok: false, message: 'Please remove links and e-mail addresses. They can’t be sent in the chat.'};
  if (PHONE_PATTERN.test(text)) return {ok: false, message: 'Please remove phone numbers. They can’t be sent in the chat.'};
  const lower = text.toLowerCase();
  const words = lower.split(/[^\p{L}\p{N}@$*!]+/u).filter(Boolean);
  const spaced = ` ${lower.replace(/[^\p{L}\p{N}]+/gu, ' ')} `;
  const flagged = words.some(w => BLOCKED_WORDS.has(w) || BLOCKED_WORDS.has(unLeet(w)))
    || BLOCKED_PHRASES.some(p => spaced.includes(` ${p} `));
  if (flagged) return {ok: false, message: 'That message isn’t allowed in the community chat. Keep it friendly — no sexual content, abuse, hate or threats.'};
  return {ok: true};
}

export type ChatMessage = {id: string; uid: string; name: string; text: string; at: number};

/** Decide whether a community post may be sent. Same content policy as chat. */
export function screenPost(raw: string): ChatScreening {
  const text = cleanText(raw, POST_MAX_LENGTH);
  if (!text) return {ok: false, message: 'Type your post first.'};
  if (raw.trim().length > POST_MAX_LENGTH) return {ok: false, message: `Keep it under ${POST_MAX_LENGTH} characters.`};
  if (CONTACT_PATTERN.test(text)) return {ok: false, message: 'Please remove links and e-mail addresses. They can’t be sent in a post.'};
  if (PHONE_PATTERN.test(text)) return {ok: false, message: 'Please remove phone numbers. They can’t be sent in a post.'};
  const lower = text.toLowerCase();
  const words = lower.split(/[^\p{L}\p{N}@$*!]+/u).filter(Boolean);
  const spaced = ` ${lower.replace(/[^\p{L}\p{N}]+/gu, ' ')} `;
  const flagged = words.some(w => BLOCKED_WORDS.has(w) || BLOCKED_WORDS.has(unLeet(w)))
    || BLOCKED_PHRASES.some(p => spaced.includes(` ${p} `));
  if (flagged) return {ok: false, message: 'That post isn’t allowed in the community. Keep it friendly — no sexual content, abuse, hate or threats.'};
  return {ok: true};
}

export type CommunityPost = {id: string; uid: string; name: string; text: string; at: number; likeCount: number};

/** Validate one Firestore post document before it is shown. Untrusted input is dropped, never rendered. */
export function toCommunityPost(id: string, data: unknown): CommunityPost | null {
  if (!data || typeof data !== 'object') return null;
  const d = data as Record<string, unknown>;
  if (d.hidden !== false) return null;
  if (typeof d.uid !== 'string' || d.uid.length < 1 || d.uid.length > 128) return null;
  if (typeof d.name !== 'string' || d.name.trim().length < 1 || d.name.trim().length > 24) return null;
  if (typeof d.text !== 'string' || d.text.trim().length < 1 || d.text.length > POST_MAX_LENGTH) return null;
  if (typeof d.likeCount !== 'number' || !Number.isInteger(d.likeCount) || d.likeCount < 0) return null;
  const at = typeof d.createdAt === 'number' ? d.createdAt
    : (d.createdAt && typeof (d.createdAt as {toMillis?: unknown}).toMillis === 'function' ? (d.createdAt as {toMillis: () => number}).toMillis() : 0);
  if (!at) return null;
  return {id, uid: d.uid, name: cleanText(d.name, 24), text: cleanText(d.text, POST_MAX_LENGTH), at, likeCount: d.likeCount};
}

/** Validate one Firestore document before it is shown. Untrusted input is dropped, never rendered. */
export function toChatMessage(id: string, data: unknown): ChatMessage | null {
  if (!data || typeof data !== 'object') return null;
  const d = data as Record<string, unknown>;
  if (d.status !== 'live') return null;
  if (typeof d.uid !== 'string' || d.uid.length < 1 || d.uid.length > 128) return null;
  if (typeof d.name !== 'string' || d.name.trim().length < 1 || d.name.trim().length > 24) return null;
  if (typeof d.text !== 'string' || d.text.trim().length < 1 || d.text.length > CHAT_MAX_LENGTH) return null;
  const at = typeof d.createdAt === 'number' ? d.createdAt
    : (d.createdAt && typeof (d.createdAt as {toMillis?: unknown}).toMillis === 'function' ? (d.createdAt as {toMillis: () => number}).toMillis() : 0);
  if (!at) return null;
  return {id, uid: d.uid, name: cleanText(d.name, 24), text: cleanText(d.text, CHAT_MAX_LENGTH), at};
}
