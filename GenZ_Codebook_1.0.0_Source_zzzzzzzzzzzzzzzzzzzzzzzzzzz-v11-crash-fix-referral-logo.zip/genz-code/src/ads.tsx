/**
 * Google AdMob — token-based model with interstitials shown as usual.
 *
 * The app earns tokens, not attention. Advertisements appear in two places:
 *  - A voluntary rewarded ad, shown only when the user taps a button such
 *    as "Watch an ad and earn 10 tokens". It is the only ad that pays
 *    tokens, and no tokens are awarded when the ad is unavailable, fails,
 *    or is closed early.
 *  - An interstitial (full-screen) ad, preloaded at boot and shown when the
 *    user opens Suggest a word or the Community tab, at most once a minute.
 *    It never gates a feature: if no ad is ready, or Premium (ad-free) is
 *    active, the feature opens exactly as normal and nothing is shown.
 *  - NO banner ads anywhere (not on feature screens, not in dictionary
 *    entries, not in community messages). The banner unit (…/5427038644)
 *    still exists in the AdMob account but nothing in the app references it.
 *  - NO automatic ad triggers when the user opens Decode, Words, Play,
 *    Send or any other feature — only Suggest and Community show the
 *    interstitial, and only once a minute at most.
 *
 * Which ID is which:
 *  - App ID (ca-app-pub-9776667186789824~9376759074) identifies the app to the SDK.
 *    It lives in app.json (config plugin + react-native-google-mobile-ads key) and in
 *    android/app/src/main/AndroidManifest.xml. It is never passed to an ad view.
 *  - Interstitial ad unit ID (ca-app-pub-9776667186789824/4760116398): the
 *    full-screen ad shown on Suggest/Community. Dev builds use Google's
 *    test interstitial.
 *  - Rewarded ad unit ID: pays only on the SDK's EARNED_REWARD callback; dev
 *    builds use Google's test rewarded ad. Rewarded ads are opt-in — the user
 *    taps to watch one and earns 10 Code Tokens.
 *  - Rewarded interstitial unit (ca-app-pub-9776667186789824/6311057124):
 *    recorded, NOT wired — the app has no RewardedInterstitialAd format code.
 *    It lands with a future 25-token "Watch Ad & Earn" button. Do not use it
 *    as a plain interstitial.
 *
 * While developing, Google's test ads are served instead of the real ones —
 * never tap a real ad in a debug build; AdMob treats that as invalid
 * traffic. Ads are non-personalised, matching the app's privacy stance and
 * avoiding a consent form for basic serving.
 */
import {Platform} from 'react-native';
import {AdEventType, InterstitialAd, MobileAds, RewardedAd, RewardedAdEventType, TestIds} from 'react-native-google-mobile-ads';
import {IS_DEV} from './secure/config';

export const ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074';
/** Rewarded unit (created in AdMob 2026-11-08). Pays only on the SDK's EARNED_REWARD callback; dev builds use Google's test rewarded ad. */
export const REWARDED_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4151797642';
/** Rewarded interstitial unit (created in AdMob 2026-11-08). NOT wired yet: the app has no RewardedInterstitialAd format code — it lands with a future 25-token "Watch Ad & Earn" button. Do not use it as a plain interstitial. */
export const REWARDED_INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/6311057124';
/** Interstitial unit (created in AdMob 2026-11-08). Full-screen ad, preloaded at boot and shown when opening Suggest/Community, at most once a minute. Never gates a feature. */
export const INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4760116398';
/** Minimum gap between two interstitial shows (60 seconds). */
export const INTERSTITIAL_COOLDOWN_MS = 60_000;

/** Interstitial ad unit ID: Google's test interstitial in dev; the real one in release builds. */
export function interstitialAdUnitId(): string | null {
  if (IS_DEV) return TestIds.INTERSTITIAL;
  return INTERSTITIAL_AD_UNIT_ID || null;
}

/** Rewarded ad unit ID: Google's test rewarded ad in dev; the real one in release builds, or null until one is created in AdMob. */
export function rewardedAdUnitId(): string | null {
  if (IS_DEV) return TestIds.REWARDED;
  return REWARDED_AD_UNIT_ID || null;
}

let adsStarted = false;
let adsDisabled = false;
const adsDisabledListeners = new Set<(disabled: boolean) => void>();
/**
 * Premium (ad-free) switch. App.tsx sets this from the subscription
 * entitlement (users/{uid}/subscription/current). While it is on, no
 * interstitial is preloaded or shown. Rewarded ads stay available — they
 * are opt-in earning, not an interruption. Defaults to ads on; a failed
 * subscription read leaves ads on.
 */
export function setAdsDisabled(disabled: boolean): void {
  if (adsDisabled === disabled) return;
  adsDisabled = disabled;
  adsDisabledListeners.forEach(cb => {
    try {cb(disabled);} catch {/* ignore */}
  });
}
export function onAdsDisabledChange(cb: (disabled: boolean) => void): () => void {
  adsDisabledListeners.add(cb);
  return () => {adsDisabledListeners.delete(cb);};
}
export function isAdsDisabled(): boolean {
  return adsDisabled;
}

/** Initialise the SDK once, Android only, and preload one interstitial. Safe to call on every launch; a failure only means no ads. */
export function initAds(): void {
  if (adsStarted || Platform.OS !== 'android') return;
  adsStarted = true;
  void MobileAds().initialize().catch(() => undefined);
  preloadInterstitial();
}

/**
 * The preloaded interstitial, if any. A fresh instance is created per load:
 * once an interstitial is shown it cannot be shown again, so the CLOSED
 * listener clears it and preloads the next one.
 */
let interstitial: InterstitialAd | null = null;
let interstitialLoaded = false;
let lastInterstitialShownAt = 0;

/**
 * Preload one interstitial so it is ready when the user opens Suggest or
 * Community. No-op when ads are disabled (Premium), when there is no unit
 * ID, or when one is already loaded or loading. A failed load simply leaves
 * nothing ready — the next launch (or the next close) retries.
 */
export function preloadInterstitial(): void {
  if (Platform.OS !== 'android' || adsDisabled) return;
  const unitId = interstitialAdUnitId();
  if (!unitId) return;
  if (interstitial) return;
  // Constructing the interstitial touches the native ads module. If that
  // module is not ready this throws synchronously — and preloadInterstitial
  // runs from a setTimeout / ad-event listener that no ErrorBoundary covers,
  // so a throw here kills the app process. Never throw: a failed preload
  // just means no interstitial is ready.
  let ad: InterstitialAd;
  try {
    ad = InterstitialAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
  } catch {
    interstitial = null;
    interstitialLoaded = false;
    return;
  }
  interstitial = ad;
  const unsubs: (() => void)[] = [];
  const clear = () => {
    for (const u of unsubs) {try {u();} catch {/* ignore */}}
    unsubs.length = 0;
  };
  unsubs.push(
    ad.addAdEventListener(AdEventType.LOADED, () => {interstitialLoaded = true;}),
    ad.addAdEventListener(AdEventType.CLOSED, () => {
      clear();
      interstitial = null;
      interstitialLoaded = false;
      preloadInterstitial();
    }),
    ad.addAdEventListener(AdEventType.ERROR, () => {
      clear();
      interstitial = null;
      interstitialLoaded = false;
    }),
  );
  try { ad.load(); } catch { interstitial = null; interstitialLoaded = false; }
}

/**
 * Show the preloaded interstitial, if one is ready and at least a minute
 * has passed since the last show. Fire-and-forget: it never blocks, never
 * awaits, and never gates the feature the user opened — when nothing is
 * ready, when ads are disabled (Premium), or inside the cooldown, it
 * silently does nothing and the feature proceeds as normal.
 */
export function showInterstitialIfReady(): void {
  if (Platform.OS !== 'android' || adsDisabled) return;
  if (Date.now() - lastInterstitialShownAt < INTERSTITIAL_COOLDOWN_MS) return;
  if (!interstitial || !interstitialLoaded) return;
  lastInterstitialShownAt = Date.now();
  interstitialLoaded = false;
  try {interstitial.show();} catch {/* ignore */}
}

/**
 * Show one rewarded ad. Resolves true only when the user actually earned the
 * reward (watched to the end); closing early, an error, or no ad unit ID
 * resolves false and pays nothing. The caller credits the tokens.
 */
export function watchRewardedAd(): Promise<boolean> {
  return new Promise(resolve => {
    if (Platform.OS !== 'android') return resolve(false);
    const unitId = rewardedAdUnitId();
    if (!unitId) return resolve(false);
    let done = false;
    const unsubs: (() => void)[] = [];
    const finish = (earned: boolean) => {
      if (done) return;
      done = true;
      for (const u of unsubs) {try {u();} catch {/* ignore */}}
      resolve(earned);
    };
    const ad = RewardedAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
    unsubs.push(
      ad.addAdEventListener(RewardedAdEventType.LOADED, () => {try {ad.show();} catch {finish(false);}}),
      ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => finish(true)),
      ad.addAdEventListener(AdEventType.CLOSED, () => finish(false)),
      ad.addAdEventListener(AdEventType.ERROR, () => finish(false)),
    );
    ad.load();
  });
}
