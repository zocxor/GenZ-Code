/**
 * Achievements: the six badges, with progress hints.
 *
 * The badge list and rules are the SAME computation ProfileDashboard ("You"
 * tab) uses for "Your little wins" — see src/achievements.ts. Nothing here
 * is a separate badge system; this page just shows the same badges as full
 * cards, so earning one on the profile and seeing it here can never disagree.
 *
 * Visuals only: navy type, blue/purple earned tiles, grey locked tiles,
 * gold reserved for the trophy. Per-badge numeric progress is not shown —
 * computeBadges reports only earned / the next-step hint, so no percentage
 * is invented here; the header bar shows real overall progress (earned / 6).
 */
import React, {useMemo} from 'react';
import {View, Text, ScrollView, StyleSheet} from 'react-native';
import {C, Button, FadeIn, Icon, IconTile, ProgressBar, SectionHeader} from './ui';
import type {LearningState, Profile} from './profile';
import {computeBadges, type Badge} from './achievements';

export default function AchievementsScreen({state, profile, onClose}: {state: LearningState; profile: Profile; onClose: () => void}) {
  const badges = useMemo(() => computeBadges(state, profile), [state, profile]);
  const earned = badges.filter(b => b.earned).length;
  const remaining = badges.length - earned;

  return (
    <ScrollView contentContainerStyle={s.content}>
      <FadeIn>
        <View style={s.card}>
          <SectionHeader
            eyebrow="YOUR ACHIEVEMENTS"
            title={`${earned} of ${badges.length} earned`}
            action={<IconTile icon="trophy" from={C.gold} to={C.goldDeep} size={44} iconSize={22} />}
          />
          <View accessibilityRole="progressbar" accessibilityValue={{min: 0, max: badges.length, now: earned}}>
            <ProgressBar value={earned / badges.length} color={C.accent} height={9} />
          </View>
          <View style={s.metaRow}>
            <Text style={s.metaStrong}>{earned} earned</Text>
            <Text style={s.meta}>{remaining === 0 ? 'All badges earned — nice work.' : `${remaining} to go`}</Text>
          </View>
        </View>
      </FadeIn>

      <View style={s.grid}>
        {badges.map((b, i) => (
          <FadeIn key={b.label} delay={i * 60} style={s.gridCell}>
            <BadgeCard badge={b} />
          </FadeIn>
        ))}
      </View>

      <Text style={s.fine}>Earned from your saved learning on this device.</Text>
      <Button title="Done" onPress={onClose} />
    </ScrollView>
  );
}

function BadgeCard({badge: b}: {badge: Badge}) {
  return (
    <View
      accessible
      accessibilityLabel={`${b.label}. ${b.earned ? 'Earned.' : b.hint}`}
      style={[s.badgeCard, !b.earned && s.badgeCardLocked]}
    >
      <IconTile
        icon={b.earned ? b.icon : (`${b.icon}-outline` as typeof b.icon)}
        from={b.earned ? C.accent : '#c3d0de'}
        to={b.earned ? C.purple : '#9db1c6'}
        size={40}
        iconSize={20}
      />
      <Text style={[s.badgeName, !b.earned && s.badgeNameLocked]}>{b.label}</Text>
      {!b.earned && <Text style={s.caption}>{b.hint}</Text>}
      <View style={s.pillRow}>
        {b.earned ? (
          <View style={s.earnedPill}>
            <Icon name="checkmark" size={12} color="#13684a" />
            <Text style={s.earnedText}>Earned</Text>
          </View>
        ) : (
          <View style={s.lockedPill}>
            <Icon name="lock-closed" size={12} color={C.muted} />
            <Text style={s.lockedText}>Locked</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 14, gap: 8, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  metaRow: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'},
  metaStrong: {fontSize: 13, fontWeight: '800', color: C.navy},
  meta: {fontSize: 12, fontWeight: '700', color: C.muted},
  grid: {flexDirection: 'row', flexWrap: 'wrap', gap: 12},
  gridCell: {width: '48%', flexGrow: 1},
  badgeCard: {flex: 1, backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 12, gap: 6, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3},
  badgeCardLocked: {backgroundColor: '#f7fafd', borderColor: '#e2eaf3'},
  badgeName: {fontSize: 14, fontWeight: '800', color: C.navy, letterSpacing: -0.2},
  badgeNameLocked: {color: '#7d93ab'},
  pillRow: {flexDirection: 'row', marginTop: 2},
  earnedPill: {flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#e1f5e9', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5},
  earnedText: {fontSize: 12, fontWeight: '800', color: '#13684a'},
  lockedPill: {flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#edf1f6', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5},
  lockedText: {fontSize: 12, fontWeight: '800', color: C.muted},
});
