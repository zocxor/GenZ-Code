/**
 * Referral system (client): Firestore + share-sheet logic.
 *
 * Flow:
 *  1. A signed-in user gets a code (referralCodeForUid, deterministic from
 *     their UID) and registers it once in referrals/{code} (ensureReferralCode).
 *     The code is shown in the You tab with a Share button (genzcode:// link).
 *  2. A new user opens the link (App.tsx deep-link listener stores the code
 *     in memory) or types a code in the sign-up form (AccountScreen).
 *  3. On sign-up, claimReferral runs ONE Firestore batch:
 *       - referralClaims/{newUserUid} {code, referrerUid, newUserUid} — one
 *         per new user, so a second claim is impossible (create-only).
 *       - the new user's own ledger entry (type 'referral', +100) + their
 *         wallet cache (+100) — so the reward survives the login wallet
 *         re-read.
 *       - the referrer's ledger entry (type 'referral', +100, keyed
 *         referral-{newUserUid}) — the referrer's app picks it up on its
 *         next login / Wallet open (reconcileReferralCredits) and credits
 *         it locally. The new user NEVER writes the referrer's wallet
 *         (that would let anyone credit anyone); only the ledger entry,
 *         and the rules tie it to a matching claim.
 *     If any step fails, NEITHER user is credited (the batch is atomic;
 *     the local credit only happens after the batch commits).
 *  4. The referrer's app reconciles: it reads its ledger, finds 'referral'
 *     entries not yet in the local credited list, updates its own server
 *     wallet (so the next login's wallet re-read does not wipe the credit),
 *     then credits locally via creditReferrals (idempotent per device).
 *
 * Security (enforced by firestore.rules, not just here): a claim needs a
 * code that resolves to the named referrer, the referrer cannot be the new
 * user, and a user can only claim once. A referral ledger entry needs a
 * matching claim and exactly 100 tokens. Forging a credit without a real
 * referral is impossible through the rules.
 *
 * All functions are best-effort where noted and never throw into the UI —
 * a referral must never block sign-up.
 */
import {Share} from 'react-native';
import {referralCodeForUid, isReferralCode, normaliseReferralCode, parseReferralLink, referralShareMessage, referralClaimLedgerId, referralReferrerLedgerId, referralCreditKey, decideReferralClaim} from '../shared/referral';
import {TOKENS} from '../shared/tokens';
import {fetchTokenTxns, fetchTokenWallet, type TokenTxnRow} from './tokenLedger';

const libs = () => Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);

// ---------- deep-link pending code (in-memory; the sign-up form reads it) ----------
let pendingReferralCode: string | null = null;
export function setPendingReferralCode(code: string): void {
  if (isReferralCode(code)) pendingReferralCode = code;
}
export function peekPendingReferralCode(): string | null {
  return pendingReferralCode;
}
export function takePendingReferralCode(): string | null {
  const code = pendingReferralCode;
  pendingReferralCode = null;
  return code;
}
/** Parse a deep-link URL; store the code when it is a referral link.
 *  Returns true when a code was captured. */
export function handleReferralDeepLink(url: string): boolean {
  const code = parseReferralLink(url);
  if (!code) return false;
  setPendingReferralCode(code);
  return true;
}

// ---------- the user's own code ----------
/** Register this user's code in referrals/{code} (once). Returns the code,
 *  or null when it could not be registered (offline, or — vanishingly
 *  unlikely — the code belongs to another UID). */
export async function ensureReferralCode(uid: string): Promise<string | null> {
  const code = referralCodeForUid(uid);
  if (!code) return null;
  try {
    const [{doc, getDoc, setDoc, serverTimestamp}, {cloudDb: dbFn}] = await libs();
    const db = dbFn();
    const ref = doc(db, 'referrals', code);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      return (snap.data() as {uid?: unknown}).uid === uid ? code : null;
    }
    await setDoc(ref, {uid, createdAt: serverTimestamp()});
    return code;
  } catch {
    return null;
  }
}

/** How many friends have joined with this user's code (claims where they
 *  are the referrer). Returns 0 when signed out, offline, or none — never
 *  an invented number. */
export async function fetchReferralCount(uid: string): Promise<number> {
  try {
    const [{collection, query, where, getDocs}, {cloudDb: dbFn}] = await libs();
    const snap = await getDocs(query(collection(dbFn(), 'referralClaims'), where('referrerUid', '==', uid)));
    return snap.size;
  } catch {
    return 0;
  }
}

// ---------- claim ----------
export type ClaimResult = {status: 'claimed' | 'invalid' | 'self' | 'already-claimed' | 'error'; referrerUid?: string};

/** The account document is created by the sync engine right after sign-in;
 *  the claim needs it (the rules require an active account). Poll briefly
 *  so a fresh sign-up does not fail the claim for a timing reason. */
async function waitForAccount(uid: string, timeoutMs = 5000): Promise<boolean> {
  const started = Date.now();
  const {doc, getDoc} = await import('firebase/firestore/lite');
  const {cloudDb: dbFn} = await import('./firebase/app');
  const db = dbFn();
  for (;;) {
    try {
      if ((await getDoc(doc(db, 'users', uid))).exists()) return true;
    } catch {
      /* keep waiting */
    }
    if (Date.now() - started > timeoutMs) return false;
    await new Promise(r => setTimeout(r, 500));
  }
}

/**
 * Claim a referral for a newly signed-up user. One atomic batch writes the
 * claim, the new user's ledger entry + wallet, and the referrer's ledger
 * entry; the caller credits the new user locally only after this returns
 * 'claimed'. Never throws — every failure is a status, and sign-up must
 * never be blocked by a referral.
 */
export async function claimReferral(code: string, newUserUid: string, localBalance: number): Promise<ClaimResult> {
  const clean = normaliseReferralCode(code);
  if (!isReferralCode(clean) || !newUserUid) return {status: 'invalid'};
  try {
    if (!(await waitForAccount(newUserUid))) return {status: 'error'};
    const [{doc, getDoc, writeBatch, serverTimestamp}, {cloudDb: dbFn}] = await libs();
    const db = dbFn();
    const codeSnap = await getDoc(doc(db, 'referrals', clean));
    if (!codeSnap.exists()) return {status: 'invalid'};
    const rawUid = (codeSnap.data() as {uid?: unknown}).uid;
    const referrerUid = typeof rawUid === 'string' && rawUid ? rawUid : null;
    const claimRef = doc(db, 'referralClaims', newUserUid);
    const decision = decideReferralClaim(clean, newUserUid, referrerUid, (await getDoc(claimRef)).exists());
    if (decision !== 'claimed') return {status: decision};
    if (!referrerUid) return {status: 'invalid'}; // Unreachable after 'claimed'; narrows the type for the batch below.
    const wallet = await fetchTokenWallet(newUserUid);
    const base = wallet ? wallet.balance : Math.max(0, Math.floor(localBalance));
    const earnedBase = wallet ? wallet.earnedTotal : 0;
    const purchased = wallet ? wallet.purchasedTotal : 0;
    const spent = wallet ? wallet.spentTotal : 0;
    const reward = TOKENS.REFERRAL_REWARD;
    const batch = writeBatch(db);
    batch.set(claimRef, {code: clean, referrerUid, newUserUid, createdAt: serverTimestamp()});
    batch.set(doc(db, 'users', newUserUid, 'tokenLedger', referralClaimLedgerId(clean)), {
      type: 'referral', amount: reward, balanceAfter: base + reward, ref: clean, createdAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', newUserUid, 'tokenWallet', 'wallet'), {
      balance: base + reward, earnedTotal: earnedBase + reward, purchasedTotal: purchased, spentTotal: spent, updatedAt: serverTimestamp(),
    }, {merge: true});
    // The referrer's entry carries balanceAfter == the reward (not their
    // true balance — the writer cannot read the referrer's wallet). The
    // wallet cache is authoritative; the ledger entry is the audit record
    // and the signal the referrer's app reconciles from.
    batch.set(doc(db, 'users', referrerUid, 'tokenLedger', referralReferrerLedgerId(newUserUid)), {
      type: 'referral', amount: reward, balanceAfter: reward, ref: newUserUid, createdAt: serverTimestamp(),
    });
    try {
      await batch.commit();
    } catch (e) {
      // A race: another claim landed first and the claim document now exists.
      if ((await getDoc(claimRef)).exists()) return {status: 'already-claimed'};
      throw e;
    }
    return {status: 'claimed', referrerUid};
  } catch {
    return {status: 'error'};
  }
}

// ---------- referrer reconcile ----------
/**
 * Find this user's referral rewards that have not been credited locally
 * yet (ledger entries of type 'referral' whose friend UID is not in the
 * local credited list). Updates this user's OWN server wallet first, so
 * the reward survives the next login's wallet re-read, then returns the
 * friend UIDs for the caller to credit locally via creditReferrals
 * (idempotent — already-credited friends are skipped there too).
 * Returns [] when there is nothing new, or on any error. The caller
 * passes the local balance as the fallback base when no server wallet
 * exists yet.
 */
export async function reconcileReferralCredits(uid: string, alreadyCredited: string[], localBalance: number, txns?: TokenTxnRow[]): Promise<string[]> {
  try {
    const list = txns ?? (await fetchTokenTxns(uid, 100));
    const fresh = list
      .filter(t => t.type === 'referral' && typeof t.ref === 'string' && t.ref.length > 0 && !alreadyCredited.includes(referralCreditKey(t.ref)))
      .map(t => t.ref as string);
    if (!fresh.length) return [];
    const wallet = await fetchTokenWallet(uid);
    const base = wallet ? wallet.balance : Math.max(0, Math.floor(localBalance));
    const earnedBase = wallet ? wallet.earnedTotal : 0;
    const purchased = wallet ? wallet.purchasedTotal : 0;
    const spent = wallet ? wallet.spentTotal : 0;
    const reward = TOKENS.REFERRAL_REWARD * fresh.length;
    const [{doc, setDoc, serverTimestamp}, {cloudDb: dbFn}] = await libs();
    await setDoc(doc(dbFn(), 'users', uid, 'tokenWallet', 'wallet'), {
      balance: base + reward, earnedTotal: earnedBase + reward, purchasedTotal: purchased, spentTotal: spent, updatedAt: serverTimestamp(),
    }, {merge: true});
    return fresh;
  } catch {
    return [];
  }
}

// ---------- share ----------
/** Open the OS share sheet with the referral link + message. Best-effort. */
export async function shareReferral(code: string): Promise<void> {
  try {
    await Share.share({message: referralShareMessage(code)});
  } catch {
    /* share sheet dismissed or unavailable */
  }
}
