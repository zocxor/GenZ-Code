/**
 * About: what GenZ Codebook is, the real version, and the legal pages.
 *
 * The Terms of Use and Privacy Policy below are written for this app as it
 * actually works — tokens live on the device, purchases go through Google
 * Play, learning data syncs to Firebase only when signed in, no voice
 * recordings and no passport or bank uploads. The open-source list is the
 * app's real direct dependencies, with the licence each one publishes in
 * its installed package (read from node_modules, 2026-11-09) — not a
 * generic list.
 */
import React, {useState} from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet, Linking} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Button, FadeIn, Icon, IconName, IconTile, Mark, BrandWordmark, CompanyFooter, SectionHeader} from './ui';
import {APP_VERSION, PRIVACY_POLICY_URL} from './secure/config';
import {SUPPORT_EMAIL, supportMailto} from '../shared/brand';

/** Direct dependencies from package.json, with the licence each publishes. */
const LICENSES: {name: string; version: string; license: string}[] = [
  {name: '@expo/vector-icons', version: '15.1.1', license: 'MIT'},
  {name: '@react-native-async-storage/async-storage', version: '2.2.0', license: 'MIT'},
  {name: '@react-native-google-signin/google-signin', version: '17.0.0', license: 'MIT'},
  {name: 'expo', version: '54.0.38', license: 'MIT'},
  {name: 'expo-font', version: '14.0.12', license: 'MIT'},
  {name: 'expo-image-manipulator', version: '14.0.8', license: 'MIT'},
  {name: 'expo-image-picker', version: '17.0.11', license: 'MIT'},
  {name: 'expo-linear-gradient', version: '15.0.8', license: 'MIT'},
  {name: 'expo-secure-store', version: '15.0.8', license: 'MIT'},
  {name: 'expo-status-bar', version: '3.0.9', license: 'MIT'},
  {name: 'expo-system-ui', version: '6.0.9', license: 'MIT'},
  {name: 'firebase', version: '13.1.0', license: 'Apache-2.0'},
  {name: 'react', version: '19.1.0', license: 'MIT'},
  {name: 'react-dom', version: '19.1.0', license: 'MIT'},
  {name: 'react-native', version: '0.81.5', license: 'MIT'},
  {name: 'react-native-google-mobile-ads', version: '16.5.0', license: 'Apache-2.0'},
  {name: 'react-native-iap', version: '15.6.2', license: 'MIT'},
  {name: 'react-native-nitro-modules', version: '0.36.5', license: 'MIT'},
  {name: 'react-native-safe-area-context', version: '5.6.2', license: 'MIT'},
  {name: 'react-native-web', version: '0.21.4', license: 'MIT'},
];

const TERMS = `GenZ Codebook is an educational dictionary and decoder for internet slang and abbreviations. Definitions are reference entries and community contributions; they explain how words are used, they are not a substitute for professional, legal or medical advice.

Accounts are optional. Signing in backs up your learning to your Firebase account so you can use it on another phone. Without an account, everything stays on this device.

Tokens are the app's in-app currency. You earn them by learning, by daily visits and by watching a rewarded ad. You spend them to suggest a word, send a community message or unlock a quiz level early. Tokens live on this device only, have no cash value, and cannot be transferred or exchanged for money. Token purchases and Premium subscriptions are charged through Google Play; refunds follow Google Play's policy.

The community is for everyone, so be kind. No sexual content, abuse, hate, threats, links or personal details. Messages and suggested words are screened on your device and by the server rules. Anything can be reported, and moderators can hide content that breaks the rules. Accounts that abuse the community can be restricted.

Do not misuse the app: no spam, scraping, impersonation, or attempts to break its security. Content you submit must be your own words or properly attributed, and must not infringe anyone else's rights.

The app is provided "as is", without warranties. We work to keep definitions accurate and the app reliable, but we cannot guarantee it is error-free or always available.`;

const PRIVACY = `We collect as little as possible.

If you sign in, we store your e-mail address and nickname with your Firebase account, and your learning data (saved words, review progress, best scores, token balance) is backed up to Firestore under your account so it follows you between phones. Without an account, all of that stays on this device only.

Your token balance is stored on this device and does not sync between devices. Purchases are charged through Google Play; we store the Google Play order ID and the token amount in your account's ledger so a purchase can only ever credit once. We never see your card.

Your profile photo, if you add one, is resized and kept only on this device. It is never uploaded or shown to anyone else.

We do not record your voice, and the app never asks for a passport, bank statement or any identity document. We do not collect your location or your contacts.

Rewarded ads are served by Google (AdMob) and may use the advertising ID on your device. There are no banner ads. An interstitial ad may occasionally appear when you open Suggest a word or the Community tab (at most once a minute); it never blocks a feature.

You can delete everything on this device from Threat Shield (You tab), and you can delete your account — including its cloud data — from the account page. Questions or requests about your data: ${SUPPORT_EMAIL}.`;

export default function AboutScreen({onClose}: {onClose: () => void}) {
  const [open, setOpen] = useState<'terms' | 'privacy' | 'licenses' | null>(null);
  const toggle = (k: 'terms' | 'privacy' | 'licenses') => setOpen(open === k ? null : k);

  return (
    <ScrollView contentContainerStyle={s.content}>
      <FadeIn>
        <LinearGradient colors={['#ffffff', C.soft]} start={{x: 0, y: 0}} end={{x: 0, y: 1}} style={s.hero}>
          <View style={s.brand}>
            <Mark large />
            <View style={{width: 250, maxWidth: '100%', alignSelf: 'center'}}><BrandWordmark /></View>
            <Text style={s.tagline}>A little context. A lot more clarity.</Text>
          </View>
          <View style={s.versionPill}><Text style={s.version}>Version {APP_VERSION}</Text></View>
          <Text style={s.body}>Decode GenZ language, learn new words, and play.</Text>
        </LinearGradient>
      </FadeIn>

      <FadeIn delay={60}>
        <SectionHeader eyebrow="LEGAL" title="Terms, privacy & licences" />
        <View style={s.group}>
          <Section icon="document-text-outline" title="Terms of Use" open={open === 'terms'} onPress={() => toggle('terms')}>
            <Text style={s.legal}>{TERMS}</Text>
          </Section>
          <Section icon="shield-checkmark-outline" title="Privacy Policy" open={open === 'privacy'} onPress={() => toggle('privacy')}>
            <Text style={s.legal}>{PRIVACY}</Text>
            <Pressable accessibilityRole="button" onPress={() => void Linking.openURL(PRIVACY_POLICY_URL).catch(() => {})} style={s.linkRow}>
              <Text style={s.link}>View the full policy online</Text>
              <Icon name="open-outline" size={16} color={C.blue} />
            </Pressable>
          </Section>
          <Section icon="library-outline" title="Open Source Licenses" open={open === 'licenses'} onPress={() => toggle('licenses')} last>
            <Text style={s.caption}>Built on these open-source libraries.</Text>
            {LICENSES.map(l => (
              <View key={l.name} style={s.licRow}>
                <View style={{flex: 1}}><Text style={s.licName}>{l.name}</Text><Text style={s.caption}>v{l.version}</Text></View>
                <Text style={s.licBadge}>{l.license}</Text>
              </View>
            ))}
          </Section>
        </View>
      </FadeIn>

      <FadeIn delay={120}>
        <SectionHeader eyebrow="SUPPORT" title="Contact support" />
        <View style={s.group}>
          <View style={s.pad}>
            <Text style={s.body}>Questions or feedback? Write to us.</Text>
            <Pressable accessibilityRole="button" onPress={() => void Linking.openURL(supportMailto()).catch(() => {})} style={({pressed}) => [s.mailRow, pressed && {opacity: 0.7}]}>
              <IconTile icon="mail-outline" from={C.accent} to={C.purple} size={44} iconSize={22} />
              <Text style={s.mail}>{SUPPORT_EMAIL}</Text>
              <Icon name="chevron-forward" size={17} color={C.muted} />
            </Pressable>
          </View>
        </View>
      </FadeIn>

      <CompanyFooter />
      <Button title="Done" icon="checkmark-outline" onPress={onClose} />
    </ScrollView>
  );
}

function Section({icon, title, open, onPress, last, children}: {icon: IconName; title: string; open: boolean; onPress: () => void; last?: boolean; children: React.ReactNode}) {
  return (
    <View style={[s.section, last && {borderBottomWidth: 0}]}>
      <Pressable accessibilityRole="button" accessibilityState={{expanded: open}} onPress={onPress} style={({pressed}) => [s.sectionHead, pressed && {opacity: 0.7}]}>
        <IconTile icon={icon} from={C.accent} to={C.purple} size={44} iconSize={22} />
        <Text style={s.rowTitle}>{title}</Text>
        <Icon name={open ? 'chevron-up' : 'chevron-down'} size={18} color={C.muted} />
      </Pressable>
      {open && <View style={s.sectionBody}>{children}</View>}
    </View>
  );
}

const s = StyleSheet.create({
  content: {gap: 18, paddingBottom: 8},
  hero: {borderRadius: 28, borderWidth: 1.5, borderColor: '#dce8f5', padding: 24, gap: 14, alignItems: 'center', shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.11, shadowRadius: 18, elevation: 3, overflow: 'hidden'},
  brand: {alignItems: 'center', gap: 10},
  tagline: {fontSize: 13, color: C.muted, fontWeight: '700', textAlign: 'center'},
  versionPill: {backgroundColor: C.soft, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5},
  version: {fontSize: 12, fontWeight: '900', color: C.accent, textAlign: 'center'},
  body: {fontSize: 15, lineHeight: 23, color: C.muted, textAlign: 'center'},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  rowTitle: {flex: 1, fontSize: 15, fontWeight: '800', color: C.navy},
  legal: {fontSize: 14, lineHeight: 22, color: C.ink},
  group: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 24, marginTop: 10, paddingHorizontal: 6, paddingVertical: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.09, shadowRadius: 14, elevation: 3, overflow: 'hidden'},
  pad: {padding: 12, gap: 12},
  section: {paddingVertical: 8, paddingHorizontal: 10, borderBottomWidth: 1, borderBottomColor: '#e3eefb'},
  sectionHead: {flexDirection: 'row', alignItems: 'center', gap: 13, minHeight: 60},
  sectionBody: {gap: 12, paddingTop: 4, paddingBottom: 12, paddingHorizontal: 4},
  linkRow: {flexDirection: 'row', alignItems: 'center', gap: 6, minHeight: 44},
  link: {fontSize: 14, color: C.accent, fontWeight: '800'},
  licRow: {flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderTopWidth: 1, borderTopColor: '#eef4fb'},
  licName: {fontSize: 13, fontWeight: '800', color: C.navy},
  licBadge: {fontSize: 11, fontWeight: '900', color: C.accent, backgroundColor: C.soft, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 4, overflow: 'hidden'},
  mailRow: {flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 48},
  mail: {flex: 1, fontSize: 15, fontWeight: '800', color: C.accent},
});
