/**
 * Learning Dashboard: the real learning picture, from the saved state.
 *
 * Every number comes from `state` + `profile` — XP and rank, day streak,
 * mastered words, quiz rounds, cleared levels, words due for review and the
 * 7-day activity strip. The computations are the same ones ProfileDashboard
 * ("You" tab) uses. There is NO "Community Posts" row: the communityPosts
 * collection does not exist yet, so that number has no real source and is
 * omitted rather than invented.
 *
 * Restyled on the GenZ Codebook brand system: deep navy type, electric blue
 * actions, soft blue surfaces, purple accents, gold reserved for tokens /
 * rewards. Built on the shared ui.tsx primitives.
 */
import React, {useMemo} from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Button, Icon, IconName, IconTile, ProgressBar, SectionHeader, FadeIn} from './ui';
import type {LearningState, Profile} from './profile';
import {totalXP, streak, localDayOf} from './profile';
import {rankFor} from './ProfileDashboard';
import {computeBadges} from './achievements';
import {stages} from './games';
import {dueTerms} from './reviewQueue';

export default function DashboardScreen({state, profile: p, onClose, onPlay, onReview}: {state: LearningState; profile: Profile; onClose: () => void; onPlay: () => void; onReview: () => void}) {
  const now = Date.now();
  const d = useMemo(() => {
    const xp = totalXP(p.best);
    const rank = rankFor(xp);
    const st = streak(state.days, now);
    const mastered = Object.values(p.progress).filter(r => r.mastery >= 80).length;
    const reviewing = Object.keys(p.progress).length;
    const progress = reviewing > 0 ? mastered / reviewing : 0;
    const due = dueTerms(p, now).length;
    const week = Array.from({length: 7}, (_, i) => {const t = new Date(now); t.setHours(12, 0, 0, 0); t.setDate(t.getDate() - (6 - i)); const key = localDayOf(t.getTime()); return {key, label: t.toLocaleDateString('en', {weekday: 'narrow'}), count: state.days[key] ?? 0, today: i === 6};});
    const weekMax = Math.max(1, ...week.map(w => w.count));
    const attempts = Object.values(state.attempts).length;
    const cleared = stages.filter(g => (p.best[g.id] ?? 0) >= 60).length;
    const earnedBadges = computeBadges(state, p).filter(b => b.earned).length;
    return {xp, rank, st, mastered, reviewing, progress, due, week, weekMax, attempts, cleared, earnedBadges, weekAnswers: week.reduce((a, w) => a + w.count, 0), weekDays: week.filter(w => w.count > 0).length};
  }, [state, p, now - (now % 60_000)]);

  return (
    <ScrollView contentContainerStyle={s.content}>
      <FadeIn>
      <View style={s.grid}>
        <Stat icon="flash" from={C.accent} to="#4D8DFF" value={d.xp.toLocaleString()} label="Total XP" sub={`Level ${d.rank.level} · ${d.rank.name}`} />
        <Stat icon="flame" from="#F97316" to={C.gold} value={String(d.st.current)} label="Day streak" sub={d.st.activeToday ? `Best ${d.st.best} · today done` : d.st.current ? 'Play today to keep it' : `Best ${d.st.best} days`} />
        <Stat icon="ribbon" from={C.purple} to="#9B7BFF" value={`${d.earnedBadges} / 6`} label="Achievements" sub="Badges earned" />
      </View>
      </FadeIn>

      <FadeIn delay={60}>
      <Glass>
        <SectionHeader eyebrow="LEARNING PROGRESS" title={d.reviewing ? `${Math.round(d.progress * 100)}% mastered` : 'Nothing in review yet'} action={<Icon name="trending-up-outline" color={C.accent} size={24} />} />
        <View accessibilityRole="progressbar" accessibilityValue={{min: 0, max: 100, now: Math.round(d.progress * 100)}}>
          <ProgressBar value={d.progress} color={C.accent} height={10} />
        </View>
        <Text style={s.caption}>{d.reviewing ? `${d.mastered} of ${d.reviewing} mastered (80%+).` : 'Answer a quiz question to start.'}</Text>
        <View style={s.reviewRow}>
          <IconTile icon="repeat" from="#0E9F8A" to="#34C3A5" size={40} iconSize={20} />
          <View style={{flex: 1}}><Text style={s.rowTitle}>{d.due ? `${d.due} ${d.due === 1 ? 'word is' : 'words are'} ready to review` : 'Reviews are scheduled'}</Text></View>
          {d.due > 0 && <Pressable accessibilityRole="button" onPress={onReview} style={s.smallCta}><Text style={s.smallCtaText}>Review</Text></Pressable>}
        </View>
      </Glass>
      </FadeIn>

      <FadeIn delay={120}>
      <Glass style={{padding: 8}}>
        <StatRow icon="book-outline" from={C.accent} to="#4D8DFF" title="Words learned" value={String(d.mastered)} sub="80% or better" />
        <StatRow icon="game-controller-outline" from={C.purple} to="#9B7BFF" title="Quiz rounds played" value={String(d.attempts)} sub="On this device" />
        <StatRow icon="trophy-outline" from={C.gold} to="#E89B0C" title="Levels cleared" value={`${d.cleared} of ${stages.length}`} sub="60% or better" last />
      </Glass>
      </FadeIn>

      <FadeIn delay={180}>
      <Glass>
        <SectionHeader eyebrow="THIS WEEK" title={d.weekAnswers ? `${d.weekAnswers} answers · ${d.weekDays} of 7 days` : 'A fresh week'} action={<Icon name="pulse-outline" color={C.accent} size={24} />} />
        <View style={s.bars} accessible accessibilityLabel={`Activity in the last 7 days: ${d.week.map(w => w.count).join(', ')} answers`}>
          {d.week.map(w => <View key={w.key} style={s.barCol}>
            <View style={s.barSlot}><LinearGradient colors={w.today ? [C.accent, C.purple] : ['#B9D2F5', '#8EAEEA']} style={[s.bar, {height: w.count ? `${Math.max(12, (w.count / d.weekMax) * 100)}%` : 4, opacity: w.count ? 1 : 0.5}]} /></View>
            <Text style={[s.barLabel, w.today && {color: C.accent, fontWeight: '900'}]}>{w.label}</Text>
          </View>)}
        </View>
        {!d.weekAnswers && <Text style={s.caption}>Answer one quiz question to start a streak.</Text>}
      </Glass>
      </FadeIn>

      <FadeIn delay={240}>
      <Button title="Play a level" icon="game-controller-outline" onPress={onPlay} />
      </FadeIn>
      <Pressable accessibilityRole="button" onPress={onClose} style={({pressed}) => [s.done, pressed && {opacity: 0.85}]}><Text style={s.doneText}>Done</Text></Pressable>
    </ScrollView>
  );
}

function Stat({icon, from, to, value, label, sub}: {icon: IconName; from: string; to: string; value: string; label: string; sub: string}) {
  return <View accessible accessibilityLabel={`${label}: ${value}. ${sub}`} style={s.stat}>
    <View style={s.statTop}><IconTile icon={icon} from={from} to={to} size={40} iconSize={20} /><Text style={s.statValue} numberOfLines={1}>{value}</Text></View>
    <Text style={s.statLabel}>{label}</Text><Text style={s.fine} numberOfLines={1}>{sub}</Text>
  </View>;
}

function StatRow({icon, from, to, title, value, sub, last}: {icon: IconName; from: string; to: string; title: string; value: string; sub: string; last?: boolean}) {
  return (
    <View style={[s.statRow, last && {borderBottomWidth: 0}]}>
      <IconTile icon={icon} from={from} to={to} size={40} iconSize={20} />
      <View style={{flex: 1, gap: 2}}><Text style={s.rowTitle}>{title}</Text><Text style={s.caption}>{sub}</Text></View>
      <Text style={s.statRowValue}>{value}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  grid: {flexDirection: 'row', flexWrap: 'wrap', gap: 12},
  stat: {flexBasis: '30%', flexGrow: 1, backgroundColor: '#fff', borderRadius: 16, paddingVertical: 12, paddingHorizontal: 12, gap: 2, borderWidth: 1.5, borderColor: '#DCE8F5', shadowColor: '#3E6C9A', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.08, shadowRadius: 12, elevation: 2},
  statTop: {flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6},
  statValue: {flex: 1, fontSize: 18, fontWeight: '900', color: C.navy, letterSpacing: -0.5},
  statLabel: {fontSize: 12, fontWeight: '800', color: C.navy},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 16, color: '#5C7189'},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.navy},
  reviewRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderRadius: 14, backgroundColor: C.soft, marginTop: 8},
  smallCta: {minHeight: 40, paddingHorizontal: 14, borderRadius: 14, backgroundColor: C.accent, justifyContent: 'center'},
  smallCtaText: {color: '#fff', fontWeight: '800', fontSize: 13},
  statRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderBottomWidth: 1, borderBottomColor: '#EAF2FB'},
  statRowValue: {fontSize: 17, fontWeight: '900', color: C.navy},
  bars: {flexDirection: 'row', gap: 8, height: 88, alignItems: 'flex-end', marginTop: 8},
  barCol: {flex: 1, alignItems: 'center', gap: 6, height: '100%'},
  barSlot: {flex: 1, width: '100%', justifyContent: 'flex-end', alignItems: 'center'},
  bar: {width: '72%', maxWidth: 30, borderRadius: 9},
  barLabel: {fontSize: 11, color: C.muted, fontWeight: '700'},
  done: {minHeight: 48, borderRadius: 16, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center'},
  doneText: {color: '#fff', fontSize: 16, fontWeight: '800'},
});
