/**
 * My suggestions: the words this account suggested, with edit.
 *
 * Two sources, both owned by the signed-in account:
 *  - submissions (status 'pending' | 'accepted' | 'rejected') — words waiting
 *    for, or already decided by, a moderator.
 *  - communityWords (status 'live' | 'hidden') — words that went live
 *    instantly. These are public; only the rows this account owns are shown.
 * Nothing is simulated: an empty account sees the empty state.
 *
 * Editing costs EDIT_SUGGESTION_COST (250) tokens per edit, for everyone.
 * The charge happens only after the new wording is saved to the server —
 * the same pattern as the suggest cost (spend only on success). The edit
 * itself follows the server contract in firestore.rules: a pending
 * submission may change only term/meaning/example/category + updatedAt, and
 * a live community word owned by the user may change only the same fields
 * while it is live. Accepted or rejected suggestions can no longer be
 * edited, and neither can a hidden word.
 *
 * A live word whose new wording the word filter flags for moderator review
 * cannot be edited in place — the flagged wording would go live without a
 * review. A pending submission may be edited into flagged wording, because
 * it still waits for a moderator either way.
 */
import React, {useEffect, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, ActivityIndicator, TextInput} from 'react-native';
import {C, Glass, Button, Chip, Icon} from './ui';
import {CONTENT_CATEGORIES, validateEntry} from '../shared/contentSchema';
import {communityId, screenWord, containsOwnName, OWN_NAME_ERROR} from '../shared/community';
import {TOKENS, canEditSuggestion, type TokensState} from '../shared/tokens';
import {spendTokens, type Action} from './learning';
import {useAccountUser} from './services';
import {addLocalCommunityWord} from './contentSync';
import {fmtWhen} from './notifications';

type SuggestionStatus = 'pending' | 'accepted' | 'rejected' | 'live' | 'hidden';
type Suggestion = {
  id: string;
  kind: 'submission' | 'communityWord';
  term: string;
  meaning: string;
  example: string;
  category: string;
  status: SuggestionStatus;
  createdAt: number;
};

const STATUS_META: Record<SuggestionStatus, {label: string; bg: string; fg: string}> = {
  pending: {label: 'Pending', bg: '#fff3d6', fg: '#8a5a00'},
  accepted: {label: 'Accepted', bg: '#e1f5e9', fg: '#175e47'},
  rejected: {label: 'Rejected', bg: '#fff0ee', fg: '#96383f'},
  live: {label: 'Live', bg: '#e1f5e9', fg: '#175e47'},
  hidden: {label: 'Hidden', bg: '#fff0ee', fg: '#96383f'},
};

const toMs = (v: unknown): number => (v !== null && typeof v === 'object' && typeof (v as {toMillis?: unknown}).toMillis === 'function' ? (v as {toMillis: () => number}).toMillis() : 0);

/** The user's own suggestions from both collections, newest first. */
async function fetchMySuggestions(uid: string): Promise<Suggestion[]> {
  try {
    const [{collection, query, where, getDocs, limit}, {cloudDb: dbFn}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    const db = dbFn();
    // Single-field queries (uid only) so no composite index is needed; the
    // lists are the user's own and small, so sorting runs here.
    const [subs, words] = await Promise.all([
      getDocs(query(collection(db, 'submissions'), where('uid', '==', uid), limit(50))),
      getDocs(query(collection(db, 'communityWords'), where('uid', '==', uid), limit(50))),
    ]);
    const out: Suggestion[] = [];
    for (const d of subs.docs) {
      const data = d.data();
      if (typeof data.term !== 'string' || typeof data.meaning !== 'string') continue;
      if (data.status !== 'pending' && data.status !== 'accepted' && data.status !== 'rejected') continue;
      out.push({id: d.id, kind: 'submission', term: data.term, meaning: data.meaning, example: typeof data.example === 'string' ? data.example : '', category: typeof data.category === 'string' ? data.category : 'Chat', status: data.status, createdAt: toMs(data.createdAt)});
    }
    for (const d of words.docs) {
      const data = d.data();
      if (typeof data.term !== 'string' || typeof data.meaning !== 'string') continue;
      if (data.status !== 'live' && data.status !== 'hidden') continue;
      out.push({id: d.id, kind: 'communityWord', term: data.term, meaning: data.meaning, example: typeof data.example === 'string' ? data.example : '', category: typeof data.category === 'string' ? data.category : 'Chat', status: data.status, createdAt: toMs(data.createdAt)});
    }
    return out.sort((a, b) => b.createdAt - a.createdAt);
  } catch {return [];}
}

/** Save an edit. Only the five fields the rules allow are written. */
async function updateSuggestion(s: Suggestion, fields: {term: string; meaning: string; example: string; category: string}): Promise<{ok: true} | {ok: false; message: string}> {
  try {
    const [{collection, doc, getDoc, updateDoc, serverTimestamp}, {cloudDb: dbFn}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    const db = dbFn();
    if (s.kind === 'communityWord') {
      // The document ID is derived from the original term; a new term that
      // already lives under another ID would publish a duplicate word.
      const newId = communityId(fields.term);
      if (newId !== s.id) {
        const clash = await getDoc(doc(db, 'communityWords', newId));
        if (clash.exists() && (clash.data() as {status?: unknown}).status === 'live') return {ok: false, message: `“${fields.term}” is already in GenZ Codebook.`};
      }
    }
    await updateDoc(doc(db, s.kind === 'submission' ? 'submissions' : 'communityWords', s.id), {...fields, updatedAt: serverTimestamp()});
    return {ok: true};
  } catch (e) {
    const code = (e as {code?: unknown})?.code;
    return {ok: false, message: code === 'permission-denied' ? 'The server didn’t accept this change. If the app was just updated, the latest rules may not be published yet — try again later.' : 'Couldn’t save that change. Check your connection and try again.'};
  }
}

const isEditable = (s: Suggestion): boolean => (s.kind === 'submission' && s.status === 'pending') || (s.kind === 'communityWord' && s.status === 'live');

export default function MySuggestionsScreen({tokens, nickname, onTokensAction, onSignIn, onOpenShop, onClose}: {tokens: TokensState; nickname: string; onTokensAction: (a: Action) => void; onSignIn: () => void; onOpenShop?: () => void; onClose: () => void}) {
  const user = useAccountUser();
  const [items, setItems] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(!!user);
  const [editing, setEditing] = useState<Suggestion | null>(null);
  const affordable = canEditSuggestion(tokens);

  useEffect(() => {
    if (!user?.uid) {setLoading(false); return;}
    let live = true;
    void fetchMySuggestions(user.uid).then(list => {if (live) {setItems(list); setLoading(false);}});
    return () => {live = false;};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.uid]);

  const now = Date.now();

  if (editing) return <EditSuggestionForm
    suggestion={editing}
    nickname={nickname}
    tokens={tokens}
    onTokensAction={onTokensAction}
    onOpenShop={onOpenShop}
    onCancel={() => setEditing(null)}
    onSaved={fields => {
      setItems(list => list.map(x => x.id === editing.id && x.kind === editing.kind ? {...x, ...fields} : x));
      if (editing.kind === 'communityWord') void addLocalCommunityWord(editing.id, {...fields, status: 'live'});
      setEditing(null);
    }}
  />;

  return (
    <ScrollView contentContainerStyle={s.content}>
      <Text style={s.body}>Every word you suggested, and what happened to it. Editing one costs {TOKENS.EDIT_SUGGESTION_COST} tokens.</Text>
      {!user ? (
        <Glass>
          <Icon name="person-circle-outline" size={30} color={C.blue} />
          <Text style={s.rowTitle}>Sign in to see your suggestions.</Text>
          <Text style={s.body}>Your suggested words are tied to your account, so they only show here once you sign in.</Text>
          <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
        </Glass>
      ) : loading ? (
        <Glass><ActivityIndicator color={C.blue} /><Text style={s.body}>Loading your suggestions…</Text></Glass>
      ) : items.length === 0 ? (
        <Glass>
          <Icon name="chatbox-ellipses-outline" size={30} color={C.blue} />
          <Text style={s.rowTitle}>You haven’t suggested any words yet.</Text>
          <Text style={s.body}>Words you suggest will show up here, with their status — and you can edit them from here for {TOKENS.EDIT_SUGGESTION_COST} tokens each.</Text>
        </Glass>
      ) : (
        <Glass style={{padding: 8}}>
          {items.map((item, i) => <SuggestionRow key={`${item.kind}-${item.id}`} item={item} now={now} last={i === items.length - 1} canEdit={affordable} onEdit={() => setEditing(item)} />)}
        </Glass>
      )}
      {user && items.length > 0 && !affordable && <Glass><Text style={s.body}>You need {TOKENS.EDIT_SUGGESTION_COST} tokens to edit a word (you have {tokens.balance}).</Text>{onOpenShop && <Button title="Buy tokens" icon="card-outline" onPress={onOpenShop} />}</Glass>}
      <Button title="Done" icon="checkmark-outline" onPress={onClose} />
    </ScrollView>
  );
}

function SuggestionRow({item, now, last, canEdit, onEdit}: {item: Suggestion; now: number; last: boolean; canEdit: boolean; onEdit: () => void}) {
  const meta = STATUS_META[item.status];
  const editable = isEditable(item);
  return (
    <View style={[s.row, last && {borderBottomWidth: 0}]}>
      <View style={{flex: 1, gap: 4}}>
        <View style={s.rowHead}>
          <Text style={s.rowTitle} numberOfLines={1}>{item.term}</Text>
          <View style={[s.pill, {backgroundColor: meta.bg}]}><Text style={[s.pillText, {color: meta.fg}]}>{meta.label}</Text></View>
        </View>
        <Text style={s.caption} numberOfLines={2}>{item.meaning}</Text>
        {item.example ? <Text style={s.caption} numberOfLines={1}>“{item.example}”</Text> : null}
        <Text style={s.when}>{item.category}{item.createdAt > 0 ? ` · ${fmtWhen(item.createdAt, now)}` : ''}</Text>
        {!editable && <Text style={s.fine}>{item.status === 'accepted' ? 'Accepted by a moderator — it can no longer be edited.' : item.status === 'rejected' ? 'Rejected by a moderator — it can no longer be edited.' : 'Hidden by a moderator — it can no longer be edited.'}</Text>}
      </View>
      {editable && <Button title={canEdit ? 'Edit' : `Need ${TOKENS.EDIT_SUGGESTION_COST}`} icon="create-outline" light disabled={!canEdit} onPress={onEdit} />}
    </View>
  );
}

function EditSuggestionForm({suggestion, nickname, tokens, onTokensAction, onOpenShop, onCancel, onSaved}: {suggestion: Suggestion; nickname: string; tokens: TokensState; onTokensAction: (a: Action) => void; onOpenShop?: () => void; onCancel: () => void; onSaved: (fields: {term: string; meaning: string; example: string; category: string}) => void}) {
  const [term, setTerm] = useState(suggestion.term), [meaning, setMeaning] = useState(suggestion.meaning), [example, setExample] = useState(suggestion.example), [category, setCategory] = useState(suggestion.category);
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [saved, setSaved] = useState(false);
  const affordable = canEditSuggestion(tokens);
  const changed = term.trim() !== suggestion.term || meaning.trim() !== suggestion.meaning || example.trim() !== suggestion.example || category !== suggestion.category;

  const save = async () => {
    if (busy || saved) return;
    if (!affordable) {setError(`You need ${TOKENS.EDIT_SUGGESTION_COST} tokens to edit a word (you have ${tokens.balance}).`); return;}
    if (!changed) {setError('Nothing changed yet.'); return;}
    if (containsOwnName({term, meaning, example}, nickname)) {setError(OWN_NAME_ERROR); return;}
    const v = validateEntry({term, meaning, example, category, language: 'English'});
    if (!v.ok) {setError(v.errors[0]!); return;}
    const screen = screenWord({term: v.entry.term, meaning: v.entry.meaning, example: v.entry.example});
    if (!screen.ok) {setError(screen.message); return;}
    if (suggestion.kind === 'communityWord' && screen.review) {setError('This wording needs a moderator to look at it, so it can’t be applied to a live word. Try simpler, neutral wording.'); return;}
    // Re-check the balance at the last moment, so a balance that dropped
    // since the form opened can never buy a free edit.
    if (tokens.balance < TOKENS.EDIT_SUGGESTION_COST) {setError(`You need ${TOKENS.EDIT_SUGGESTION_COST} tokens to edit a word (you have ${tokens.balance}).`); return;}
    setBusy(true); setError('');
    const fields = {term: v.entry.term, meaning: v.entry.meaning, example: v.entry.example, category: v.entry.category};
    const r = await updateSuggestion(suggestion, fields);
    setBusy(false);
    if (!r.ok) {setError(r.message); return;}
    // Tokens are spent only after the server accepted the edit, never on a failed save.
    onTokensAction(spendTokens(TOKENS.EDIT_SUGGESTION_COST));
    setSaved(true);
    onSaved(fields);
  };

  return (
    <ScrollView contentContainerStyle={s.content}>
      <Text style={s.body}>Change “{suggestion.term}”. Saving costs {TOKENS.EDIT_SUGGESTION_COST} tokens — your balance is {tokens.balance}.</Text>
      <Glass>
        <Text style={s.label}>Word or phrase</Text>
        <TextInput accessibilityLabel="Suggested word" value={term} onChangeText={setTerm} maxLength={60} autoCapitalize="none" style={s.input} placeholder="e.g. delulu or 143" placeholderTextColor={C.muted} />
        <Text style={s.label}>What it means</Text>
        <TextInput accessibilityLabel="Meaning" value={meaning} onChangeText={setMeaning} maxLength={500} multiline style={[s.input, s.multi]} placeholder="Explain it simply and neutrally" placeholderTextColor={C.muted} />
        <Text style={s.label}>Example (optional)</Text>
        <TextInput accessibilityLabel="Example" value={example} onChangeText={setExample} maxLength={300} style={s.input} placeholder="Avoid real names or private details" placeholderTextColor={C.muted} />
        <Text style={s.label}>Category</Text>
        <View style={s.wrap}>{CONTENT_CATEGORIES.map(c => <Chip key={c} label={c} selected={category === c} onPress={() => setCategory(c)} />)}</View>
        {!affordable && <Text accessibilityRole="alert" style={s.err}>You need {TOKENS.EDIT_SUGGESTION_COST} tokens to edit a word (you have {tokens.balance}).</Text>}
        {!!error && affordable && <Text accessibilityRole="alert" style={s.err}>{error}</Text>}
        {onOpenShop && !affordable && <Button light title="Buy tokens" icon="card-outline" onPress={onOpenShop} />}
        <Button title={busy ? 'Saving…' : `Save changes · ${TOKENS.EDIT_SUGGESTION_COST} tokens`} icon="checkmark-outline" disabled={busy || !affordable || !changed || !term.trim() || meaning.trim().length < 2} onPress={() => void save()} />
        <Button light title="Back to my suggestions" icon="arrow-back-outline" disabled={busy} onPress={onCancel} />
        <Text style={s.small}>Your own name or nickname can’t appear in the word, its meaning or its example. A moderator can still hide a word that breaks the rules.</Text>
      </Glass>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  small: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.ink},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  label: {fontSize: 14, fontWeight: '800', color: C.ink},
  input: {minHeight: 52, padding: 14, borderWidth: 1, borderColor: '#bccfe6', borderRadius: 16, backgroundColor: '#e7f0fb', fontSize: 16, color: C.ink},
  multi: {minHeight: 96, textAlignVertical: 'top'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  err: {padding: 12, borderRadius: 14, backgroundColor: '#fff0ee', color: '#96383f', lineHeight: 20},
  row: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderBottomWidth: 1, borderBottomColor: '#e3eefb'},
  rowHead: {flexDirection: 'row', alignItems: 'center', gap: 8},
  pill: {paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10},
  pillText: {fontSize: 11, fontWeight: '800'},
  when: {fontSize: 11, color: C.muted, fontWeight: '700'},
});
