/**
 * Community posts: longer-form posts in the Community tab, next to the chat room.
 *
 * Free-tier design (Spark plan, no paid services): posts live in Firestore
 * (`communityPosts`), read through one realtime listener capped at the newest
 * 50 posts. Creating a post costs 25 tokens (TOKENS.POST_COST), deducted only
 * after the post is accepted — chat messages are 1 token each. Likes live in
 * `communityPostLikes/{postId}_{uid}` (one document per like); the post's
 * `likeCount` is kept in sync by a client transaction, so a like and its
 * count can never drift apart. Reports go to `postReports`, mirroring
 * `chatReports`. Posts are screened on the device before sending (see
 * shared/chat.ts screenPost) and again by the server rules.
 */
import {Platform} from 'react-native';
import type {User} from 'firebase/auth';
import {cleanText} from '../shared/contentSchema';
import {screenPost, toCommunityPost, POST_MAX_LENGTH, POST_RATE_LIMIT_SECONDS, POST_PAGE_SIZE, type CommunityPost} from '../shared/chat';
import {APP_VERSION} from './secure/config';
import {REPORT_REASONS} from './ugc';

export type {CommunityPost};
export type PostResult = {ok: true; liked?: boolean} | {ok: false; message: string; wait?: number};
const fail = (message: string, extra: Partial<Extract<PostResult, {ok: false}>> = {}): PostResult => ({ok: false, message, ...extra});

const libs = () => Promise.all([import('firebase/firestore/lite'), import('firebase/firestore'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

function errorText(e: unknown, CloudError: typeof import('./sync/engine').CloudError): string {
  if (e instanceof CloudError) {
    if (e.code === 'offline') return 'You’re offline. Connect to the internet and try again.';
    if (e.code === 'unauthenticated') return 'Your session expired. Sign in again, then try once more.';
    if (e.code === 'permission-denied') return 'The server didn’t accept that. If you just verified your e-mail, wait a minute and try again. (code: permission-denied)';
    if (e.code === 'server-setup') return 'The GenZ Codebook server isn’t set up yet: its security rules haven’t been published, so the database refuses every request. Publish the rules, then try again. (code: rules-missing)';
    return `Couldn’t send that right now. Please try again. (code: ${e.raw || e.code})`;
  }
  return 'Couldn’t send that right now. Please try again.';
}

/** Rules read the e-mail_verified claim from the ID token, so refresh it after verifying. */
async function emailVerified(user: User): Promise<boolean> {
  const {reload} = await import('firebase/auth');
  if (!user.emailVerified) {await reload(user); if (!user.emailVerified) return false;}
  if ((await user.getIdTokenResult()).claims.email_verified === true) return true;
  return (await user.getIdTokenResult(true)).claims.email_verified === true;
}

/** Signed-in, active, verified account with no recent post. Returns the user or a reason. */
async function preparePost(): Promise<{user: User; wait: number} | PostResult> {
  const [{doc, getDoc}, , {cloudDb, accountAuth}, {firestoreCloud}] = await libs();
  const user = accountAuth.currentUser;
  if (!user) return fail('Sign in to post. It keeps the community accountable and lets us prevent spam.');
  const status = await firestoreCloud.ensureAccount(user.uid, {appVersion: APP_VERSION, platform: Platform.OS});
  if (status === 'suspended') return fail('Your account is restricted, so it can’t post. Contact support if you think this is a mistake.');
  if (status === 'deleted') return fail('This account is being deleted.');
  if (!(await emailVerified(user))) return fail('Verify your e-mail to post. Open the link we sent you, then try again.');
  const stamp = await getDoc(doc(cloudDb(), 'users', user.uid, 'limits', 'post'));
  const last = stamp.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
  const wait = Math.min(POST_RATE_LIMIT_SECONDS, Math.ceil((last + (POST_RATE_LIMIT_SECONDS + 1) * 1000 - Date.now()) / 1000));
  return {user, wait: Math.max(0, wait)};
}

/** Create one post. The screen filter runs first; the rules re-check everything. */
export async function createPost(name: string, text: string): Promise<PostResult> {
  const screen = screenPost(text);
  if (!screen.ok) return fail(screen.message);
  const cleanName = cleanText(name, 24).trim() || 'Code Explorer';
  const [{doc, writeBatch, serverTimestamp, collection}, , {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    const ready = await preparePost();
    if ('ok' in ready) return ready;
    if (ready.wait > 0) return fail(`Please wait ${ready.wait} s before posting again.`, {wait: ready.wait});
    const db = cloudDb(), batch = writeBatch(db);
    batch.set(doc(db, 'users', ready.user.uid, 'limits', 'post'), {last: serverTimestamp()});
    batch.set(doc(collection(db, 'communityPosts')), {uid: ready.user.uid, name: cleanName, text: cleanText(text, POST_MAX_LENGTH).trim(), likeCount: 0, hidden: false, createdAt: serverTimestamp()});
    await batch.commit();
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}

/** Live posts, newest first. Subscribes only while the Posts view is open; returns the unsubscribe function. */
export function subscribePosts(onPosts: (posts: CommunityPost[]) => void, onError: (message: string) => void): () => void {
  let stop = () => {};
  void libs().then(([, live, {cloudDbLive}]) => {
    const q = live.query(
      live.collection(cloudDbLive(), 'communityPosts'),
      live.where('hidden', '==', false),
      live.orderBy('createdAt', 'desc'),
      live.limit(POST_PAGE_SIZE),
    );
    stop = live.onSnapshot(q, snap => {
      const posts = snap.docs
        .map(d => toCommunityPost(d.id, d.data()))
        .filter((p): p is CommunityPost => p !== null);
      onPosts(posts);
    }, () => onError('Couldn’t load the posts. Check your connection and try again.'));
  }).catch(() => onError('Couldn’t load the posts. Check your connection and try again.'));
  return () => stop();
}

/** The post IDs the signed-in user has liked (for the filled heart). Returns [] when signed out or on error. */
export async function fetchMyLikedPostIds(): Promise<Set<string>> {
  try {
    const [{collection, query, where, getDocs, limit}, , {cloudDb, accountAuth}] = await libs();
    const uid = accountAuth.currentUser?.uid;
    if (!uid) return new Set();
    const snap = await getDocs(query(collection(cloudDb(), 'communityPostLikes'), where('uid', '==', uid), limit(500)));
    return new Set(snap.docs.map(d => (typeof d.data().postId === 'string' ? d.data().postId as string : '')).filter(Boolean));
  } catch {return new Set();}
}

/**
 * Like or unlike a post. One transaction reads the post and the like document,
 * then writes both together — the like document and the post's likeCount can
 * never drift apart, and a like on a hidden post is refused by the rules.
 * Returns the new liked state.
 */
export async function toggleLike(postId: string): Promise<PostResult> {
  const [{doc, runTransaction, serverTimestamp}, , {cloudDb, accountAuth}, {toCloudError}, {CloudError}] = await libs();
  const user = accountAuth.currentUser;
  if (!user) return fail('Sign in to like a post.');
  if (typeof postId !== 'string' || !postId) return fail('That post no longer exists.');
  const db = cloudDb();
  const postRef = doc(db, 'communityPosts', postId);
  const likeRef = doc(db, 'communityPostLikes', `${postId}_${user.uid}`);
  try {
    const liked = await runTransaction(db, async tx => {
      const postSnap = await tx.get(postRef);
      if (!postSnap.exists()) throw new Error('missing');
      const data = postSnap.data() as Record<string, unknown>;
      if (data.hidden !== false) throw new Error('hidden');
      const likeCount = typeof data.likeCount === 'number' ? data.likeCount : 0;
      const likeSnap = await tx.get(likeRef);
      if (likeSnap.exists()) {
        tx.delete(likeRef);
        tx.update(postRef, {likeCount: Math.max(0, likeCount - 1)});
        return false;
      }
      tx.set(likeRef, {postId, uid: user.uid, createdAt: serverTimestamp()});
      tx.update(postRef, {likeCount: likeCount + 1});
      return true;
    });
    return {ok: true, liked};
  } catch (e) {
    if (e instanceof Error && (e.message === 'missing' || e.message === 'hidden')) return fail('That post no longer exists.');
    return fail(errorText(toCloudError(e), CloudError));
  }
}

/** Delete one of your own posts. Moderators hide other people’s posts from the admin portal. */
export async function deleteOwnPost(id: string): Promise<PostResult> {
  const [{doc, deleteDoc}, , {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    await deleteDoc(doc(cloudDb(), 'communityPosts', id));
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}

/** Report one community post. Same reasons and rate limit as chat reports. */
export async function reportPost(postId: string, reason: string, note: string): Promise<PostResult> {
  if (!(REPORT_REASONS as readonly string[]).includes(reason)) return fail('Choose a reason.');
  if (typeof postId !== 'string' || !postId) return fail('That post no longer exists.');
  const [{doc, collection, writeBatch, serverTimestamp, getDoc}, , {cloudDb, accountAuth}, {firestoreCloud, toCloudError}, {CloudError}] = await libs();
  try {
    const user = accountAuth.currentUser;
    if (!user) return fail('Sign in to report a post.');
    const status = await firestoreCloud.ensureAccount(user.uid, {appVersion: APP_VERSION, platform: Platform.OS});
    if (status === 'suspended') return fail('Your account is restricted, so it can’t report. Contact support if you think this is a mistake.');
    if (status === 'deleted') return fail('This account is being deleted.');
    const stamp = await getDoc(doc(cloudDb(), 'users', user.uid, 'limits', 'ugc'));
    const last = stamp.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
    const wait = Math.min(60, Math.ceil((last + 61_000 - Date.now()) / 1000));
    if (wait > 0) return fail(`Please wait ${wait} s before sending another report.`, {wait});
    const db = cloudDb(), batch = writeBatch(db);
    batch.set(doc(db, 'users', user.uid, 'limits', 'ugc'), {last: serverTimestamp()});
    batch.set(doc(collection(db, 'postReports')), {postId, reason, note: cleanText(note, 300), uid: user.uid, status: 'open', createdAt: serverTimestamp()});
    await batch.commit();
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}
