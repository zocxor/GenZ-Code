/**
 * Buy Tokens + Premium: the seven consumable token packages and the two
 * Premium subscriptions, sold through Google Play Billing. Prices come from
 * Play (localized by the user's Play country and currency) — never from
 * code. Tapping Buy / Subscribe opens the official Google Play purchase
 * dialog; there is no in-app payment form and no simulated success.
 *
 * Tokens are credited only after a real Play purchase is verified and recorded
 * in the account's ledger (see src/billing.ts). Premium benefits are granted
 * only after the subscription is verified by the backend (see
 * src/subscription.ts). Pending purchases are never credited; cancelled
 * purchases are reported calmly, not as errors. Purchases need a signed-in
 * account, because the ledger and the subscription are keyed by the account.
 */
import React, {useEffect, useState} from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet, ActivityIndicator} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Button, Icon, IconTile, SectionHeader, FadeIn, Skeleton} from './ui';
import {useAccountUser} from './services';
import {
  getBillingProducts, getBillingStatus, retryBilling, buyTokens,
  onBillingEvent, type BillingProduct, type BillingEvent,
} from './billing';
import {
  getSubscriptionProducts, getSubscriptionStatus, buySubscription,
  isSubscriptionPurchaseEnabled,
  onSubscriptionEvent, type SubscriptionProduct, type SubscriptionEvent,
} from './subscription';
import type {TokensState} from '../shared/tokens';

type Msg = {kind: 'success' | 'pending' | 'error' | 'info'; text: string} | null;

export default function TokenShopScreen({tokens, onSignIn, onOpenWallet}: {tokens: TokensState; onSignIn: () => void; onOpenWallet: () => void}) {
  const user = useAccountUser();
  const [products, setProducts] = useState<BillingProduct[]>(() => getBillingProducts());
  const [status, setStatus] = useState(() => getBillingStatus());
  // Loading only while billing has not finished its first load. Without the
  // `loaded` check this stuck on "Loading prices…" forever when billing had
  // already finished (with zero products) before this screen mounted, because
  // the 'products' event had already fired and was never received here.
  const [loading, setLoading] = useState(products.length === 0 && status.available && !status.loaded);
  const [buying, setBuying] = useState<string | null>(null);
  const [retrying, setRetrying] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);
  const [subs, setSubs] = useState<SubscriptionProduct[]>(() => getSubscriptionProducts());
  const [subStatus, setSubStatus] = useState(() => getSubscriptionStatus());
  const [subscribing, setSubscribing] = useState<string | null>(null);

  useEffect(() => {
    // Billing may have finished between the state initializers above and
    // this subscription (initBilling runs at app start). If it already
    // loaded, sync now instead of waiting for an event that already fired.
    const s = getBillingStatus();
    if (s.loaded) {
      setProducts(getBillingProducts());
      setStatus(s);
      setLoading(false);
    }
    return onBillingEvent((e: BillingEvent) => {
    if (e.kind === 'products') {
      setProducts(getBillingProducts());
      setStatus(getBillingStatus());
      setLoading(false);
    } else if (e.kind === 'unavailable') {
      setStatus(getBillingStatus());
      setLoading(false);
    } else if (e.kind === 'credited') {
      setBuying(null);
      setMsg({kind: 'success', text: `${e.tokens.toLocaleString()} tokens added to your wallet.`});
    } else if (e.kind === 'already-credited') {
      setBuying(null);
      setMsg({kind: 'info', text: 'This purchase was already credited to your wallet.'});
    } else if (e.kind === 'pending') {
      setBuying(null);
      setMsg({kind: 'pending', text: 'Payment pending — your tokens will arrive once Google Play confirms it. Check back in a moment.'});
    } else if (e.kind === 'failed') {
      setBuying(null);
      setMsg({kind: 'error', text: e.message});
    } else if (e.kind === 'cancelled') {
      setBuying(null);
      setMsg({kind: 'info', text: 'Purchase cancelled. No charge was made.'});
    } else if (e.kind === 'restored' && e.count > 0) {
      setMsg({kind: 'success', text: `${e.count} earlier purchase${e.count > 1 ? 's' : ''} restored to your wallet.`});
    } else if (e.kind === 'signin-required') {
      setBuying(null);
      setMsg({kind: 'error', text: 'Sign in first — purchases are recorded on your account.'});
    }
    });
  }, []);

  useEffect(() => {
    setSubs(getSubscriptionProducts());
    setSubStatus(getSubscriptionStatus());
    return onSubscriptionEvent((e: SubscriptionEvent) => {
      if (e.kind === 'products') {
        setSubs(getSubscriptionProducts());
        setSubStatus(getSubscriptionStatus());
      } else if (e.kind === 'subscribed') {
        setSubscribing(null);
        setMsg({kind: 'success', text: `Premium is active — ${e.tokens.toLocaleString()} tokens added, and ads are off until ${new Date(e.expiryTime).toLocaleDateString()}.`});
      } else if (e.kind === 'already-subscribed') {
        setSubscribing(null);
        setMsg({kind: 'info', text: 'Your Premium subscription is already active.'});
      } else if (e.kind === 'pending') {
        setSubscribing(null);
        setMsg({kind: 'pending', text: 'Payment pending — Premium starts once Google Play confirms it.'});
      } else if (e.kind === 'failed') {
        setSubscribing(null);
        setMsg({kind: 'error', text: e.message});
      } else if (e.kind === 'cancelled') {
        setSubscribing(null);
        setMsg({kind: 'info', text: 'Subscription cancelled. No charge was made.'});
      } else if (e.kind === 'signin-required') {
        setSubscribing(null);
        setMsg({kind: 'error', text: 'Sign in first — subscriptions are recorded on your account.'});
      }
    });
  }, []);

  const retry = async () => {
    setRetrying(true);
    setMsg(null);
    const r = await retryBilling();
    setProducts(r.products);
    setStatus(getBillingStatus());
    setLoading(false);
    setRetrying(false);
  };

  const buy = async (productId: string) => {
    if (buying) return;
    setMsg(null);
    setBuying(productId);
    const r = await buyTokens(productId);
    if (!r.started) {
      setBuying(null);
      if (r.error && r.error !== 'Purchase cancelled.') setMsg({kind: 'error', text: r.error});
      else if (r.error === 'Purchase cancelled.') setMsg({kind: 'info', text: 'Purchase cancelled. No charge was made.'});
    }
    // When started, the result arrives through the billing event listener.
  };

  const subscribe = async (productId: string) => {
    if (subscribing) return;
    setMsg(null);
    setSubscribing(productId);
    const r = await buySubscription(productId);
    if (!r.started) {
      setSubscribing(null);
      if (r.error && r.error !== 'Subscription cancelled.') setMsg({kind: 'error', text: r.error});
      else if (r.error === 'Subscription cancelled.') setMsg({kind: 'info', text: 'Subscription cancelled. No charge was made.'});
    }
    // When started, the result arrives through the subscription event listener.
  };

  return (
    <ScrollView contentContainerStyle={s.content}>
      <FadeIn>
        <LinearGradient colors={[C.navy, '#1B3A8F', C.accent]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.hero}>
          <View style={s.between}>
            <View style={{flex: 1}}>
              <Text style={s.heroEyebrow}>YOUR BALANCE</Text>
              <Text style={s.heroBalance}>{tokens.balance.toLocaleString()} tokens</Text>
            </View>
            <IconTile icon="star" from={C.gold} to="#D9930D" size={44} iconSize={22} />
          </View>
          <Text style={s.heroCaption}>For suggesting words and unlocking levels early.</Text>
        </LinearGradient>
      </FadeIn>

      {!user && (
        <FadeIn delay={60}>
          <View style={s.card}>
            <View style={s.cardHead}>
              <IconTile icon="log-in-outline" from={C.accent} to={C.navy} size={44} iconSize={22} />
              <Text style={s.sectionTitle}>Sign in to buy tokens</Text>
            </View>
            <Text style={s.body}>Purchases stay on your account across reinstalls.</Text>
            <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
          </View>
        </FadeIn>
      )}

      {msg && (
        <View style={[s.msg, msg.kind === 'success' ? s.msgOk : msg.kind === 'pending' ? s.msgPending : msg.kind === 'error' ? s.msgErr : s.msgInfo]}>
          <Icon name={msg.kind === 'success' ? 'checkmark-circle-outline' : msg.kind === 'pending' ? 'hourglass-outline' : msg.kind === 'error' ? 'alert-circle-outline' : 'information-circle-outline'} color={msg.kind === 'success' ? C.success : msg.kind === 'pending' ? C.warn : msg.kind === 'error' ? C.danger : C.accent} size={20} />
          <Text style={s.msgText}>{msg.text}</Text>
        </View>
      )}

      <SectionHeader eyebrow="BUY TOKENS" title="Token packages" />

      {loading ? (
        <View style={s.card}>
          <ActivityIndicator color={C.accent} />
          <Skeleton height={16} />
          <Skeleton height={16} width="70%" />
          <Text style={s.body}>Loading prices from Google Play…</Text>
        </View>
      ) : !status.available ? (
        <FadeIn>
          <View style={s.card}>
            <View style={s.cardHead}>
              <IconTile icon="alert-circle-outline" from={C.accent} to={C.navy} size={44} iconSize={22} />
              <Text style={s.sectionTitle}>Google Play billing is unavailable</Text>
            </View>
            <Text style={s.body}>{status.error || 'Billing could not be reached on this device. Purchases need Google Play on Android.'}</Text>
            <Button title={retrying ? 'Retrying…' : 'Try again'} icon="refresh-outline" onPress={() => void retry()} disabled={retrying} />
          </View>
        </FadeIn>
      ) : products.length === 0 ? (
        <FadeIn>
          <View style={s.card}>
            <View style={s.cardHead}>
              <IconTile icon="search-outline" from={C.accent} to={C.navy} size={44} iconSize={22} />
              <Text style={s.sectionTitle}>No token packages found</Text>
            </View>
            <Text style={s.body}>Google Play returned no products.</Text>
            <Button title={retrying ? 'Retrying…' : 'Try again'} icon="refresh-outline" onPress={() => void retry()} disabled={retrying} />
          </View>
        </FadeIn>
      ) : (
        products.map((p, i) => (
          <FadeIn key={p.productId} delay={Math.min(i, 6) * 50}>
            <View style={[s.card, p.popular && s.cardPopular]}>
              <View style={s.between}>
                <IconTile icon="cash-outline" from={C.gold} to="#D9930D" size={48} iconSize={24} />
                <View style={{flex: 1}}>
                  <View style={s.row}>
                    <Text style={s.pkg}>{p.tokens.toLocaleString()} tokens</Text>
                    {p.popular && <View style={s.pop}><Text style={s.popText}>MOST POPULAR</Text></View>}
                  </View>
                  <Text style={s.caption}>{p.title}</Text>
                </View>
                <Text style={s.price}>{p.localizedPrice}</Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Buy ${p.tokens.toLocaleString()} tokens for ${p.localizedPrice}`}
                accessibilityState={{disabled: !user || buying !== null}}
                disabled={!user || buying !== null}
                onPress={() => void buy(p.productId)}
                style={[s.buy, (!user || buying !== null) && {opacity: .5}]}>
                {buying === p.productId
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={s.buyText}>Buy</Text>}
              </Pressable>
            </View>
          </FadeIn>
        ))
      )}

      <SectionHeader eyebrow="PREMIUM" title="GenZ Codebook Premium" />
      <FadeIn>
        <LinearGradient colors={[C.purple, '#4B2FD6', C.navy]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.hero}>
          <View style={s.cardHead}>
            <IconTile icon="star" from="#B79CFF" to={C.purple} size={44} iconSize={22} />
            <Text style={s.heroTitle}>GenZ Codebook Premium</Text>
          </View>
          <Text style={s.heroCaption}>No ads, plus tokens every billing period.</Text>
        </LinearGradient>
      </FadeIn>
      {!isSubscriptionPurchaseEnabled() ? (
        <FadeIn>
          <View style={s.card}>
            <Text style={s.body}>Premium is not available yet.</Text>
            <Text style={s.caption}>No purchase is accepted until then — opens once verification is deployed.</Text>
          </View>
        </FadeIn>
      ) : subs.length === 0 ? (
        <FadeIn>
          <View style={s.card}>
            <Text style={s.body}>Premium plans are not listed in Google Play yet (premium_monthly, premium_yearly).</Text>
          </View>
        </FadeIn>
      ) : (
        subs.map((p, i) => (
          <FadeIn key={p.productId} delay={Math.min(i, 1) * 50}>
            <View style={[s.card, p.productId === 'premium_yearly' && s.cardPopular]}>
              <View style={s.between}>
                <IconTile icon="star" from={C.purple} to="#4B2FD6" size={48} iconSize={24} />
                <View style={{flex: 1}}>
                  <View style={s.row}>
                    <Text style={s.pkg}>Premium {p.productId === 'premium_yearly' ? 'Yearly' : 'Monthly'}</Text>
                    {p.productId === 'premium_yearly' && <View style={s.pop}><Text style={s.popText}>BEST VALUE</Text></View>}
                  </View>
                  <View style={s.premiumDetails}>
                    <View style={s.premiumChip}><Text style={s.premiumChipText}>{p.tokensPerPeriod.toLocaleString()} tokens {p.periodLabel}</Text></View>
                    <View style={s.premiumChip}><Text style={s.premiumChipText}>No ads</Text></View>
                  </View>
                  {!!p.description && <Text style={s.caption} numberOfLines={1}>{p.description}</Text>}
                </View>
                <Text style={s.price}>{p.localizedPrice}</Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel={`Subscribe to Premium ${p.productId === 'premium_yearly' ? 'Yearly' : 'Monthly'} for ${p.localizedPrice}`}
                accessibilityState={{disabled: !user || subscribing !== null}}
                disabled={!user || subscribing !== null}
                onPress={() => void subscribe(p.productId)}
                style={[s.buy, s.buyPremium, (!user || subscribing !== null) && {opacity: .5}]}>
                {subscribing === p.productId
                  ? <ActivityIndicator color="#fff" />
                  : <Text style={s.buyText}>Subscribe</Text>}
              </Pressable>
            </View>
          </FadeIn>
        ))
      )}
      {subStatus.missing.length > 0 && subStatus.available && (
        <Text style={s.fine}>Not listed yet in Google Play: {subStatus.missing.join(', ')}.</Text>
      )}

      {status.missing.length > 0 && status.available && (
        <Text style={s.fine}>Not listed yet in Google Play: {status.missing.join(', ')}.</Text>
      )}

      <Text style={s.fine}>Prices come from Google Play. Payment is charged through Google Play — this app never sees your card.</Text>
      <Button title="View my wallet" icon="wallet-outline" light onPress={onOpenWallet} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  row: {flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap'},
  cardHead: {flexDirection: 'row', alignItems: 'center', gap: 12},
  hero: {borderRadius: 20, padding: 16, gap: 8},
  heroEyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.6, color: '#FFD97A'},
  heroBalance: {fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -.5},
  heroTitle: {fontSize: 20, fontWeight: '800', letterSpacing: -.4, color: '#fff', flex: 1, flexWrap: 'wrap'},
  heroCaption: {fontSize: 13, lineHeight: 19, color: 'rgba(255,255,255,0.85)'},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 12, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: .09, shadowRadius: 14, elevation: 3},
  cardPopular: {borderColor: C.gold, borderWidth: 2},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  sectionTitle: {fontSize: 18, fontWeight: '800', letterSpacing: -.4, color: C.navy, flex: 1, flexWrap: 'wrap'},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  pkg: {fontSize: 18, fontWeight: '900', color: C.navy, letterSpacing: -.4},
  price: {fontSize: 16, fontWeight: '900', color: C.accent},
  pop: {backgroundColor: C.gold, borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3},
  popText: {fontSize: 9, fontWeight: '900', letterSpacing: 1, color: C.navy},
  premiumDetails: {flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8},
  premiumChip: {backgroundColor: C.soft, borderWidth: 1, borderColor: '#dbe7f5', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5},
  premiumChipText: {fontSize: 12, fontWeight: '800', color: C.accent},
  buy: {marginTop: 4, minHeight: 44, borderRadius: 16, backgroundColor: C.accent, alignItems: 'center', justifyContent: 'center'},
  buyPremium: {backgroundColor: C.purple},
  buyText: {color: '#fff', fontSize: 16, fontWeight: '800'},
  msg: {flexDirection: 'row', gap: 10, padding: 14, borderRadius: 16, borderWidth: 1, alignItems: 'flex-start'},
  msgText: {flex: 1, fontSize: 14, lineHeight: 20, color: C.ink, fontWeight: '600'},
  msgOk: {backgroundColor: '#e1f5e9', borderColor: '#77bb95'},
  msgPending: {backgroundColor: '#fff4cc', borderColor: '#d9b64a'},
  msgErr: {backgroundColor: '#fff0ee', borderColor: '#d0a09c'},
  msgInfo: {backgroundColor: '#e7f0fb', borderColor: '#b6cae2'},
});
