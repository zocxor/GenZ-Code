/**
 * App service container. Local services start immediately; Firebase-backed services are
 * started after the first render so cloud code never delays opening the app.
 */
import {useSyncExternalStore} from 'react';
import {AppState, Platform} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {LearningStore} from './storage';
import {LearningRepository} from './repository';
import {SecurityEventLog} from './secure/events';
import {LoginGuard} from './shield/loginGuard';
import type {SyncEngine, SyncStatus} from './sync/engine';
import type {User} from 'firebase/auth';
import {APP_VERSION} from './secure/config';
import {loadContentOverlay, refreshContent, refreshCommunity} from './contentSync';
import {loadPhoto} from './avatarPhoto';

export const repository = new LearningRepository(new LearningStore(AsyncStorage));
export const securityLog = new SecurityEventLog(AsyncStorage);
export const loginGuard = new LoginGuard(AsyncStorage);

type CloudServices = {engine: SyncEngine; getUser: () => User | null; onUser: (fn: () => void) => () => void};
let cloud: CloudServices | null = null;
let cloudStarting: Promise<CloudServices> | null = null;
const cloudListeners = new Set<() => void>();

/** Lazily start Firebase Auth + sync. Safe to call many times. */
export function startCloud(): Promise<CloudServices> {
  if (cloud) return Promise.resolve(cloud);
  if (!cloudStarting) cloudStarting = (async () => {
    const [{SyncEngine}, {firestoreCloud}, {startSession}] = await Promise.all([import('./sync/engine'), import('./sync/firestoreCloud'), import('./secure/session')]);
    const engine = new SyncEngine(repository, firestoreCloud, {appVersion: APP_VERSION, platform: Platform.OS, onSecurityEvent: (t, d) => void securityLog.record(t, d)});
    const session = startSession(engine, securityLog);
    cloud = {engine, getUser: session.getUser, onUser: session.onUser};
    engine.subscribe(() => cloudListeners.forEach(f => f()));
    session.onUser(() => cloudListeners.forEach(f => f()));
    cloudListeners.forEach(f => f());
    AppState.addEventListener('change', s => {if (s === 'active') {engine.requestSync(); void refreshContent(securityLog); void refreshCommunity();}});
    return cloud;
  })();
  return cloudStarting;
}
export const getCloud = () => cloud;

/** Boot sequence: local data first; the content overlay and cloud start in the background so they can never delay the first paint. */
export async function bootServices() {
  // Local data first. The whole local boot is time-boxed (5s) so a slow or
  // hung read can never leave the app stuck on the splash screen; the
  // repository still finishes in the background and the UI updates via
  // subscription when it does. allSettled (not all) so one failed load can
  // never reject the boot — App.tsx marks booted in .finally either way.
  const local = Promise.allSettled([repository.load(), securityLog.load(), loginGuard.load(), loadPhoto()]);
  const timeout = new Promise<null>(resolve => setTimeout(() => resolve(null), 5000));
  await Promise.race([local, timeout]);
  // Content overlay (published updates) loads in the background. The bundled
  // content is the first paint; the overlay applies when it arrives (via
  // onContentChange), so a large cached overlay (up to 5000 entries +
  // 3000 community words, parsed and validated one by one) can never delay
  // opening the app again.
  setTimeout(() => { void loadContentOverlay().catch(() => {}); }, 0);
  setTimeout(() => {void startCloud().then(() => Promise.all([refreshContent(securityLog), refreshCommunity()])).catch(() => {});}, 0);
}

// ---------- React bindings ----------
export const useLearningState = () => useSyncExternalStore(repository.subscribe, repository.getState);
export const useStorageHealth = () => useSyncExternalStore(repository.subscribe, repository.getHealth);
export const useSecurityEvents = () => useSyncExternalStore(securityLog.subscribe, securityLog.list);
const subscribeCloud = (fn: () => void) => {cloudListeners.add(fn); return () => {cloudListeners.delete(fn);};};
const signedOut: SyncStatus = {phase: 'signed-out', uid: null, account: null, lastError: null, nextRetryAt: 0, lastSyncAt: 0, pending: false};
export const useSyncStatus = () => useSyncExternalStore(subscribeCloud, () => cloud?.engine.getStatus() ?? signedOut);
export const useAccountUser = () => useSyncExternalStore(subscribeCloud, () => cloud?.getUser() ?? null);
