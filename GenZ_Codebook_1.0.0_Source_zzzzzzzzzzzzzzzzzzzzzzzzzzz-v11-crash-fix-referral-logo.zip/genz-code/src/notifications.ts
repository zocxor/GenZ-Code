/**
 * Notifications feed: real recent activity, newest first.
 *
 * Pure builder — no Firebase, no React — so the grouping and sorting are
 * unit-tested. Every item comes from something the app genuinely records:
 *  - the token ledger (purchases, subscription grants, admin grants,
 *    migration) — same fetch WalletScreen uses, with real server timestamps;
 *  - accepted word submissions (a moderator's `reviewedAt` stamp);
 *  - the daily reward (the collected date in the local token state);
 *  - best quiz scores (the `u` stamp on each best record);
 *  - day-streak milestones (dates computed from the recorded activity days).
 * There is deliberately NO "Community Reply" or "Daily Word" item: the app
 * does not record those events, so they are not shown.
 */
import type {IconName} from './ui';
import type {TokenTxnRow} from './tokenLedger';
import {TOKENS} from '../shared/tokens';
import {ago} from './shield/status';

export type NotificationKind = 'tokens' | 'learning' | 'community';
export type NotificationItem = {id: string; at: number; kind: NotificationKind; icon: IconName; title: string; subtitle: string};

/** Same display labels WalletScreen uses for ledger entries. */
const TYPE_LABEL: Record<string, string> = {
  purchase: 'Token purchase',
  subscription: 'Premium tokens',
  migration: 'Opening balance',
  daily: 'Daily reward',
  ad: 'Rewarded ad',
  game: 'Quiz reward',
  spend: 'Spent',
  adjustment: 'Adjustment',
};
const TYPE_ICON: Record<string, IconName> = {
  purchase: 'card-outline',
  subscription: 'star-outline',
  migration: 'gift-outline',
  daily: 'gift-outline',
  ad: 'play-circle-outline',
  game: 'game-controller-outline',
  spend: 'arrow-down-circle-outline',
  adjustment: 'construct-outline',
};

const DAY = /^\d{4}-\d{2}-\d{2}$/;
/** Local noon on a 'YYYY-MM-DD' day, so the date never shifts with timezones. */
export function dayToMs(day: string): number {
  const [y, m, d] = day.split('-').map(Number) as [number, number, number];
  return new Date(y, m - 1, d, 12).getTime();
}
function previousDay(day: string): string {
  const [y, m, d] = day.split('-').map(Number) as [number, number, number];
  return localDayOf(new Date(y, m - 1, d - 1, 12).getTime());
}
function localDayOf(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * Streak milestones, from the recorded activity days. Returns at most one
 * 3-day and one 7-day milestone, dated on the day the longest recorded run
 * reached that length. An empty list when no run reaches 3 days.
 */
export function streakMilestones(days: Record<string, number>): {days: 3 | 7; at: number}[] {
  const keys = Object.keys(days).filter(d => (days[d] ?? 0) > 0).sort();
  if (!keys.length) return [];
  const runs: string[][] = [];
  for (const day of keys) {
    const last = runs[runs.length - 1];
    if (last && previousDay(day) === last[last.length - 1]) last.push(day);
    else runs.push([day]);
  }
  let best = runs[0]!;
  for (const r of runs) if (r.length >= best.length) best = r;
  const out: {days: 3 | 7; at: number}[] = [];
  if (best.length >= 3) out.push({days: 3, at: dayToMs(best[2]!)});
  if (best.length >= 7) out.push({days: 7, at: dayToMs(best[6]!)});
  return out;
}

export type AcceptedWord = {id: string; term: string; reviewedAt: number};

/** Build the feed, newest first, capped at 25 items. */
export function buildNotifications(input: {
  txns: TokenTxnRow[];
  accepted: AcceptedWord[];
  lastDailyCollect: string;
  best: Record<string, {v: number; u: number}>;
  days: Record<string, number>;
  stageName: (id: string) => string;
}): NotificationItem[] {
  const items: NotificationItem[] = [];
  for (const t of input.txns) {
    if (!t.createdAt) continue;
    items.push({
      id: `txn-${t.id}`, at: t.createdAt, kind: 'tokens', icon: TYPE_ICON[t.type] ?? 'wallet-outline',
      title: TYPE_LABEL[t.type] ?? t.type,
      subtitle: `${t.amount >= 0 ? '+' : ''}${t.amount.toLocaleString()} tokens${t.ref ? ` · ${t.ref}` : ''}`,
    });
  }
  for (const w of input.accepted) {
    if (!w.reviewedAt) continue;
    items.push({
      id: `sub-${w.id}`, at: w.reviewedAt, kind: 'community', icon: 'checkmark-circle-outline',
      title: `Your word “${w.term}” was accepted`,
      subtitle: `+${TOKENS.ACCEPTED_WORD} tokens`,
    });
  }
  if (DAY.test(input.lastDailyCollect)) {
    items.push({
      id: `daily-${input.lastDailyCollect}`, at: dayToMs(input.lastDailyCollect), kind: 'tokens', icon: 'gift-outline',
      title: 'Daily reward collected',
      subtitle: `+${TOKENS.DAILY_COLLECT} tokens`,
    });
  }
  for (const [stageId, r] of Object.entries(input.best)) {
    if (!r.u) continue;
    if (r.v === 100) {
      items.push({id: `best-${stageId}`, at: r.u, kind: 'learning', icon: 'star', title: `Perfect round in ${input.stageName(stageId)}`, subtitle: 'Scored 5 / 5'});
    } else if (r.v >= 60) {
      items.push({id: `best-${stageId}`, at: r.u, kind: 'learning', icon: 'trophy-outline', title: `Cleared ${input.stageName(stageId)}`, subtitle: `Best score ${r.v}%`});
    }
  }
  for (const m of streakMilestones(input.days)) {
    items.push({
      id: `streak-${m.days}`, at: m.at, kind: 'learning', icon: 'flame',
      title: `${m.days}-day streak`,
      subtitle: 'Keep it going — practise today to extend it.',
    });
  }
  return items.sort((a, b) => b.at - a.at || a.id.localeCompare(b.id)).slice(0, 25);
}

/** Relative time for a feed item ("just now", "3 h ago", "2 d ago"). */
export function fmtWhen(at: number, now = Date.now()): string {
  return ago(Math.max(0, now - at));
}
