/**
 * Achievements: the badge list, computed from the saved learning state.
 *
 * This is the SAME computation ProfileDashboard ("You" tab) uses for its
 * "Your little wins" section — same six badges, same earned/hint logic —
 * extracted here so the Achievements page shows exactly what the profile
 * shows, with no second source of truth for the rules. ProfileDashboard
 * keeps its own inline copy (it is not edited); if the badge rules change,
 * change them in both places.
 */
import type {IconName} from './ui';
import type {LearningState, Profile} from './profile';
import {streak} from './profile';
import {stages} from './games';

export type Badge = {icon: IconName; label: string; earned: boolean; hint: string};

/** The six badges, in display order. Every threshold reads the real state. */
export function computeBadges(state: LearningState, profile: Profile): Badge[] {
  const played = stages.filter(g => profile.best[g.id] !== undefined).length;
  const perfect = Object.values(profile.best).some(v => v === 100);
  const mastered = Object.values(profile.progress).filter(r => r.mastery >= 80).length;
  const st = streak(state.days);
  return [
    {icon: 'chatbubbles', label: 'Code cracker', earned: played > 0, hint: 'Play a level'},
    {icon: 'star', label: 'Perfect round', earned: perfect, hint: 'Score 5 / 5'},
    {icon: 'bookmark', label: 'Word collector', earned: profile.saved.length >= 5, hint: 'Save 5 words'},
    {icon: 'flame', label: 'On a roll', earned: st.best >= 3, hint: '3-day streak'},
    {icon: 'calendar', label: 'Week warrior', earned: st.best >= 7, hint: '7-day streak'},
    {icon: 'school', label: 'Sharp memory', earned: mastered >= 10, hint: 'Master 10 words'},
  ];
}
