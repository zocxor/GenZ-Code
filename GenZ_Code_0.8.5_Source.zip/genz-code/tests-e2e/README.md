# Browser end-to-end checks

Run against exported web builds (AsyncStorage → localStorage on web):

```
mkdir -p tests-e2e/shots && npx expo export --platform web --clear --output-dir build/web && python3 -m http.server 8090 --directory build/web &
node tests-e2e/persistence.mjs   # close/reopen persistence, corruption recovery, quarantine, deletion (18 checks)
node tests-e2e/photo.mjs         # profile photo pick → crop/downscale → persist → delete (8 checks)

# Account flows need the Firebase Auth emulator and an emulator-wired build:
firebase emulators:start --only auth --project gen-z-code-55caf &
EXPO_PUBLIC_FIREBASE_EMULATOR_HOST=127.0.0.1 npx expo export --platform web --clear --output-dir build/web-emu
python3 -m http.server 8091 --directory build/web-emu &
node tests-e2e/auth.mjs          # sign-up, throttling, sign-out, safe deletion (17 checks; Firestore must NOT be running)

# Community words + cloud restore (0.8.3) also need a local Firestore emulator on :8080.
# The official one (firebase emulators:start --only auth,firestore) works; without Java,
# `npx hidane --host 127.0.0.1 --port 8080` speaks the same protocol but does NOT enforce
# security rules, so this checks app behaviour only (rules: npm run test:rules).
EXPO_PUBLIC_FIREBASE_EMULATOR_HOST=localhost npx expo export --platform web --clear --output-dir build/web-emu
node tests-e2e/community.mjs     # banners, verify gate, instant publish, other phone sees it, hide, duplicates, wait, restore after wipe (18 checks)
node tests-e2e/server-not-set-up.mjs  # stop :8080 first; its own deny-all Firestore = rules never published (3 checks)

# Admin portal moderation (Auth + Firestore emulators, portal built with VITE_FIREBASE_EMULATOR_HOST=127.0.0.1 into <dir>/admin, served on :8093)
node tests-e2e/admin-community.mjs  # password sign-in without MFA, verify gate, hide/restore + audit, instant-publish switch (8 checks)

# Admin portal with production headers (after `cd admin && npm run build`):
node tests-e2e/hosting-server.mjs admin/dist 8092 firebase.json &
node tests-e2e/admin.mjs         # CSP, public pages, fail-closed gate (10 checks; gate part needs an emulator build on :8093)
```
Always rebuild release bundles with `--clear` and without `EXPO_PUBLIC_FIREBASE_EMULATOR_HOST`.
