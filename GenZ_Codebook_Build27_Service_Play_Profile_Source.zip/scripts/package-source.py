"""Package deployable source without excluding source directories named lib."""
import argparse
import subprocess
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument('output', type=Path)
output = parser.parse_args().output.resolve()
subprocess.run(['node', str(root / 'scripts/check-admin-source.mjs')], check=True)
output.parent.mkdir(parents=True, exist_ok=True)

def include(path):
    parts = path.relative_to(root).parts
    if any(part in {'node_modules', '.git', '.expo', '.gradle', '.cxx', '__pycache__', 'dist', 'build', 'shots'} for part in parts):
        return False
    if parts[0].startswith(('dist-', '.callable')):
        return False
    # Only these lib/validation folders are generated. admin/src/lib is source.
    if parts[:2] == ('functions', 'lib') or parts[:3] == ('functions', 'src', 'validation'):
        return False
    if str(path.relative_to(root)) == 'admin/public/library-index.json':
        return False
    if path.name.startswith('.env') or path.suffix in {'.log', '.zip', '.pyc'}:
        return False
    if path.suffix in {'.jks', '.keystore'} and str(path.relative_to(root)) != 'android/app/debug.keystore':
        return False
    return path.is_file()

files = sorted(path for path in root.rglob('*') if include(path))
with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.relative_to(root))
with ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    for path in files:
        assert archive.read(str(path.relative_to(root))) == path.read_bytes()
    assert archive.getinfo('android/gradlew').external_attr >> 16 & 0o111
print(f'Validated {len(files)} source files: {output}')
