import {terms,Term} from './content';
import {Stage,Question} from './games';
import type {IconName} from './ui';
function rng(seed:number){let value=seed|0;return()=>{value^=value<<13;value^=value>>>17;value^=value<<5;return(value>>>0)/4294967296;};}
export const localDay=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
export const seedFrom=(s:string)=>[...s].reduce((a,c)=>Math.imul(a,31)+c.charCodeAt(0)|0,173);
const pool=terms.filter(t=>t.sensitivity==='None'&&t.full.length>=4&&t.full.length<=90&&(t.priority>=100||t.source?.license==='Apache-2.0'||t.category==='Emoji'));
export function dailyTerm(day=localDay()):Term{const picks=pool.filter(t=>t.priority>=100&&t.example);return picks[Math.abs(seedFrom(day))%picks.length]!;}
export function quizRound(category='Chat',day?:string):Stage{
 const questions=buildQuestions(category,day??String(Date.now()));
 return {id:day?'daily-'+day:'shuffle-'+category.toLowerCase(),name:day?'Daily five':category==='Emoji'?'Emoji name quest':'Shuffle: '+category,subtitle:'Fresh five-question practice',icon:category==='Emoji'?'happy':'sparkles',color:'#008493',questions};
}
/** Build one five-question round from a category, deterministically for a
 *  given seed: the same seed always deals the same five questions. */
function buildQuestions(category:string,seed:string):Question[]{
 const random=rng(seedFrom(seed));let choices=pool.filter(t=>category==='All'||t.categories.includes(category));if(choices.length<5)choices=pool;
 const shuffled=[...choices].sort((a,b)=>a.id.localeCompare(b.id));for(let i=shuffled.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[shuffled[i],shuffled[j]]=[shuffled[j]!,shuffled[i]!];}
 const selected:Term[]=[];const used=new Set<string>();for(const t of shuffled){if(used.has(t.full.toLowerCase()))continue;used.add(t.full.toLowerCase());selected.push(t);if(selected.length===5)break;}
 return selected.map(t=>{const distractors:Term[]=[];for(const other of shuffled){if(other.id!==t.id&&other.full.toLowerCase()!==t.full.toLowerCase()&&!distractors.some(x=>x.full.toLowerCase()===other.full.toLowerCase()))distractors.push(other);if(distractors.length===2)break;}
 const options=[t,...distractors];for(let i=options.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[options[i],options[j]]=[options[j]!,options[i]!];}
 return {prompt:t.category==='Emoji'?`Which standard name matches ${t.expression}?`:`In this reference, what does “${t.expression}” mean?`,context:t.example||`Reference practice · ${t.region}. Other contexts may use other meanings.`,answers:options.map(x=>x.full),correct:options.findIndex(x=>x.id===t.id),why:`${t.expression}: ${t.meaning}${t.status==='Imported reference'?' Imported reference; not individually editor-reviewed.':''}`,termId:t.id};});
}
/** The 30 quiz levels: 3 category tracks x 10 levels, built on the same quiz
 *  engine as the daily/shuffle rounds. Each level is seeded from its own id,
 *  so the same level always deals the same five questions (a level's best
 *  score means something), while different levels deal different questions.
 *  Only tracks with enough terms to fill 10 distinct rounds are used: Chat
 *  (1,466), Emoji (2,214) and Numbers (153). Gaming has 27 terms, too few. */
const LEVEL_TRACKS=[
 {category:'Chat',icon:'chatbubbles' as const,color:'#2c6bea',subtitle:'Everyday chat codes'},
 {category:'Emoji',icon:'happy' as const,color:'#a344b7',subtitle:'Emoji names and meanings'},
 {category:'Numbers',icon:'school' as const,color:'#00806c',subtitle:'Number codes and shortcuts'},
] as const;
const LEVEL_NAMES:Record<string,readonly string[]>={
 chat:['Inbox Insider','The BRB Trail','Lowkey Signals','Group Chat Secrets','The Ghosted Thread','Slang After Dark','Context Detective','Between the Lines','The Unsent Message','Chat Codebreaker'],
 emoji:['Beyond the Smile','Tears or Laughter?','The Skull Mystery','Hidden Reactions','Faces in Disguise','The Silent Reply','Emoji Alchemist','A Thousand Meanings','The Final Reaction','Emoji Mindreader'],
 numbers:['The 143 Door','Digits in Disguise','The Secret Sequence','Numbers After Midnight','The Hidden Pattern','Cipher Playground','The Countdown Clue','Beyond the Digits','The Locked Vault','Number Oracle'],
};
const LEVEL_ICONS:Record<string,readonly IconName[]>={
 chat:['mail-open','hourglass','radio','people','eye-off','moon','search','reader','send','key'],
 emoji:['happy','sad','skull','heart','glasses','chatbubble-ellipses','flask','color-palette','flash','trophy'],
 numbers:['keypad','finger-print','git-branch','moon','grid','extension-puzzle','timer','calculator','lock-closed','diamond'],
};
export function levelNameForId(id:string):string|undefined{
 const match=/^(chat|emoji|numbers)-(\d+)$/.exec(id);
 return match?LEVEL_NAMES[match[1]!]?.[Number(match[2])-1]:undefined;
}
export function levelStage(category:string,level:number):Stage{
 const track=LEVEL_TRACKS.find(t=>t.category===category)??LEVEL_TRACKS[0]!;
 const id=`${category.toLowerCase()}-${level}`;
 return {id,name:levelNameForId(id)??`${category} challenge ${level}`,subtitle:track.subtitle,icon:LEVEL_ICONS[category.toLowerCase()]?.[level-1]??track.icon,color:track.color,questions:buildQuestions(category,`level-${id}`)};
}
export function levelStages():Stage[]{
 const out:Stage[]=[];
 for(const t of LEVEL_TRACKS)for(let level=1;level<=10;level++)out.push(levelStage(t.category,level));
 return out;
}
export const quizPoolCount=pool.length;
