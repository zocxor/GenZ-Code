import React,{useEffect,useState} from 'react';
import {collection,documentId,endAt,getDocs,limit,orderBy,query,where,startAfter,startAt,type QueryDocumentSnapshot} from 'firebase/firestore/lite';
import {connectFunctionsEmulator,getFunctions,httpsCallable} from 'firebase/functions';
import {app,db} from '../firebase';
import {Card,Notice,Pill} from '../ui';
import policy from '../../../functions/src/communityPolicy.json';

const functions=getFunctions(app,'us-central1');
const emu=import.meta.env.VITE_FIREBASE_EMULATOR_HOST;
if(emu && /^(127\.0\.0\.1|localhost)$/.test(emu))connectFunctionsEmulator(functions,emu,5001);
const runFeature=httpsCallable(functions,'communityFeature');
type Kind='daily'|'post'|'verification';
type Report={id:string;postId:string;reason:string;note?:string};
type Row={id:string;status?:string;hidden?:boolean;name?:string;uid?:string;term?:string;text?:string;meaning?:string;category?:string;example?:string;payment?:string;fee?:number;createdAt?:{toMillis:()=>number};updatedAt?:{toMillis:()=>number};requestedDate?:string;publicationDate?:string;reservedDate?:string;reason?:string;schema?:number};
const sources={daily:'dailyCodeApplications',post:'communityPosts',verification:'verificationApplications'};
const day=(now=Date.now())=>new Date(now).toISOString().slice(0,10);
const when=(value?:{toMillis:()=>number})=>value?day(value.toMillis()):'—';
const statusOf=(r:Row)=>r.status??(r.hidden?'removed':'pending');
const label=(s:string)=>s.charAt(0).toUpperCase()+s.slice(1);
const statusTone=(s:string)=>s==='published'||s==='approved'?'good':s==='rejected'||s==='removed'||s==='revoked'?'bad':s==='scheduled'?'info':'warn';
const msgOf=(e:unknown)=>e instanceof Error?e.message:'The request could not be completed.';
function saveReport(rows:Row[]){
  const escape=(value:string)=>'"'+(/^[=+\-@\t\r]/.test(value)?"'":'')+value.replace(/"/g,'""')+'"';
  const csv=[['Word','Category','Submitted by','Status','Applied UTC','Requested UTC','Confirmed UTC','Payment'],...rows.map(r=>[r.term??'',r.category??'',r.name??'',statusOf(r),when(r.createdAt),r.requestedDate??'',r.publicationDate??'',r.payment??''])].map(r=>r.map(escape).join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const link=document.createElement('a');link.href=url;link.download='daily-code-report.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
export default function CommunityWorkflow({kind}:{kind:Kind}){
  const [rows,setRows]=useState<Row[]>([]),[cursor,setCursor]=useState<QueryDocumentSnapshot|null>(null),[more,setMore]=useState(false);
  const [reports,setReports]=useState<Report[]>([]);
  const [filter,setFilter]=useState('all'),[search,setSearch]=useState(''),[dateFilter,setDateFilter]=useState('');
  const [month,setMonth]=useState(day().slice(0,7)),[slots,setSlots]=useState<Record<string,string>>({}),[publications,setPublications]=useState<Row[]>([]);
  const [selected,setSelected]=useState(''),[date,setDate]=useState(''),[meaning,setMeaning]=useState(''),[example,setExample]=useState(''),[category,setCategory]=useState(''),[reason,setReason]=useState('');
  const [error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[refresh,setRefresh]=useState(0);
  const active=rows.find(r=>r.id===selected);
  const from=month+'-01';
  const days=new Date(Date.UTC(Number(month.slice(0,4)),Number(month.slice(5)),0)).getUTCDate();
  const last=month+'-'+String(days).padStart(2,'0');
  const load=async(after?:QueryDocumentSnapshot)=>{
    const snap=await getDocs(query(collection(db,sources[kind]),orderBy('createdAt','desc'),...(after?[startAfter(after)]:[]),limit(75)));
    const data=snap.docs.map(d=>({...d.data(),id:d.id}) as Row);
    setRows(current=>after?[...current,...data]:data);
    setCursor(snap.docs.at(-1)??null);setMore(snap.size===75);
  };
  useEffect(()=>{
    setLoading(true);setError('');
    void load().catch(e=>setError(msgOf(e))).finally(()=>setLoading(false));
  },[kind,refresh]);
  useEffect(()=>{
    if(kind!=='daily'||!/^\d{4}-\d{2}$/.test(month))return;
    let alive=true;
    const range=(name:string)=>getDocs(query(collection(db,name),orderBy(documentId()),startAt(from),endAt(last)));
    void Promise.all([range('dailyCodeDates'),range('dailyCodePublic')]).then(([s,p])=>{
      if(alive){setSlots(Object.fromEntries(s.docs.map(d=>[d.id,d.get('status')])));setPublications(p.docs.map(d=>({...d.data(),id:d.id}) as Row));}
    },e=>{if(alive)setError(msgOf(e));});
    return ()=>{alive=false;};
  },[kind,from,last,month,refresh]);
  useEffect(()=>{
    if(kind!=='post')return;
    let alive=true;
    void getDocs(query(collection(db,'postReports'),where('status','==','open'),limit(50))).then(snap=>{
      if(alive)setReports(snap.docs.map(d=>({...d.data(),id:d.id}) as Report));
    },e=>{if(alive)setError(msgOf(e));});
    return ()=>{alive=false;};
  },[kind,refresh]);
  const reviewReport=async(id:string,command:'dismiss'|'remove')=>{
    if(busy||!window.confirm(command==='remove'?'Resolve this report and remove the post?':'Dismiss this report?'))return;
    setBusy(true);setError('');setNotice('');
    try{await runFeature({action:'resolve-post-report',id,command});setRefresh(r=>r+1);setNotice('Report decision recorded.');}
    catch(e){setError(msgOf(e));}
    finally{setBusy(false);}
  };
  const choose=(r:Row)=>{
    setSelected(r.id);setDate(r.publicationDate??r.reservedDate??'');setMeaning(r.meaning??'');setExample(r.example??'');setCategory(r.category??policy.postCategories[0]!);setReason('');
  };
  const command=async(cmd:string)=>{
    if(busy)return;
    if(['reject','remove','revoked'].includes(cmd)&&!window.confirm(`Confirm ${cmd==='revoked'?'badge revocation':cmd}?`))return;
    setBusy(true);setError('');setNotice('');
    try {
      await runFeature({action:kind==='verification'?'verification-admin':kind+'-admin',command:cmd,id:selected,date:cmd==='publish'?day():date,meaning,example,category,...(reason.trim()?{reason:reason.trim()}: {})});
      setNotice('Saved. The action was recorded in the audit log.');setRefresh(r=>r+1);
    } catch(e){setError(msgOf(e));}
    finally{setBusy(false);}
  };
  const filters=kind==='daily'?['all','pending','approved','scheduled','published','rejected','cancelled']:kind==='post'?['all','pending','approved','rejected','removed']:['all','pending','approved','rejected','revoked'];
  const visible=rows.filter(r=>(filter==='all'||statusOf(r)===filter)&&(!dateFilter||when(r.createdAt)===dateFilter)&&(!search||[r.term,r.name,r.category,r.text,r.uid].some(v=>v?.toLowerCase().includes(search.toLowerCase().trim()))));
  return <div className="stack">
    {!!error&&<Notice kind="error">{error}</Notice>}{!!notice&&<Notice kind="ok">{notice}</Notice>}
    {kind==='daily'&&<Card title="Scheduling calendar" subtitle="Publication dates use UTC. Pending applications reserve a slot until they are scheduled, cancelled, or expire." actions={<>
      <a className="btn" href="#moderation">Dictionary approvals</a>
      <button className="btn" disabled={busy} onClick={()=>saveReport(visible)}>Export loaded applications</button>
      <button className="btn" disabled={busy} onClick={()=>void command('publish')}>Publish today</button>
    </>}>
      <label className="field">Month<input type="month" value={month} onChange={e=>{if(e.target.value)setMonth(e.target.value);}}/></label>
      <div className="feature-calendar" aria-label="Daily Code schedule">
        {Array.from({length:days},(_,i)=>{
          const key=month+'-'+String(i+1).padStart(2,'0');
          const status=slots[key]??(key<=day()?'past':'available');
          return <button key={key} type="button" className="btn feature-date" aria-pressed={date===key} onClick={()=>setDate(key)}><strong>{i+1}</strong><span>{label(status)}</span></button>;
        })}
      </div>
      <div className="row wrap"><label className="field">Publication date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label><button className="btn primary" disabled={busy||!date||date<=day()||!!slots[date]} onClick={()=>void command('generate')}>Generate and schedule Daily Code</button></div>
      <h3>Publication history for {month}</h3>
      {publications.length?publications.map(r=><div className="row wrap" key={r.id}><Pill tone="good">{r.id}</Pill><strong>{r.term}</strong><span className="muted">{r.category} · {r.meaning}</span></div>):<p className="muted">No publications this month.</p>}
    </Card>}
    <Card title={kind==='daily'?'Applications queue':kind==='post'?'Post submissions':'Contributor applications'} subtitle={kind==='post'?'Only approved posts are public. Older posts enter this queue for review.':'Review submissions, payment status and decisions.'}
      actions={<button className="btn" onClick={()=>setRefresh(r=>r+1)} disabled={loading}>Refresh</button>}>
      <div className="row wrap">{filters.map(f=><button key={f} className={f===filter?'btn primary':'btn'} aria-pressed={f===filter} onClick={()=>setFilter(f)}>{label(f)}</button>)}</div>
      <div className="row wrap"><label className="field grow">Search loaded records<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Word, nickname or category"/></label><label className="field">Submission date (UTC)<input type="date" value={dateFilter} onChange={e=>setDateFilter(e.target.value)}/></label></div>
      {loading?<p className="muted">Loading…</p>:visible.length?<div className="table-wrap"><table><thead><tr><th>Entry</th><th>Contributor</th><th>Status</th><th>Submitted / updated</th><th>Payment</th>{kind==='daily'&&<th>Requested / confirmed</th>}<th>Review</th></tr></thead>
      <tbody>{visible.map(r=><tr key={r.id}><td><strong>{r.term??(kind==='post'?r.text:'Contributor badge')}</strong>{r.category&&<div className="muted">{r.category}</div>}</td><td>{r.name??'Code Explorer'}<div className="muted small">{r.uid}</div></td><td><Pill tone={statusTone(statusOf(r))}>{label(statusOf(r))}</Pill></td><td>{when(r.createdAt)} / {when(r.updatedAt)}</td><td>{r.fee? r.fee.toLocaleString()+' tokens · '+r.payment:'Legacy entry'}</td>{kind==='daily'&&<td>{r.requestedDate??'—'} / {r.publicationDate??'—'}</td>}<td><button className="btn" onClick={()=>choose(r)}>Open</button></td></tr>)}</tbody></table></div>:<p className="muted">No matching records.</p>}
      {more&&cursor&&<button className="btn" disabled={loading} onClick={()=>{setLoading(true);void load(cursor).catch(e=>setError(msgOf(e))).finally(()=>setLoading(false));}}>Load older records</button>}
    </Card>
    {kind==='post'&&<Card title="Open post reports" subtitle="Up to 50 reports awaiting review.">
      {reports.length?reports.map(r=><div className="row wrap" key={r.id}>
        <div className="grow"><strong>{r.reason}</strong><div className="muted">{r.note||'No details'}</div><code>{r.postId}</code></div>
        <button className="btn" disabled={busy} onClick={()=>void reviewReport(r.id,'dismiss')}>Dismiss report</button>
        <button className="btn danger" disabled={busy} onClick={()=>void reviewReport(r.id,'remove')}>Remove post</button>
      </div>):<p className="muted">No open post reports.</p>}
    </Card>}
    {active&&<Card title={active.term??active.name??'Review submission'} subtitle={`${label(statusOf(active))} · Submitted ${when(active.createdAt)} UTC`}>
      <p>{active.meaning??active.text??(active.name+' · '+active.uid)}</p>
      {!!active.example&&<p className="muted">Example: {active.example}</p>}
      {!!active.reason&&<p className="muted">{active.reason}</p>}
      {kind!=='verification'&&['pending','approved','scheduled'].includes(statusOf(active))&&active.term&&<>
        <label className="field">Edit meaning<textarea value={meaning} maxLength={kind==='post'?200:500} onChange={e=>setMeaning(e.target.value)}/></label>
        {kind==='post'&&<div className="row wrap"><label className="field">Category<select value={category} onChange={e=>setCategory(e.target.value)}>{policy.postCategories.map(c=><option key={c}>{c}</option>)}</select></label><label className="field grow">Example<input value={example} maxLength={200} onChange={e=>setExample(e.target.value)}/></label></div>}
        <button className="btn" disabled={busy||!meaning.trim()} onClick={()=>void command('edit')}>Save edits</button>
      </>}
      {kind==='daily'&&['pending','approved','scheduled'].includes(statusOf(active))&&<label className="field">Rejection reason<input value={reason} maxLength={200} onChange={e=>setReason(e.target.value)}/></label>}
      <div className="row wrap">
        {statusOf(active)==='pending'&&<button className="btn primary" disabled={busy} onClick={()=>void command(kind==='verification'?'approved':'approve')}>Approve</button>}
        {(statusOf(active)==='pending'||kind==='daily'&&['approved','scheduled'].includes(statusOf(active)))&&<button className="btn danger" disabled={busy} onClick={()=>void command(kind==='verification'?'rejected':'reject')}>{kind==='daily'?'Reject and refund':'Reject'}</button>}
        {kind==='daily'&&['approved','scheduled'].includes(statusOf(active))&&<>
          <label className="field">Confirmed date (UTC)<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
          <button className="btn primary" disabled={busy||!date} onClick={()=>void command('schedule')}>{statusOf(active)==='scheduled'?'Reschedule':'Schedule'}</button>
        </>}
        {kind==='post'&&statusOf(active)==='approved'&&<button className="btn danger" disabled={busy} onClick={()=>void command('remove')}>Remove from feed</button>}
        {kind==='verification'&&statusOf(active)==='approved'&&<button className="btn danger" disabled={busy} onClick={()=>void command('revoked')}>Revoke badge</button>}
      </div>
    </Card>}
  </div>;
}
