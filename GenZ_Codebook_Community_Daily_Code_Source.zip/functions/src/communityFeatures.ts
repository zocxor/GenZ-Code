import {createHash} from 'node:crypto';
import type {CallableRequest} from 'firebase-functions/v2/https';
type AuthData = NonNullable<CallableRequest['auth']>;
import {HttpsError} from 'firebase-functions/v2/https';
import {FieldPath, FieldValue, Timestamp, type Firestore, type Transaction} from 'firebase-admin/firestore';
import {communityId} from './validation/community';
import {normalizeTerm, cleanText} from './validation/contentSchema';
import {screenPost} from './validation/chat';
import dictionary from './validation/dictionary.json';
import policy from './communityPolicy.json';

const {dailyFee, postFee, verificationFee, bookingDays, postCategories} = policy;
const dayMs = 86_400_000;
const stamp = FieldValue.serverTimestamp;
export const utcDay = (time = Date.now()) => new Date(time).toISOString().slice(0, 10);
const digest = (s: string) => createHash('sha256').update(s).digest('hex');
function generateEntry(date: string) {
  const choices = dictionary.featured;
  return choices[parseInt(digest(date).slice(0,8),16)%choices.length];
}
const bundled = new Set(dictionary.terms.map(normalizeTerm));
const moderation = ['super_admin', 'content_manager', 'moderator'];
const editorial = ['super_admin', 'content_manager'];
const publicComment = (d: FirebaseFirestore.DocumentData) => ({name: d.name, uid: d.uid, text: d.text, createdAt: d.createdAt});
type Input = Record<string, unknown>;
function id(v: unknown) {
  if (typeof v !== 'string' || !/^[\w-]{1,128}$/.test(v)) throw new HttpsError('invalid-argument', 'Invalid record identifier.');
  return v;
}
function text(v: unknown, max: number, optional = false) {
  if (typeof v !== 'string' || v.trim().length > max) throw new HttpsError('invalid-argument', `Use at most ${max} characters.`);
  const value = cleanText(v, max);
  if (!optional && !value) throw new HttpsError('invalid-argument', 'Complete the required fields.');
  return value;
}
function screened(value: string) {
  if (!value) return value;
  const result = screenPost(value);
  if (!result.ok) throw new HttpsError('invalid-argument', result.message);
  return value;
}
function futureDate(input: unknown, now: number) {
  if (typeof input !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(input)) throw new HttpsError('invalid-argument', 'Choose an available date.');
  const time = Date.parse(input+'T00:00:00Z');
  if (!Number.isFinite(time) || utcDay(time) !== input || input <= utcDay(now) || input > utcDay(now+bookingDays*dayMs)) {
    throw new HttpsError('invalid-argument', `Choose a future UTC date within ${bookingDays} days.`);
  }
  return input;
}
function authRequired(auth: AuthData | undefined) {
  if (!auth) throw new HttpsError('unauthenticated', 'Sign in to continue.');
  if (auth.token.email_verified !== true) throw new HttpsError('permission-denied', 'Verify your email and sign in again.');
  return auth;
}
async function active(db: Firestore, tx: Transaction, uid: string) {
  if ((await tx.get(db.doc(`users/${uid}`))).get('status') !== 'active') throw new HttpsError('permission-denied', 'An active account is required.');
}
async function adminRole(db: Firestore, tx: Transaction, auth: AuthData, roles: string[]) {
  const [staff, config] = await Promise.all([tx.get(db.doc(`admins/${auth.uid}`)),tx.get(db.doc('config/security'))]);
  const role = staff.get('role');
  const secondFactor = (auth.token.firebase as {sign_in_second_factor?: string} | undefined)?.sign_in_second_factor;
  if (staff.get('active') !== true || !roles.includes(role) || (config.get('adminMfaRequired') === true && !secondFactor)) {
    throw new HttpsError('permission-denied', 'This action requires the appropriate administrator role.');
  }
  return role as string;
}
function audit(db: Firestore, tx: Transaction, actor: string, role: string, action: string, target: string, summary = '') {
  tx.create(db.collection('auditLogs').doc(), {actor, role, action, target, summary, at: stamp(), expireAt: Timestamp.fromMillis(Date.now()+365*dayMs)});
}
async function nickname(db: Firestore, tx: Transaction, uid: string) {
  const snap = await tx.get(db.doc(`users/${uid}/sync/profile`));
  const data = snap.data();
  const raw = data?.profile?.name ?? data?.name;
  const name = typeof raw === 'string' ? cleanText(raw, 24) : '';
  return name && screenPost(name).ok ? name : 'Code Explorer';
}

type Wallet = {ref: FirebaseFirestore.DocumentReference; balance: number; legacy: FirebaseFirestore.DocumentData; validated: FirebaseFirestore.DocumentReference[]};
const safeAmount = (v: unknown) => Number.isSafeInteger(v) ? Number(v) : 0;
/** The existing balance cache is intentionally writable by legacy clients. Verify the immutable receipts instead. */
async function wallet(db: Firestore, tx: Transaction, uid: string): Promise<Wallet> {
  const ref = db.doc(`users/${uid}/tokenWallet/wallet`);
  const [cache, ledger] = await Promise.all([
    tx.get(ref), tx.get(ref.parent.parent!.collection('tokenLedger').where('type','in',['purchase','subscription','adjustment','referral','feature_fee','feature_refund'])),
  ]);
  let balance = 0;
  const validated: FirebaseFirestore.DocumentReference[] = [];
  for (const entry of ledger.docs) {
    const d = entry.data(), amount = safeAmount(d.amount);
    if (d.type === 'feature_fee' || d.type === 'feature_refund' || d.type === 'subscription' || d.verifiedForFeatures === true) {
      balance += amount;
      continue;
    }
    if (amount <= 0) continue;
    if (d.type === 'purchase' && typeof d.purchaseToken === 'string' && /^[^/]{1,500}$/.test(d.purchaseToken)) {
      const proof = (await tx.get(db.doc(`processedTokens/${d.purchaseToken}`))).data();
      if (proof?.uid !== uid || proof.orderId !== d.ref || entry.id !== 'order-'+d.ref || proof.tokens !== amount
          || !proof.createdAt?.isEqual(d.createdAt)) continue;
    } else if (d.type === 'adjustment' && d.ref === 'admin-grant' && typeof d.lastAuditId === 'string' && /^[\w-]{1,128}$/.test(d.lastAuditId)) {
      const proof = (await tx.get(db.doc(`auditLogs/${d.lastAuditId}`))).data();
      if (proof?.action !== 'tokens.send' || proof.role !== 'super_admin' || proof.target !== `users/${uid}`
          || !proof.at?.isEqual(d.createdAt) || !new RegExp(`^Sent ${amount} tokens(?:$| — )`).test(proof.summary)) continue;
    } else if (d.type === 'referral' && amount === 100 && typeof d.ref === 'string' && /^[\w-]{1,128}$/.test(d.ref)) {
      const applicant = /^GZ[A-Z0-9]{6}$/.test(d.ref) ? uid : d.ref;
      const claim = (await tx.get(db.doc(`referralClaims/${applicant}`))).data();
      if (!claim || entry.id !== 'referral-'+d.ref || (applicant === uid ? claim.code !== d.ref : claim.referrerUid !== uid)) continue;
    } else continue;
    balance += amount;
    validated.push(entry.ref);
  }
  return {ref, balance: Math.max(0,balance), legacy: cache.data() ?? {}, validated};
}
function payment(tx: Transaction, w: Wallet, operation: string, amount: number, note: string) {
  if (w.balance + amount < 0) throw new HttpsError('failed-precondition', `You need ${-amount} eligible tokens. Your eligible balance is ${w.balance}.`);
  // Reading and writing this same wallet document serializes payments even when the initial wallet was empty.
  const balance = Math.max(0, Math.min(1_000_000, safeAmount(w.legacy.balance)+amount));
  tx.set(w.ref, {balance, earnedTotal: safeAmount(w.legacy.earnedTotal), purchasedTotal: safeAmount(w.legacy.purchasedTotal),
    spentTotal: Math.max(0,safeAmount(w.legacy.spentTotal)-amount), updatedAt: stamp()});
  for (const ref of w.validated.slice(0, 350)) tx.update(ref, {verifiedForFeatures:true});
  tx.create(w.ref.parent.parent!.collection('tokenLedger').doc(operation), {
    type: amount < 0 ? 'feature_fee' : 'feature_refund', amount, balanceAfter:w.balance+amount, ref:operation, note, createdAt:stamp(),
  });
}

function postFields(d: Input) {
  const term = screened(text(d.term,30));
  const meaning = screened(text(d.meaning,200));
  const example = screened(text(d.example ?? '',200,true));
  screened([term,meaning,example].filter(Boolean).join(' '));
  if (typeof d.category !== 'string' || !postCategories.includes(d.category)) throw new HttpsError('invalid-argument','Choose a post category.');
  return {term,meaning,example,category:d.category,text: `${term}: ${meaning}`};
}
async function claimTerm(db: Firestore, tx: Transaction, term: string) {
  const key = normalizeTerm(term);
  const ref = db.doc(`communityPostTerms/${digest(key)}`);
  const cms = db.collection('content');
  const slug = key.normalize('NFKD').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40) || 'entry';
  const prefix = 'cms-'+slug+'-';
  const [lock,word,exact,variations,normalized] = await Promise.all([
    tx.get(ref),tx.get(db.doc(`communityWords/${communityId(term)}`)),
    tx.get(cms.where('term','==',term).limit(10)),tx.get(cms.where('variations','array-contains',term).limit(10)),
    tx.get(cms.orderBy(FieldPath.documentId()).startAt(prefix).endAt(prefix+'\uf8ff').limit(50)),
  ]);
  const duplicate = [...exact.docs,...variations.docs,...normalized.docs].some(doc=>{
    const d=doc.data();
    return d.status==='published' && [d.term,...(Array.isArray(d.variations)?d.variations:[])].some(v=>typeof v==='string'&&normalizeTerm(v)===key);
  });
  if (lock.exists || bundled.has(key) || word.get('status') === 'live' || duplicate) {
    throw new HttpsError('already-exists','That word is already in the dictionary or the posts queue.');
  }
  return ref;
}
async function readDailyApplication(db: Firestore, tx: Transaction, appId: string) {
  const ref = db.doc(`dailyCodeApplications/${appId}`);
  const snap = await tx.get(ref);
  if (!snap.exists) throw new HttpsError('not-found','Application not found.');
  return {ref, data:snap.data()!};
}
async function resolveDaily(db: Firestore, tx: Transaction, appId: string, status: 'rejected' | 'cancelled', actor: string, role: string, reason: string) {
  const {ref,data} = await readDailyApplication(db,tx,appId);
  if (role === 'owner' && data.uid !== actor) throw new HttpsError('permission-denied','This application belongs to a different account.');
  if (data.status === status) return {id:appId};
  if (!['pending','approved','scheduled'].includes(data.status) || (role === 'owner' && data.status !== 'pending')) {
    throw new HttpsError('failed-precondition','This application cannot be closed by this account.');
  }
  const slot = db.doc(`dailyCodeDates/${data.reservedDate}`);
  const [reservation,w,account] = await Promise.all([tx.get(slot),wallet(db,tx,data.uid),tx.get(db.doc(`users/${data.uid}`))]);
  if (reservation.get('applicationId') === appId) tx.delete(slot);
  const deleted = account.get('status') === 'deleted';
  if (!deleted) payment(tx,w,`daily-refund-${appId}`,dailyFee,'Daily Code application refund');
  tx.update(ref,{status, payment:deleted?'closed':'refunded',reason,updatedAt:stamp()});
  tx.delete(db.doc(`dailyCodeWordLocks/${digest(data.uid+':'+data.wordId)}`));
  audit(db,tx,actor,role,`daily-code.${status}`,ref.path,reason);
  return {id:appId};
}

async function publishDaily(db: Firestore, tx: Transaction, date: string, now: number, actor: string, role: string) {
  if (date !== utcDay(now)) throw new HttpsError('failed-precondition','A Daily Code can be published only on its UTC publication date.');
  const slotRef = db.doc(`dailyCodeDates/${date}`);
  const live = db.doc(`dailyCodePublic/${date}`);
  const [slot,current] = await Promise.all([tx.get(slotRef),tx.get(live)]);
  if (current.exists) return {published:true};
  const data = slot.data();
  const publishFallback = () => {
    const entry = generateEntry(date);
    if (!entry) return {published:false};
    tx.create(live,{...entry,date,publishedAt:stamp()});
    tx.set(slotRef,{status:'published',publishedAt:stamp()});
    audit(db,tx,actor,role,'daily-code.publish-fallback',live.path);
    return {published:true};
  };
  if (!data || data.status !== 'scheduled') {
    if (data?.applicationId) await resolveDaily(db,tx,data.applicationId,'rejected',actor,role,'The word was not scheduled before its publication date.');
    return publishFallback();
  }
  const app = data.applicationId ? await readDailyApplication(db,tx,data.applicationId) : null;
  if (app) {
    const [account, suggestion] = await Promise.all([tx.get(db.doc(`users/${app.data.uid}`)),tx.get(db.doc(`submissions/${app.data.wordId}`))]);
    if (account.get('status') === 'deleted' || suggestion.get('status') !== 'accepted') {
      await resolveDaily(db,tx,data.applicationId,'rejected',actor,role,'The approved dictionary entry is no longer available.');
      return publishFallback();
    }
  }
  const entry = app?.data ?? data;
  tx.create(live,{date,term:entry.term,meaning:entry.meaning,category:entry.category,publishedAt:stamp()});
  tx.set(slotRef,{...data,status:'published',publishedAt:stamp()});
  if (app) tx.update(app.ref,{status:'published',publicationDate:date,updatedAt:stamp()});
  audit(db,tx,actor,role,'daily-code.publish',live.path);
  return {published:true};
}

export async function communityAction(db: Firestore, input: Input, identity: AuthData | undefined, now = Date.now()): Promise<Record<string, unknown>> {
  const auth = authRequired(identity), uid = auth.uid;
  const action = input.action;
  return db.runTransaction(async tx => {
    if (action === 'balance') {
      await active(db,tx,uid);
      return {balance:(await wallet(db,tx,uid)).balance};
    }
    if (action === 'apply-daily' || action === 'apply-verification' || action === 'create-post') {
      await active(db,tx,uid);
      if (action === 'create-post' && (await tx.get(db.doc('config/app'))).get('ugcEnabled') === false) {
        throw new HttpsError('failed-precondition','Community submissions are paused.');
      }
      const requestId = digest(uid+':'+id(input.requestId)).slice(0,40);
      const collection = action === 'apply-daily' ? 'dailyCodeApplications' : action === 'apply-verification' ? 'verificationApplications' : 'communityPosts';
      const ref = db.doc(`${collection}/${requestId}`);
      if ((await tx.get(ref)).exists) return {id:requestId,duplicate:true};
      const [w,name] = await Promise.all([wallet(db,tx,uid),nickname(db,tx,uid)]);
      const base = {uid,name,createdAt:stamp(),updatedAt:stamp(),status:'pending',payment:'paid'};
      if (action === 'apply-daily') {
        const wordId = id(input.wordId);
        const requestedDate = futureDate(input.date,now);
        const slot = db.doc(`dailyCodeDates/${requestedDate}`);
        const lock = db.doc(`dailyCodeWordLocks/${digest(uid+':'+wordId)}`);
        const [word,reserved,existing] = await Promise.all([tx.get(db.doc(`submissions/${wordId}`)),tx.get(slot),tx.get(lock)]);
        if (word.get('uid') !== uid || word.get('status') !== 'accepted' || typeof word.get('reviewedBy') !== 'string') {
          throw new HttpsError('failed-precondition','Choose one of your administrator-approved dictionary entries.');
        }
        if (existing.exists) throw new HttpsError('already-exists','This word already has a Daily Code application.');
        if (reserved.exists) {
          const end = utcDay(now+bookingDays*dayMs);
          const following = await tx.get(db.collection('dailyCodeDates').orderBy(FieldPath.documentId()).startAfter(requestedDate).endAt(end));
          const dates = new Set(following.docs.map(d=>d.id));
          let next = Date.parse(requestedDate+'T00:00:00Z')+dayMs;
          while (dates.has(utcDay(next))) next += dayMs;
          throw new HttpsError('already-exists','That date is reserved. Choose an available date.',{next:utcDay(next)<=end?utcDay(next):null});
        }
        payment(tx,w,`daily-fee-${requestId}`,-dailyFee,'Daily Code application');
        tx.create(ref,{...base,wordId,requestedDate,reservedDate:requestedDate,publicationDate:null,fee:dailyFee,
          term:word.get('term'),meaning:word.get('meaning'),category:word.get('category')});
        tx.create(slot,{status:'pending',applicationId:requestId});
        tx.create(lock,{applicationId:requestId});
      } else if (action === 'apply-verification') {
        const current = db.doc(`verificationState/${uid}`);
        const previous = await tx.get(current);
        if (['pending','approved'].includes(previous.get('status'))) throw new HttpsError('already-exists','You already have an application or a verified badge.');
        payment(tx,w,`verification-fee-${requestId}`,-verificationFee,'Verified Contributor manual review');
        tx.create(ref,{...base,fee:verificationFee});
        tx.set(current,{status:'pending',applicationId:requestId});
      } else {
        const fields = postFields(input);
        const lock = await claimTerm(db,tx,fields.term);
        payment(tx,w,`post-fee-${requestId}`,-postFee,'Community post submission');
        tx.create(ref,{...base,...fields,fee:postFee,schema:2,hidden:true,likeCount:0,commentCount:0,engagementScore:0,termLock:lock.id});
        tx.create(lock,{postId:requestId});
      }
      return {id:requestId,balance:w.balance-(action==='create-post'?postFee:action==='apply-daily'?dailyFee:verificationFee)};
    }
    if (action === 'cancel-daily') {
      await active(db,tx,uid);
      return resolveDaily(db,tx,id(input.id),'cancelled',uid,'owner','Cancelled before approval.');
    }
    if (action === 'daily-admin') {
      const role = await adminRole(db,tx,auth,editorial);
      if (input.command === 'generate') {
        const date = futureDate(input.date,now), slot = db.doc(`dailyCodeDates/${date}`);
        if ((await tx.get(slot)).exists) throw new HttpsError('already-exists','That date already has a reservation.');
        const entry = generateEntry(date);
        if (!entry) throw new HttpsError('failed-precondition','No dictionary entries are available.');
        tx.create(slot,{status:'scheduled',...entry,createdAt:stamp()});
        audit(db,tx,uid,role,'daily-code.generate',slot.path);
        return {id:date};
      }
      if (input.command === 'publish') return publishDaily(db,tx,String(input.date),now,uid,role);
      const appId = id(input.id);
      if (input.command === 'reject') return resolveDaily(db,tx,appId,'rejected',uid,role,text(input.reason ?? 'Declined by the review team.',200));
      const {ref,data} = await readDailyApplication(db,tx,appId);
      if (!['pending','approved','scheduled'].includes(data.status)) throw new HttpsError('failed-precondition','This application is closed.');
      if (input.command === 'edit') {
        tx.update(ref,{meaning:screened(text(input.meaning,500)),updatedAt:stamp()});
      } else if (input.command === 'approve' && data.status === 'pending') {
        tx.update(ref,{status:'approved',updatedAt:stamp()});
      } else if (input.command === 'schedule' && ['approved','scheduled'].includes(data.status)) {
        const date = futureDate(input.date,now);
        const next = db.doc(`dailyCodeDates/${date}`), previous = db.doc(`dailyCodeDates/${data.reservedDate}`);
        const [nextSnap,oldSnap] = await Promise.all([tx.get(next),tx.get(previous)]);
        if (nextSnap.exists && nextSnap.get('applicationId') !== appId) throw new HttpsError('already-exists','That date is already reserved.');
        if (next.path !== previous.path && oldSnap.get('applicationId') === appId) tx.delete(previous);
        tx.set(next,{status:'scheduled',applicationId:appId});
        tx.update(ref,{status:'scheduled',reservedDate:date,publicationDate:date,updatedAt:stamp()});
      } else throw new HttpsError('failed-precondition','That action is not available in this status.');
      audit(db,tx,uid,role,'daily-code.'+input.command,ref.path);
      return {id:appId};
    }
    if (action === 'verification-admin') {
      const role = await adminRole(db,tx,auth,['super_admin']);
      const appId = id(input.id), ref = db.doc(`verificationApplications/${appId}`);
      const data = (await tx.get(ref)).data();
      if (!data) throw new HttpsError('not-found','Application not found.');
      const current = db.doc(`verificationState/${data.uid}`);
      if ((await tx.get(current)).get('applicationId') !== appId) throw new HttpsError('failed-precondition','This is a historical application.');
      const status = input.command;
      if ((status !== 'approved' && status !== 'rejected' || data.status !== 'pending') && (status !== 'revoked' || data.status !== 'approved')) {
        throw new HttpsError('failed-precondition','That decision is not available.');
      }
      if (status === 'approved') {
        await active(db,tx,data.uid);
        tx.set(db.doc(`verifiedContributors/${data.uid}`),{verified:true});
      } else tx.delete(db.doc(`verifiedContributors/${data.uid}`));
      tx.update(ref,{status,updatedAt:stamp()});
      tx.update(current,{status});
      audit(db,tx,uid,role,`verification.${status}`,ref.path);
      return {id:appId};
    }
    if (action === 'resolve-post-report') {
      const role = await adminRole(db,tx,auth,moderation);
      const ref = db.doc(`postReports/${id(input.id)}`);
      const report = (await tx.get(ref)).data();
      if (!report || report.status !== 'open') throw new HttpsError('failed-precondition','This report has already been handled.');
      if (!['dismiss','remove'].includes(String(input.command))) throw new HttpsError('invalid-argument','Choose a report decision.');
      if (input.command === 'remove') {
        const post = db.doc(`communityPosts/${id(report.postId)}`);
        const data = (await tx.get(post)).data();
        if (data?.status === 'approved') {
          if (data.termLock) tx.delete(db.doc(`communityPostTerms/${data.termLock}`));
          tx.update(post,{hidden:true,status:'removed',moderatedBy:uid,updatedAt:stamp()});
          audit(db,tx,uid,role,'post.remove',post.path,'Removed after report');
        }
      }
      const status = input.command === 'remove' ? 'resolved' : 'dismissed';
      tx.update(ref,{status,resolvedBy:uid,resolvedAt:stamp(),resolution:input.command});
      audit(db,tx,uid,role,`report.${input.command === 'remove' ? 'resolve' : 'dismiss'}`,ref.path);
      return {id:ref.id};
    }
    if (action === 'post-admin' || action === 'delete-post' || action === 'like-post' || action === 'comment-post' || action === 'save-post') {
      const postId = id(input.id);
      const role = action === 'post-admin' ? await adminRole(db,tx,auth,moderation) : null;
      if (!role) await active(db,tx,uid);
      const ref = db.doc(`communityPosts/${postId}`);
      const data = (await tx.get(ref)).data();
      if (!data) throw new HttpsError('not-found','Post no longer exists.');
      const status = data.status ?? (data.hidden ? 'removed' : 'pending');
      if (action === 'post-admin' || action === 'delete-post') {
        if (!role && data.uid !== uid) throw new HttpsError('permission-denied','Only the author may remove this post.');
        const command = role ? input.command : 'remove';
        if (command === 'edit' && ['pending','approved'].includes(status) && data.schema===2) {
          const fields = postFields({...input,term:data.term});
          tx.update(ref,{...fields,updatedAt:stamp()});
        } else {
          const next = command === 'approve' && status === 'pending' ? 'approved'
            : command === 'reject' && status === 'pending' ? 'rejected'
            : command === 'remove' && ['pending','approved'].includes(status) ? 'removed' : null;
          if (!next) throw new HttpsError('failed-precondition','That action is not available in this status.');
          if (data.termLock && next !== 'approved') tx.delete(db.doc(`communityPostTerms/${data.termLock}`));
          tx.update(ref,{status:next,hidden:next!=='approved',updatedAt:stamp(),moderatedBy:uid,...(next==='approved'?{publishedAt:stamp(),engagementScore:safeAmount(data.likeCount)+safeAmount(data.commentCount)}:{})});
        }
        audit(db,tx,uid,role ?? 'owner',`post.${command}`,ref.path);
        return {id:postId};
      }
      const saved = db.doc(`users/${uid}/savedCommunityPosts/${postId}`);
      if (action === 'save-post' && input.enabled === false) {tx.delete(saved);return {saved:false};}
      if (data.hidden || status !== 'approved') throw new HttpsError('not-found','This post is not public.');
      if (action === 'save-post') {tx.set(saved,{postId,createdAt:stamp()});return {saved:true};}
      if (action === 'like-post') {
        if (typeof input.enabled !== 'boolean') throw new HttpsError('invalid-argument','Invalid like state.');
        const like = db.doc(`communityPostLikes/${postId}_${uid}`), existing = (await tx.get(like)).exists;
        if (input.enabled !== existing) {
          if (input.enabled) tx.create(like,{postId,uid,createdAt:stamp()}); else tx.delete(like);
          const likeCount = Math.max(0,safeAmount(data.likeCount)+(input.enabled?1:-1));
          tx.update(ref,{likeCount,engagementScore:likeCount+safeAmount(data.commentCount)});
        }
        return {liked:input.enabled};
      }
      if ((await tx.get(db.doc('config/app'))).get('ugcEnabled') === false) throw new HttpsError('failed-precondition','Community submissions are paused.');
      const comment = screened(text(input.text,200));
      const commentRef = ref.collection('comments').doc(digest(uid+':'+normalizeTerm(comment)));
      const [existing,name] = await Promise.all([tx.get(commentRef),nickname(db,tx,uid)]);
      if (existing.exists) return {id:commentRef.id,duplicate:true};
      tx.create(commentRef,publicComment({uid,name,text:comment,createdAt:stamp()}));
      const commentCount = safeAmount(data.commentCount)+1;
      tx.update(ref,{commentCount,engagementScore:commentCount+safeAmount(data.likeCount)});
      return {id:commentRef.id};
    }
    throw new HttpsError('invalid-argument','Unknown action.');
  });
}

/** Overlap/retry safe. Unfulfilled reservations are refunded once through the same transaction. */
export async function runDailySchedule(db: Firestore, now = Date.now()) {
  const day = utcDay(now);
  await db.runTransaction(tx=>publishDaily(db,tx,day,now,'scheduler','system'));
  const expired = await db.collection('dailyCodeDates').where('status','in',['pending','scheduled']).where(FieldPath.documentId(),'<',day).limit(50).get();
  for (const doc of expired.docs) {
    await db.runTransaction(async tx=>{
      const current = await tx.get(doc.ref);
      if (!current.exists || current.get('status')==='published') return;
      const applicationId=current.get('applicationId');
      if (applicationId) await resolveDaily(db,tx,applicationId,'rejected','scheduler','system','The reserved date passed before publication.');
      else tx.delete(doc.ref);
    });
  }
}


/** Remove the public badge and new contributions when the existing account tombstone is written. */
export async function purgeContributions(db: Firestore, uid: string) {
  await db.doc(`verifiedContributors/${uid}`).delete();
  await db.doc(`verificationState/${uid}`).delete();
  const daily = await db.collection('dailyCodeApplications').where('uid','==',uid).get();
  for (const row of daily.docs) {
    await db.runTransaction(async tx=>{
      const snap=await tx.get(row.ref);
      if (!snap.exists) return;
      const data=snap.data()!;
      if (['pending','approved','scheduled'].includes(data.status)) {
        const slot=db.doc(`dailyCodeDates/${data.reservedDate}`);
        if ((await tx.get(slot)).get('applicationId')===row.id) tx.delete(slot);
      }
      tx.delete(db.doc(`dailyCodeWordLocks/${digest(uid+':'+data.wordId)}`));
      tx.delete(row.ref);
    });
  }
  const [posts,applications] = await Promise.all([
    db.collection('communityPosts').where('uid','==',uid).get(),
    db.collection('verificationApplications').where('uid','==',uid).get(),
  ]);
  for (const post of posts.docs) {
    const termLock=post.get('termLock');
    await db.runTransaction(async tx=>{
      if (termLock) {
        const ref=db.doc(`communityPostTerms/${termLock}`);
        if ((await tx.get(ref)).get('postId')===post.id) tx.delete(ref);
      }
      tx.set(post.ref,{hidden:true,status:'removed',createdAt:post.get('createdAt')??stamp(),updatedAt:stamp()});
    });
    await db.recursiveDelete(post.ref.collection('comments'));
  }
  for (const app of applications.docs) await app.ref.delete();
  await db.recursiveDelete(db.collection(`users/${uid}/savedCommunityPosts`));
}
