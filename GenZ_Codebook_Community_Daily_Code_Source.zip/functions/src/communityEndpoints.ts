import {getFirestore} from 'firebase-admin/firestore';
import {onCall} from 'firebase-functions/v2/https';
import {onDocumentUpdated} from 'firebase-functions/v2/firestore';
import {onSchedule} from 'firebase-functions/v2/scheduler';
import {communityAction, runDailySchedule, purgeContributions} from './communityFeatures';

export const communityFeature = onCall({region:'us-central1', timeoutSeconds:60}, request =>
  communityAction(getFirestore(),request.data ?? {},request.auth));
export const publishDailyCodes = onSchedule({schedule:'every 1 minutes',timeZone:'UTC',region:'us-central1'}, async ()=>{
  await runDailySchedule(getFirestore());
});

export const cleanupContributions = onDocumentUpdated({document:'users/{uid}',region:'us-central1',retry:true}, async event=>{
  if(event.data?.after.get('status')==='deleted' && event.data.before.get('status')!=='deleted') await purgeContributions(getFirestore(),event.params.uid);
});
