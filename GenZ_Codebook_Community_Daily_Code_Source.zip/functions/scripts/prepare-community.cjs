const {mkdirSync, copyFileSync, writeFileSync} = require('node:fs');
const {join} = require('node:path');
const root = join(__dirname, '../..');
const dir = join(root, 'functions/src/validation');
mkdirSync(dir, {recursive: true});
for (const name of ['chat', 'community', 'contentSchema']) copyFileSync(join(root, 'shared', name+'.ts'), join(dir, name+'.ts'));
const entries = require(join(root, 'src/data/library.json'));
writeFileSync(join(dir, 'dictionary.json'), JSON.stringify({
  terms: entries.flatMap(e => [e.expression, ...(e.aliases ?? [])]),
  featured: entries.filter(e => e.priority >= 100 && e.example && e.sensitivity === 'None').map(({expression:term, meaning, category})=>({term,meaning,category})),
}));
