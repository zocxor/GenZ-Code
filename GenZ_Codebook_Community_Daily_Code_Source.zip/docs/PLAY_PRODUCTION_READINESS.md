# GenZ Codebook — Google Play Production Readiness

Date: 2026-11-09. Package: `com.genzmode.app`. Display version: `1.0.0`.
This is the pre-upload checklist for Play Console (internal testing → public release).
It does **not** claim production readiness where a required configuration is still open.

## 1. Completed configurations (in this source)

| # | Item | Evidence |
|---|------|----------|
| 1 | Package name preserved | `android/app/build.gradle` `applicationId 'com.genzmode.app'`, `namespace 'com.genzmode.app'`, `app.json` `"package": "com.genzmode.app"`. Same ID in debug, beta, internal and release builds. |
| 2 | Google Play Billing Library 8+ | `react-native-iap` **15.6.2** + `react-native-nitro-modules` 0.36.5. The installed library uses Billing Library **9.1.0** (via `io.github.hyochan.openiap:openiap-google:2.5.2`). Google Play stopped accepting Billing Library 7 for new apps and updates on 31 Aug 2026 (one-time extension to 1 Nov 2026, now past) — the previous 12.16.4 / Billing 7.0.0 build **could not be uploaded**. |
| 3 | Billing API migrated to 15.x | `src/billing.ts`: `fetchProducts({skus, type: 'in-app'})` (was `getProducts`; 14.x used `type: 'inapp'`), `requestPurchase({request: {android: {skus: [...]}}}, type: 'in-app'})`, `getAvailablePurchases()` (no `onlyIncludeActiveItems` option on Android in 15.x), product fields `id` / `displayPrice`, order ID from `purchase.id`, purchase state is now the string `'purchased' | 'pending' | 'unknown'` (was the numeric `PurchaseAndroidState`), error type `PurchaseError` with `ErrorCode.UserCancelled` (was `NitroPurchaseResult` / `E_USER_CANCELLED`). `fetchProducts` returns a `ProductOrSubscription[] | null` union — the code filters by `type` (`'in-app'` for tokens, `'subs'` for Premium). `android/app/build.gradle` no longer sets `missingDimensionStrategy 'store', 'play'` — 15.x has no store flavor dimension, and leaving it would break the Gradle build. The obsolete `patches/react-native-iap+12.16.4.patch` and `patch-package` are removed. |
| 4 | Product IDs (consumables, exact) | `shared/tokens.ts`: `tokens_1000`, `tokens_2500`, `tokens_5000`, `tokens_10000`, `tokens_25000`, `tokens_50000`, `tokens_100000`. These are the IDs that must exist in Play Console (see §2). |
| 5 | Live localized prices, no hardcoding | Prices are read from Play (`displayPrice`); the shop shows Play's localized price and never a hardcoded amount. No mock, fake or simulated purchase path exists anywhere in the app. |
| 6 | Purchase acknowledgement / consumption | `finishTransaction({purchase, isConsumable: true})` consumes each package after the ledger write, so the same package can be bought again. |
| 7 | Pending / cancelled / failed handling | `creditPurchase` returns `pending` for `PurchaseAndroidState.PENDING` and never credits it; cancelled purchases emit `cancelled` (calm, not an error); failed purchases emit `failed` with a message. Pending purchases are never written to the ledger. |
| 8 | Restore / reconcile | `restorePurchases()` re-runs `reconcileOwnedPurchases()` (Wallet open and the Restore button). A purchase already recorded in the ledger under its order ID is credited once and then consumed; the ledger document per order ID is the duplicate guard. |
| 9 | Release signing | `android/app/build.gradle` `signingConfigs.production` reads the upload keystore from `GENZ_UPLOAD_STORE_FILE` / `GENZ_UPLOAD_STORE_PASSWORD` / `GENZ_UPLOAD_KEY_ALIAS` / `GENZ_UPLOAD_KEY_PASSWORD` (environment, never committed). Release and beta builds refuse to run with the debug keystore. The debug keystore (`android/app/debug.keystore`) is only used by the `debug` and `internal` build types. |
| 10 | Versioning | `versionName "1.0.0"` (first public release — keep until Kashif says otherwise). `versionCode` comes from `-PgenzVersionCode` (CI sets 100 + GitHub run number for each Play upload); default 21. |
| 11 | Release build hardening | `release` build type: production signing, `minifyEnabled`, ProGuard, PNG crunching. `beta` (Play testing) inherits release and uses production signing. |
| 12 | Permissions | Only `INTERNET` is requested. Camera, biometric, fingerprint, storage, media, audio, alert-window and vibrate permissions are explicitly removed (`tools:node="remove"`). |
| 13 | No private credentials bundled | No service-account JSON, private key, `.p12` or release keystore in the source. `google-services.json` is the public Firebase client config (expected). `BILLING_VERIFY_URL` is empty, so no credential is embedded for verification. |
| 14 | No debug-only billing configuration | There is no debug, mock or test billing path in the app. Billing is only available on Android; other platforms report "Google Play billing is only available on Android." |
| 15 | Verification (this source) | Root `tsc` exit 0, root tests 82/82, admin `tsc` exit 0, admin tests 8/8, admin build clean, functions `tsc` exit 0, security scan 0 findings, `expo export --platform android` OK. Rules tests (39) run only in the Deploy Firebase workflow (no Java in this environment). |

## 2. Subscriptions — Premium (two tiers)

The app now sells two **Premium subscriptions** alongside the seven
consumable token packages. Full reference: `docs/SUBSCRIPTIONS.md`.

| Product ID | Base plan | Tokens per period | Benefit |
|---|---|---|---|
| `premium_monthly` | `monthly` | 500 | No banner/interstitial ads + 500 tokens every month |
| `premium_yearly` | `yearly` | 6000 | No banner/interstitial ads + 6000 tokens every year |

- Prices are set in Play Console (per-country pricing) — never in code.
  Create the subscription products + base plans in Play Console
  (Monetize → Products → Subscriptions), then activate them.
- Purchase flow: `src/subscription.ts` — fetch with `type: 'subs'`,
  buy with the base plan's offer token, verify via `verifySubscription`,
  acknowledge (never consume). Benefits are granted only after server
  verification, and only the backend writes the entitlement.
- Lifecycle: renewals, cancellations, expiry, grace period, hold, pause
  and refunds are handled by the RTDN handler (`rtdnHandler`) plus the
  app's reconcile on start / Wallet open. See `docs/SUBSCRIPTIONS.md`.
- Play Billing Library 9.1 supports both consumables and subscriptions; the
  library upgrade in §1 covers either.

## 3. Missing Google Play Console configurations (Kashif's steps)

These are **not** in the source and cannot be done from here. The app is not
uploadable until the products exist.

| # | Play Console step | Detail |
|---|-------------------|--------|
| 1 | Create the 7 in-app products | Monetize → Products → In-app products. Create each with the **exact** product ID from §1.4 (`tokens_1000` … `tokens_100000`) and the prices from his table ($1.99 / $2.99 / $3.99 / $5.99 / $10.99 / $15.99 / $25.99). Set each to **Active**. |
| 1b | Create the 2 subscriptions | Monetize → Products → Subscriptions. Create `premium_monthly` with base plan `monthly` and `premium_yearly` with base plan `yearly` (see §2 / `docs/SUBSCRIPTIONS.md` for the token grants). Set prices and activate both. Without these, the Premium section shows "not listed in Google Play yet". |
| 1c | Set up RTDN | Create the Pub/Sub topic `genz-codebook-rtdn`, grant `google-play-developer-notifications@system.gserviceaccount.com` the Publisher role on it, then Play Console → Monetize → Monetization setup → Real-time developer notifications → topic `projects/gen-z-code-55caf/topics/genz-codebook-rtdn`. See `functions/README.md` §6. |
| 2 | Merchant / payments profile | Confirm the merchant account and payments profile are linked (he already has 5+ apps published, so this is likely done; if none of them sell anything, it is one free extra step). Pakistan is eligible as a Play merchant; payouts by USD wire, $100 minimum, around the 15th of the following month. |
| 3 | License testers | Settings → License testing. Add the Gmail accounts that will test purchases. Only license testers can buy without being charged (test purchases are free and do not go through real payment). |
| 4 | Internal testing track | Release → Testing → Internal testing. Create the track, upload the signed AAB from §5, and add the tester list (license testers). Internal testing is the first Play-installed build. |
| 5 | Data safety | Update Play Console Data safety by hand: the app shows ads and uses the advertising ID (AdMob), and collects the account data the app already declares. See `docs/PLAY_DATA_SAFETY.md`. |
| 6 | App name | Play Console app / listing name still says "GenZ Code" — change it to "GenZ Codebook" in the console (do not change the package name). |
| 7 | Check Policy status | After uploading, check Play Console → Policy status for any Billing Library or target-API warning. The Billing 8 upgrade (§1.2) is what clears the billing warning. |

## 4. Required external credentials / backend setup

| # | Item | Status | What is needed |
|---|------|--------|----------------|
| 1 | Upload keystore + 4 GitHub secrets | **Kashif's step — not verified here** | A release keystore (`.jks`/`.keystore`) created once, backed up offline, never committed. GitHub repo secrets: `GENZ_UPLOAD_KEYSTORE_BASE64`, `GENZ_UPLOAD_STORE_PASSWORD`, `GENZ_UPLOAD_KEY_ALIAS`, `GENZ_UPLOAD_KEY_PASSWORD`. The CI `play-aab` job fails loudly if any is missing. See `docs/BUILD_APK.md`. |
| 2 | Server-side purchase verification | **BUILT, NOT DEPLOYED** | The backend endpoint is built in `functions/` (`verifyPurchase` Cloud Function, 2nd gen): Firebase ID-token auth, Play Developer API `purchases.products.get` via a service account (from the `PLAY_SERVICE_ACCOUNT_JSON` Firebase secret — never in the repo/app/AAB), verifies package `com.genzmode.app`, productId, `purchaseState == 0` (pending/cancelled rejected), and credits exactly once in a single atomic Firestore transaction keyed by `processedTokens/{purchaseToken}` (ledger + wallet in the same transaction). The client (`src/billing.ts`) now branches: when `BILLING_VERIFY_URL` is set, the backend credits and the client only updates its local balance + consumes; when empty, a DEBUG build falls back to local-only, but a PRODUCTION build (`__DEV__` false: release / beta / internal) REFUSES to credit and reports that server verification is not configured. Deploy runs through the existing "Deploy Firebase" GitHub workflow (new `functions` target; `everything` now includes functions) or manually. Deploy still needs: Firebase Blaze plan, the Play service account created + granted in Play Console → Setup → API access, the secret set, `firebase deploy --only functions`, and `BILLING_VERIFY_URL` set in `src/billing.ts`. See `functions/README.md`. Until deployed, verification is local-only (ledger + order-ID guard, plus a purchaseToken query check in `recordPurchaseTxn`) — and production builds will not credit at all. Real-time refund / voided-purchase detection (RTDN) still needs a separate backend. |
| 3 | Firebase service account (admin deploy) | Needed for the Deploy Firebase workflow only | `FIREBASE_SERVICE_ACCOUNT` repo secret. Not needed for the Play upload itself. |

## 5. Internal testing instructions

1. **Build the AAB.** In GitHub, run the `android-apk` workflow (`workflow_dispatch`) with the **aab** input on. It builds `bundleBeta` (signed with the upload key from the §4.1 secrets) and sets `versionCode` to 100 + run number. Commit the extracted source at the repository root and check the project folder in the run log.
2. **Upload to internal testing.** Play Console → Release → Testing → Internal testing → Create release → upload the AAB. Add the license-tester accounts (§3.3) as testers.
3. **Install from Play.** Testers open the internal-testing opt-in link on their phone, then install the app from Play. A Play-installed build is required for real billing — a sideloaded APK cannot complete a Play purchase.
4. **Make a test purchase.** As a license tester, open the app → You → Buy Tokens → buy the cheapest package (`tokens_1000`). The Play dialog shows the test price. Confirm the tokens land in the Wallet and the ledger shows the transaction. Repeat for a second package and for Restore (Wallet → Restore purchases) to confirm no double credit.
5. **Confirm the failure paths.** Cancel a purchase at the Play dialog (should show the calm "cancelled" state, no tokens). Buy, then force-close the app before the credit lands, then reopen — the reconcile on start should credit it once and consume it.
6. **What "operational" means.** Billing is operational only after a real license-tester test purchase completes **and** the correct tokens are credited. Do not announce it before that.

## 6. Production upload readiness — verdict

**Not yet production-ready. Internal-testing-ready, once §3.1 and §4.1 are done.**

| Gate | Status |
|------|--------|
| Billing Library 8+ (the upload blocker) | ✅ Done — 9.1.0 via react-native-iap 15.6.2 |
| Package name, versioning, signing config, permissions, no credentials bundled | ✅ Done |
| 7 consumable products in Play Console | ❌ Not created yet (§3.1) |
| Upload keystore + 4 GitHub secrets | ❌ Not verified here (§4.1) |
| License testers + internal testing track | ❌ Not set up yet (§3.3, §3.4) |
| Real license-tester test purchase credited correctly | ❌ Not done yet (§5.6) |
| Server-side purchase verification (backend + service account) | 🟡 Built, not deployed — the function is written and typechecks, but it needs Blaze + the service account + the secret + `BILLING_VERIFY_URL` set before it verifies a real purchase (§4.2). The app is safe to internal-test without it because the ledger + order-ID guard prevent double credit |
| Production `release` build gates | ❌ All 11 gates in `production-readiness.json` are `blocked` (owner, content review, physical Android QA, accessibility, dependency review, privacy/terms, authentication, backend/CMS, AI gateway, monitoring, store signing). A `release` Gradle build refuses to run until each gate has evidence in `docs/release-evidence/`. The `beta` build used for internal testing is **not** blocked by these gates. |
| Subscriptions / base plans | Two Premium subscriptions (§2): `premium_monthly` (base plan `monthly`) and `premium_yearly` (base plan `yearly`). Create both in Play Console with prices and activate them. |

**Recommended order:** create the 7 products + 2 subscriptions (§3.1, §3.1b) → add the upload-key secrets (§4.1) → deploy the server verification backend (§4.2) → set `BILLING_VERIFY_URL` + `SUBSCRIPTION_VERIFY_URL` and rebuild → set up RTDN (§3.1c) → build + upload the AAB to internal testing (§5) → complete a license-tester test purchase AND a license-tester subscription (purchase, renewal, cancel, refund) → clear the 11 production-readiness gates → promote to production. The backend now comes BEFORE any test purchase: a production build (beta/internal) refuses to credit or grant Premium without server verification, so no purchase can complete until the backend is live.

## 7. Four separate statuses (2026-11-09 audit)

These are tracked independently. A green in one does not imply a green in another.

### 7.1 Internal testing readiness — 🟡 Ready to start, once §3.1 + §4.1 are done

The app itself is ready for internal testing: Billing Library 9.1.0
(react-native-iap 15.6.2), the seven product IDs + two subscription IDs,
the signed `beta` AAB config, the Buy Tokens screen (loading state fixed —
it now clears when billing finishes, even with zero products), the Premium
subscription section, and the purchase pipelines (tokens: verify → ledger →
credit → consume; subscriptions: verify → acknowledge) are all in place and
verified (root tsc 0, tests 82/82, admin 8/8 + build, functions tsc 0,
scan 0, expo export OK). What is still needed on Kashif's side: create the
7 products + 2 subscriptions in Play Console (§3.1, §3.1b) and add the
upload-key secrets (§4.1). Then build the AAB in CI, upload it to the
internal testing track, and install from Play.

### 7.2 Real Google Play purchase verification — ❌ Not done yet

No real purchase has been made. The billing code is complete, but a
purchase is only proven when a license tester buys a package on the
Play-installed internal-testing build and the correct tokens land in the
Wallet. Until that test purchase completes, this stays red. The Gradle
build itself is also unproven in this environment (no Java) — the CI
play-aab job is the proof.

### 7.3 Secure token crediting — 🟡 Backend built, not deployed; local-only guard in place

- **Server path (the secure one):** the `verifyPurchase` Cloud Function
  is written and typechecks (`functions/src/index.ts`). It authenticates
  with a Firebase ID token, verifies the purchase with the Play
  Developer API (package, product, `purchaseState == 0`), and credits
  exactly once in a single atomic Firestore transaction keyed by
  `processedTokens/{purchaseToken}`. A replayed token returns
  `duplicate: true` and credits nothing again. It is **not deployed**:
  it needs the Blaze plan, the Play service account + Play Console API
  access grant, the `PLAY_SERVICE_ACCOUNT_JSON` secret, and
  `BILLING_VERIFY_URL` set in `src/billing.ts`. It deploys through the
  existing "Deploy Firebase" GitHub workflow (new `functions` target;
  `everything` includes functions) or manually — see
  `functions/README.md`.
- **Production guard:** a production build (`__DEV__` false: release /
  beta / internal) REFUSES to credit a purchase when `BILLING_VERIFY_URL`
  is empty. The purchase stays owned by Google Play and is retried once
  the backend is live. Only a debug build (`__DEV__` true) may use the
  local-only fallback. This means the license-tester test purchase cannot
  complete until the backend is deployed and the URL is set.
- **Local-only path (current, until the backend is deployed):** the
  client verifies locally (`verifyPurchaseRecord`: known product,
  PURCHASED state, order ID, purchase token, signed receipt, package
  `com.genzmode.app`) and writes the ledger under the order ID
  (create-only, rules-enforced). `recordPurchaseTxn` now also checks for
  an existing ledger entry with the same purchaseToken before writing.
  This bounds a forged purchase to the catalog amount once per order —
  it is **not** server verification and is not presented as such.
- **Reconciliation:** the ledger is append-only and create-only; the
  wallet is a cache recomputed from it. `reconcileOwnedPurchases` runs
  on app start, wallet open, and Restore; a purchase that was credited
  but not consumed is consumed on the next reconcile (duplicate path);
  a purchase that failed before the ledger write stays owned by Play
  and is retried. Pending purchases are never credited. The ledger
  history (Wallet → Transaction history) shows every purchase,
  migration, and admin grant.

### 7.4 Production readiness — ❌ NOT production-ready

Do not promote to production while server verification is undeployed.
Remaining: deploy the backend (§7.3), complete a real license-tester
test purchase (§7.2), create the 7 Play Console products, add the
upload-key secrets, and clear all 11 production-readiness gates (all
currently `blocked`). The `release` Gradle build refuses to run until
those gates have evidence in `docs/release-evidence/`.
