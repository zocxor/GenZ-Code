# GenZ Code — 0.8.0 upgrade

Data persistence rebuilt at the root, cloud sync, Secure Engine + Threat Shield, Firestore security rules, admin portal with CMS, elegant profile dashboard, profile photo, upgraded navigation bar. **Start with [the implementation report](docs/UPGRADE_0.8_REPORT.md)** — it lists what was verified and what was not (Firestore rules tests and device QA are still required).

- Admin/Firebase setup: [docs/ADMIN_PORTAL.md](docs/ADMIN_PORTAL.md) · Retention: [docs/DATA_RETENTION.md](docs/DATA_RETENTION.md) · Play Data safety: [docs/PLAY_DATA_SAFETY.md](docs/PLAY_DATA_SAFETY.md)
- **APK:** see [docs/BUILD_APK.md](docs/BUILD_APK.md) (GitHub Actions workflow or local Android Studio)
- App: `npm ci && npm run typecheck && npm test` · Rules: `npm run test:rules` (Java 21 + firebase-tools) · Scan: `npm run security:scan`
- Portal: `cd admin && npm ci && npm test && npm run build` (hosting: `firebase deploy --only hosting`)
- Browser e2e: see [tests-e2e/README.md](tests-e2e/README.md) (needs `npm i -D playwright`)
- Release bundles: always `--clear` the Metro cache and never set `EXPO_PUBLIC_FIREBASE_EMULATOR_HOST`.

The 8,584-entry library and SQLite export are unchanged. The sections below are the earlier release notes.

# GenZ Code — branding update 0.7.0

New glossy logo, launcher icon, welcome branding and profile assets are integrated. See [branding usage and verification](docs/BRANDING_0.7.md). This source is based on the attached 0.5.0 ZIP; historical release notes below describe that baseline. No 0.7 APK has been assembled. Regional content expansion remains pending.

# GenZ Code

A glassy, skeuomorphic Android-first dictionary, chat decoder and learning app. Current source revision: **0.5.0**.

## Available in source

- Offline search across 8,584 attributed references, explicit search button, numeric/emoji/phrase matching, category and content-language filters.
- On-device message decoder, saved terms, local profile, four authored stages, daily/shuffle quizzes and scheduled word review.
- Protected local persistence, retry/recovery, data deletion and validated local-learning export.
- New Firebase email account screen: sign-up/sign-in, reset, verification, sign-out and deletion using the supplied project. Native sessions use encrypted SecureStore when available; web sessions are memory-only.

## Honest status

This source is **not a complete production release**. Firebase public configuration connectivity passed, but live account flows and native secure persistence require device verification and provider configuration. Google sign-in is unavailable because OAuth configuration is absent. Cloud progress, backend/CMS, AI, billing, community moderation, public web deployment and full curriculum remain unfinished. Most imported content still needs individual editorial review; the numeric category has 162 entries, not 500.

See [Firebase setup](docs/FIREBASE_SETUP.md), [security review](docs/FIREBASE_SECURITY_0.5.md), and [current validation](docs/VALIDATION_0.5.md). The accompanying APK is **0.5.0-internal**, test-signed for ARM64 Android 7+. Its signature, package identity, manifest and content were verified. It is not a production release or a device-test certification.

## Develop

`npm ci` → `npm run typecheck` → `npm test` → `npm run start`.

`npm run export:android` validates Android JavaScript bundling; it does not generate an APK.

With JDK 17, Android SDK 36, build-tools 35.0.0 and NDK 27.1.12297006 installed: `cd android && ./gradlew assembleInternal -PreactNativeArchitectures=arm64-v8a`. The maintained native project preserves app identity and signing guards; do not blindly overwrite it with Expo prebuild. SecureStore autolinks as an Expo module. Backups remain disabled.

Production release requires owner-controlled signing variables and completed evidence in `production-readiness.json`; run `npm run release:check` before `./gradlew bundleRelease`. The bundled debug keystore is only for internal test installs. See [handoff](docs/PRODUCTION_HANDOFF.md) for the remaining roadmap.

---

GenZ Code is a **ZTechX** product. © 2026 Zocxorian Technologies. All rights reserved.
