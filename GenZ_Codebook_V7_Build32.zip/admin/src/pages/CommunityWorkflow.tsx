import {libraryFetch} from '../lib/library';
import backend from '../../../shared/backend.json';
import React,{useEffect,useMemo,useState} from 'react';
import {SPARK_MODE} from '../../../shared/deployment';
import {sparkAdmin} from '../lib/sparkAdmin';
import {collection,documentId,endAt,getDocs,limit,orderBy,query,where,startAfter,startAt,type QueryDocumentSnapshot} from 'firebase/firestore/lite';
import {connectFunctionsEmulator,getFunctions,httpsCallable} from 'firebase/functions';
import {app,db} from '../firebase';
import {Card,Notice,Pill} from '../ui';
import DailyCodesList from './DailyCodesList';
import BadgeAdmin from './BadgeAdmin';
import policy from '../../../functions/src/communityPolicy.json';
import {dailyWordFromHash,dailyWordFromRecord,findDailyWords,wordKey,wordSourceLabel,type DailyWord,type DailyWordSource} from '../lib/dailyWordPicker';

const emu=import.meta.env.VITE_FIREBASE_EMULATOR_HOST;
const functions=getFunctions(app,emu?'us-central1':backend.url||'us-central1');
if(emu && /^(127\.0\.0\.1|localhost)$/.test(emu))connectFunctionsEmulator(functions,emu,5001);
const invokeFeature=httpsCallable<Record<string,unknown>,Record<string,unknown>>(functions,'communityFeature');
export const runFeature=async(input:Record<string,unknown>)=>{
  const direct=(!backend.url&&input.action==='daily-admin'&&['schedule-word','cancel-schedule'].includes(String(input.command)))||['code-admin','post-admin','resolve-post-report','badge-admin'].includes(String(input.action));
  if(direct){
    try{return await sparkAdmin(input);}catch(error){
      if(!backend.url||!(error instanceof Error)||!/historical paid post/i.test(error.message))throw error;
    }
  }
  if(!backend.url&&!emu)throw new Error('Configure the Firebase backend URL before using paid services.');
  return invokeFeature(input);
};
type Kind='daily'|'post'|'verification';
type Report={id:string;postId:string;reason:string;note?:string};
type Row={id:string;status?:string;hidden?:boolean;name?:string;uid?:string;term?:string;text?:string;meaning?:string;category?:string;example?:string;payment?:string;fee?:number;createdAt?:{toMillis:()=>number};updatedAt?:{toMillis:()=>number};requestedDate?:string;publicationDate?:string;reservedDate?:string;reason?:string;schema?:number};
const sources={daily:'dailyCodeApplications',post:'communityPosts',verification:'verificationApplications'};
const day=(now=Date.now())=>new Date(now).toISOString().slice(0,10);
const when=(value?:{toMillis:()=>number})=>value?day(value.toMillis()):'—';
const statusOf=(r:Row)=>r.status??(r.hidden?'removed':'pending');
const label=(s:string)=>s.charAt(0).toUpperCase()+s.slice(1);
const statusTone=(s:string)=>s==='published'||s==='approved'?'good':s==='rejected'||s==='removed'||s==='revoked'?'bad':s==='scheduled'?'info':'warn';
const msgOf=(e:unknown)=>e instanceof Error?e.message:'The request could not be completed.';
function commandError(e:unknown,command:string) {
  const code=e && typeof e==='object' && 'code' in e ? e.code : '';
  const message=msgOf(e);
  if (code==='functions/not-found' && /^(?:not-found|not found)(?:\s*\[404\])?$/i.test(message)) {
    return 'The payment and Daily Code backend is missing (404). Run GitHub Actions → Deploy Firebase → community. Deploying admin-portal alone does not activate these services. No Credits were charged.';
  }
  if ((code==='functions/internal' && /^internal(?: \[0\])?$/i.test(message)) || code==='functions/unavailable') {
    return 'The Firebase community service could not be reached. Retry, then verify that communityFeature is deployed for this project and check its logs.';
  }
  if (command==='schedule-word' && code==='functions/invalid-argument' && ['Invalid record identifier.','Choose a word from the dictionary.'].includes(message)) {
    return 'Deploy the updated communityFeature function before scheduling a selected word.';
  }
  return message;
}

async function loadDailyWords() {
  const bundled = async ():Promise<DailyWord[]> => {
    const response = await libraryFetch();
    if (!response.ok) throw new Error('The bundled dictionary could not be loaded.');
    const entries = await response.json() as {id:string;expression:string;meaning:string;category:string;sensitivity:string;aliases?:string[]}[];
    return entries.filter(w=>w.sensitivity==='None'&&w.expression&&w.meaning&&w.category)
      .map(({id,expression:term,meaning,category,aliases})=>({id,term,meaning,category,aliases,source:'bundled'}));
  };
  const liveWords = async (source:Exclude<DailyWordSource,'bundled'>,name:string,status:string) => {
    const snapshot = await getDocs(query(collection(db,name),where('status','==',status)));
    return snapshot.docs.map(doc=>dailyWordFromRecord(source,doc.id,doc.data())).filter(word=>word!==null);
  };
  const sources = ['bundled dictionary','approved suggestions','published entries','live community words'];
  const results = await Promise.allSettled([bundled(),liveWords('submission','submissions','accepted'),
    liveWords('published','publishedContent','published'),liveWords('community','communityWords','live')]);
  return {
    words:results.flatMap(result=>result.status==='fulfilled'?result.value:[]).filter(word=>!SPARK_MODE||word.source!=='submission').sort((a,b)=>a.term.localeCompare(b.term)),
    unavailable:results.flatMap((result,i)=>result.status==='rejected'?[sources[i]]:[]),
  };
}
function saveReport(rows:Row[]){
  const escape=(value:string)=>'"'+(/^[=+\-@\t\r]/.test(value)?"'":'')+value.replace(/"/g,'""')+'"';
  const csv=[['Word','Category','Submitted by','Status','Applied UTC','Requested UTC','Confirmed UTC','Payment'],...rows.map(r=>[r.term??'',r.category??'',r.name??'',statusOf(r),when(r.createdAt),r.requestedDate??'',r.publicationDate??'',r.payment??''])].map(r=>r.map(escape).join(',')).join('\r\n');
  const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
  const link=document.createElement('a');link.href=url;link.download='daily-code-report.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
export default function CommunityWorkflow({kind}:{kind:Kind}){
  const [rows,setRows]=useState<Row[]>([]),[cursor,setCursor]=useState<QueryDocumentSnapshot|null>(null),[more,setMore]=useState(false);
  const [reports,setReports]=useState<Report[]>([]);
  const [badgeUid,setBadgeUid]=useState('');
  const [filter,setFilter]=useState('all'),[search,setSearch]=useState(''),[dateFilter,setDateFilter]=useState('');
  const [month,setMonth]=useState(day().slice(0,7)),[slots,setSlots]=useState<Record<string,string>>({}),[publications,setPublications]=useState<Row[]>([]);
  const [selected,setSelected]=useState(''),[date,setDate]=useState(''),[meaning,setMeaning]=useState(''),[example,setExample]=useState(''),[category,setCategory]=useState(''),[reason,setReason]=useState('');
  const [reviewDate,setReviewDate]=useState('');
  const [words,setWords]=useState<DailyWord[]>([]),[wordSearch,setWordSearch]=useState(''),[wordKeySelected,setWordKeySelected]=useState(()=>dailyWordFromHash(location.hash));
  const [wordError,setWordError]=useState(''),[wordsLoading,setWordsLoading]=useState(true);
  const [error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false),[loading,setLoading]=useState(true),[refresh,setRefresh]=useState(0);
  const active=rows.find(r=>r.id===selected);
  const from=month+'-01';
  const days=new Date(Date.UTC(Number(month.slice(0,4)),Number(month.slice(5)),0)).getUTCDate();
  const last=month+'-'+String(days).padStart(2,'0');
  const today=day(), firstDate=day(Date.now()+86_400_000), maxDate=day(Date.now()+policy.bookingDays*86_400_000);
  const picked=words.find(w=>wordKey(w)===wordKeySelected);
  const matchingWords=useMemo(()=>findDailyWords(words,wordSearch),[words,wordSearch]);
  const wordOptions=matchingWords.slice(0,100);
  if (picked&&!wordOptions.includes(picked)) wordOptions.unshift(picked);
  const dateAvailable=date>=firstDate&&date<=maxDate&&!slots[date];
  const scheduleBlock=wordsLoading?'Loading dictionary words…':!date?'Choose a publication date.':date<firstDate||date>maxDate?`Choose a date from ${firstDate} to ${maxDate}.`:slots[date]?`${date} is already ${slots[date]}.`:!picked?'Choose a dictionary word.':'';
  const load=async(after?:QueryDocumentSnapshot)=>{
    const snap=await getDocs(query(collection(db,sources[kind]),orderBy('createdAt','desc'),...(after?[startAfter(after)]:[]),limit(75)));
    const data=snap.docs.map(d=>({...d.data(),id:d.id}) as Row);
    setRows(current=>after?[...current,...data]:data);
    setCursor(snap.docs.at(-1)??null);setMore(snap.size===75);
  };
  useEffect(()=>{
    setLoading(true);setError('');
    void load().catch(e=>setError(msgOf(e))).finally(()=>setLoading(false));
  },[kind,refresh]);
  useEffect(()=>{
    if(kind!=='daily'||!/^\d{4}-\d{2}$/.test(month))return;
    let alive=true;
    const range=(name:string)=>getDocs(query(collection(db,name),orderBy(documentId()),startAt(from),endAt(last)));
    void Promise.all([range('dailyCodeDates'),range('dailyCodePublic')]).then(([s,p])=>{
      if(alive){setSlots(Object.fromEntries([...s.docs.map(d=>[d.id,d.get('status')]),...p.docs.map(d=>[d.id,d.id<=day()?'published':'scheduled'])]));setPublications(p.docs.map(d=>({...d.data(),id:d.id}) as Row));}
    },e=>{if(alive)setError(msgOf(e));});
    return ()=>{alive=false;};
  },[kind,from,last,month,refresh]);
  useEffect(()=>{
    if (kind!=='daily') return;
    let alive=true;
    setWordsLoading(true);setWordError('');
    void loadDailyWords().then(({words,unavailable})=>{
      if (!alive) return;
      setWords(words);
      if (unavailable.length) setWordError(`Could not load ${unavailable.join(', ')}. Refresh to try again.`);
    }).catch(e=>{if(alive)setWordError(msgOf(e));}).finally(()=>{if(alive)setWordsLoading(false);});
    return ()=>{alive=false;};
  },[kind,refresh]);
  useEffect(()=>{
    if(kind!=='post')return;
    let alive=true;
    void getDocs(query(collection(db,'postReports'),where('status','==','open'),limit(50))).then(snap=>{
      if(alive)setReports(snap.docs.map(d=>({...d.data(),id:d.id}) as Report));
    },e=>{if(alive)setError(msgOf(e));});
    return ()=>{alive=false;};
  },[kind,refresh]);
  const reviewReport=async(id:string,command:'dismiss'|'remove')=>{
    if(busy||!window.confirm(command==='remove'?'Resolve this report and remove the post?':'Dismiss this report?'))return;
    setBusy(true);setError('');setNotice('');
    try{await runFeature({action:'resolve-post-report',id,command});setRefresh(r=>r+1);setNotice('Report decision recorded.');}
    catch(e){setError(commandError(e,command));}
    finally{setBusy(false);}
  };
  const choose=(r:Row)=>{
    setSelected(r.id);{const wanted=r.publicationDate??r.reservedDate??r.requestedDate??'';setReviewDate(wanted&&wanted>=firstDate?wanted:firstDate);}setMeaning(r.meaning??'');setExample(r.example??'');setCategory(r.category??policy.postCategories[0]!);setReason('');
  };
  const command=async(cmd:string)=>{
    if(busy)return;
    if(['reject','remove','revoked','delete'].includes(cmd)&&!window.confirm(`Confirm ${cmd==='revoked'?'badge revocation':cmd}?`))return;
    setBusy(true);setError('');setNotice('');
    try {
      const commandDate=cmd==='publish'?day():cmd==='schedule'||cmd==='approve-schedule'?reviewDate:date;
      const calendarAction=['publish','generate','schedule-word','cancel-schedule'].includes(cmd);
      const fields=calendarAction ? (cmd==='schedule-word'&&picked?{wordId:picked.id,wordSource:picked.source}:{}) : {id:selected,meaning,example,category,...(reason.trim()?{reason:reason.trim()}: {})};
      await runFeature({action:kind==='verification'?'verification-admin':kind+'-admin',command:cmd==='approve-schedule'?'approve':cmd,date:commandDate,...fields});
      setNotice(cmd==='schedule-word'&&picked?`${picked.term} is scheduled for ${commandDate} UTC.`:cmd==='approve-schedule'?`Approved and scheduled for ${commandDate} UTC.`:'Saved. The action was recorded in the audit log.');
      setRefresh(r=>r+1);
    } catch(e){setError(commandError(e,cmd));}
    finally{setBusy(false);}
  };
  const runListAction=async(input:Record<string,unknown>,success:string)=>{
    if(busy)return false;
    setBusy(true);setError('');setNotice('');
    try{await runFeature(input);setNotice(success+' Recorded in the audit log.');setRefresh(r=>r+1);return true;}
    catch(e){setError(commandError(e,String(input.command??'')));return false;}
    finally{setBusy(false);}
  };
  // Why "Approve & schedule"/"Confirm date" is disabled, shown next to the button.
  const approveBlock=!reviewDate?'Choose a publication date.':reviewDate<firstDate||reviewDate>maxDate?`Choose a date from ${firstDate} to ${maxDate} (UTC). The requested date may have passed.`:slots[reviewDate]&&active&&active.reservedDate!==reviewDate?`${reviewDate} is already ${slots[reviewDate]}. Choose another date.`:'';
  const filters=kind==='daily'?['all','pending','approved','scheduled','published','rejected','cancelled']:kind==='post'?['all','pending','approved','hidden','rejected','removed']:['all','pending','approved','rejected','revoked'];
  const visible=rows.filter(r=>(filter==='all'||statusOf(r)===filter)&&(!dateFilter||when(r.createdAt)===dateFilter)&&(!search||[r.term,r.name,r.category,r.text,r.uid].some(v=>v?.toLowerCase().includes(search.toLowerCase().trim()))));
  const manualBadge=kind==='verification'?<BadgeAdmin/>:null;
  if(!backend.url&&kind==='verification')return manualBadge;
  return <div className="stack">
    {manualBadge}
    {!!error&&<Notice kind="error">{error}</Notice>}{!!notice&&<Notice kind="ok">{notice}</Notice>}
    {kind==='daily'&&<Card title="Scheduling calendar" subtitle="Publication dates use UTC. Firebase publishes scheduled words automatically and refunds applications that cannot be fulfilled." actions={<>
      <a className="btn" href="#moderation">Dictionary approvals</a>
      <button className="btn" disabled={busy} onClick={()=>saveReport(visible)}>Export loaded applications</button>
      <button className="btn" disabled={!backend.url||busy||slots[today]==='published'} onClick={()=>void command('publish')}>Publish today</button>
    </>}>
      <label className="field">Month<input type="month" value={month} onChange={e=>{if(e.target.value)setMonth(e.target.value);}}/></label>
      <div className="feature-calendar" aria-label="Daily Code schedule">
        {Array.from({length:days},(_,i)=>{
          const key=month+'-'+String(i+1).padStart(2,'0');
          const status=slots[key]??(key<=day()?'past':'available');
          return <button key={key} type="button" className={`btn feature-date is-${status}`} aria-label={`${key} ${label(status)}`} aria-pressed={date===key} onClick={()=>setDate(key)}><strong>{i+1}</strong><span>{label(status)}</span></button>;
        })}
      </div>
      <div className="cal-legend" aria-hidden="true"><span className="is-scheduled">Reserved / scheduled</span><span className="is-published">Published</span><span className="is-pending">Pending request</span><span className="is-available">Available</span><span className="is-past">Past</span></div>
      <h3>Choose a Daily Code</h3>
      <div className="row wrap">
        <label className="field">Publication date (UTC)<input type="date" min={firstDate} max={maxDate} value={date} onChange={e=>{setDate(e.target.value);if(e.target.value)setMonth(e.target.value.slice(0,7));}}/></label>
        <label className="field grow">Search dictionary words<input value={wordSearch} onChange={e=>{setWordSearch(e.target.value);setWordKeySelected('');}} placeholder="Search by word or alias"/></label>
        <label className="field grow">Dictionary word<select value={picked?wordKey(picked):''} onChange={e=>setWordKeySelected(e.target.value)} disabled={wordsLoading||!wordOptions.length}><option value="">Choose a word</option>{wordOptions.map(w=><option key={wordKey(w)} value={wordKey(w)}>{w.term} · {wordSourceLabel[w.source]}</option>)}</select></label>
      </div>
      {wordError&&<Notice kind="error">{wordError}</Notice>}
      {!wordsLoading&&wordKeySelected&&!picked&&<Notice kind="error">The selected word is no longer available for Daily Code. Choose another entry or refresh.</Notice>}
      {wordsLoading?<p className="muted">Loading dictionary words…</p>:!wordError&&!matchingWords.length?<p className="muted">No eligible words match your search.</p>:matchingWords.length>100?<p className="muted">Showing the first 100 matches. Search to narrow the list.</p>:null}
      {picked&&<div className="daily-glass-preview"><strong>{picked.term}</strong><p>{picked.meaning}</p><span>{picked.category} · {wordSourceLabel[picked.source]}</span></div>}
      {date&&slots[date]&&<p className="muted">This date is {slots[date]}. Choose an available date.</p>}
      <div className="row wrap">
        <button className="btn primary" disabled={busy||!dateAvailable||!picked||wordsLoading} title={scheduleBlock||'Schedule'} onClick={()=>void command('schedule-word')}>Schedule selected word</button>
        {!!scheduleBlock&&<span className="muted small" role="status">{scheduleBlock}</span>}
        {!!backend.url&&date>today&&slots[date]==='scheduled'&&<button className="btn" disabled={busy} onClick={()=>{if(window.confirm('Cancel this scheduled Daily Code?'))void command('cancel-schedule');}}>Cancel selected schedule</button>}
        {!!backend.url&&<button className="btn" disabled={busy||!dateAvailable} onClick={()=>void command('generate')}>Auto-pick and schedule</button>}
      </div>
      <h3>{SPARK_MODE?'Scheduled and published entries':'Publication history'} for {month}</h3>
      {publications.length?publications.map(r=><div className="row wrap" key={r.id}><Pill tone="good">{r.id}</Pill><strong>{r.term}</strong><span className="muted">{r.category} · {r.meaning}</span></div>):<p className="muted">No publications this month.</p>}
    </Card>}
    {kind==='daily'&&<DailyCodesList picked={picked} refresh={refresh} onChanged={()=>setRefresh(r=>r+1)} run={runListAction}/>}
    <Card title={kind==='daily'?'Applications queue':kind==='post'?'Post submissions':'Verified Badge applications'} subtitle={kind==='post'?'Open-mode posts appear immediately. Use the queue to review, hide, restore, edit or delete posts.':'Review submissions, payment status and decisions.'}
      actions={<button className="btn" onClick={()=>setRefresh(r=>r+1)} disabled={loading}>Refresh</button>}>
      <div className="row wrap">{filters.map(f=><button key={f} className={f===filter?'btn primary':'btn'} aria-pressed={f===filter} onClick={()=>setFilter(f)}>{label(f)}</button>)}</div>
      <div className="row wrap"><label className="field grow">Search loaded records<input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Word, nickname or category"/></label><label className="field">Submission date (UTC)<input type="date" value={dateFilter} onChange={e=>setDateFilter(e.target.value)}/></label></div>
      {loading?<p className="muted">Loading…</p>:visible.length?<div className="table-wrap"><table><thead><tr><th>Entry</th><th>Contributor</th><th>Status</th><th>Submitted / updated</th><th>Payment</th>{kind==='daily'&&<th>Requested / confirmed</th>}<th>Review</th></tr></thead>
      <tbody>{visible.map(r=><tr key={r.id}><td><strong>{r.term??(kind==='post'?r.text:'Verified Badge')}</strong>{r.category&&<div className="muted">{r.category}</div>}</td><td>{r.name??'Code Explorer'}<div className="muted small">{r.uid}</div></td><td><Pill tone={statusTone(statusOf(r))}>{label(statusOf(r))}</Pill></td><td>{when(r.createdAt)} / {when(r.updatedAt)}</td><td>{r.fee? r.fee.toLocaleString()+' Credits · '+r.payment:'Legacy entry'}</td>{kind==='daily'&&<td>{r.requestedDate??'—'} / {r.publicationDate??'—'}</td>}<td><button className="btn" onClick={()=>choose(r)}>Open</button></td></tr>)}</tbody></table></div>:<p className="muted">No matching records.</p>}
      {more&&cursor&&<button className="btn" disabled={loading} onClick={()=>{setLoading(true);void load(cursor).catch(e=>setError(msgOf(e))).finally(()=>setLoading(false));}}>Load older records</button>}
    </Card>
    {kind==='post'&&<Card title="Open post reports" subtitle="Up to 50 reports awaiting review.">
      {reports.length?reports.map(r=><div className="row wrap" key={r.id}>
        <div className="grow"><strong>{r.reason}</strong><div className="muted">{r.note||'No details'}</div><code>{r.postId}</code></div>
        <button className="btn" disabled={busy} onClick={()=>void reviewReport(r.id,'dismiss')}>Dismiss report</button>
        <button className="btn danger" disabled={busy} onClick={()=>void reviewReport(r.id,'remove')}>Remove post</button>
      </div>):<p className="muted">No open post reports.</p>}
    </Card>}
    {active&&<Card title={active.term??active.name??'Review submission'} subtitle={`${label(statusOf(active))} · Submitted ${when(active.createdAt)} UTC`}>
      <p>{active.meaning??active.text??(active.name+' · '+active.uid)}</p>
      {!!active.example&&<p className="muted">Example: {active.example}</p>}
      {!!active.reason&&<p className="muted">{active.reason}</p>}
      {kind!=='verification'&&['pending','approved','scheduled'].includes(statusOf(active))&&active.term&&<>
        <label className="field">Edit meaning<textarea value={meaning} maxLength={kind==='post'?200:500} onChange={e=>setMeaning(e.target.value)}/></label>
        {kind==='post'&&<div className="row wrap"><label className="field">Category<select value={category} onChange={e=>setCategory(e.target.value)}>{policy.postCategories.map(c=><option key={c}>{c}</option>)}</select></label><label className="field grow">Example<input value={example} maxLength={200} onChange={e=>setExample(e.target.value)}/></label></div>}
        <button className="btn" disabled={busy||!meaning.trim()} onClick={()=>void command('edit')}>Save edits</button>
      </>}
      {kind==='daily'&&['pending','approved','scheduled'].includes(statusOf(active))&&<label className="field">Rejection reason<input value={reason} maxLength={200} onChange={e=>setReason(e.target.value)}/></label>}
      <div className="row wrap">
        {statusOf(active)==='pending'&&kind==='daily'&&<>
          <label className="field">Publication date (UTC)<input type="date" min={firstDate} max={maxDate} value={reviewDate} onChange={e=>setReviewDate(e.target.value)}/></label>
          <button className="btn primary" disabled={busy||!!approveBlock} title={approveBlock||'Approve and schedule'} onClick={()=>void command('approve-schedule')}>Approve &amp; schedule</button>
          {!!approveBlock&&<span className="muted small" role="status">{approveBlock}</span>}
        </>}
        {statusOf(active)==='pending'&&kind!=='daily'&&<button className="btn primary" disabled={busy} onClick={()=>void command(kind==='verification'?'approved':'approve')}>Approve</button>}
        {(statusOf(active)==='pending'||kind==='daily'&&['approved','scheduled'].includes(statusOf(active)))&&<button className="btn danger" disabled={busy} onClick={()=>void command(kind==='verification'?'rejected':'reject')}>{kind==='daily'?'Reject and refund':'Reject'}</button>}
        {kind==='daily'&&['approved','scheduled'].includes(statusOf(active))&&<>
          <label className="field">Confirmed date (UTC)<input type="date" min={firstDate} max={maxDate} value={reviewDate} onChange={e=>setReviewDate(e.target.value)}/></label>
          <button className="btn primary" disabled={busy||!!approveBlock} title={approveBlock||'Confirm the publication date'} onClick={()=>void command('schedule')}>{statusOf(active)==='scheduled'?'Reschedule':'Confirm date'}</button>
          {!!approveBlock&&<span className="muted small" role="status">{approveBlock}</span>}
        </>}
        {kind==='post'&&statusOf(active)==='approved'&&<button className="btn" disabled={busy} onClick={()=>void command('hide')}>Hide post</button>}
        {kind==='post'&&statusOf(active)==='hidden'&&<button className="btn" disabled={busy} onClick={()=>void command('restore')}>Restore post</button>}
        {kind==='post'&&<button className="btn danger" disabled={busy} onClick={()=>void command('delete')}>Delete post permanently</button>}
        {kind==='post'&&statusOf(active)==='approved'&&<button className="btn danger" disabled={busy} onClick={()=>void command('remove')}>Remove from feed</button>}
        {kind==='verification'&&statusOf(active)==='approved'&&<button className="btn danger" disabled={busy} onClick={()=>void command('revoked')}>Revoke badge</button>}
      </div>
    </Card>}
  </div>;
}
