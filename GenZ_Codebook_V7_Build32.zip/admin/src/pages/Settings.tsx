import React, {useState} from 'react';
import {doc, getDoc, serverTimestamp} from 'firebase/firestore/lite';
import {multiFactor} from 'firebase/auth';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can, ROLE_LABELS} from '../rbac';
import {publishingMode,type PublishingMode} from '../../../shared/publishing';
import {BYLINE, RIGHTS, copyright} from '../../../shared/brand';
import {Card, Notice, Field, useLoad} from '../ui';

type AppConfig = {dictionaryPostingMode:'open'|'review'|'paused';postPostingMode:'open'|'review'|'paused';ugcEnabled: boolean; contentUpdatesEnabled: boolean; communityWordsEnabled: boolean; chatEnabled: boolean; minSupportedVersion: string; paidCommunity: boolean; encodeFreeDaily: number; decodeFreeDaily: number; prices: Prices};
type Prices = {chatDay: number; post: number; code: number; dailyCode: number; verification: number; encode: number; decode: number};
const PRICE_FIELDS: {key: keyof Prices; label: string; min: number; def: number}[] = [
  {key: 'chatDay', label: 'Community chat · whole day', min: 1, def: 30}, {key: 'post', label: 'Publish one community post', min: 1, def: 50},
  {key: 'code', label: 'Create / suggest a dictionary word', min: 1, def: 150}, {key: 'dailyCode', label: 'Request a personal Daily Code', min: 1, def: 250},
  {key: 'verification', label: 'Verified badge review', min: 1, def: 5000}, {key: 'encode', label: 'Encode Message · each after the free ones (0 = free)', min: 0, def: 5},
  {key: 'decode', label: 'Decode Message · each after the free ones (0 = free)', min: 0, def: 5}];
const readPrices = (raw: unknown): Prices => Object.fromEntries(PRICE_FIELDS.map(f => {const v = (raw as Record<string, unknown> | undefined)?.[f.key]; return [f.key, Number.isInteger(v) && (v as number) >= f.min ? v : f.def];})) as Prices;

export default function Settings() {
  const s = useSession();
  const cfg = useLoad(async (): Promise<AppConfig> => {
    const d = await getDoc(doc(db, 'config', 'app'));
    const v = d.exists() ? d.data() : {};
    return {dictionaryPostingMode:publishingMode(v,'code'),postPostingMode:publishingMode(v,'post'),ugcEnabled: v.ugcEnabled !== false, contentUpdatesEnabled: v.contentUpdatesEnabled !== false, communityWordsEnabled: v.communityWordsEnabled !== false, chatEnabled: v.chatEnabled !== false, paidCommunity: v.paidCommunity === true, encodeFreeDaily: Number.isInteger(v.encodeFreeDaily) ? v.encodeFreeDaily : 10, decodeFreeDaily: Number.isInteger(v.decodeFreeDaily) ? v.decodeFreeDaily : 10, prices: readPrices(v.prices), minSupportedVersion: typeof v.minSupportedVersion === 'string' ? v.minSupportedVersion : '0.8.3'};
  }, []);
  const [draft, setDraft] = useState<AppConfig | null>(null);
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  const value = draft ?? cfg.data;
  const save = async () => {
    if (!value) return;
    setBusy(true); setMsg(null);
    try {
      const b = newBatch();
      const lastAuditId = addAudit(b, s.uid, s.role, 'config.update', 'config/app', `ugc=${value.ugcEnabled} instant=${value.communityWordsEnabled} chat=${value.chatEnabled} paid=${value.paidCommunity} encode=${value.encodeFreeDaily} decode=${value.decodeFreeDaily} prices=${PRICE_FIELDS.map(f => f.key + ':' + value.prices[f.key]).join(',')} content=${value.contentUpdatesEnabled} min=${value.minSupportedVersion}`);
      b.set(doc(db, 'config', 'app'), {...value, updatedAt: serverTimestamp(), updatedBy: s.uid, lastAuditId});
      await b.commit(); setMsg({kind: 'ok', text: 'Settings saved and audited.'}); setDraft(null); cfg.reload();
    } catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };
  const factors = multiFactor(s.user).enrolledFactors;
  return <div className="stack">
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    <Card title="Your session" index={0}>
      <dl className="grid-dl"><dt>Signed in as</dt><dd>{s.email}</dd><dt>Role</dt><dd>{ROLE_LABELS[s.role]}</dd><dt>Second factors</dt><dd>{factors.map(f => f.displayName ?? f.factorId).join(', ') || '—'}</dd><dt>Session</dt><dd>This tab only · ends after 30 minutes of inactivity</dd></dl>
    </Card>
    {can(s.role, 'config.manage') && <Card title="App controls" subtitle="Public flags read by the app and enforced by security rules. Changes are audited." index={1}>
      {cfg.error ? <Notice kind="error">{errorMessage(cfg.error)}</Notice> : value && <>
        <label className="row"><input type="checkbox" checked={value.ugcEnabled} onChange={e => setDraft({...value, ugcEnabled: e.target.checked})} /> Accept word suggestions and reports from users (kill switch for abuse)</label>
        {(['dictionaryPostingMode','postPostingMode'] as const).map(key=><Field key={key} label={key==='dictionaryPostingMode'?'Dictionary code publishing':'Community post publishing'}>
          <select value={value[key]} onChange={e=>setDraft({...value,[key]:e.target.value as PublishingMode,...(key==='dictionaryPostingMode'?{communityWordsEnabled:e.target.value==='open'}:{})})}>
            <option value="open">Open — publish immediately after payment</option><option value="review">Approval required</option><option value="paused">Paused — accept no new submissions</option>
          </select>
        </Field>)}
        <label className="row"><input type="checkbox" checked={value.chatEnabled} onChange={e => setDraft({...value, chatEnabled: e.target.checked})} /> Community chat is open (turn off to close the chat room)</label>
        <h3>Credits</h3>
        <label className="row"><input type="checkbox" checked={value.paidCommunity} onChange={e => setDraft({...value, paidCommunity: e.target.checked})} /> Charge Credits for chat ({value.prices.chatDay}/day), posts ({value.prices.post}) and new dictionary words ({value.prices.code})</label>
        <Notice kind={value.paidCommunity ? 'ok' : 'info'}>{value.paidCommunity ? 'Paid mode is on. The app and security rules require Credits for these actions.' : 'While off, chat, posts and new words are free. Daily Code requests, badge review and extra Encode/Decode conversions are always charged at the prices below.'}</Notice>
        <h3>Prices (Credits)</h3>
        <p className="muted small">Users see the new price immediately and the server charges exactly this amount. Changes are audited.</p>
        <div className="price-grid">{PRICE_FIELDS.map(f => <Field key={f.key} label={f.label}><input type="number" min={f.min} max={f.key === 'encode' || f.key === 'decode' ? 1000 : 100000} value={value.prices[f.key]} onChange={e => setDraft({...value, prices: {...value.prices, [f.key]: Math.max(f.min, Math.min(f.key === 'encode' || f.key === 'decode' ? 1000 : 100000, Math.floor(Number(e.target.value) || 0)))}})} /></Field>)}</div>
        <h3>Free Encode / Decode</h3>
        <div className="price-grid">
          <Field label="Free encodes per user per day"><input type="number" min={0} max={1000} value={value.encodeFreeDaily} onChange={e => setDraft({...value, encodeFreeDaily: Math.max(0, Math.min(1000, Math.floor(Number(e.target.value) || 0)))})} /></Field>
          <Field label="Free decodes per user per day"><input type="number" min={0} max={1000} value={value.decodeFreeDaily} onChange={e => setDraft({...value, decodeFreeDaily: Math.max(0, Math.min(1000, Math.floor(Number(e.target.value) || 0)))})} /></Field>
        </div>
        <h3>Content</h3>
        <label className="row"><input type="checkbox" checked={value.contentUpdatesEnabled} onChange={e => setDraft({...value, contentUpdatesEnabled: e.target.checked})} /> Deliver published content updates to apps</label>
        <Field label="Minimum supported app version (informational)"><input value={value.minSupportedVersion} onChange={e => setDraft({...value, minSupportedVersion: e.target.value.slice(0, 20)})} /></Field>
        <button className="btn primary" disabled={busy || !draft} onClick={() => void save()}>Save settings</button>
      </>}
    </Card>}
    <Card title="About this portal" index={2}>
      <dl className="grid-dl"><dt>Product</dt><dd>GenZ Codebook Admin Portal</dd><dt>Version</dt><dd>1.0.0 — First release</dd><dt>Publisher</dt><dd>{BYLINE}</dd></dl>
      <p className="muted small">{copyright()}. {RIGHTS}</p>
    </Card>
  </div>;
}
