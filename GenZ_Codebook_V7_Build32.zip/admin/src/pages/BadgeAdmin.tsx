import React,{useState} from 'react';
import {collection,getDocs,limit,query,where} from 'firebase/firestore/lite';
import {db,errorMessage} from '../firebase';
import {sparkAdmin} from '../lib/sparkAdmin';
import {Card,Notice} from '../ui';

/** Find a user's Firebase ID from an email address (directory, PII roles) or accept an ID as-is. */
export async function resolveUser(raw:string):Promise<{uid:string;label:string}>{
  const v=raw.trim();
  if(!v)throw new Error('Enter the user’s email address or Firebase user ID.');
  if(v.includes('@')){
    const snap=await getDocs(query(collection(db,'directory'),where('email','==',v.toLowerCase()),limit(2)));
    if(snap.empty)throw new Error(`No account uses ${v}. The user must sign in to the app once with that email.`);
    return {uid:snap.docs[0]!.id,label:v};
  }
  if(!/^[A-Za-z0-9_-]{6,128}$/.test(v))throw new Error('Enter an email address or a Firebase user ID.');
  return {uid:v,label:v};
}

/** Blue = verified user. Gold = owner / authorised staff (Super Admin only; enforced by security rules). */
export default function BadgeAdmin(){
  const [who,setWho]=useState(''),[tier,setTier]=useState<'blue'|'gold'>('blue');
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const act=async(verified:boolean)=>{
    setBusy(true);setError('');setNotice('');
    try{
      const {uid,label}=await resolveUser(who);
      const name=tier==='gold'?'Gold (owner/staff)':'Blue (verified user)';
      if(!window.confirm(verified?`Grant the ${name} badge to ${label}?\nUser ID: ${uid}`:`Remove the badge from ${label}?\nUser ID: ${uid}`))return;
      await sparkAdmin({action:'badge-admin',id:uid,verified,tier});
      setNotice(verified?`${name} badge granted to ${label}. It appears in the app within a few seconds.`:`Badge removed from ${label}.`);
    }catch(e){setError(e instanceof Error&&!('code' in e)?e.message:errorMessage(e));}
    finally{setBusy(false);}
  };
  return <Card title="Verified badges" subtitle="Blue for verified users. Gold for the owner and authorised staff. Recorded in the audit log.">
    <div className="row wrap">
      <label className="field grow">User email or ID<input value={who} onChange={e=>setWho(e.target.value)} placeholder="e.g. kbr.path@gmail.com" autoComplete="off"/></label>
      <label className="field">Badge<select value={tier} onChange={e=>setTier(e.target.value as 'blue'|'gold')}><option value="blue">Blue · verified user</option><option value="gold">Gold · owner / staff</option></select></label>
    </div>
    <div className="row wrap">
      <button className="btn primary" disabled={busy||!who.trim()} onClick={()=>void act(true)}>{busy?'Working…':'Grant badge'}</button>
      <button className="btn" disabled={busy||!who.trim()} onClick={()=>void act(false)}>Revoke badge</button>
    </div>
    {error&&<Notice kind="error">{error}</Notice>}{notice&&<Notice kind="ok">{notice}</Notice>}
  </Card>;
}
