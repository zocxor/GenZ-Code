/**
 * The bundled dictionary (library-index.json, ~4.9 MB, ~0.44 MB compressed) downloaded at most
 * once per portal session and shared by every page (Content, Daily Code, moderation). Firebase
 * Hosting revalidates it with an ETag, so a new download happens only after a deploy changes it.
 */
let cached: Promise<unknown> | null = null;
export function libraryFetch(): Promise<{ok: boolean; json: () => Promise<any>}> {
  cached ??= fetch('/admin/library-index.json').then(r => {
    if (!r.ok) throw new Error('The bundled dictionary could not be loaded.');
    return r.json();
  }).catch(e => {cached = null; throw e;});
  return cached.then(data => ({ok: true, json: async () => data}), () => ({ok: false, json: async () => []}));
}
