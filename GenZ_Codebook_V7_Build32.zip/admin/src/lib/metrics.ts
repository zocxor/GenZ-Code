/**
 * Dashboard metrics. Every number is computed from Firestore at request time:
 * count()/sum()/average() aggregation queries, or bounded samples that are labelled as such.
 * Definitions are shown next to each metric in the UI.
 */
import {collection, collectionGroup, query, where, getCount, getAggregate, sum, average, getDocs, orderBy, limit, Timestamp} from 'firebase/firestore/lite';
import {db} from '../firebase';
import {TOKENS} from '../../../shared/tokens';
import {resolveReferrerName} from './referralNames';

const DAY = 86400_000;
const LIVE = ['active', 'suspended'];

export * from './metricsPure';
import {retention, versionShare, topReferrers} from './metricsPure';

const ts = (ms: number) => Timestamp.fromMillis(ms);
const users = collection(db, 'users');
/**
 * The counts use one field each and run on automatic single-field indexes. The learning totals
 * (sum/average of five stats.* fields) need the composite index declared in
 * firebase/firestore.indexes.json; if it is missing or still building, the counts still load
 * and only the totals show as unavailable. Deleted-account tombstones keep only
 * {status, deletedAt, updatedAt}, so they never match the activity, sign-up or stats queries.
 */
export async function userMetrics(now = Date.now()) {
  const [total, suspended, dau, wau, mau, new7, new30, totals] = await Promise.all([
    getCount(query(users, where('status', 'in', LIVE))),
    getCount(query(users, where('status', '==', 'suspended'))),
    getCount(query(users, where('lastActiveAt', '>=', ts(now - DAY)))),
    getCount(query(users, where('lastActiveAt', '>=', ts(now - 7 * DAY)))),
    getCount(query(users, where('lastActiveAt', '>=', ts(now - 30 * DAY)))),
    getCount(query(users, where('createdAt', '>=', ts(now - 7 * DAY)))),
    getCount(query(users, where('createdAt', '>=', ts(now - 30 * DAY)))),
    getAggregate(users, {quizzes: sum('stats.quizzes'), saved: sum('stats.saved'), reviewed: sum('stats.reviewed'), levels: average('stats.levels'), streak: average('stats.streak')}).catch((e: unknown) => ({error: e})),
  ]);
  return {
    total: total.data().count, suspended: suspended.data().count, dau: dau.data().count, wau: wau.data().count, mau: mau.data().count,
    new7: new7.data().count, new30: new30.data().count,
    ...('error' in totals
      ? {quizzes: null, saved: null, reviewed: null, avgLevels: null, avgStreak: null, totalsError: totals.error as unknown}
      : {quizzes: totals.data().quizzes ?? 0, saved: totals.data().saved ?? 0, reviewed: totals.data().reviewed ?? 0,
         avgLevels: totals.data().levels ?? null, avgStreak: totals.data().streak ?? null, totalsError: null as unknown}),
  };
}
/** Users by day last active over the last 30 days (bounded sample of the
 * 2,000 most recently active accounts). This is NOT "daily active users per
 * day" — a user active on several days appears once, on their most recent
 * day. Label it exactly that way in the UI. */
export async function activityHistogram(now = Date.now()) {
  const snap = await getDocs(query(users, where('status', 'in', LIVE), orderBy('lastActiveAt', 'desc'), limit(2000)));
  const days: number[] = Array.from({length: 30}, () => 0);
  const labels: string[] = Array.from({length: 30}, (_, i) => {
    const d = new Date(now - (29 - i) * DAY);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  });
  for (const d of snap.docs) {
    const ms = d.data().lastActiveAt?.toMillis?.() ?? 0;
    if (!ms) continue;
    const idx = 29 - Math.floor((now - ms) / DAY);
    if (idx >= 0 && idx < 30) days[idx] = (days[idx] ?? 0) + 1;
  }
  return {sample: snap.size, days, labels};
}
/** Retention over users who signed up in the last 90 days (bounded sample of 2,000). */
export async function retentionMetrics(now = Date.now()) {
  const snap = await getDocs(query(users, where('status', 'in', LIVE), where('createdAt', '>=', ts(now - 90 * DAY)), orderBy('createdAt', 'desc'), limit(2000)));
  const cohort = snap.docs.map(d => ({createdAt: d.data().createdAt?.toMillis?.() ?? 0, lastActiveAt: d.data().lastActiveAt?.toMillis?.() ?? 0}));
  return {sample: cohort.length, rows: retention(cohort, now, [1, 7, 30])};
}
export async function versionMetrics() {
  const snap = await getDocs(query(users, where('status', '==', 'active'), orderBy('lastActiveAt', 'desc'), limit(500)));
  return {sample: snap.size, rows: versionShare(snap.docs.map(d => String(d.data().appVersion ?? '')))};
}
export async function contentMetrics() {
  const c = collection(db, 'content');
  const [draft, review, published, archived, live] = await Promise.all(['draft', 'in_review', 'published', 'archived'].map(s => getCount(query(c, where('status', '==', s)))).concat([getCount(query(collection(db, 'publishedContent'), where('status', '==', 'published')))]));
  return {draft: draft!.data().count, review: review!.data().count, published: published!.data().count, archived: archived!.data().count, live: live!.data().count};
}
export async function moderationMetrics() {
  const [pending, open, chatOpen, fbNew, fbAll, rating] = await Promise.all([
    getCount(query(collection(db, 'submissions'), where('status', '==', 'pending'))),
    getCount(query(collection(db, 'reports'), where('status', '==', 'open'))),
    getCount(query(collection(db, 'chatReports'), where('status', '==', 'open'))),
    getCount(query(collection(db, 'feedback'), where('status', '==', 'new'))),
    getCount(collection(db, 'feedback')),
    getAggregate(collection(db, 'feedback'), {avg: average('rating')}),
  ]);
  return {pending: pending.data().count, openReports: open.data().count, openChatReports: chatOpen.data().count, feedbackNew: fbNew.data().count, feedbackTotal: fbAll.data().count, avgRating: rating.data().avg ?? null};
}
export async function securityMetrics(now = Date.now()) {
  const snap = await getDocs(query(collection(db, 'securityEvents'), where('at', '>=', ts(now - 7 * DAY)), orderBy('at', 'desc'), limit(1000)));
  const byType = new Map<string, number>();
  for (const d of snap.docs) byType.set(d.data().type, (byType.get(d.data().type) ?? 0) + 1);
  return {total: snap.size, capped: snap.size === 1000, byType: [...byType.entries()].sort((a, b) => b[1] - a[1])};
}

/** Referral overview (bounded sample of the 1,000 most recent claims for the
 *  top-referrers table; the total is an exact count, not a sample).
 *  - total: completed referral sign-ups (one claim each).
 *  - tokensPaid: the sum of the 'referral' ledger entries across all users
 *    — the true payout. Each completed referral writes exactly two entries
 *    of exactly 100 tokens (the rules enforce amount == 100 and tie every
 *    entry to a claim). The ledger holds balances, so only PII roles may
 *    read it; other user-read roles get the provably-equal claims-derived
 *    figure (total x 2 x 100) instead — the total is computed, never
 *    hardcoded.
 *  - top: the 5 referrers with the most referrals, labelled by display name
 *    when the role can read the synced profile, otherwise by their public
 *    referral code — never an e-mail or a UID. */
const REFERRAL_SAMPLE = 1000;
export async function referralMetrics() {
  const claimsSnap = await getDocs(query(collection(db, 'referralClaims'), orderBy('createdAt', 'desc'), limit(REFERRAL_SAMPLE)));
  const claims = claimsSnap.docs.map(d => {
    const v = d.data() as {referrerUid?: unknown; code?: unknown; createdAt?: {toMillis?: () => number}};
    return {referrerUid: typeof v.referrerUid === 'string' ? v.referrerUid : '', code: typeof v.code === 'string' ? v.code : '', newUserUid: d.id, createdAtMs: v.createdAt?.toMillis?.() ?? 0};
  });
  const total = (await getCount(collection(db, 'referralClaims'))).data().count;
  let tokensPaid: number;
  let tokensDerived = false;
  try {
    const agg = await getAggregate(query(collectionGroup(db, 'tokenLedger'), where('type', '==', 'referral')), {total: sum('amount')});
    tokensPaid = agg.data().total ?? 0;
  } catch {
    tokensPaid = total * 2 * TOKENS.REFERRAL_REWARD;
    tokensDerived = true;
  }
  const top = await Promise.all(topReferrers(claims).map(async t => ({label: (await resolveReferrerName(t.referrerUid)) ?? (t.code ? `via ${t.code}` : '—'), count: t.count})));
  return {total, tokensPaid, tokensDerived, top, sample: claimsSnap.size, capped: claimsSnap.size === REFERRAL_SAMPLE};
}
