/**
 * GenZ Codebook Premium subscriptions (Google Play subscriptions).
 *
 * Two tiers. Prices are NOT in code: they live in Play Console (per-country
 * pricing) and the app shows Play's localized price at runtime. The token
 * grant per billing period and the base-plan IDs here are the single source
 * of truth — the backend (functions/src/index.ts) enforces the same table,
 * so a subscription can only grant the exact amount for its product.
 * Product IDs and base-plan IDs must match Play Console exactly.
 *
 * Benefits of an active Premium subscription:
 *  - No interstitial ads while Premium is active (rewarded ads stay —
 *    they are opt-in earning, not an interruption). Banner ads were
 *    removed from the app under the token-based model and were not restored.
 *  - A token grant at the start of every billing period (purchase + each
 *    renewal), credited only after server-side verification.
 *
 * A subscription is "active" (premium) while the backend-recorded state is
 * ACTIVE, CANCELED (keeps access until the paid period ends) or
 * IN_GRACE_PERIOD and the expiry time is in the future. On-hold, paused,
 * expired and pending-canceled subscriptions are not premium. The backend
 * (verifySubscription + the RTDN handler) is the only writer of the
 * subscription document; the client only reads it.
 */

export const SUBSCRIPTION_PRODUCTS = [
  {
    id: 'premium_monthly',
    basePlanId: 'monthly',
    tokensPerPeriod: 10000,
    periodLabel: 'per month',
    /** Planned US price for the Play Console base plan (display only; Play's localized price wins). */
    price: '$4.99',
  },
  {
    id: 'premium_yearly',
    basePlanId: 'yearly',
    tokensPerPeriod: 200000,
    periodLabel: 'per year',
    price: '$39.99',
  },
] as const;

export type SubscriptionProductId = (typeof SUBSCRIPTION_PRODUCTS)[number]['id'];

export function subscriptionForProduct(productId: string): (typeof SUBSCRIPTION_PRODUCTS)[number] | null {
  const found = SUBSCRIPTION_PRODUCTS.find(p => p.id === productId);
  return found ?? null;
}

export function isSubscriptionProduct(productId: string): boolean {
  return SUBSCRIPTION_PRODUCTS.some(p => p.id === productId);
}

/**
 * Subscription states from the Play Developer API (subscriptionsv2).
 * Only ACTIVE and IN_GRACE_PERIOD count as premium (while unexpired).
 */
export type SubscriptionState =
  | 'SUBSCRIPTION_STATE_ACTIVE'
  | 'SUBSCRIPTION_STATE_CANCELED'
  | 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'
  | 'SUBSCRIPTION_STATE_ON_HOLD'
  | 'SUBSCRIPTION_STATE_PAUSED'
  | 'SUBSCRIPTION_STATE_EXPIRED'
  | 'SUBSCRIPTION_STATE_PENDING'
  | 'SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED'
  | 'SUBSCRIPTION_STATE_UNSPECIFIED';

export type SubscriptionDoc = {
  productId: string;
  basePlanId: string;
  purchaseToken: string;
  state: SubscriptionState;
  /** ISO-8601 expiry of the current billing period (from Play). */
  expiryTime: string;
  autoRenewing: boolean;
  acknowledged: boolean;
  /** Order ID of the latest successful order (drives the token grant). */
  lastOrderId: string;
  /** Order ID the period token grant was already given for (idempotency). */
  lastTokenGrantOrderId: string;
  updatedAt: unknown;
};

/** Premium is active while the state is ACTIVE, CANCELED (keeps access until expiry) or IN_GRACE_PERIOD and the period has not ended. */
export function isPremiumActive(sub: SubscriptionDoc | null, nowMs: number = Date.now()): boolean {
  if (!sub) return false;
  if (
    sub.state !== 'SUBSCRIPTION_STATE_ACTIVE' &&
    sub.state !== 'SUBSCRIPTION_STATE_CANCELED' &&
    sub.state !== 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'
  ) return false;
  const expiryMs = Date.parse(sub.expiryTime);
  if (Number.isNaN(expiryMs)) return false;
  return expiryMs > nowMs;
}
