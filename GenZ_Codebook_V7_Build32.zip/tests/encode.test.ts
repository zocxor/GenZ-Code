import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encode} from '../src/encode';
import {decode} from '../src/engine';
import {applyOverlay, bundledTerms, type Term} from '../src/content';

test('hello, how are you? keeps punctuation and encodes the phrase', () => {
  const r = encode('Hello, how are you?');
  assert.match(r.output, /, hru\?$/);
});
test('common phrases become their well-known codes, case-insensitively', () => {
  assert.equal(encode('BE RIGHT BACK').output, 'BRB');
  assert.equal(encode("to be honest I don't know").output, 'tbh idk');
  assert.equal(encode('what are you doing right now').output, 'wyd rn');
});
test('every word with a sensible code converts; the rest stays exactly as typed', () => {
  const r = encode('When will you come back to me ?');
  assert.ok(r.output.includes(' u '), r.output);
  assert.ok(r.output.endsWith(' ?'), 'spacing and punctuation preserved');
  assert.ok(r.replaced >= 1);
});
test('leetspeak and emoji are never chosen or offered for ordinary words', () => {
  const seg = encode('you').segments.find(s => s.code)!;
  assert.equal(seg.code, 'u');
  assert.ok(!seg.options!.some(o => /\d/.test(o)), JSON.stringify(seg.options));
});
test('community dictionary words (e.g. HOD = Headach) are used', () => {
  const hod: Term = {...bundledTerms[0]!, id: 'community-hod', expression: 'HOD', full: 'Headach', meaning: 'Headach', status: 'Community', priority: 110, decode: true, category: 'Chat', categories: ['Chat'], language: 'English', sensitivity: 'None', aliases: [], decoderAliases: []};
  applyOverlay([hod], []);
  try {assert.match(encode('I have a headach').output, /^I \w+ a HOD$/);}
  finally {applyOverlay([], []);}
});
test('phrases never join across punctuation', () => {
  assert.ok(!encode('be right, back').output.includes('brb'));
});
test('alternatives are offered and a chosen alternative is used', () => {
  const seg = encode('thank you').segments.find(s => s.code)!;
  assert.ok(seg.options!.length > 1, 'has alternatives');
  const other = seg.options!.find(o => o !== seg.code)!;
  assert.equal(encode('thank you', {[seg.phrase!]: other}).output, other);
});
test('encoded output decodes back', () => {
  assert.ok(decode(encode('be right back, to be honest').output).recognized >= 2);
});
test('long input is rejected like the decoder', () => {
  assert.throws(() => encode('x'.repeat(2001)), RangeError);
});
