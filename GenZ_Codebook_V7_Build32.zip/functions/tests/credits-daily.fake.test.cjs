// Runs the real compiled backend (lib/communityFeatures.js) against an in-memory Firestore.
// Covers the V7 critical paths: admin grants/deductions, spending, Daily Code approval and scheduling.
// Run: npm run build && node --test tests/credits-daily.fake.test.cjs
const {test} = require('node:test');
const assert = require('node:assert/strict');
const {createDb} = require('./fake-firestore.cjs');
const {communityAction, runDailySchedule} = require('../lib/communityFeatures');

const NOW = Date.UTC(2026, 10, 12, 12);
const owner = {uid: 'owner', token: {email_verified: true}};
const user = {uid: 'kbr', token: {email_verified: true}};
function setup() {
  const db = createDb(() => NOW);
  db.store.set('admins/owner', {active: true, role: 'super_admin'});
  db.store.set('admins/mod', {active: true, role: 'moderator'});
  for (const uid of ['owner', 'kbr', 'mod']) {db.store.set('users/' + uid, {status: 'active'}); db.store.set(`users/${uid}/sync/profile`, {profile: {name: uid.toUpperCase()}});}
  db.store.set('communityWords/hdot', {status: 'live', term: 'HDOT', meaning: 'Hot day out today', category: 'Chat'});
  db.store.set('communityWords/hod', {status: 'live', term: 'HOD', meaning: 'Headache of the day', category: 'Code Word'});
  const run = (who, action, data = {}, at = NOW) => communityAction(db, {action, ...data}, who, at);
  return {db, run, balance: async who => (await run(who, 'balance')).balance};
}
const code = c => e => e.code === c;

test('admin grants 500 Credits once; the user can see and spend them', async () => {
  const {run, balance} = setup();
  assert.equal((await run(owner, 'grant-tokens', {uid: 'kbr', amount: 500, note: 'Launch tester', requestId: 'g1'})).balance, 500);
  assert.equal(await balance(user), 500);
  assert.equal((await run(owner, 'grant-tokens', {uid: 'kbr', amount: 500, note: 'Launch tester', requestId: 'g1'})).duplicate, true, 'same request is not credited twice');
  assert.equal(await balance(user), 500);
});
test('only an active Super Admin can grant; errors say why', async () => {
  const {run} = setup();
  await assert.rejects(run({uid: 'mod', token: {email_verified: true}}, 'grant-tokens', {uid: 'kbr', amount: 10, requestId: 'x'}), e => e.code === 'permission-denied' && /super_admin/.test(e.message));
  await assert.rejects(run(user, 'grant-tokens', {uid: 'kbr', amount: 10, requestId: 'x'}), code('permission-denied'));
  await assert.rejects(run({uid: 'owner', token: {email_verified: false}}, 'grant-tokens', {uid: 'kbr', amount: 10, requestId: 'x'}), code('permission-denied'));
});
test('admin deduction lowers the verified balance, never below zero, idempotently', async () => {
  const {run, balance} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 300, requestId: 'g'});
  await run(owner, 'deduct-tokens', {uid: 'kbr', amount: 120, note: 'Duplicate grant reversal', requestId: 'd1'});
  await run(owner, 'deduct-tokens', {uid: 'kbr', amount: 120, note: 'Duplicate grant reversal', requestId: 'd1'});
  assert.equal(await balance(user), 180);
  await assert.rejects(run(owner, 'deduct-tokens', {uid: 'kbr', amount: 181, note: 'too much', requestId: 'd2'}), code('failed-precondition'));
  await assert.rejects(run(user, 'deduct-tokens', {uid: 'kbr', amount: 1, note: 'x', requestId: 'd3'}), code('permission-denied'));
});
test('Daily Code request costs 250 admin-granted Credits; Approve & schedule confirms the date in one step', async () => {
  const {db, run, balance} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 500, requestId: 'g'});
  const app = await run(user, 'apply-daily', {wordId: 'hdot', wordSource: 'community', date: '2026-11-14', requestId: 'r1'});
  assert.equal(app.balance, 250); assert.equal(await balance(user), 250);
  assert.equal(db.store.get('dailyCodeDates/2026-11-14').status, 'pending');
  await assert.rejects(run(user, 'apply-daily', {wordId: 'hod', wordSource: 'community', date: '2026-11-14', requestId: 'r2'}), code('already-exists'), 'a reserved date cannot be booked twice');
  await run(owner, 'daily-admin', {command: 'approve', id: app.id, date: '2026-11-15'});
  const a = db.store.get('dailyCodeApplications/' + app.id);
  assert.equal(a.status, 'scheduled'); assert.equal(a.publicationDate, '2026-11-15');
  assert.equal(db.store.has('dailyCodeDates/2026-11-14'), false, 'old reservation released');
  assert.equal(db.store.get('dailyCodeDates/2026-11-15').applicationId, app.id);
});
test('an approved request is published on its date', async () => {
  const {db, run} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 500, requestId: 'g'});
  const app = await run(user, 'apply-daily', {wordId: 'hdot', wordSource: 'community', date: '2026-11-13', requestId: 'r1'});
  await run(owner, 'daily-admin', {command: 'approve', id: app.id, date: '2026-11-13'});
  await runDailySchedule(db, Date.UTC(2026, 10, 13, 0, 5));
  assert.equal(db.store.get('dailyCodePublic/2026-11-13').term, 'HDOT');
  assert.equal(db.store.get('dailyCodeApplications/' + app.id).status, 'published');
});
test('an unapproved request is never published; the automatic word is used instead and the user refunded', async () => {
  const {db, run, balance} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 500, requestId: 'g'});
  const app = await run(user, 'apply-daily', {wordId: 'hdot', wordSource: 'community', date: '2026-11-13', requestId: 'r1'});
  await runDailySchedule(db, Date.UTC(2026, 10, 13, 0, 5));
  const pub = db.store.get('dailyCodePublic/2026-11-13');
  assert.ok(pub && pub.term, 'an automatic Daily Code is published'); assert.notEqual(pub.term, 'HDOT');
  assert.equal(db.store.get('dailyCodeApplications/' + app.id).status, 'rejected');
  assert.equal(await balance(user), 500, 'refunded');
});
test('admin-scheduled word: edit is published on its date; replace refunds; delete works', async () => {
  const {db, run, balance} = setup();
  await run(owner, 'daily-admin', {command: 'schedule-word', date: '2026-11-13', wordId: 'hdot', wordSource: 'community'});
  await run(owner, 'daily-admin', {command: 'edit-schedule', date: '2026-11-13', term: 'HDOT', meaning: 'Edited by admin', category: 'Chat'});
  await runDailySchedule(db, Date.UTC(2026, 10, 13, 0, 5));
  assert.equal(db.store.get('dailyCodePublic/2026-11-13').meaning, 'Edited by admin');
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 500, requestId: 'g'});
  const app = await run(user, 'apply-daily', {wordId: 'hdot', wordSource: 'community', date: '2026-11-20', requestId: 'r9'});
  await run(owner, 'daily-admin', {command: 'approve', id: app.id, date: '2026-11-20'});
  assert.equal(await balance(user), 250);
  await run(owner, 'daily-admin', {command: 'replace-schedule', date: '2026-11-20', wordId: 'hod', wordSource: 'community'});
  assert.equal(db.store.get('dailyCodeDates/2026-11-20').term, 'HOD');
  assert.equal(db.store.get('dailyCodeApplications/' + app.id).status, 'rejected');
  assert.equal(await balance(user), 500, 'refunded');
  await run(owner, 'daily-admin', {command: 'cancel-schedule', date: '2026-11-20'});
  assert.equal(db.store.has('dailyCodeDates/2026-11-20'), false);
  await assert.rejects(run(user, 'daily-admin', {command: 'cancel-schedule', date: '2026-11-21'}), code('permission-denied'));
});
test('chat day pass is charged once per UTC day', async () => {
  const {run, balance} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 100, requestId: 'g'});
  await run(user, 'chat-pass');
  assert.equal((await run(user, 'chat-pass')).duplicate, true);
  assert.equal(await balance(user), 70);
  assert.equal((await run(user, 'chat-pass-status')).active, true);
  await run(user, 'chat-pass', {}, NOW + 86_400_000);
  assert.equal(await balance(user), 40, 'a new day needs a new pass');
});
test('posting costs 50 Credits and is refused without enough Credits', async () => {
  const {run, balance} = setup();
  await assert.rejects(run(user, 'create-post', {term: 'rizzler', meaning: 'Someone with charm', category: 'Slang', example: '', requestId: 'p0'}), code('failed-precondition'));
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 60, requestId: 'g'});
  await run(user, 'create-post', {term: 'rizzler', meaning: 'Someone with charm', category: 'Slang', example: '', requestId: 'p1'});
  assert.equal(await balance(user), 10);
});

test('extra Encode/Decode conversions charge the admin price once per request; 0 means free', async () => {
  const {db, run, balance} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 20, requestId: 'g'});
  const a = await run(user, 'convert-fee', {kind: 'encode', requestId: 'c1'});
  assert.equal(a.balance, 15, 'default price is 5');
  assert.equal((await run(user, 'convert-fee', {kind: 'encode', requestId: 'c1'})).duplicate, true, 'same request is not charged twice');
  db.store.set('config/app', {prices: {decode: 3, encode: 0}});
  await run(user, 'convert-fee', {kind: 'decode', requestId: 'c2'});
  assert.equal(await balance(user), 12, 'admin-set decode price 3');
  assert.equal((await run(user, 'convert-fee', {kind: 'encode', requestId: 'c3'})).free, true, 'encode price 0 = free');
  assert.equal(await balance(user), 12);
  await assert.rejects(run(user, 'convert-fee', {kind: 'translate', requestId: 'c4'}), code('invalid-argument'));
  db.store.set('config/app', {prices: {decode: 50}});
  await assert.rejects(run(user, 'convert-fee', {kind: 'decode', requestId: 'c5'}), code('failed-precondition'), 'not enough Credits');
});
test('admin-set prices are charged, and refunds return what was actually paid', async () => {
  const {db, run, balance} = setup();
  await run(owner, 'grant-tokens', {uid: 'kbr', amount: 1000, requestId: 'g'});
  db.store.set('config/app', {prices: {post: 70, dailyCode: 300, chatDay: 25}});
  await run(user, 'create-post', {term: 'zelvaprice', meaning: 'A pricing test expression.', category: 'Slang', example: '', requestId: 'p1'});
  assert.equal(await balance(user), 930);
  await run(user, 'chat-pass');
  assert.equal(await balance(user), 905);
  const app = await run(user, 'apply-daily', {wordId: 'hdot', wordSource: 'community', date: '2026-11-20', requestId: 'd1'});
  assert.equal(await balance(user), 605);
  db.store.set('config/app', {prices: {dailyCode: 100}});   // price lowered after the user paid 300
  await run(owner, 'daily-admin', {command: 'reject', id: app.id, reason: 'Test'});
  assert.equal(await balance(user), 905, 'refund equals the 300 actually paid');
});
