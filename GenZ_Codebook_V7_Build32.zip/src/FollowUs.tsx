/**
 * Follow Us / Stay connected: official social channels and Help & Support email.
 * Only the fixed https URLs in shared/brand.ts are opened (no user- or server-supplied
 * links), in the system browser or the installed app. If nothing can open a link, it is
 * copied instead so the user is never stuck. No rewards are offered for following
 * (Google Play: no incentivised social actions).
 */
import React,{useState} from 'react';
import {Linking,Pressable,StyleSheet,Text,View} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {LinearGradient} from 'expo-linear-gradient';
import {C,Icon,type IconName} from './ui';
import {SOCIAL_LINKS,SUPPORT_EMAIL,supportMailto} from '../shared/brand';

const LOOK:Record<string,{icon:IconName;colors:[string,string]}>={
  instagram:{icon:'logo-instagram',colors:['#F58529','#DD2A7B']},
  facebook:{icon:'logo-facebook',colors:['#1877F2','#0B5FD0']},
  whatsapp:{icon:'logo-whatsapp',colors:['#25D366','#128C7E']},
  email:{icon:'mail',colors:['#4D7BFF','#6D28D9']},
};
const allowed=new Set<string>([...SOCIAL_LINKS.map(l=>l.url)]);

async function openLink(url:string,fallback:string,setNote:(m:string)=>void){
  setNote('');
  if(!allowed.has(url)&&!url.startsWith(`mailto:${SUPPORT_EMAIL}`))return;
  try{await Linking.openURL(url);}
  catch{await Clipboard.setStringAsync(fallback).catch(()=>{});setNote(`Couldn’t open it on this device, so ${fallback} was copied.`);}
}
/** Compact horizontal "Follow us" icons for the main profile page. */
export function FollowUsRow(){
  const [note,setNote]=useState('');
  const items=[...SOCIAL_LINKS.map(l=>({id:l.id as string,label:l.id==='whatsapp'?'WhatsApp':l.label,url:l.url as string,fallback:l.url as string})),{id:'email',label:'Email us',url:supportMailto('GenZ Codebook – help request'),fallback:SUPPORT_EMAIL}];
  return <View style={s.rowCard}>
    <Text accessibilityRole="header" style={s.rowTitle}>Follow us</Text>
    <View style={s.iconRow}>{items.map(i=>{const look=LOOK[i.id]!;return <Pressable key={i.id} accessibilityRole="link" accessibilityLabel={`${i.label}. Opens outside the app.`} hitSlop={4} onPress={()=>void openLink(i.url,i.fallback,setNote)} style={({pressed})=>[s.iconItem,pressed&&{opacity:.8,transform:[{scale:.95}]}]}>
      <LinearGradient colors={look.colors} start={{x:0,y:0}} end={{x:1,y:1}} style={s.circle}><Icon name={look.icon} size={22} color="#fff"/></LinearGradient>
      <Text style={s.iconLabel} numberOfLines={1}>{i.label}</Text>
    </Pressable>;})}</View>
    {!!note&&<Text accessibilityRole="alert" style={s.sub}>{note}</Text>}
  </View>;
}

export default function FollowUs(){
  const [note,setNote]=useState('');
  const open=(url:string,fallback:string)=>openLink(url,fallback,setNote);
  const rows=[...SOCIAL_LINKS.map(l=>({id:l.id,label:l.label,sub:l.handle,url:l.url as string,fallback:l.url as string})),
    {id:'email',label:'Help & Support',sub:SUPPORT_EMAIL,url:supportMailto('GenZ Codebook – help request'),fallback:SUPPORT_EMAIL}];
  return <View style={s.card}>
    <Text accessibilityRole="header" style={s.title}>Stay connected</Text>
    <Text style={s.sub}>New codes, Daily Code picks and updates.</Text>
    <View style={s.grid}>{rows.map(r=>{const look=LOOK[r.id]!;return <Pressable key={r.id} accessibilityRole="link" accessibilityLabel={`${r.label}, ${r.sub}. Opens outside the app.`} onPress={()=>void open(r.url,r.fallback)} style={({pressed})=>[s.item,pressed&&{opacity:.8,transform:[{scale:.98}]}]}>
      <LinearGradient colors={look.colors} start={{x:0,y:0}} end={{x:1,y:1}} style={s.icon}><Icon name={look.icon} size={20} color="#fff"/></LinearGradient>
      <View style={{flex:1,minWidth:0}}><Text style={s.label} numberOfLines={1}>{r.label}</Text><Text style={s.handle} numberOfLines={1}>{r.sub}</Text></View>
      <Icon name="open-outline" size={15} color={C.muted}/>
    </Pressable>;})}</View>
    {!!note&&<Text accessibilityRole="alert" style={s.sub}>{note}</Text>}
  </View>;
}
const s=StyleSheet.create({
  card:{backgroundColor:'#fff',borderRadius:20,padding:14,gap:8,borderWidth:1,borderColor:'#E2E8F5'},
  title:{fontSize:17,fontWeight:'900',color:C.ink},sub:{fontSize:13,color:C.muted,lineHeight:18},
  grid:{gap:8,marginTop:2},item:{flexDirection:'row',alignItems:'center',gap:10,minHeight:52,paddingHorizontal:10,borderRadius:14,backgroundColor:'#F5F7FE'},
  icon:{width:36,height:36,borderRadius:11,alignItems:'center',justifyContent:'center'},
  label:{fontSize:14.5,fontWeight:'800',color:C.ink},handle:{fontSize:12,color:C.muted},
  rowCard:{backgroundColor:'#fff',borderRadius:20,paddingVertical:12,paddingHorizontal:10,gap:8,borderWidth:1,borderColor:'#E2E8F5'},rowTitle:{fontSize:15,fontWeight:'900',color:C.ink,paddingHorizontal:4},
  iconRow:{flexDirection:'row',justifyContent:'space-around'},iconItem:{alignItems:'center',gap:5,minWidth:64},circle:{width:48,height:48,borderRadius:24,alignItems:'center',justifyContent:'center'},iconLabel:{fontSize:11.5,fontWeight:'700',color:C.ink},
});
