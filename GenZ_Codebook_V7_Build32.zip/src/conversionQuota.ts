/** Pure Encode/Decode allowance helpers (no React Native imports, unit-tested). */
import {localDay} from './discovery';

export type ConvKind = 'encode' | 'decode';
export type ConvState = {day: string; used: Record<ConvKind, number>; bonus: Record<ConvKind, number>};
export const AD_BONUS = 5;
export const fresh = (day = localDay()): ConvState => ({day, used: {encode: 0, decode: 0}, bonus: {encode: 0, decode: 0}});
export const today = (s: ConvState, day = localDay()) => s.day === day ? s : fresh(day);
export const remaining = (s: ConvState, kind: ConvKind, freeDaily: number, day = localDay()) => {const t = today(s, day); return Math.max(0, freeDaily + t.bonus[kind] - t.used[kind]);};
export const spendFree = (s: ConvState, kind: ConvKind, day = localDay()): ConvState => {const t = today(s, day); return {...t, used: {...t.used, [kind]: t.used[kind] + 1}};};
export const addBonus = (s: ConvState, kind: ConvKind, day = localDay()): ConvState => {const t = today(s, day); return {...t, bonus: {...t.bonus, [kind]: t.bonus[kind] + AD_BONUS}};};

