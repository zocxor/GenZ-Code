import React,{useState} from 'react';
import {Pressable,Text,View} from 'react-native';
import {useAccountUser} from './services';
import {useEligibleBalance} from './ContributionScreens';
import {feature,errorOf} from './communityFeatures';
import {BACKEND_URL} from './backend';
import {C,Glass,Icon,Button} from './ui';

export default function AccountTokens({compact=false,onOpen}:{compact?:boolean;onOpen?:()=>void}){
  const user=useAccountUser(),credit=useEligibleBalance(BACKEND_URL?user?.uid:undefined);
  const [busy,setBusy]=useState(false),[note,setNote]=useState('');
  if(!BACKEND_URL||!user)return null;
  if(compact)return <Pressable accessibilityRole="button" accessibilityLabel={'Credits '+(credit.balance??'unavailable')+'. Open wallet.'} onPress={onOpen} style={{minHeight:44,paddingHorizontal:9,borderRadius:15,backgroundColor:'#FFE39A',flexDirection:'row',alignItems:'center',gap:4}}><Icon name="star" color="#785100" size={16}/><Text style={{fontWeight:'900',color:'#593D00',fontSize:13}}>{credit.balance===null?'—':credit.balance.toLocaleString()}</Text></Pressable>;
  const collect=async()=>{if(busy)return;setBusy(true);setNote('');try{const r=await feature('daily-reward');setNote(r.duplicate?'Today’s account reward is already collected.':'+5 Credits collected.');credit.reload();}catch(e){setNote(errorOf(e));}finally{setBusy(false);}};
  return <Glass><View style={{flexDirection:'row',alignItems:'center',gap:6}}><Icon name="wallet-outline" color={C.accent}/><Text style={{fontSize:18,fontWeight:'800',color:C.navy}}>Credits: {credit.balance===null?'—':credit.balance.toLocaleString()}</Text></View><Text style={{color:C.muted}}>For Daily Code promotion and optional badge review. Learning points are separate and keep games available offline.</Text>{credit.error&&<><Text accessibilityRole="alert" style={{color:C.muted}}>{credit.error}</Text><Button light title="Retry account balance" onPress={credit.reload}/></>}<Button light title={busy?'Collecting…':'Daily account reward · +5 Credits'} disabled={busy} onPress={()=>void collect()}/>{!!note&&<Text accessibilityLiveRegion="polite" style={{color:C.muted}}>{note}</Text>}</Glass>;
}
