import React,{useRef,useState} from 'react';
import {Platform,Pressable,Share,StyleSheet,Text,TextInput,View} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {Button,C,Glass,Icon,IconTile,confirmAction,type IconName} from './ui';
import {encode,type EncodeResult} from './encode';
import {useConversion,AD_BONUS} from './conversions';

const askToPay=(cost:number)=>new Promise<boolean>(resolve=>confirmAction('Encode for Credits?',`You’ve used today’s free encodes. This conversion costs ${cost} Credits. Credits are charged only after the conversion succeeds.`,()=>resolve(true),`Pay ${cost} Credits`,()=>resolve(false)));

/** Encode Message – Convert your words into Gen Z codes (Home). */
export default function EncodePanel({onDecode}:{onDecode:(text:string)=>void}){
  const conv=useConversion('encode');
  const [text,setText]=useState(''),[result,setResult]=useState<EncodeResult|null>(null),[choices,setChoices]=useState<Record<string,string>>({});
  const [note,setNote]=useState(''),[busy,setBusy]=useState(false),[needsAd,setNeedsAd]=useState(false);
  const input=useRef<TextInput>(null);
  const run=async()=>{
    if(busy)return;
    setNote('');setNeedsAd(false);
    if(!text.trim()){setNote('Type a message to encode.');return;}
    const r=encode(text,choices);
    if(r.replaced===0){setResult(null);setNote('No dictionary codes matched this message yet. Try everyday words and phrases like “be right back”, “thank you” or “to be honest”.');return;}
    setBusy(true);
    try{
      const paid=await conv.spend(true,askToPay);
      if(!paid.ok){setNote(paid.message);setNeedsAd(!!paid.needsAd);return;}
      setResult(r);
      if(paid.paid)setNote(`${paid.paid} Credits used.`);
    }finally{setBusy(false);}
  };
  const cycle=(phrase:string,options:string[],current:string)=>{
    if(options.length<2)return;
    const next={...choices,[phrase]:options[(options.indexOf(current)+1)%options.length]!};
    setChoices(next);setResult(encode(text,next));   // switching alternatives is free
  };
  const copy=async()=>{if(result){await Clipboard.setStringAsync(result.output);setNote('Copied.');}};
  const share=async()=>{if(!result)return;if(Platform.OS==='web'){await copy();}else await Share.share({message:result.output});};
  const unlock=async()=>{if(busy)return;setBusy(true);try{setNote(await conv.watchForBonus());setNeedsAd(false);}finally{setBusy(false);}};
  return <Glass>
    <View style={s.row}><IconTile icon="code-slash-outline" from="#8B3FE0" to="#4B3BDB" size={44} iconSize={22}/><View style={{flex:1}}><Text style={s.title}>Encode Message</Text><Text style={s.sub}>Convert your words into Gen Z codes</Text></View></View>
    <TextInput ref={input} accessibilityLabel="Message to encode" multiline maxLength={2000} value={text} onChangeText={v=>{setText(v);setResult(null);setChoices({});setNote('');}} placeholder="e.g. Hello, how are you? Be right back" placeholderTextColor={C.muted} style={s.input} textAlignVertical="top"/>
    <Text style={s.cost} accessibilityLiveRegion="polite">{conv.label}</Text>
    <Button title={busy?'Working…':conv.left>0||conv.cost===0?'Encode message':`Encode · ${conv.cost} Credits`} icon="sparkles" disabled={busy} onPress={()=>void run()}/>
    {needsAd&&<Button light title={`Watch an optional ad · +${AD_BONUS} free encodes`} icon="play-circle-outline" disabled={busy} onPress={()=>void unlock()}/>}
    {!!note&&<Text accessibilityRole="alert" style={s.sub}>{note}</Text>}
    {result&&<View style={s.resultCard}>
      <View style={s.resultHead}>
        <Text style={s.resultLabel}>Your Gen Z message</Text>
        <Pressable accessibilityRole="button" accessibilityLabel="Copy the coded message" hitSlop={8} onPress={()=>void copy()} style={s.iconBtn}><Icon name="copy-outline" size={18} color="#4C1D95"/></Pressable>
        <Pressable accessibilityRole="button" accessibilityLabel="Share the coded message" hitSlop={8} onPress={()=>void share()} style={s.iconBtn}><Icon name="share-social-outline" size={18} color="#4C1D95"/></Pressable>
      </View>
      <Text selectable style={s.outputText}>{result.segments.map((x,i)=>x.code
        ?<Text key={i} accessibilityRole="button" accessibilityLabel={`${x.text} encoded as ${x.code}${x.options!.length>1?'. Tap for another option.':''}`} onPress={()=>cycle(x.phrase!,x.options!,x.code!)} style={s.code}>{x.code}</Text>
        :<Text key={i}>{x.text}</Text>)}</Text>
      <Text style={s.meta}>{result.replaced} code{result.replaced===1?'':'s'} used · the other words stay as typed{result.segments.some(x=>(x.options?.length??0)>1)?' · tap a highlighted code to switch it':''}</Text>
    </View>}
    {result&&<View style={s.wrap}>
      <Action icon="create-outline" label="Edit message" onPress={()=>input.current?.focus()}/>
      <Action icon="scan-outline" label="Decode it" onPress={()=>onDecode(result.output)}/>
    </View>}
  </Glass>;
}
function Action({icon,label,onPress}:{icon:IconName;label:string;onPress:()=>void}){
  return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({pressed})=>[s.action,pressed&&{opacity:.75}]}><Icon name={icon} size={16} color={C.ink}/><Text style={s.actionText}>{label}</Text></Pressable>;
}
const s=StyleSheet.create({
  row:{flexDirection:'row',alignItems:'center',gap:10},title:{fontSize:17,fontWeight:'900',color:C.ink},sub:{fontSize:13,lineHeight:18,color:C.muted},
  input:{minHeight:84,borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,fontSize:16,color:C.ink,backgroundColor:'#fff'},
  cost:{fontSize:12.5,fontWeight:'800',color:'#6D28D9'},
  resultCard:{borderRadius:16,padding:14,gap:8,backgroundColor:'#F5F0FF',borderWidth:1,borderColor:'#DDD0FF'},
  resultHead:{flexDirection:'row',alignItems:'center',gap:6},resultLabel:{flex:1,fontSize:12.5,fontWeight:'900',color:'#5B21B6'},
  iconBtn:{width:36,height:36,borderRadius:12,backgroundColor:'#fff',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#E4D9FF'},
  outputText:{fontSize:19,fontWeight:'700',color:'#1E1B4B',lineHeight:28},
  code:{fontWeight:'900',color:'#6D28D9',backgroundColor:'#E9DDFF'},
  meta:{fontSize:12,color:'#6B5B95'},
  wrap:{flexDirection:'row',flexWrap:'wrap',gap:6},
  action:{flexDirection:'row',alignItems:'center',gap:5,minHeight:36,paddingHorizontal:11,borderRadius:18,backgroundColor:'#E3EAFB'},actionText:{fontWeight:'800',fontSize:12.5,color:C.ink},
});
