/**
 * Community chat room: one shared room for every signed-in user, by nickname.
 *
 * Free-tier design (Spark plan, no paid services): messages live in Firestore
 * (`communityMessages`), read through one realtime listener capped at the newest
 * 50 messages. Each room open costs at most 50 reads, then one read per new
 * message — well inside the free 50,000 reads/day for a small community.
 * Writes are one message + one rate-limit stamp, at most one message per user
 * every 10 seconds (enforced server-side by the security rules).
 */
import {Platform} from 'react-native';
import type {User} from 'firebase/auth';
import {cleanText} from '../shared/contentSchema';
import {screenMessage, toChatMessage, CHAT_PAGE_SIZE, CHAT_RATE_LIMIT_SECONDS, type ChatMessage} from '../shared/chat';
import {APP_VERSION} from './secure/config';

export type ChatResult = {ok: true} | {ok: false; message: string; wait?: number};
const fail = (message: string, extra: Partial<Extract<ChatResult, {ok: false}>> = {}): ChatResult => ({ok: false, message, ...extra});

const libs = () => Promise.all([import('firebase/firestore/lite'), import('firebase/firestore'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

function errorText(e: unknown, CloudError: typeof import('./sync/engine').CloudError): string {
  if (e instanceof CloudError) {
    if (e.code === 'offline') return 'You’re offline. Connect to the internet and try again.';
    if (e.code === 'unauthenticated') return 'Your session expired. Sign in again, then try once more.';
    if (e.code === 'permission-denied') return 'The server didn’t accept that. If you just verified your e-mail, wait a minute and try again. (code: permission-denied)';
    if (e.code === 'server-setup') return 'The GenZ Codebook server isn’t set up yet: its security rules haven’t been published, so the database refuses every request. Publish the rules, then try again. (code: rules-missing)';
    return `Couldn’t send that right now. Please try again. (code: ${e.raw || e.code})`;
  }
  return 'Couldn’t send that right now. Please try again.';
}

/** Rules read the e-mail_verified claim from the ID token, so refresh it after verifying. */
async function emailVerified(user: User): Promise<boolean> {
  const {reload} = await import('firebase/auth');
  if (!user.emailVerified) {await reload(user); if (!user.emailVerified) return false;}
  if ((await user.getIdTokenResult()).claims.email_verified === true) return true;
  return (await user.getIdTokenResult(true)).claims.email_verified === true;
}

// The account/e-mail/chat-switch checks used to run one after another before every message
// (4 network round trips, ~2 s). They now run in parallel once, are reused for a few minutes,
// and the 10-second rate limit is tracked locally after the first read. The security rules
// still enforce every one of these checks on each write.
const READY_MS = 3 * 60_000;
let readyFor: {uid: string; at: number} | null = null;
const lastSent = new Map<string, number>();
const waitFrom = (last: number) => Math.max(0, Math.min(CHAT_RATE_LIMIT_SECONDS, Math.ceil((last + (CHAT_RATE_LIMIT_SECONDS + 1) * 1000 - Date.now()) / 1000)));

/** Signed-in, active, verified account with no recent chat message. Returns the user or a reason. */
async function prepareChat(): Promise<{user: User; wait: number} | ChatResult> {
  const [{doc, getDoc}, , {cloudDb, accountAuth}, {firestoreCloud}] = await libs();
  const user = accountAuth.currentUser;
  if (!user) return fail('Sign in to chat. It keeps the room accountable and lets us prevent spam.');
  const known = lastSent.get(user.uid);
  if (readyFor?.uid === user.uid && Date.now() - readyFor.at < READY_MS && known !== undefined) return {user, wait: waitFrom(known)};
  const db = cloudDb();
  const [status, verified, config, stamp] = await Promise.all([
    firestoreCloud.ensureAccount(user.uid, {appVersion: APP_VERSION, platform: Platform.OS}),
    emailVerified(user),
    getDoc(doc(db, 'config', 'app')).catch(() => null),
    getDoc(doc(db, 'users', user.uid, 'limits', 'chat')).catch(() => null),
  ]);
  if (status === 'suspended') return fail('Your account is restricted, so it can’t chat. Contact support if you think this is a mistake.');
  if (status === 'deleted') return fail('This account is being deleted.');
  if (!verified) return fail('Verify your e-mail to chat. Open the link we sent you, then try again.');
  if (config?.exists() && config.data().chatEnabled === false) return fail('The community chat is closed right now. Please try again later.');
  const last = stamp?.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
  lastSent.set(user.uid, Math.max(last, lastSent.get(user.uid) ?? 0));
  readyFor = {uid: user.uid, at: Date.now()};
  return {user, wait: waitFrom(lastSent.get(user.uid) ?? 0)};
}

/** Run the pre-checks while the room is open so the first message only needs the write. */
export function warmChat(): void {void prepareChat().catch(() => {});}

/** Send one message to the room. The screen filter runs first; the rules re-check everything. */
export async function sendChatMessage(name: string, text: string): Promise<ChatResult> {
  const screen = screenMessage(text);
  if (!screen.ok) return fail(screen.message);
  const cleanName = cleanText(name, 24).trim() || 'Code Explorer';
  const [{doc, writeBatch, serverTimestamp, collection}, , {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    const ready = await prepareChat();
    if ('ok' in ready) return ready;
    if (ready.wait > 0) return fail(`Please wait ${ready.wait} s before sending another message.`, {wait: ready.wait});
    const db = cloudDb(), batch = writeBatch(db);
    batch.set(doc(db, 'users', ready.user.uid, 'limits', 'chat'), {last: serverTimestamp()});
    batch.set(doc(collection(db, 'communityMessages')), {uid: ready.user.uid, name: cleanName, text: cleanText(text, 500).trim(), status: 'live', createdAt: serverTimestamp()});
    await batch.commit();
    lastSent.set(ready.user.uid, Date.now());
    return {ok: true};
  } catch (e) {readyFor = null; return fail(errorText(toCloudError(e), CloudError));}
}

/** Live messages, newest last. Subscribes only while the room is open; returns the unsubscribe function. */
export function subscribeChat(onMessages: (messages: ChatMessage[]) => void, onError: (message: string) => void): () => void {
  let stop = () => {};
  void libs().then(([, live, {cloudDbLive}]) => {
    const q = live.query(
      live.collection(cloudDbLive(), 'communityMessages'),
      live.where('status', '==', 'live'),
      live.orderBy('createdAt', 'desc'),
      live.limit(CHAT_PAGE_SIZE),
    );
    stop = live.onSnapshot(q, snap => {
      const messages = snap.docs
        .map(d => toChatMessage(d.id, d.data()))
        .filter((m): m is ChatMessage => m !== null)
        .sort((a, b) => (a.at - b.at) || (a.id < b.id ? -1 : 1));
      onMessages(messages);
    }, () => onError('Couldn’t load the chat. Check your connection and try again.'));
  }).catch(() => onError('Couldn’t load the chat. Check your connection and try again.'));
  return () => stop();
}

/** Delete one of your own messages. Moderators hide other people’s messages from the admin portal. */
export async function deleteOwnMessage(id: string): Promise<ChatResult> {
  const [{doc, deleteDoc}, , {cloudDb}, {toCloudError}, {CloudError}] = await libs();
  try {
    await deleteDoc(doc(cloudDb(), 'communityMessages', id));
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}
