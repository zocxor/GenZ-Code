/**
 * Credit prices, live. Defaults come from functions/src/communityPolicy.json; the owner can
 * change any price in the admin portal (config/app.prices) and the server charges the same
 * value, so what users see before confirming is what they pay.
 */
import rawPolicy from '../functions/src/communityPolicy.json';
import {getAppConfig} from './appConfig';
export const policy = {
  ...rawPolicy,
  get chatDailyFee() {return getAppConfig().fees.chat;},
  get postFee() {return getAppConfig().fees.post;},
  get dictionaryFee() {return getAppConfig().fees.code;},
  get dailyFee() {return getAppConfig().fees.daily;},
  get verificationFee() {return getAppConfig().fees.verification;},
};
