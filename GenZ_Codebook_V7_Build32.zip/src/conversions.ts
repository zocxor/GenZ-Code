/**
 * Encode / Decode allowance: `freeDaily` free conversions per day each (admin setting,
 * default 10), then each conversion costs the admin-set Credit price (default 5; 0 means
 * unlimited free). An optional rewarded ad adds +5 free conversions. Credits are charged by
 * the server only after the conversion has produced a result, and only once per request.
 * A conversion that recognises/changes nothing is never counted or charged.
 */
import {useSyncExternalStore} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useAppConfig} from './appConfig';
import {useAccountUser} from './services';

import {AD_BONUS,addBonus,fresh,remaining,spendFree,today,type ConvKind,type ConvState} from './conversionQuota';
export {AD_BONUS,type ConvKind};
const KEY = 'genz.conversions.v1';
let state: ConvState = fresh();
const listeners = new Set<() => void>();
let loaded = false;
function set(next: ConvState) {state = next; listeners.forEach(f => f()); void AsyncStorage.setItem(KEY, JSON.stringify(next)).catch(() => {});}
function load() {
  if (loaded) return; loaded = true;
  void AsyncStorage.getItem(KEY).then(raw => {
    const v = raw ? JSON.parse(raw) : null;
    if (v && typeof v.day === 'string' && v.used && v.bonus) {state = today(v); listeners.forEach(f => f());}
  }).catch(() => {});
}
const subscribe = (fn: () => void) => {listeners.add(fn); load(); return () => {listeners.delete(fn);};};

export type SpendResult = {ok: true; paid: number} | {ok: false; message: string; needsAd?: boolean};
const requestKey = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;

export function useConversion(kind: ConvKind) {
  const s = useSyncExternalStore(subscribe, () => state);
  const cfg = useAppConfig(), user = useAccountUser();
  const freeDaily = kind === 'encode' ? cfg.encodeFreeDaily : cfg.decodeFreeDaily;
  const cost = cfg.fees[kind];
  const left = remaining(s, kind, freeDaily);
  const label = left > 0 ? `Free · ${left} ${kind === 'encode' ? 'encode' : 'decode'}${left === 1 ? '' : 's'} left today`
    : cost === 0 ? 'Free today' : `Free ${kind}s used · ${cost} Credits each`;
  /** Call after the conversion produced its result. `changed` false = nothing found → not counted. */
  async function spend(changed: boolean, confirm: (cost: number) => Promise<boolean>): Promise<SpendResult> {
    if (!changed) return {ok: true, paid: 0};
    if (left > 0) {set(spendFree(state, kind)); return {ok: true, paid: 0};}
    if (cost === 0) return {ok: true, paid: 0};
    if (!user) return {ok: false, message: `You’ve used today’s free ${kind}s. Sign in to continue for ${cost} Credits each, or watch an optional ad for +${AD_BONUS}.`, needsAd: true};
    if (!(await confirm(cost))) return {ok: false, message: 'Cancelled. No Credits were charged.'};
    try {
      const {feature} = await import('./communityFeatures');
      await feature('convert-fee', {kind, requestId: requestKey()});
      return {ok: true, paid: cost};
    } catch (e) {
      const {errorOf} = await import('./communityFeatures');
      return {ok: false, message: errorOf(e), needsAd: true};
    }
  }
  async function watchForBonus(): Promise<string> {
    const {watchRewardedAd} = await import('./ads');
    if (await watchRewardedAd()) {set(addBonus(state, kind)); return `+${AD_BONUS} free ${kind}s unlocked for today.`;}
    return 'No ad is available right now. Try again later.';
  }
  return {left, cost, freeDaily, label, spend, watchForBonus};
}
