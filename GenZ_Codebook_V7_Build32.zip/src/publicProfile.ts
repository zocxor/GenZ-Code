/**
 * Public author card (publicProfiles/{uid}) shown beside community posts and comments:
 * nickname, avatar icon and — only when the owner turns on "Show my photo on my posts" —
 * a small 96 px copy of their photo. Owner-written (security rules), public read,
 * removed when the account is deleted. Reads are batched (30 per query) and cached.
 */
import {useEffect,useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type PublicProfile = {name: string; avatar: number; photo?: string};
const cache = new Map<string, PublicProfile | null>();
const SHARE_KEY = 'genz.sharePhoto.v1';

export async function getSharePhoto(): Promise<boolean> {try {return (await AsyncStorage.getItem(SHARE_KEY)) === '1';} catch {return false;}}
export async function setSharePhoto(on: boolean) {try {await AsyncStorage.setItem(SHARE_KEY, on ? '1' : '0');} catch {}}

async function thumbnail(dataUri: string): Promise<string | null> {
  try {
    const M = await import('expo-image-manipulator');
    const out = await M.manipulateAsync(dataUri, [{resize: {width: 96}}], {compress: 0.7, format: M.SaveFormat.JPEG, base64: true});
    if (out.base64) return 'data:image/jpeg;base64,' + out.base64;
  } catch {}
  return dataUri.length <= 60000 ? dataUri : null;
}

/** Publish (or refresh) the signed-in user's public card. `photo` null removes any shared photo. */
export async function publishPublicProfile({name, avatar, photo}: {name: string; avatar: number; photo: string | null}) {
  const [{doc, setDoc, serverTimestamp}, {cloudDb, accountAuth}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
  const user = accountAuth.currentUser;
  if (!user) return;
  const clean = name.trim().slice(0, 24) || 'Code Explorer';
  const shared = photo ? await thumbnail(photo) : null;
  const card: PublicProfile = {name: clean, avatar: Number.isInteger(avatar) && avatar >= 0 && avatar <= 11 ? avatar : 0, ...(shared ? {photo: shared} : {})};
  await setDoc(doc(cloudDb(), 'publicProfiles', user.uid), {...card, updatedAt: serverTimestamp()});
  cache.set(user.uid, card);
}

export function usePublicProfiles(uids: string[]): Map<string, PublicProfile> {
  const key = JSON.stringify([...new Set(uids.filter(Boolean))].sort());
  const [map, setMap] = useState<Map<string, PublicProfile>>(() => new Map());
  useEffect(() => {
    let alive = true;
    const ids = JSON.parse(key) as string[];
    const known = () => new Map(ids.flatMap(id => {const v = cache.get(id); return v ? [[id, v] as [string, PublicProfile]] : [];}));
    setMap(known());
    const missing = ids.filter(id => !cache.has(id));
    if (!missing.length) return;
    void (async () => {
      const [{collection, documentId, getDocs, query, where}, {cloudDb}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
      for (let i = 0; i < missing.length; i += 30) {
        const chunk = missing.slice(i, i + 30);
        try {
          const snap = await getDocs(query(collection(cloudDb(), 'publicProfiles'), where(documentId(), 'in', chunk)));
          const found = new Set(snap.docs.map(d => d.id));
          for (const d of snap.docs) {const v = d.data(); cache.set(d.id, {name: String(v.name ?? ''), avatar: Number(v.avatar) || 0, ...(typeof v.photo === 'string' ? {photo: v.photo} : {})});}
          for (const id of chunk) if (!found.has(id)) cache.set(id, null);
        } catch {/* offline: letters stay */}
      }
      if (alive) setMap(known());
    })();
    return () => {alive = false;};
  }, [key]);
  return map;
}
