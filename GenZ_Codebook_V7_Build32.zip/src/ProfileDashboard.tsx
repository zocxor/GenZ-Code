import {FollowUsRow} from './FollowUs';
import AccountTokens from './AccountTokens';
import {BACKEND_URL} from './backend';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
/**
 * "You" tab — profile dashboard. Every number comes from the saved learning state;
 * nothing is simulated. Restyled on the GenZ Codebook brand system:
 * deep navy type, electric blue actions, soft blue surfaces, purple accents,
 * gold reserved for tokens / rewards. Built on the shared ui.tsx primitives.
 */
import {SPARK_MODE} from '../shared/deployment';
import React, {useEffect, useMemo, useState} from 'react';
import {View, Text, Pressable, StyleSheet, Linking, ActivityIndicator} from 'react-native';
import {PLAY_STORE_URL, SUPPORT_EMAIL, supportMailto} from '../shared/brand';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Icon, IconName, Button, BrandAvatar, CompanyFooter, IconTile, ProgressBar, SectionHeader, FadeIn, LiquidHero} from './ui';
import {LearningState, Profile, streak, totalXP, localDayOf} from './profile';
import {levelFor, TOKENS} from '../shared/tokens';
import {stages, unlocked} from './games';
import {termsById, Term, contentManifest, terms} from './content';
import {dueTerms} from './reviewQueue';
import {ago} from './shield/status';
import type {SyncStatus} from './sync/engine';
import {APP_VERSION} from './secure/config';
import {useAccountUser} from './services';
import {useAvatarPhoto} from './avatarPhoto';
import {referralCodeForUid} from '../shared/referral';
import * as Clipboard from 'expo-clipboard';
import {levelNameForId} from './discovery';
import {ensureReferralCode, fetchReferralCount, fetchReferredBy, fetchReferredFriends, shareReferral, type ReferredByInfo, type ReferredFriendView} from './referral';

export const RANKS: [number, string][] = [[0, 'Rookie'], [100, 'Decoder'], [250, 'Code Cracker'], [500, 'Lingo Pro'], [900, 'Internet Linguist'], [1400, 'Code Legend']];
export function rankFor(xp: number) {
  let i = 0;
  while (i + 1 < RANKS.length && xp >= RANKS[i + 1]![0]) i++;
  const [floor, name] = RANKS[i]!;
  const next = RANKS[i + 1];
  return {level: i + 1, name, floor, next: next ? {xp: next[0], name: next[1]} : null, progress: next ? (xp - floor) / (next[0] - floor) : 1};
}
const stageName = (id: string) => stages.find(s => s.id === id)?.name ?? levelNameForId(id) ?? (id === 'review' ? 'Daily review' : id.startsWith('daily-') ? 'Daily five' : id.startsWith('shuffle-') ? 'Shuffle: ' + id.slice(8, 9).toUpperCase() + id.slice(9) : id);

type Props = {
  state: LearningState; profile: Profile; sync: SyncStatus; signedInEmail: string | null;
  onEdit: () => void; onOpen: (sheet: 'login' | 'export' | 'guide' | 'privacy' | 'feedback' | 'suggest' | 'wallet' | 'shop' | 'notifications' | 'dashboard' | 'achievements' | 'settings' | 'about' | 'my-suggestions' | 'daily-apply' | 'daily-history' | 'my-posts' | 'verification') => void; onAccount: (mode: 'signin' | 'create') => void;
  onSavedWords: () => void; onOpenTerm: (t: Term) => void; onReview: () => void; onPlay: () => void; onUnlockLevel: (stageId: string) => void; onRefresh: () => void;
};

export default function ProfileDashboard({state, profile: p, sync, signedInEmail, onEdit, onOpen, onAccount, onSavedWords, onOpenTerm, onReview, onPlay, onUnlockLevel, onRefresh}: Props) {
  const now = Date.now();
  const photo = useAvatarPhoto();
  const user = useAccountUser();
  const badges=useBadges(user?[user.uid]:[]);
  // Referral: the code is deterministic from the UID (shared/referral.ts),
  // so it shows immediately; the effect below registers it in Firestore
  // and counts successful referrals (0 when none — never invented).
  const myReferralCode = user ? referralCodeForUid(user.uid) : '';
  const [codeCopyStatus,setCodeCopyStatus]=useState('');
  useEffect(()=>setCodeCopyStatus(''),[myReferralCode]);
  const copyRegistrationCode=async()=>{
    if(!myReferralCode)return;
    try{await Clipboard.setStringAsync(myReferralCode);setCodeCopyStatus('Copied');}
    catch{setCodeCopyStatus('Could not copy. Press and hold the code to copy it.');}
  };
  const [referralCount, setReferralCount] = useState<number | null>(null);
  // Who referred this user, and who they referred — display names only
  // (see src/referral.ts: names come from public sources; a null name means
  // "Referred by a user" / "A friend", never a UID). Null = not loaded yet
  // (or the load failed — nothing is shown rather than a wrong fact).
  const [referredBy, setReferredBy] = useState<ReferredByInfo | null>(null);
  const [referredFriends, setReferredFriends] = useState<ReferredFriendView[] | null>(null);
  useEffect(() => {
    if (!user) {setReferralCount(null); setReferredBy(null); setReferredFriends(null); return;}
    void ensureReferralCode(user.uid).catch(() => {});
    void fetchReferralCount(user.uid).then(setReferralCount);
    let cancelled = false;
    void fetchReferredBy(user.uid).then(v => {if (!cancelled) setReferredBy(v);}).catch(() => {});
    void fetchReferredFriends(user.uid, 10).then(v => {if (!cancelled) setReferredFriends(v);}).catch(() => {});
    return () => {cancelled = true;};
  }, [user?.uid]);
  const shareMyCode = () => {
    if (!user || !myReferralCode) return;
    // Register the code first, so a friend who uses it right away can
    // claim it; the share sheet opens whether or not that write lands.
    void ensureReferralCode(user.uid).catch(() => {}).then(() => shareReferral(myReferralCode));
  };
  const d = useMemo(() => {
    const xp = totalXP(p.best);
    const rank = rankFor(xp);
    const st = streak(state.days, now);
    const mastered = Object.values(p.progress).filter(r => r.mastery >= 80).length;
    const due = dueTerms(p, now).length;
    const week = Array.from({length: 7}, (_, i) => {const t = new Date(now); t.setHours(12, 0, 0, 0); t.setDate(t.getDate() - (6 - i)); const key = localDayOf(t.getTime()); return {key, label: t.toLocaleDateString('en', {weekday: 'narrow'}), count: state.days[key] ?? 0, today: i === 6};});
    const weekMax = Math.max(1, ...week.map(w => w.count));
    const attempts = Object.values(state.attempts).sort((a, b) => b.at - a.at);
    const cleared = stages.filter(g => (p.best[g.id] ?? 0) >= 60).length;
    const played = stages.filter(g => p.best[g.id] !== undefined).length;
    const recent = state.recent.map(r => termsById.get(r.id)).filter((t): t is Term => !!t).slice(0, 8);
    const perfect = Object.values(p.best).some(v => v === 100);
    const badges: {icon: IconName; label: string; earned: boolean; hint: string}[] = [
      {icon: 'chatbubbles', label: 'Code cracker', earned: played > 0, hint: 'Play a level'},
      {icon: 'star', label: 'Perfect round', earned: perfect, hint: 'Score 5 / 5'},
      {icon: 'bookmark', label: 'Word collector', earned: p.saved.length >= 5, hint: 'Save 5 words'},
      {icon: 'flame', label: 'On a roll', earned: st.best >= 3, hint: '3-day streak'},
      {icon: 'calendar', label: 'Week warrior', earned: st.best >= 7, hint: '7-day streak'},
      {icon: 'school', label: 'Sharp memory', earned: mastered >= 10, hint: 'Master 10 words'},
    ];
    return {xp, rank, st, mastered, due, week, weekMax, attempts, cleared, recent, badges, weekAnswers: week.reduce((a, w) => a + w.count, 0), weekDays: week.filter(w => w.count > 0).length, reviewing: Object.keys(p.progress).length, tokens: levelFor(state.tokens.balance), nextLocked: stages.find((g, i) => !unlocked(i, p.best, state.tokens.unlockedLevels))};
  }, [state, p, now - (now % 60_000)]);

  const syncLabel = !signedInEmail ? 'Stored on this device only' : sync.phase === 'idle' && !sync.pending ? `Backed up${sync.lastSyncAt ? ' · ' + ago(now - sync.lastSyncAt) : ''}` : sync.phase === 'syncing' ? 'Syncing…' : sync.phase === 'offline' ? 'Offline · will sync later' : sync.pending ? 'Changes waiting to sync' : 'Sync needs attention';
  const syncIcon: IconName = !signedInEmail ? 'phone-portrait-outline' : sync.phase === 'idle' && !sync.pending ? 'cloud-done-outline' : sync.phase === 'offline' ? 'cloud-offline-outline' : 'cloud-upload-outline';
  const syncing = sync.phase === 'syncing';
  const [section,setSection] = useState<'wallet'|'learning'|'contributions'|'account'|null>(null);
  const toggle = (next:NonNullable<typeof section>) => setSection(current=>current===next?null:next);

  return <>
    <FadeIn>
    <LiquidHero style={[s.hero,s.heroCompact]} tone="plum">
      <View style={s.heroRow}>
        <Pressable accessibilityRole="button" accessibilityLabel="Edit your profile" onPress={onEdit} style={s.avatarRing}>
          <BrandAvatar index={p.avatar} size={52} photo={p.usePhoto ? photo : null} />
          <View style={s.editBadge}><Icon name="pencil" size={13} color={C.accent} /></View>
        </Pressable>
        <View style={{flex: 1, gap: 6}}>
          
          <View style={{flexDirection:'row',alignItems:'center',gap:6}}><Text accessibilityRole="header" style={[s.heroName,{flexShrink:1,fontSize:22}]} numberOfLines={1}>{p.name}</Text><VerifiedBadge verified={!!user&&badges.has(user.uid)} tier={badges.tier(user?.uid)} size={22}/></View>
          {!!myReferralCode&&<View style={{gap:3}}><View style={{flexDirection:'row',alignItems:'center',gap:6,flexWrap:'wrap'}}><Text style={s.heroSmall}>User code</Text><Text selectable accessibilityLabel={'Your registration code '+myReferralCode} style={{fontSize:13,fontWeight:'800',letterSpacing:1,color:'#fff'}}>{myReferralCode}</Text><Pressable accessibilityRole="button" accessibilityLabel={'Copy registration code '+myReferralCode} hitSlop={8} onPress={()=>void copyRegistrationCode()} style={{minWidth:44,minHeight:44,alignItems:'center',justifyContent:'center'}}><Icon name="copy-outline" color="#fff" size={17}/></Pressable></View>{!!codeCopyStatus&&<Text accessibilityLiveRegion="polite" style={s.heroSmall}>{codeCopyStatus}</Text>}</View>}
          <View style={s.rankPill}><Icon name="sparkles" size={13} color="#fff" /><Text style={s.rankText}>Level {d.rank.level} · {d.rank.name}</Text></View>
        </View>
      </View>
      <View style={{gap: 5}}>
        <View accessibilityRole="progressbar" accessibilityValue={{min: 0, max: 100, now: Math.round(d.rank.progress * 100)}}>
          <ProgressBar value={d.rank.progress} color={C.gold} height={6} />
        </View>
        <View style={s.between}><Text style={s.heroSmall}>{d.xp} XP</Text><Text style={s.heroSmall}>{d.rank.next ? `${d.rank.next.xp - d.xp} XP to ${d.rank.next.name}` : 'Top rank reached'}</Text></View>
      </View>
      {signedInEmail ? <View style={s.syncRow}>
        <Pressable accessibilityRole="button" onPress={() => onOpen('login')} style={[s.syncChip, {flex: 1, minHeight: 40, paddingVertical: 7}]}>
          <Icon name={syncIcon} size={16} color="#fff" />
          <Text style={s.syncText} numberOfLines={1}>{syncLabel}</Text>
          <Icon name="chevron-forward" size={14} color="rgba(255,255,255,.8)" />
        </Pressable>
        <Pressable accessibilityRole="button" accessibilityLabel="Refresh profile" accessibilityState={{disabled: syncing}} disabled={syncing} onPress={onRefresh} style={[s.refreshBtn, {width: 42, height: 42}, syncing && s.refreshBtnBusy]}>
          {syncing ? <ActivityIndicator color="#fff" /> : <Icon name="refresh-outline" size={20} color="#fff" />}
        </Pressable>
      </View> : <View style={{gap: 8}}>
        <View style={s.authRow}>
          <Pressable accessibilityRole="button" onPress={() => onAccount('signin')} style={[s.authBtn, s.authPrimary]}><Icon name="log-in-outline" size={18} color={C.accent} /><Text style={[s.authText, {color: C.accent}]}>Sign in</Text></Pressable>
          <Pressable accessibilityRole="button" onPress={() => onAccount('create')} style={[s.authBtn, s.authGhost]}><Icon name="person-add-outline" size={18} color="#fff" /><Text style={s.authText}>Create account</Text></Pressable>
        </View>
        <Text style={s.heroHint}>Back up your progress to use it on any phone.</Text>
      </View>}
    </LiquidHero>
    </FadeIn>

    <View style={s.grid}>
      <Stat icon="flame" value={String(d.st.current)} label="Day streak" />
      <Stat icon="bookmark" value={String(p.saved.length)} label="Saved" onPress={onSavedWords} />
      <Stat icon="ribbon" value={String(d.mastered)} label="Mastered" />
    </View>
    <View style={s.groupStack}>
    <ProfileGroup icon="shield-checkmark-outline" title="Verified badge" detail={user&&badges.has(user.uid)?(badges.tier(user.uid)==='gold'?'Gold · GenZ Codebook team':'Blue · verified'):'See eligibility and apply'} open={false} onPress={()=>onOpen('verification')}>{null}</ProfileGroup>
    <ProfileGroup icon="wallet-outline" title="Wallet & rewards" detail={`${state.tokens.balance.toLocaleString()} learning points`} open={section==='wallet'} onPress={()=>toggle('wallet')}>
    <Glass>
      <AccountTokens/>
      <SectionHeader eyebrow="LEARNING POINTS" title={`${state.tokens.balance.toLocaleString()} learning points · Level ${d.tokens.level} ${d.tokens.name}`} action={<IconTile icon="star" from={C.gold} to="#E89B0C" size={40} iconSize={20} />} />
      <View accessibilityRole="progressbar" accessibilityValue={{min: 0, max: 100, now: Math.round(d.tokens.progress * 100)}}>
        <ProgressBar value={d.tokens.progress} color={C.gold} height={10} />
      </View>
      <Text style={s.caption}>{d.tokens.next ? `${(d.tokens.next.tokens - state.tokens.balance).toLocaleString()} points to ${d.tokens.next.name}` : 'Top learning points level reached'}</Text>
      <Text style={s.caption}>Learning points: games and guest ads. Credits: verified ads +10 and daily account reward +5. Earn: watch an ad +10 · visit daily +5 · perfect round +10 · Daily Five +15 · word accepted +20 · friend joins with your code +100. Creating codes, posting and chat are free. Use learning points to unlock a level early for 50.</Text>
      {d.nextLocked && (state.tokens.balance >= TOKENS.UNLOCK_LEVEL_COST
        ? <Button title={`Unlock ${d.nextLocked.name} early · ${TOKENS.UNLOCK_LEVEL_COST} points`} icon="lock-open-outline" onPress={() => onUnlockLevel(d.nextLocked!.id)} />
        : <Text style={s.caption}>Earn {(TOKENS.UNLOCK_LEVEL_COST - state.tokens.balance).toLocaleString()} more points to unlock {d.nextLocked.name} early.</Text>)}
      <View style={s.row}>
        {!!BACKEND_URL&&<View style={{flex: 1}}><Button title="Buy Credits" icon="card-outline" onPress={() => onOpen('shop')} /></View>}
        <View style={{flex: 1}}><Button title="Wallet" icon="wallet-outline" light onPress={() => onOpen('wallet')} /></View>
      </View>
      {signedInEmail && myReferralCode ? <View style={s.referralBox}>
        <Text style={s.referralLabel}>Invite friends · you both get {TOKENS.REFERRAL_REWARD} Credits</Text>
        <View style={s.row}>
          <View style={{flex: 1, justifyContent: 'center'}}><Text selectable accessibilityLabel={`Your referral code ${myReferralCode}`} style={s.referralCode}>{myReferralCode}</Text></View>
          <View style={{flex: 1}}><Button title="Share" icon="share-social-outline" onPress={shareMyCode} /></View>
        </View>
        <Text style={s.caption}>{referralCount === null ? 'Counting your referrals…' : referralCount === 0 ? `No friends joined with your code yet — share it to earn ${TOKENS.REFERRAL_REWARD} Credits each.` : `${referralCount} friend${referralCount === 1 ? '' : 's'} joined with your code · +${(referralCount * TOKENS.REFERRAL_REWARD).toLocaleString()} Credits earned`}</Text>
        {referredBy && referredBy.claimed === false && <Text style={s.caption}>You joined directly — no one referred you.</Text>}
        {referredBy && referredBy.claimed === true && <Text style={s.caption}>Referred by {referredBy.displayName ?? 'a user'} — you both got {TOKENS.REFERRAL_REWARD} Credits.</Text>}
        {referredFriends && referredFriends.length > 0 && <View style={{gap: 4}}>
          <Text style={s.referralLabel}>Friends you referred</Text>
          {referredFriends.map((f, i) => <Text key={i} style={s.caption}>• {f.displayName ?? 'A friend'}{f.joinedAtMs ? ` — joined ${ago(now - f.joinedAtMs)}` : ''}</Text>)}
          {referralCount !== null && referralCount > referredFriends.length && <Text style={s.caption}>and {referralCount - referredFriends.length} more</Text>}
        </View>}
      </View> : signedInEmail ? <Text style={s.caption}>Your referral code appears here once you’re back online.</Text> : null}
    </Glass>
    </ProfileGroup>
    <ProfileGroup icon="school-outline" title="Learning" detail={d.due?`${d.due} due for review`:undefined} open={section==='learning'} onPress={()=>toggle('learning')}>
      <Glass style={{padding:4,gap:0}}>
        <Row icon="pulse-outline" from={C.accent} to={C.purple} title="Learning dashboard" onPress={() => onOpen('dashboard')} />
        <Row icon="ribbon-outline" from={C.gold} to="#E89B0C" title="Achievements" onPress={() => onOpen('achievements')} last />
      </Glass>
    <Glass>
      <SectionHeader eyebrow="THIS WEEK" title={d.weekAnswers ? `${d.weekAnswers} answers · ${d.weekDays} of 7 days` : 'A fresh week'} action={<Icon name="pulse-outline" color={C.accent} size={24} />} />
      <View style={s.bars} accessible accessibilityLabel={`Activity in the last 7 days: ${d.week.map(w => w.count).join(', ')} answers`}>
        {d.week.map(w => <View key={w.key} style={s.barCol}>
          <View style={s.barSlot}><LinearGradient colors={w.today ? [C.accent, C.purple] : ['#B9D2F5', '#8EAEEA']} style={[s.bar, {height: w.count ? `${Math.max(12, (w.count / d.weekMax) * 100)}%` : 4, opacity: w.count ? 1 : 0.5}]} /></View>
          <Text style={[s.barLabel, w.today && {color: C.accent, fontWeight: '900'}]}>{w.label}</Text>
        </View>)}
      </View>
      {!d.weekAnswers && <Text style={s.caption}>Answer one quiz question to start a streak.</Text>}
    </Glass>

    <Glass>
      <SectionHeader eyebrow="LEARNING PATH" title={`${d.cleared} of ${stages.length} levels cleared`} action={<Pressable accessibilityRole="button" onPress={onPlay} style={s.linkRow}><Text style={s.link}>Play</Text><Icon name="arrow-forward" size={16} color={C.accent} /></Pressable>} />
      <View style={s.path}>
        {stages.map((g, i) => {const best = p.best[g.id]; const done = (best ?? 0) >= 60; const open = unlocked(i, p.best, state.tokens.unlockedLevels); return <React.Fragment key={g.id}>
          {i > 0 && <View style={[s.pathLine, done && {backgroundColor: g.color}]} />}
          <View accessible accessibilityLabel={`${g.name}: ${done ? `cleared, best ${best}%` : open ? 'unlocked' : 'locked'}`} style={[s.node, done ? {backgroundColor: g.color, borderColor: g.color} : open ? {borderColor: g.color} : null]}>
            <Icon name={done ? 'checkmark' : open ? g.icon : 'lock-closed'} size={done ? 20 : 17} color={done ? '#fff' : open ? g.color : C.muted} />
          </View>
        </React.Fragment>;})}
      </View>
      <View style={s.reviewRow}>
        <IconTile icon="repeat" from="#0E9F8A" to="#34C3A5" size={40} iconSize={20} />
        <View style={{flex: 1}}><Text style={s.rowTitle}>{d.due ? `${d.due} ${d.due === 1 ? 'word is' : 'words are'} ready to review` : d.reviewing ? 'Reviews are scheduled' : 'Your review queue is empty'}</Text>{d.reviewing ? <Text style={s.caption}>{d.reviewing} words in review</Text> : null}</View>
        {d.due > 0 && <Pressable accessibilityRole="button" onPress={onReview} style={s.smallCta}><Text style={s.smallCtaText}>Review</Text></Pressable>}
      </View>
    </Glass>
    {d.attempts.length > 0 && <>
    <Glass>
      <SectionHeader eyebrow="RECENT ROUNDS" title="Your recent rounds" action={<Text style={s.caption}>{d.attempts.length} saved</Text>} />
      {d.attempts.slice(0, 3).map((a, i) => {const pct = Math.round((a.score / a.total) * 100); return <View key={i} style={s.attempt}>
        <View style={{flex: 1}}><Text style={s.rowTitle} numberOfLines={1}>{stageName(a.stage)}</Text><Text style={s.caption}>{ago(now - a.at)}</Text></View>
        <View style={[s.scorePill, {backgroundColor: pct >= 60 ? '#E1F5E9' : '#FFF1E6'}]}><Text style={[s.scoreText, {color: pct >= 60 ? '#13684A' : '#97501C'}]}>{a.score}/{a.total}</Text></View>
      </View>;})}
    </Glass>
    </>}

    <View style={{gap: 12}}>
      <SectionHeader eyebrow="ACHIEVEMENTS" title="Your little wins" />
      <View style={s.badges}>{d.badges.map(b => <View key={b.label} accessible accessibilityLabel={`${b.label}: ${b.earned ? 'earned' : 'not yet. ' + b.hint}`} style={[s.badge, !b.earned && {opacity: 0.6}]}>
        <IconTile icon={b.earned ? b.icon : (b.icon + '-outline') as IconName} from={b.earned ? C.gold : '#CBD8E8'} to={b.earned ? '#E89B0C' : '#9FB4CC'} size={44} iconSize={22} />
        <Text style={s.badgeText} numberOfLines={1}>{b.label}</Text>
        <Text style={s.fine}>{b.earned ? 'Earned' : b.hint}</Text>
      </View>)}</View>
    </View>
    {d.recent.length > 0 && <>
    <Glass>
      <SectionHeader eyebrow="RECENTLY VIEWED" title="Recently viewed" />
      <View style={s.wrap}>{d.recent.map(t => <Pressable key={t.id} accessibilityRole="button" accessibilityLabel={`Open ${t.expression}`} onPress={() => onOpenTerm(t)} style={({pressed}) => [s.recentChip, pressed && {opacity: 0.75}]}><Text style={s.recentText} numberOfLines={1}>{t.expression}</Text></Pressable>)}</View>
    </Glass>
    </>}

    </ProfileGroup>
    <ProfileGroup icon="create-outline" title="Contributions" open={section==='contributions'} onPress={()=>toggle('contributions')}>
      <Glass style={{padding:4,gap:0}}>
        <Row icon="create-outline" from={C.purple} to="#9B7BFF" title="Suggest a word" onPress={()=>onOpen('suggest')}/>
        <Row icon="list-outline" from={C.purple} to="#9B7BFF" title="My suggestions" onPress={()=>onOpen('my-suggestions')}/>
        <Row icon="albums-outline" from={C.purple} to="#9B7BFF" title="My Posts" onPress={()=>onOpen('my-posts')}/>
{!!BACKEND_URL&&<Row icon="calendar-outline" from={C.accent} to={C.purple} title="Apply for Daily Code" onPress={()=>onOpen('daily-apply')}/>}
        <Row icon="list-outline" from={C.accent} to={C.purple} title="Daily Code applications" onPress={()=>onOpen('daily-history')}/>
        <Row icon="shield-checkmark-outline" from={C.accent} to={C.purple} title="Verified Badge" onPress={()=>onOpen('verification')} last/>
      </Glass>
    </ProfileGroup>
    <ProfileGroup icon="settings-outline" title="Account & settings" open={section==='account'} onPress={()=>toggle('account')}>
      <Glass style={{padding:4,gap:0}}>
        <Row icon="person-circle-outline" from={C.accent} to="#4D8DFF" title="My account" description={signedInEmail ? `Signed in · ${syncLabel.toLowerCase()}` : 'Back up and sync'} onPress={() => onOpen('login')} />
        <Row icon="notifications-outline" from="#0EA5E9" to="#38BDF8" title="Notifications" description="Activity and Credit updates" onPress={() => onOpen('notifications')} />
        <Row icon="settings-outline" from="#64748B" to="#94A3B8" title="Settings" onPress={() => onOpen('settings')} />
        <Row icon="shield-checkmark-outline" from="#0D9488" to="#14B8A6" title="Threat Shield" onPress={() => onOpen('privacy')} />
        <Row icon="download-outline" from={C.accent} to="#4D8DFF" title="Export learning data" onPress={() => onOpen('export')} />
        <Row icon="chatbubble-ellipses-outline" from={C.purple} to="#A78BFA" title="Send feedback" onPress={() => onOpen('feedback')} />
        <Row icon="mail-outline" from="#0EA5E9" to="#38BDF8" title="Contact support" description={SUPPORT_EMAIL} onPress={() => void Linking.openURL(supportMailto()).catch(() => {})} />
        <Row icon="help-buoy-outline" from="#8B5CF6" to="#C4B5FD" title="Where do I start?" onPress={() => onOpen('guide')} last />
      </Glass>
    </ProfileGroup>
    </View>
    {/* Display version: the first public release. APP_VERSION comes from
        app.json and stays 1.0.0 until Kashif says to move to the next version.
        Show it exactly as-is — no build suffixes here. */}
    <View style={s.quickRow}>
      <Pressable accessibilityRole="button" accessibilityLabel="Rate GenZ Codebook on Google Play" onPress={() => void Linking.openURL(PLAY_STORE_URL).catch(() => {})} style={({pressed}) => [s.quick, pressed && {opacity: .8}]}>
        <IconTile icon="star" from={C.gold} to="#E89B0C" size={38} iconSize={19} /><View style={{flex: 1}}><Text style={s.quickTitle}>Rate the app</Text><Text style={s.fine}>On Google Play</Text></View>
      </Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel="Send feedback" onPress={() => onOpen('feedback')} style={({pressed}) => [s.quick, pressed && {opacity: .8}]}>
        <IconTile icon="chatbubble-ellipses" from={C.purple} to="#A78BFA" size={38} iconSize={19} /><View style={{flex: 1}}><Text style={s.quickTitle}>Feedback</Text><Text style={s.fine}>Ideas & bugs</Text></View>
      </Pressable>
    </View>
    <FollowUsRow />
    <View style={s.versionRow} accessible accessibilityLabel={`GenZ Codebook version ${APP_VERSION}`}>
      <View style={s.versionPill}><View style={s.versionDot} /><Text style={s.versionText}>v{APP_VERSION}</Text></View>
      <Text style={s.fine}>{terms.length.toLocaleString()} entries{terms.length !== contentManifest.uniqueEntries ? ' (includes published updates)' : ''}</Text>
    </View>
    <CompanyFooter />
  </>;
}

function ProfileGroup({icon,title,detail,open,onPress,children}:{icon:IconName;title:string;detail?:string;open:boolean;onPress:()=>void;children:React.ReactNode}) {
  return <View style={s.group}>
    <Pressable accessibilityRole="button" accessibilityState={{expanded:open}} onPress={onPress} style={({pressed})=>[s.groupHead,pressed&&{backgroundColor:C.soft}]}>
      <View style={s.groupIcon}><Icon name={icon} color={C.accent} size={19}/></View>
      <View style={{flex:1,minWidth:0}}>
        <Text style={s.rowTitle}>{title}</Text>
        {!!detail&&<Text style={s.caption}>{detail}</Text>}
      </View>
      <Icon name={open?'chevron-up':'chevron-down'} color={C.muted} size={16}/>
    </Pressable>
    {open&&<View style={s.groupBody}>{children}</View>}
  </View>;
}

function Stat({icon,value,label,onPress}:{icon:IconName;value:string;label:string;onPress?:()=>void}) {
  const body=<><View style={s.statTop}><Icon name={icon} color={icon==='flame'?C.goldDeep:C.accent} size={16}/><Text style={s.statValue} numberOfLines={1}>{value}</Text></View><Text style={s.statLabel}>{label}</Text></>;
  return onPress?<Pressable accessibilityRole="button" accessibilityLabel={`${label}: ${value}`} onPress={onPress} style={s.stat}>{body}</Pressable>:<View accessible accessibilityLabel={`${label}: ${value}`} style={s.stat}>{body}</View>;
}
function Row({icon, from, to, title, description, onPress, last}: {icon: IconName; from: string; to: string; title: string; description?: string; onPress: () => void; last?: boolean}) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({pressed}) => [s.settingRow, !last && s.settingDivider, pressed && {opacity: 0.8, backgroundColor: C.soft}]}><IconTile icon={icon} from={from} to={to} size={40} iconSize={20} /><View style={{flex: 1, gap: 3}}><Text style={s.rowTitle}>{title}</Text>{description && <Text style={s.caption} numberOfLines={1}>{description}</Text>}</View><Icon name="chevron-forward" size={17} color={C.muted} /></Pressable>;
}

const s = StyleSheet.create({
  heroCompact:{padding:14,gap:10,borderRadius:22},quickRow:{flexDirection:'row',gap:10},quick:{flex:1,flexDirection:'row',alignItems:'center',gap:10,padding:12,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#E2E8F5'},quickTitle:{fontSize:14.5,fontWeight:'900',color:C.ink},
  hero: {borderRadius: 20, padding: 14, gap: 9, overflow: 'hidden', shadowColor: C.navy, shadowOffset: {width: 0, height: 12}, shadowOpacity: 0.25, shadowRadius: 22, elevation: 8},
  heroRow: {flexDirection: 'row', alignItems: 'center', gap: 11},
  row: {flexDirection: 'row', gap: 10, marginTop: 4},
  avatarRing: {width: 62, height: 62, borderRadius: 31, borderWidth: 3, borderColor: 'rgba(255,255,255,.85)', alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,.15)'},
  editBadge: {position: 'absolute', right: -2, bottom: 2, width: 28, height: 28, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOpacity: 0.15, shadowRadius: 4, shadowOffset: {width: 0, height: 2}, elevation: 3},
  heroName: {fontSize: 24, fontWeight: '900', letterSpacing: -0.8, color: '#fff'},
  rankPill: {alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 4, paddingHorizontal: 9, borderRadius: 999, backgroundColor: 'rgba(255,255,255,.18)', borderWidth: 1, borderColor: 'rgba(255,255,255,.3)'},
  rankText: {color: '#fff', fontSize: 12, fontWeight: '800'},
  heroSmall: {color: 'rgba(255,255,255,.88)', fontSize: 12, fontWeight: '700'},
  syncChip: {flexDirection: 'row', alignItems: 'center', gap: 8, minHeight: 44, paddingHorizontal: 14, borderRadius: 16, backgroundColor: 'rgba(14,20,70,.22)', borderWidth: 1, borderColor: 'rgba(255,255,255,.22)'},
  syncText: {flex: 1, color: '#fff', fontSize: 13, fontWeight: '700'},
  syncRow: {flexDirection: 'row', gap: 10, alignItems: 'stretch'},
  refreshBtn: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, width:44, minHeight: 44, borderRadius: 14, backgroundColor: 'rgba(255,255,255,.2)', borderWidth: 1, borderColor: 'rgba(255,255,255,.35)'},
  refreshBtnBusy: {opacity: 0.7},
  authRow: {flexDirection: 'row', gap: 10},
  authBtn: {flex: 1, minHeight: 46, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7},
  authPrimary: {backgroundColor: '#fff', borderBottomWidth: 2, borderBottomColor: '#cfdcf5'},
  authGhost: {backgroundColor: 'rgba(255,255,255,.14)', borderWidth: 1.5, borderColor: 'rgba(255,255,255,.55)'},
  authText: {fontSize: 14, fontWeight: '800', color: '#fff'},
  heroHint: {color: 'rgba(255,255,255,.85)', fontSize: 12, lineHeight: 17},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10},
  grid: {flexDirection:'row',gap:7},
  stat: {flex:1,minWidth:0,backgroundColor:'#fff',borderRadius:14,paddingVertical:8,paddingHorizontal:6,alignItems:'center',gap:2,borderWidth:1,borderColor:'#DCE8F5'},
  statTop: {flexDirection:'row',alignItems:'center',gap:5},
  statValue: {fontSize:17,fontWeight:'900',color:C.navy},
  statLabel: {fontSize:12,fontWeight:'700',color:C.muted,textAlign:'center'},
  groupStack: {gap:7},
  group: {backgroundColor:'#fff',borderRadius:15,borderWidth:1,borderColor:'#DCE8F5',overflow:'hidden'},
  groupHead: {minHeight:53,paddingHorizontal:11,paddingVertical:7,flexDirection:'row',alignItems:'center',gap:9},
  groupIcon: {width:33,height:33,borderRadius:10,alignItems:'center',justifyContent:'center',backgroundColor:C.soft},
  groupBody: {padding:8,gap:8,backgroundColor:'#F4F7FF'},
  bars: {flexDirection: 'row', gap: 8, height: 88, alignItems: 'flex-end'},
  barCol: {flex: 1, alignItems: 'center', gap: 6, height: '100%'},
  barSlot: {flex: 1, width: '100%', justifyContent: 'flex-end', alignItems: 'center'},
  bar: {width: '72%', maxWidth: 30, borderRadius: 9},
  barLabel: {fontSize: 11, color: C.muted, fontWeight: '700'},
  linkRow: {flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 44},
  link: {fontSize: 14, color: C.accent, fontWeight: '800'},
  path: {flexDirection: 'row', alignItems: 'center', paddingVertical: 4},
  pathLine: {flex: 1, height: 3, borderRadius: 3, backgroundColor: '#D3DFEE', marginHorizontal: 4},
  node: {width: 44, height: 44, borderRadius: 22, borderWidth: 2, borderColor: '#CBD8E8', backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center'},
  reviewRow: {flexDirection: 'row', alignItems: 'center', gap: 12, padding: 10, borderRadius: 14, backgroundColor: C.soft},
  smallCta: {minHeight: 40, paddingHorizontal: 14, borderRadius: 14, backgroundColor: C.accent, justifyContent: 'center'},
  smallCtaText: {color: '#fff', fontWeight: '800', fontSize: 13},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.navy},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  referralBox: {marginTop: 10, padding: 12, borderRadius: 14, backgroundColor: '#FFF8E6', borderWidth: 1.5, borderColor: '#F5D67B', gap: 8},
  referralLabel: {fontSize: 13, fontWeight: '800', color: C.navy},
  referralCode: {fontSize: 20, fontWeight: '900', letterSpacing: 2, color: C.navy},
  fine: {fontSize: 11, lineHeight: 16, color: '#5C7189'},
  versionRow: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, flexWrap: 'wrap'},
  versionPill: {flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#fff', borderWidth: 1, borderColor: '#DCE8F5', borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4},
  versionDot: {width: 8, height: 8, borderRadius: 4, backgroundColor: C.accent},
  versionText: {fontSize: 11, fontWeight: '900', color: C.navy, letterSpacing: 0.3},
  attempt: {flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 6},
  scorePill: {paddingVertical: 6, paddingHorizontal: 12, borderRadius: 999},
  scoreText: {fontSize: 13, fontWeight: '900'},
  badges: {flexDirection: 'row', flexWrap: 'wrap', gap: 10},
  badge: {flexBasis: '30%', flexGrow: 1, alignItems: 'center', gap: 5, paddingVertical: 10, paddingHorizontal: 6, borderRadius: 16, backgroundColor: '#fff', borderWidth: 1.5, borderColor: '#DCE8F5'},
  badgeText: {fontSize: 11, fontWeight: '800', color: C.navy, textAlign: 'center'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 8},
  recentChip: {minHeight: 40, paddingHorizontal: 14, justifyContent: 'center', borderRadius: 14, backgroundColor: C.soft, borderWidth: 1, borderColor: '#D3E6FB', maxWidth: 180},
  recentText: {fontSize: 14, fontWeight: '800', color: C.accent},
  settingRow: {padding: 10, minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 13, borderRadius: 16},
  settingDivider: {borderBottomWidth: 1, borderBottomColor: '#EAF2FB'},
});
