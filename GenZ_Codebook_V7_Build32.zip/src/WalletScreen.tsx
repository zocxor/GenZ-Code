import AccountTokens from './AccountTokens';
import {BACKEND_URL} from './backend';
/**
 * Wallet: the token balance, what was bought, and the permanent transaction
 * history. The history comes from the account's Firestore ledger
 * (users/{uid}/tokenLedger) — purchases are recorded there before the tokens
 * are credited, so the list survives logout, reinstall and device change.
 * Earned and spent tokens are still device-local in this release; their
 * history joins the ledger in the next wallet update.
 */
import {SPARK_MODE} from '../shared/deployment';
import React, {useEffect, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, ActivityIndicator, Linking} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Button, IconTile, SectionHeader, FadeIn, Skeleton, type IconName} from './ui';
import {useAccountUser} from './services';
import {fetchTokenTxns, fetchTokenWallet, currentUid, type TokenTxnRow, type TokenWallet} from './tokenLedger';
import {restorePurchases} from './billing';
import {fetchSubscription, reconcileSubscriptions} from './subscription';
import {isPremiumActive, type SubscriptionDoc} from '../shared/subscriptions';
import {watchRewardedAd} from './ads';
import {earnTokens, setTokenBalance, creditReferrals, type Action} from './learning';
import {reconcileReferralCredits} from './referral';
import {TOKENS, type TokensState} from '../shared/tokens';

const TYPE_LABEL: Record<string, string> = {
  purchase: 'Credit purchase',
  subscription: 'Premium Credits',
  migration: 'Opening balance',
  daily: 'Daily reward',
  ad: 'Rewarded ad',
  game: 'Quiz reward',
  spend: 'Spent',
  adjustment: 'Adjustment',
  feature_fee: 'Community feature payment',
  feature_refund: 'Daily Code refund',
  referral: 'Referral bonus',
};

/** Icon tile per transaction type — gold for purchases/rewards, purple for Premium. */
const TYPE_TILE: Record<string, {icon: IconName; from: string; to: string}> = {
  purchase: {icon: 'card-outline', from: C.gold, to: '#D9930D'},
  subscription: {icon: 'star', from: C.purple, to: '#4B2FD6'},
  migration: {icon: 'flag-outline', from: C.accent, to: C.navy},
  daily: {icon: 'gift-outline', from: C.gold, to: '#D9930D'},
  ad: {icon: 'play-circle-outline', from: C.accent, to: C.navy},
  game: {icon: 'trophy-outline', from: C.purple, to: '#4B2FD6'},
  spend: {icon: 'remove-circle-outline', from: '#E5484D', to: C.danger},
  feature_fee: {icon:'remove-circle-outline',from:C.purple,to:C.navy},
  feature_refund: {icon:'arrow-undo-outline',from:C.teal,to:C.blue},
  adjustment: {icon: 'swap-horizontal-outline', from: C.accent, to: C.navy},
  referral: {icon: 'people-outline', from: C.gold, to: '#D9930D'},
};

function fmtDate(at: number): string {
  if (!at) return '';
  return new Date(at).toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'});
}

export default function WalletScreen({tokens, onTokensAction, onOpenShop}: {tokens: TokensState; onTokensAction: (a: Action) => void; onOpenShop: () => void}) {
  const user = useAccountUser();
  const [wallet, setWallet] = useState<TokenWallet | null>(null);
  const [txns, setTxns] = useState<TokenTxnRow[]>([]);
  const [loading, setLoading] = useState(!!user);
  const [restoring, setRestoring] = useState(false);
  const [restoreMsg, setRestoreMsg] = useState('');
  const [earning, setEarning] = useState(false);
  const [sub, setSub] = useState<SubscriptionDoc | null>(null);

  const refresh = async () => {
    const uid = currentUid();
    if (!uid) {setLoading(false); return;}
    setLoading(true);
    // Reconcile first: an owned purchase that never got credited lands now.
    await restorePurchases().catch(() => {});
    await reconcileSubscriptions().catch(() => {});
    // Referral: a friend who joined with this user's code pays +100 into
    // this user's ledger; credit it locally now. Runs BEFORE the wallet
    // fetch below, so the wallet read already includes the referral and
    // the setTokenBalance drift repair converges instead of wiping it.
    const freshReferrals = await reconcileReferralCredits(uid, tokens.credited, tokens.balance).catch(() => [] as string[]);
    if (freshReferrals.length) onTokensAction(creditReferrals(freshReferrals));
    const [w, list, s] = await Promise.all([fetchTokenWallet(uid), fetchTokenTxns(uid), fetchSubscription()]);
    if (w && w.balance !== tokens.balance) onTokensAction(setTokenBalance(w.balance));
    setWallet(w);
    setTxns(list);
    setSub(s);
    setLoading(false);
  };

  useEffect(() => {void refresh();}, []);

  const restore = async () => {
    setRestoring(true);
    setRestoreMsg('');
    const r = await restorePurchases();
    await refresh();
    setRestoreMsg(r.restored > 0 ? `${r.restored} purchase${r.restored > 1 ? 's' : ''} restored to your wallet.` : 'Nothing to restore — every purchase is already credited.');
    setRestoring(false);
  };

  const earnAd = async () => {
    if (earning) return;
    setEarning(true);
    const ok = await watchRewardedAd();
    if (ok) onTokensAction(earnTokens(TOKENS.REWARDED_AD));
    setEarning(false);
  };

  return (
    <ScrollView contentContainerStyle={s.content}><AccountTokens/>
      <FadeIn>
        <LinearGradient colors={[C.navy, '#1B3A8F', C.accent]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.hero}>
          <View style={s.between}>
            <View style={{flex: 1}}>
              <Text style={s.heroEyebrow}>YOUR BALANCE</Text>
              <Text style={s.heroBalance}>{tokens.balance.toLocaleString()} Credits</Text>
            </View>
            <IconTile icon="star" from={C.gold} to="#D9930D" size={44} iconSize={22} />
          </View>
          <View style={s.totals}>
            <View style={s.total}>
              <Text style={s.totalNum}>{wallet ? wallet.purchasedTotal.toLocaleString() : '—'}</Text>
              <Text style={s.totalLabel}>Purchased</Text>
            </View>
            <View style={s.total}>
              <Text style={s.totalNum}>{wallet ? wallet.balance.toLocaleString() : '—'}</Text>
              <Text style={s.totalLabel}>On record</Text>
            </View>
          </View>
          <Text style={s.heroCaption}>“On record” is your account balance — opening this screen syncs them.</Text>
        </LinearGradient>
      </FadeIn>

      {sub?.productId && <FadeIn delay={60}>
        <View style={s.card}>
          <View style={s.cardHead}>
            <IconTile icon="star" from={C.purple} to="#4B2FD6" size={44} iconSize={22} />
            <Text style={s.sectionTitle}>Your Premium subscription</Text>
          </View>
          {isPremiumActive(sub) ? (
            <Text style={s.body}>Premium {sub.productId === 'premium_yearly' ? 'Yearly' : 'Monthly'} is active. {sub.autoRenewing ? 'Renews' : 'Access ends'} {new Date(sub.expiryTime).toLocaleDateString()}.</Text>
          ) : <Text style={s.body}>Your Premium subscription is inactive.</Text>}
          <Button title="Manage in Google Play" icon="settings-outline" light onPress={() => void Linking.openURL('https://play.google.com/store/account/subscriptions?package=com.genzmode.app')} />
        </View>
      </FadeIn>}

      <FadeIn delay={120}>
        <View style={s.card}>
          <View style={s.cardHead}>
            <IconTile icon="add-circle-outline" from={C.accent} to={C.navy} size={44} iconSize={22} />
            <Text style={s.sectionTitle}>Get more Credits</Text>
          </View>
          {!!BACKEND_URL&&<Button title="Buy Credits" icon="card-outline" onPress={onOpenShop} />}
          <Button title={earning ? 'Watching…' : 'Watch an ad · +10 Credits'} icon="play-circle-outline" light disabled={earning} onPress={() => void earnAd()} />
          <Text style={s.caption}>The rewarded ad pays only when you watch it through.</Text>
        </View>
      </FadeIn>

      <SectionHeader eyebrow="HISTORY" title="Transaction history" />
      <FadeIn delay={160}>
        <View style={s.card}>
          <Button title={restoring ? 'Checking…' : 'Restore purchases'} icon="refresh-outline" light disabled={restoring} onPress={() => void restore()} />
          {restoreMsg ? <Text style={s.caption}>{restoreMsg}</Text> : null}
          {!user ? (
            <Text style={s.body}>Sign in to keep a permanent purchase history.</Text>
          ) : loading ? (
            <>
              <ActivityIndicator color={C.accent} />
              <Skeleton height={40} />
              <Skeleton height={40} width="85%" />
              <Skeleton height={40} width="70%" />
            </>
          ) : txns.length === 0 ? (
            <View style={s.empty}>
              <IconTile icon="receipt-outline" from={C.accent} to={C.navy} size={48} iconSize={24} />
              <Text style={s.body}>No transactions yet.</Text>
            </View>
          ) : (
            txns.map(t => {
              // An admin token release is a ledger entry {type: 'adjustment',
              // ref: 'admin-grant'} — show it as "Credits released" with the
              // admin's note, not the generic "Adjustment" label. Any other
              // adjustment (different ref) keeps the "Adjustment" label.
              const isAdminGrant = t.type === 'adjustment' && t.ref === 'admin-grant';
              const tile = TYPE_TILE[t.type] ?? {icon: 'ellipse-outline' as IconName, from: C.accent, to: C.navy};
              return (
                <View key={t.id} style={s.row}>
                  <IconTile icon={tile.icon} from={tile.from} to={tile.to} size={40} iconSize={20} />
                  <View style={{flex: 1}}>
                    <Text style={s.rowTitle}>{isAdminGrant ? 'Credits released' : TYPE_LABEL[t.type] ?? t.type}</Text>
                    <Text style={s.caption}>{fmtDate(t.createdAt)}{!isAdminGrant && t.ref ? ` · ${t.ref}` : ''}</Text>
                    {t.note ? <Text style={s.caption}>{t.note}</Text> : null}
                  </View>
                  <Text style={[s.amount, t.amount >= 0 ? s.pos : s.neg]}>{t.amount >= 0 ? '+' : ''}{t.amount.toLocaleString()}</Text>
                </View>
              );
            })
          )}
        </View>
      </FadeIn>

      <Text style={s.fine}>Each Google Play order credits only once.</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  cardHead: {flexDirection: 'row', alignItems: 'center', gap: 12},
  hero: {borderRadius: 20, padding: 16, gap: 8},
  heroEyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.6, color: '#FFD97A'},
  heroBalance: {fontSize: 28, fontWeight: '900', color: '#fff', letterSpacing: -.5},
  heroCaption: {fontSize: 13, lineHeight: 19, color: 'rgba(255,255,255,0.85)'},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 12, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: .09, shadowRadius: 14, elevation: 3},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  sectionTitle: {fontSize: 18, fontWeight: '800', letterSpacing: -.4, color: C.navy, flex: 1, flexWrap: 'wrap'},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  totals: {flexDirection: 'row', gap: 12},
  total: {flex: 1, backgroundColor: 'rgba(255,255,255,0.14)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)', borderRadius: 16, padding: 12, alignItems: 'center', gap: 2},
  totalNum: {fontSize: 18, fontWeight: '900', color: '#fff'},
  totalLabel: {fontSize: 11, fontWeight: '700', color: '#C7D8F5'},
  empty: {alignItems: 'center', gap: 12, paddingVertical: 8},
  row: {flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderTopWidth: 1, borderTopColor: '#e3eefb'},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.navy},
  amount: {fontSize: 16, fontWeight: '900'},
  pos: {color: C.success},
  neg: {color: C.danger},
});
