/**
 * Encode Message: plain text → Gen Z codes, using the whole GenZ Codebook dictionary
 * (bundled entries, published edits and live community words such as HOD).
 * - Converts every word or phrase (up to 6 words, longest first) that has a sensible code;
 *   all other words, punctuation and spacing stay exactly as typed.
 * - Case-insensitive; phrases never join across punctuation.
 * - Leetspeak-style codes ("j00") and emoji are not used unless they are everyday codes
 *   (gr8, 2nite, <3), and a single word is only replaced by a code that is not longer than it,
 *   so the message stays readable. Each replacement carries its alternative codes.
 * Runs on the device; nothing is sent to a server.
 */
import {terms, onContentChange, type Term} from './content';

export type EncodeSegment = {text: string; code?: string; phrase?: string; options?: string[]};
export type EncodeResult = {segments: EncodeSegment[]; output: string; replaced: number; words: number};
type Candidate = {code: string; score: number; community: boolean};

const POPULAR = new Set(['lol','brb','ttyl','tbh','idk','u','ur','r','thx','ty','yw','pls','plz','bc','omg','cu','2nite','<3','fr','np','rn','hru','hbu','wyd','wbu','ily','gn','gm','imo','imho','smh','ngl','btw','irl','nvm','l8r','gr8','b4','2day','tmrw','idc','jk','bff','afaik','fyi','asap','ikr','gtg','g2g','k','ok','ppl','msg','txt','abt','cuz','tho','w8','sry','gg','dm','lmk','hmu','omw','ofc','bday','2','4','b','c','y','n','tho','pic','pics','info','convo','fav','obv','prob','def','srsly','tbf','fomo','goat','af','sus','bro','sis']);
const MAX_WORDS = 6;
const fold = (s: string) => s.toLowerCase().replace(/[’‘]/g, "'").replace(/[^\p{L}\p{N}' ]+/gu, ' ').replace(/\s+/g, ' ').trim();
const isLeet = (code: string) => /\d/.test(code) && /[a-z]/i.test(code);

function candidateFor(t: Term): Candidate | null {
  if (t.sensitivity !== 'None' || !t.expression || t.expression.length > 12) return null;
  const code = t.expression, lower = code.toLowerCase(), popular = POPULAR.has(lower), community = t.status === 'Community';
  if (!popular && (isLeet(code) || t.category === 'Emoji' || !/[\p{L}\p{N}]/u.test(code))) return null;
  let score = t.priority;
  if (popular) score += 300;
  if (community) score += 80;
  if (t.decode) score += 40;                 // round-trips through Decode
  if (t.language === 'English' || t.language === 'Universal') score += 60;
  if (t.category === 'Chat') score += 15;
  if (/^[a-z]{2,5}$/i.test(code)) score += 10;
  return {code, score, community};
}

type Index = Map<string, Candidate[]>;
let built: Index | null = null;
onContentChange(() => {built = null;});
function index(): Index {
  if (built) return built;
  const map: Index = new Map();
  for (const t of terms) {
    const c = candidateFor(t);
    if (!c) continue;
    // Meanings list alternatives with "/", ";" or "or". Commas stay: "I know, right?" is one meaning.
    const meanings = new Set([...t.full.split(/\s*[/;]\s*|\s+or\s+/), ...(c.community ? [t.meaning] : [])]);
    for (const raw of meanings) {
      const key = fold(raw);
      if (!key || key.split(' ').length > MAX_WORDS || fold(t.expression) === key) continue;
      for (const k of new Set([key, key.replace(/ /g, '')])) {
        const list = map.get(k) ?? [];
        if (!list.some(x => x.code.toLowerCase() === c.code.toLowerCase())) list.push(c);
        map.set(k, list);
      }
    }
  }
  for (const list of map.values()) list.sort((a, b) => b.score - a.score || a.code.length - b.code.length);
  return built = map;
}

/** Codes acceptable for this phrase: readable, and for a single word not longer than it. */
function usable(list: Candidate[], words: number, phrase: string) {
  return list.filter(c => words > 1 ? c.score >= 80 : (c.score >= 120 && (POPULAR.has(c.code.toLowerCase()) || c.community || c.code.length < phrase.length)));
}
/** Gen Z texting is lowercase; keep caps only when the user typed in caps; community codes keep their own case. */
function styled(c: Candidate, original: string) {
  if (!/[a-z]/i.test(c.code)) return c.code;
  if (original.length > 1 && original === original.toUpperCase() && /[A-Z]/.test(original)) return c.code.toUpperCase();
  return c.community ? c.code : c.code.toLowerCase();
}

/** @param choices optional per-phrase overrides (folded phrase → chosen code), from tapping a code. */
export function encode(message: string, choices: Readonly<Record<string, string>> = {}): EncodeResult {
  if (message.length > 2000) throw new RangeError('Message exceeds 2000 characters');
  const tokens = message.match(/[\p{L}\p{N}']+|[^\p{L}\p{N}']+/gu) ?? [];
  const map = index();
  const segments: EncodeSegment[] = [];
  let replaced = 0, words = 0;
  for (let i = 0; i < tokens.length;) {
    const tok = tokens[i]!;
    if (!/[\p{L}\p{N}]/u.test(tok)) {segments.push({text: tok}); i++; continue;}
    let hit: {end: number; phrase: string; list: Candidate[]} | null = null;
    let count = 0, phraseText = '';
    for (let j = i; j < tokens.length && count < MAX_WORDS; j += 2) {
      const w = tokens[j]!;
      if (!/[\p{L}\p{N}]/u.test(w)) break;
      count++; phraseText = phraseText ? phraseText + ' ' + w : w;
      const key = fold(phraseText);
      if (count === 1 && key.length < 2) {const sep = tokens[j + 1]; if (sep === undefined || !/^[ \t]+$/.test(sep)) break; continue;}
      const list = usable(map.get(key) ?? map.get(key.replace(/ /g, '')) ?? [], count, key);
      if (list.length) hit = {end: j, phrase: key, list};
      const sep = tokens[j + 1];
      if (sep === undefined || !/^[ \t]+$/.test(sep)) break;
    }
    if (hit) {
      const original = tokens.slice(i, hit.end + 1).join('');
      const options = [...new Set(hit.list.slice(0, 5).map(c => styled(c, original)))];
      const chosen = choices[hit.phrase] && options.includes(choices[hit.phrase]!) ? choices[hit.phrase]! : options[0]!;
      segments.push({text: original, code: chosen, phrase: hit.phrase, options});
      replaced++; words += (hit.end - i) / 2 + 1;
      i = hit.end + 1;
    } else {segments.push({text: tok}); words++; i++;}
  }
  return {segments, output: segments.map(s => s.code ?? s.text).join(''), replaced, words};
}
