# GenZ Codebook — Project Guide (read this first)

**For every developer or AI assistant who updates this project.** Read the whole page before changing anything. If the code and an older document disagree, the code and this guide win. Last updated: 14 November 2026, Build 37.

---

## 1. What this project is

| Item | Value |
|---|---|
| App | **GenZ Codebook** — Android app (Expo SDK 54, React Native 0.81, Hermes) |
| Publisher | Zocxorian Technologies (brand ZTechX) · support: genzcodebook@gmail.com |
| Android package | `com.genzmode.app` (**never change**) |
| Google Play | https://play.google.com/store/apps/details?id=com.genzmode.app |
| Firebase project | `gen-z-code-55caf` (Blaze plan) — Auth, Firestore, Cloud Functions (Node 22, `us-central1`), Hosting |
| Website / policies | https://gen-z-code-55caf.web.app · `/privacy.html` · `/delete-account.html` |
| Admin portal | https://gen-z-code-55caf.web.app/admin/ |
| Build system | GitHub Actions in **ZIP mode** (see section 4) |

## 2. Current status (Build 37)

- Build 36 was submitted to Google Play review in November 2026.
- **Build 37 switches Google Play purchases ON** (`shared/backend.json` → `"tokenPurchasesEnabled": true`): Credit packs and Premium appear in Get Credits. Every purchase is verified on the server before Credits are added.
- Google Play setup (owner, 14 Nov 2026): payments profile ✅, US tax form W‑8BEN approved ✅, 7 Credit packs active ✅, 2 Premium subscriptions active ✅, service account `genz-play-verification` with Play permissions ✅, secret `PLAY_SERVICE_ACCOUNT_JSON` with the compute account as Secret Accessor ✅.
- Remaining owner steps for Build 37 — section 9.

## 3. Folder map

| Folder / file | What it is |
|---|---|
| `App.tsx`, `index.ts` | App entry, navigation, main screens wiring |
| `src/` | App screens and logic (Community/chat, posts, wallet, shop, profile, account, billing, ads, safety) |
| `shared/` | Code shared by the app, the admin portal and the backend: Credit packs (`tokens.ts`), Premium (`subscriptions.ts`), links and e-mail (`brand.ts`), backend URL + purchase switch (`backend.json`), `deployment.ts`, referral, chat, publishing |
| `functions/` | Firebase Cloud Functions (backend). Default prices in `functions/src/communityPolicy.json` |
| `firebase/` | `firestore.rules`, `firestore.indexes.json`, `storage.rules`, `rules-tests/` |
| `admin/` | Admin portal (Vite + React, served at `/admin`) and the public website pages in `admin/site/` (home, privacy, delete account). Builds into `admin/dist` → Firebase Hosting |
| `android/` | Native Android project, **maintained by hand**. Signing config is in `android/app/build.gradle`. `google-services.json` is here |
| `assets/` | App icon, adaptive icon, splash, brand images (**do not change**) |
| `data/`, `content-inputs/` | Dictionary database (8,584 entries) and its source data |
| `scripts/` | Build and check helpers |
| `tests/`, `tests-e2e/`, `functions/tests/`, `admin/tests/` | Automated tests |
| `vps/` | Old VPS backend, **not used since Build 29**. Keep it; don't delete |
| `docs/` | Reports. `V7_UPGRADE_REPORT.md` has the details of Builds 32–36. Older files are history and may show old prices |
| `.github/workflows/` | Build and deploy workflows |

### Backend functions (all in `us-central1`)

| Function | Job |
|---|---|
| `communityFeature` | Callable API used by the app and portal: Credits balance, fees, words, posts, chat pass, Daily Code Display, badges, admin actions |
| `publishDailyCodes` | Runs every 5 minutes, publishes scheduled Daily Codes |
| `cleanupContributions` | When a user deletes their account (status `deleted`), removes their contributions and their sign-in |
| `admobReward` | Verified rewarded-ad callback from AdMob (+10 Credits) |
| `verifyPurchase` | Verifies Credit pack purchases with Google Play (needs `PLAY_SERVICE_ACCOUNT_JSON`) |
| `verifySubscription` | Verifies Premium purchases (needs `PLAY_SERVICE_ACCOUNT_JSON`) |
| `rtdnHandler` | Google Play subscription events from Pub/Sub topic `genz-codebook-rtdn` (renewals, cancellations) |

The app calls these by name and region. **Do not rename functions or change the region.**

## 4. How building and deploying works

The GitHub repository holds **exactly one project ZIP at its root** plus the `.github/workflows/` folder. Every workflow unpacks that ZIP. (If the extracted project is committed at the root instead, the workflows use that.)

| Workflow (GitHub → Actions) | What it does |
|---|---|
| **Android APK** | Builds a test APK. Tick **"Also build the Play Store AAB"** to also build the signed Play bundle → artifact `genz-code-play-aab` |
| **Deploy Firebase** | Runs the security-rules and backend tests first (deploy is blocked if any fail), then deploys the chosen target |
| Firestore rules tests | Runs only the rules tests |
| GenZ Codebook quality | Runs automatically on push: typecheck, tests, security scan, admin build |
| Deploy VPS backend | Old, not used |

**Deploy Firebase targets**

| Target | Deploys | Use when |
|---|---|---|
| `community` (default) | rules, indexes, `communityFeature`, `publishDailyCodes`, `cleanupContributions`, `admobReward`, hosting | Most updates |
| `everything` | rules, indexes, hosting, **all** functions | Purchase/Premium functions changed (`verifyPurchase`, `verifySubscription`, `rtdnHandler`) |
| `admin-portal` | hosting only (admin portal + website pages) | Only website/admin/privacy page changed |
| `rules-and-indexes` | Firestore rules + indexes | Only rules changed |
| `functions` | all functions | Only backend code changed |
| `daily-code`, `spark` | older, narrower targets | Rarely |

**Order:** deploy Firebase first, then build and upload the app.

### Secrets (never in code, never in the ZIP, never in chat)

| Secret | Where it lives | Used for |
|---|---|---|
| `FIREBASE_SERVICE_ACCOUNT` | GitHub → Settings → Secrets and variables → Actions | Deploy Firebase workflow |
| `GENZ_UPLOAD_KEYSTORE_BASE64`, `GENZ_UPLOAD_STORE_PASSWORD`, `GENZ_UPLOAD_KEY_ALIAS`, `GENZ_UPLOAD_KEY_PASSWORD` | GitHub Actions secrets | Signing the Play AAB (upload key) |
| `PLAY_SERVICE_ACCOUNT_JSON` | Google Cloud **Secret Manager**, project `gen-z-code-55caf` | Play purchase verification (to be added, section 9) |
| `VPS_*` | GitHub | Old VPS, not used |

Public values that are **allowed** in code: `google-services.json`, the Firebase web config, AdMob IDs, the Google sign-in web client ID, and `android/app/debug.keystore` (a shared internal test key, password "android", only for test APKs).

### Version numbers

- **Version name** shown to users: `1.0.0` — in `app.json` (`expo.version`) and `android/app/build.gradle` (`versionName`). Raise it for user-visible releases (for example `1.0.1`, `1.1.0`) in **both** files.
- **Build label**: `37` — `app.json` (`expo.android.versionCode`) and the default in `android/app/build.gradle` (`genzVersionCode ?: '37'`). Raise it by one for every new project ZIP (next: **38**) in **both** files.
- **Play upload version code** is set **automatically** by the Android APK workflow: `100 + GitHub run number`. Every new workflow run gives Play a higher number, so the owner never has to edit it.

## 5. Rules — never break these

1. **Never delete user data**, Firestore collections, documents or working features. No destructive migrations.
2. **Never rename** Firestore collections, field names, ledger transaction types (`purchase`, `adjustment`, `admin_debit`, `migration`, `feature_*` …) or API properties. Add new fields instead.
3. **Never change Play product IDs or base-plan IDs** (section 8). They must match Play Console exactly.
4. **Never change** the package name, the Firebase project, function names or region.
5. **Never change the signing setup** (`android/app/build.gradle` signing blocks, the workflow signing steps) or release credentials.
6. **Never change** the app icon, adaptive icon, splash screen, launcher name or branding. (Only the website favicon may change.)
7. **Never put secrets** (keystores, passwords, service-account JSON keys) into code, the ZIP, GitHub files or chat.
8. **Do not run `expo prebuild`** — it would overwrite the hand-maintained `android/` project.
9. **Do not flip `SPARK_MODE`** in `shared/deployment.ts` — it is used in about 15 files. Make narrow, specific switches instead.
10. **Credits are server-verified.** The spendable balance is calculated by the backend from validated ledger entries. The app must never write or trust a balance itself. The old `tokenWallet/wallet` document is a legacy cache that old app versions read — the server must not rewrite it.
11. **Keep Google Play policy features working:** report + block users, the community-rules agreement before first post/message, in-app and web account deletion, the privacy policy link, e-mail verification before community use. **No dead buttons** — if a feature is off, hide it.
12. **Do not loosen `firebase/firestore.rules`** without adding tests in `firebase/rules-tests/rules.test.mjs`.
13. **Do not claim something works unless it was built and tested.** If something needs a key, permission or account the owner must provide, stop and ask — never invent credentials.

## 6. Credits (money system)

| Action | Price / reward | Notes |
|---|---|---|
| New dictionary word | **First one each day free** (UTC), then **100 Credits** | Server: `users/{uid}/allowances/code-YYYY-MM-DD` |
| Daily Code Display | **1 free per month** (UTC), then **100 Credits** | Server: `users/{uid}/allowances/daily-YYYY-MM`. Cancel/reject of a free one gives the free use back |
| Community post | 50 Credits | When paid community is on |
| Chat pass | 30 Credits per UTC day | When paid community is on |
| Verified badge | 5,000 Credits | |
| Daily reward | +10 Credits | Once a day |
| Rewarded ad | +10 Credits | Verified by `admobReward` |
| Premium | 10,000 Credits/month or 200,000/year | Plus no interstitial ads |

- **Default prices:** `functions/src/communityPolicy.json` (needs a functions deploy).
- **Live prices:** Admin portal → Settings (saved in Firestore `config/app.prices`, overrides the defaults immediately).
- If you change a price, also check the texts in `src/TokenShopScreen.tsx`, `src/AboutScreen.tsx` (Terms) and the tests.

## 7. Where to change common things

| To change | Edit | Then deploy / build |
|---|---|---|
| Prices (live) | Admin portal → Settings | Nothing |
| Default prices, free allowances | `functions/src/communityPolicy.json` | Deploy Firebase `community` + new app build if texts change |
| Social links, support e-mail, Play / privacy URLs | `shared/brand.ts` | New app build (+ `admin-portal` for the website) |
| Privacy policy text | `admin/site/privacy.html` | Deploy Firebase `admin-portal` |
| Terms of use text | `src/AboutScreen.tsx` | New app build |
| Credit packs (add/change) | Play Console **and** `shared/tokens.ts` **and** `functions/src/index.ts` (catalog) **and** `firebase/firestore.rules` (product table) | Deploy `everything` + new app build |
| Premium plans | Play Console **and** `shared/subscriptions.ts` **and** `functions/src/index.ts` (`SUBSCRIPTION_CATALOG`) | Deploy `everything` + new app build |

## 8. Google Play products (must match exactly)

**Credit packs — one-time products** (purchase option ID `buy`, type Buy, no quantities, Digital app sales, age rating 13+):

| Product ID | Name | Credits | USD |
|---|---|---|---|
| `tokens_1000` | 1,000 Credits | 1,000 | 1.99 |
| `tokens_2500` | 2,500 Credits | 2,500 | 2.99 |
| `tokens_5000` | 5,000 Credits | 5,000 | 3.99 |
| `tokens_10000` | 10,000 Credits | 10,000 | 5.99 |
| `tokens_25000` | 25,000 Credits | 25,000 | 10.99 |
| `tokens_50000` | 50,000 Credits | 50,000 | 15.99 |
| `tokens_100000` | 100,000 Credits | 100,000 | 25.99 |

The app consumes each pack after the server has verified and recorded it, so packs can be bought again.

**Premium — subscriptions** (auto-renewing, **no free trial or intro offer** — the server grants Credits at the start of every period):

| Product ID | Base plan ID | Period | Credits per period | USD |
|---|---|---|---|---|
| `premium_monthly` | `monthly` | Monthly | 10,000 | 4.99 |
| `premium_yearly` | `yearly` | Yearly | 200,000 | 39.99 |

## 9. Google Play purchases

**Done:** payments profile, tax form, 7 Credit packs, 2 subscriptions, Google Play Android Developer API enabled, service account `genz-play-verification@gen-z-code-55caf.iam.gserviceaccount.com` invited in Play Console (View financial data + Manage orders and subscriptions, GenZ Codebook only), secret `PLAY_SERVICE_ACCOUNT_JSON` (version 1) with `1095502586634-compute@developer.gserviceaccount.com` as Secret Manager Secret Accessor, Build 37 code (purchases on).

**Owner steps for Build 37, in this order:**
1. Google Cloud → Pub/Sub → create topic `genz-codebook-rtdn` (no default subscription) → on the topic, give `google-play-developer-notifications@system.gserviceaccount.com` the **Pub/Sub Publisher** role.
2. GitHub: replace the ZIP; also copy `.github/workflows/deploy-firebase.yml` (it now runs the purchase tests). Run **Deploy Firebase → everything**.
3. Play Console → GenZ Codebook → Monetize with Play → Monetization setup → **Real-time developer notifications**: topic `projects/gen-z-code-55caf/topics/genz-codebook-rtdn`, send a test notification, save.
4. Play Console → App content → **Data safety**: declare Financial info → Purchase history (collected, not shared; app functionality, fraud prevention).
5. Play Console → Settings → **License testing**: add tester Gmail accounts.
6. Build the AAB (Android APK workflow, AAB ticked), upload it to **Internal testing**, buy a Credit pack and Premium with a tester account, check Credits and Premium in the app, then promote to production.

**How it works:** the app buys through Google Play → sends the purchase to `verifyPurchase` / `verifySubscription` → the server checks it with Google Play using the service account → records it once (`processedTokens/{token}`, ledger `order-<Play order ID>`, `sub-<order ID>`) → the app consumes the pack / acknowledges the subscription. Renewals arrive through `rtdnHandler` (topic `genz-codebook-rtdn`) and are also re-checked when the app starts. A subscription belongs to the first account that verified it. Known limit: a refunded Credit pack is not taken back automatically (the admin can deduct Credits).

## 10. Checks that must pass before giving back a ZIP

```bash
# App (project root)
npm ci && npm run typecheck && npm test && node scripts/security-scan.mjs
npx expo export --platform android --clear      # bundle check

# Backend
cd functions && npm ci && npm run typecheck && npm run test:memory && cd ..

# Admin portal + website
cd admin && npm ci && npm test && npm run build && cd ..
```

Firestore rules tests need Java 21 + Firebase emulator (`npm run test:rules`). If that isn't available, they run automatically in the **Deploy Firebase** workflow, which refuses to deploy when they fail.

## 11. How to deliver an update (rules for the ZIP)

1. Make the smallest change that does the job. Keep the existing code style.
2. Raise the build label (section 4) in `app.json` **and** `android/app/build.gradle`.
3. Add a short section at the **top** of `docs/V7_UPGRADE_REPORT.md` (what changed, why, tests run, what to deploy) and update the first line of `README.md`.
4. Run the checks in section 10.
5. Give back **one complete project ZIP** — the whole project, not only changed files:
   - project files at the ZIP root (`package.json`, `android/`, `firebase.json` at the top level);
   - include hidden files (`.github/`, `.gitignore`, `.firebaserc`, `.dockerignore`);
   - exclude `node_modules/`, `.git/`, `.expo/`, `admin/dist/`, `functions/lib/`, build outputs, `*.log`, other ZIPs and any secrets;
   - name it `GenZ_Codebook_V7_BuildNN.zip`.

   ```bash
   zip -r ../GenZ_Codebook_V7_Build37.zip . -x 'node_modules/*' '*/node_modules/*' '.git/*' '.expo/*' 'admin/dist/*' 'functions/lib/*' '*.log' '*.zip'
   ```
6. Tell the owner, in plain words: which Deploy Firebase target to run (or none), whether a new app upload is needed, and anything they must do in Play Console or Firebase.

## 12. Owner's release steps

1. **GitHub repository:** delete the old ZIP from the root and upload the new one (keep **exactly one** ZIP). If the update changed any file in `.github/workflows/`, copy those files into the repository's `.github/workflows/` folder too.
2. **Backend (if the update says so):** Actions → **Deploy Firebase** → choose the target → Run. Wait for green.
3. **App:** Actions → **Android APK** → Run workflow → tick **Also build the Play Store AAB** → when green, download **genz-code-play-aab** and unzip it to get the `.aab`.
4. **Play Console:** Test and release → Production (or Internal testing first) → Create new release → upload the `.aab` → release notes → Next → Save → send for review / roll out.

## 13. Copy-paste message for an AI assistant

> I'm attaching the complete project ZIP of my Android app **GenZ Codebook**. Before changing anything, read `docs/PROJECT_GUIDE.md` and follow every rule in it (no renaming of product IDs, Firebase collections or fields; no changes to signing, icons or secrets; no deleting user data). My request: **[describe the change]**. Make the smallest change needed, run the checks in section 10, raise the build number, add a short entry at the top of `docs/V7_UPGRADE_REPORT.md`, and give me back **one complete ZIP of the whole project** in the same structure (section 11) — not only the changed files. Then tell me exactly what to deploy in Firebase and whether I need to upload a new version to Google Play. If anything needs a key, permission or account you don't have, ask me instead of guessing.

## 14. Other documents

- `docs/V7_UPGRADE_REPORT.md` — detailed changes, root causes and tests for Builds 32–36.
- `docs/SUBSCRIPTIONS.md`, `docs/PLAY_PRODUCTION_READINESS.md`, `docs/PLAY_DATA_SAFETY.md` — Play details.
- `docs/BUILD_APK.md` — Android build and upload-key details.
- `docs/ADMIN_PORTAL.md`, `docs/FIREBASE_SETUP.md`, `docs/BUILD29_BLAZE.md` — Firebase and portal setup.
- Everything else in `docs/` is historical.
