import test from 'node:test';
import assert from 'node:assert/strict';
import {levelStages, levelStage, quizRound} from '../src/discovery';
import {stages, unlocked, unlockedIn} from '../src/games';
import {parseTokens} from '../shared/tokens';
import {emptyState} from '../src/profile';
import {recordRound} from '../src/learning';

test('levels: 30 generated levels — 3 tracks x 10, five questions each, unique ids', () => {
  const levels = levelStages();
  assert.equal(levels.length, 30);
  const ids = levels.map(l => l.id);
  assert.equal(new Set(ids).size, 30);
  for (const track of ['chat', 'emoji', 'numbers']) {
    const inTrack = levels.filter(l => l.id.startsWith(track + '-'));
    assert.equal(inTrack.length, 10);
    assert.deepEqual(inTrack.map(l => l.id), Array.from({length: 10}, (_, i) => `${track}-${i + 1}`));
  }
  for (const l of levels) {
    assert.equal(l.questions.length, 5);
    for (const q of l.questions) {
      assert.equal(q.answers.length, 3);
      assert.ok(q.correct >= 0 && q.correct < 3);
      assert.ok(q.prompt.length > 0 && q.why.length > 0);
    }
  }
});

test('levels: the same level always deals the same questions, different levels deal different ones', () => {
  const a = levelStage('chat', 3);
  const b = levelStage('chat', 3);
  assert.deepEqual(a.questions, b.questions);
  const c = levelStage('chat', 4);
  assert.notDeepEqual(a.questions.map(q => q.prompt), c.questions.map(q => q.prompt));
  // The generator still behaves as before for daily/shuffle rounds.
  assert.equal(quizRound('Chat', '2026-11-08').id, 'daily-2026-11-08');
  assert.equal(quizRound('Chat', '2026-11-08').questions.length, 5);
});

test('levels: the Play tab has 34 levels and the unlock chain runs through them', () => {
  const all = [...stages, ...levelStages()];
  assert.equal(all.length, 34);
  assert.equal(stages.length, 4);
  // The first level is open; each later level needs 60% on the previous one.
  assert.equal(unlockedIn(all, 0, {}), true);
  assert.equal(unlockedIn(all, 1, {}), false);
  assert.equal(unlockedIn(all, 4, {context: 60}), true);
  assert.equal(unlockedIn(all, 5, {context: 60}), false);
  assert.equal(unlockedIn(all, 5, {context: 60, 'chat-1': 80}), true);
  assert.equal(unlockedIn(all, 33, {'numbers-9': 100}), true);
  // The original 4-stage helper still works on its own list.
  assert.equal(unlocked(0, {}), true);
  assert.equal(unlocked(1, {chat: 60}), true);
  // A best score on a generated level survives storage, so the chain holds after reload.
  const now = Date.now();
  const after = recordRound('chat-1', 4, 5, 'a-test-0001')(emptyState(), now);
  assert.equal(after.best['chat-1']?.v, 80);
  const reloaded = parseTokens({unlockedLevels: ['chat-1']});
  assert.deepEqual(reloaded.unlockedLevels, ['chat-1']);
});
