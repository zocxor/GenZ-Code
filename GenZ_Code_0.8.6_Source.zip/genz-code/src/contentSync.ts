/**
 * Remote content delivery: published CMS entries reach the app without an APK update.
 *
 * - Only `publishedContent` documents are readable by the public (rules); drafts never leave
 *   the admin side. Each entry is validated with the shared schema before use.
 * - The validated overlay is cached on the device, so updates keep working offline.
 * - Bundled entries are never modified; edits overlay them and removals hide them.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import {applyOverlay, bundledTerms, terms, contentRevision, Term} from './content';
import {validateEntry, ID_PATTERN, normalizeTerm} from '../shared/contentSchema';
import {COMMUNITY_ID_PATTERN, COMMUNITY_STATUSES, CommunityStatus} from '../shared/community';
import type {SecurityEventLog} from './secure/events';
import {logger} from './secure/logger';

export const OVERLAY_KEY = 'genz-code-content-overlay';
const REFRESH_EVERY = 6 * 3600_000, PAGE = 300, MAX_ENTRIES = 5000;
type Cached = {cursor: number; cursorId: string; checkedAt: number; entries: Record<string, Term | {removed: true}>};
let cache: Cached = {cursor: 0, cursorId: '', checkedAt: 0, entries: {}};
let refreshing: Promise<number> | null = null;
const bundledById = new Map(bundledTerms.map(t => [t.id, t]));

/** Convert a validated published document into an app Term, keeping bundled provenance. */
export function toTerm(raw: unknown): Term | {removed: true} | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.id !== 'string' || !ID_PATTERN.test(r.id)) return null;
  if (r.status === 'archived') return {removed: true};
  if (r.status !== 'published') return null;
  const v = validateEntry(r, {requireId: true});
  if (!v.ok) return null;
  const e = v.entry, base = bundledById.get(e.id);
  const version = typeof r.version === 'number' && Number.isInteger(r.version) ? r.version : 1;
  return {
    ...(base ?? {source: null, senses: [], keywords: [], decoderAliases: [], reply: '', priority: 120, numericContext: /^\d+$/.test(e.term)}),
    id: e.id, expression: e.term, full: e.full, meaning: e.meaning, example: e.example,
    category: e.category, categories: base ? [...new Set([e.category, ...base.categories])] : [e.category],
    subcategory: e.subcategory, aliases: e.variations, region: e.region, tone: e.tone, language: e.language,
    sensitivity: e.sensitivity, caution: e.caution, status: 'Editor reviewed', decode: e.term.length > 1, contentVersion: version,
  } as Term;
}
// ---------- community words (published instantly by signed-in users) ----------
export const COMMUNITY_KEY = 'genz-code-community-words';
const COMMUNITY_REFRESH = 10 * 60_000, MAX_COMMUNITY = 3000;
export type CommunityRecord = {status: CommunityStatus; term?: string; meaning?: string; example?: string; category?: string};
type CommunityCache = {cursor: number; cursorId: string; checkedAt: number; words: Record<string, CommunityRecord>};
let community: CommunityCache = {cursor: 0, cursorId: '', checkedAt: 0, words: {}};
let refreshingCommunity: Promise<number> | null = null;

/** Validate one community record; anything unexpected is dropped, never shown. */
export function toCommunityRecord(id: string, raw: unknown): CommunityRecord | null {
  if (!COMMUNITY_ID_PATTERN.test(id) || !raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const status = r.status as CommunityStatus;
  if (!(COMMUNITY_STATUSES as readonly string[]).includes(status)) return null;
  if (status !== 'live') return {status};
  const v = validateEntry({term: r.term, meaning: r.meaning, example: r.example, category: r.category});
  if (!v.ok) return null;
  return {status, term: v.entry.term, meaning: v.entry.meaning, example: v.entry.example, category: v.entry.category};
}
export function communityTerm(id: string, r: CommunityRecord): Term | null {
  if (r.status !== 'live' || !r.term || !r.meaning || !r.category) return null;
  return {
    id, expression: r.term, full: r.meaning.length > 120 ? r.meaning.slice(0, 117) + '…' : r.meaning, meaning: r.meaning, example: r.example ?? '',
    category: r.category, categories: [r.category], language: 'English', region: 'Community', tone: 'Context-dependent', reply: '',
    caution: 'Added by the GenZ Code community. Meanings vary, so ask if you’re unsure.', aliases: [], status: 'Community', source: null, senses: [],
    priority: 110, decode: r.term.length > 1, decoderAliases: [], numericContext: /^\d+$/.test(r.term), sensitivity: 'None', keywords: [], subcategory: '', contentVersion: 1,
  };
}
let bundledWords: Set<string> | null = null;
const wordsOf = (t: Term) => [t.expression, ...t.aliases].map(normalizeTerm);

function apply() {
  const entries: Term[] = [], removed: string[] = [];
  for (const [id, t] of Object.entries(cache.entries)) {if ('removed' in t) removed.push(id); else entries.push(t);}
  // A community word never replaces a bundled or editor-published word with the same spelling.
  if (!bundledWords) bundledWords = new Set(bundledTerms.flatMap(wordsOf));
  const taken = new Set(bundledWords);
  for (const t of entries) for (const w of wordsOf(t)) taken.add(w);
  for (const [id, r] of Object.entries(community.words)) {
    const t = communityTerm(id, r);
    if (!t) {removed.push(id); continue;}
    const key = normalizeTerm(t.expression);
    if (taken.has(key)) continue;
    taken.add(key); entries.push(t);
  }
  applyOverlay(entries, removed);
}

let lookup: {rev: number; map: Map<string, Term>} | null = null;
/** The entry already using this spelling (expression or alias), if any. */
export function findExistingTerm(word: string): Term | undefined {
  if (!lookup || lookup.rev !== contentRevision) {
    const map = new Map<string, Term>();
    for (const t of terms) for (const w of wordsOf(t)) if (!map.has(w)) map.set(w, t);
    lookup = {rev: contentRevision, map};
  }
  return lookup.map.get(normalizeTerm(word));
}

async function saveCommunity() {
  const words = Object.entries(community.words);
  if (words.length > MAX_COMMUNITY) community.words = Object.fromEntries(words.slice(words.length - MAX_COMMUNITY));
  await AsyncStorage.setItem(COMMUNITY_KEY, JSON.stringify(community));
}
/** Show a word the user just published immediately, before the next refresh. */
export async function addLocalCommunityWord(id: string, raw: unknown) {
  const r = toCommunityRecord(id, {...(raw as object), status: 'live'});
  if (!r) return;
  community.words = {...community.words, [id]: r};
  apply();
  await saveCommunity().catch(() => logger.warn('content', 'Community cache not saved'));
}

/** Fetch community words changed since the last cursor. Throttled; returns number of changes. */
export function refreshCommunity(force = false): Promise<number> {
  if (refreshingCommunity) return refreshingCommunity;
  if (!force && Date.now() - community.checkedAt < COMMUNITY_REFRESH) return Promise.resolve(0);
  refreshingCommunity = (async () => {
    const [{collection, query, orderBy, startAfter, startAt, limit, getDocs, documentId, Timestamp}, {cloudDb}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    const from = (at: number, id: string) => id ? startAfter(Timestamp.fromMillis(at), id) : startAt(Timestamp.fromMillis(at));
    let changes = 0, cursor = community.cursor, cursorId = community.cursorId;
    const words = {...community.words};
    for (let page = 0; page < 20; page++) {
      const snap = await getDocs(query(collection(cloudDb(), 'communityWords'), orderBy('updatedAt'), orderBy(documentId()), from(cursor, cursorId), limit(PAGE)));
      for (const d of snap.docs) {
        const data = d.data();
        const at = data.updatedAt instanceof Timestamp ? data.updatedAt.toMillis() : 0;
        const r = data.id === d.id ? toCommunityRecord(d.id, data) : null;
        if (r) {words[d.id] = r; changes++;}
        if (at > cursor || (at === cursor && d.id > cursorId)) {cursor = at; cursorId = d.id;}
      }
      if (snap.docs.length < PAGE) break;
    }
    community = {cursor, cursorId, checkedAt: Date.now(), words};
    await saveCommunity();
    if (changes) apply();
    return changes;
  })().catch(e => {logger.warn('content', 'Community refresh failed', {code: String((e as {code?: unknown})?.code ?? '')}); return 0;}).finally(() => {refreshingCommunity = null;});
  return refreshingCommunity;
}
export const communityInfo = () => ({checkedAt: community.checkedAt, words: Object.keys(community.words).length, live: Object.values(community.words).filter(r => r.status === 'live').length});

async function loadCommunity() {
  try {
    const raw = await AsyncStorage.getItem(COMMUNITY_KEY);
    if (!raw) return;
    const parsed = JSON.parse(raw) as CommunityCache;
    if (!parsed || typeof parsed.cursor !== 'number' || !parsed.words || typeof parsed.words !== 'object') return;
    const words: CommunityCache['words'] = {};
    for (const [id, r] of Object.entries(parsed.words).slice(-MAX_COMMUNITY)) {const v = toCommunityRecord(id, r); if (v) words[id] = v;}
    community = {cursor: parsed.cursor, cursorId: typeof parsed.cursorId === 'string' ? parsed.cursorId : '', checkedAt: parsed.checkedAt || 0, words};
  } catch {logger.warn('content', 'Cached community words ignored');}
}

export async function loadContentOverlay() {
  await loadCommunity();
  try {
    const raw = await AsyncStorage.getItem(OVERLAY_KEY);
    if (!raw) {if (Object.keys(community.words).length) apply(); return;}
    const parsed = JSON.parse(raw) as Cached;
    if (!parsed || typeof parsed.cursor !== 'number' || typeof parsed.entries !== 'object') return;
    const entries: Cached['entries'] = {};
    for (const [id, t] of Object.entries(parsed.entries).slice(0, MAX_ENTRIES)) {
      if (!ID_PATTERN.test(id)) continue;
      if (t && 'removed' in t) entries[id] = {removed: true};
      else {const term = toTerm({...t, term: (t as Term).expression, variations: (t as Term).aliases, id, status: 'published', version: (t as Term).contentVersion}); if (term) entries[id] = term;}
    }
    cache = {cursor: parsed.cursor, cursorId: typeof parsed.cursorId === 'string' ? parsed.cursorId : '', checkedAt: parsed.checkedAt || 0, entries};
    apply();
  } catch {logger.warn('content', 'Cached content overlay ignored'); if (Object.keys(community.words).length) apply();}
}

/** Fetch published changes since the last cursor. Throttled; returns number of changes. */
export function refreshContent(log?: SecurityEventLog, force = false): Promise<number> {
  if (refreshing) return refreshing;
  if (!force && Date.now() - cache.checkedAt < REFRESH_EVERY) return Promise.resolve(0);
  refreshing = (async () => {
    const [{collection, query, where, orderBy, startAfter, startAt, limit, getDocs, documentId, Timestamp}, {cloudDb}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    // Cursor = (updatedAt, id) so entries published in the same batch are never skipped.
    // A document-ID cursor can't be empty, so the very first fetch starts at the beginning.
    const from = (at: number, id: string) => id ? startAfter(Timestamp.fromMillis(at), id) : startAt(Timestamp.fromMillis(at));
    let changes = 0, rejected = 0, cursor = cache.cursor, cursorId = cache.cursorId;
    const entries = {...cache.entries};
    for (let page = 0; page < 20; page++) {
      const snap = await getDocs(query(collection(cloudDb(), 'publishedContent'), where('status', 'in', ['published', 'archived']), orderBy('updatedAt'), orderBy(documentId()), from(cursor, cursorId), limit(PAGE)));
      for (const d of snap.docs) {
        const data = d.data();
        const at = data.updatedAt instanceof Timestamp ? data.updatedAt.toMillis() : 0;
        const t = d.id === data.id ? toTerm(data) : null;
        if (t) {entries[d.id] = t; changes++;} else rejected++;
        if (at > cursor || (at === cursor && d.id > cursorId)) {cursor = at; cursorId = d.id;}
      }
      if (snap.docs.length < PAGE) break;
    }
    if (rejected) void log?.record('content_validation_rejected', `count:${rejected}`);
    cache = {cursor, cursorId, checkedAt: Date.now(), entries: Object.fromEntries(Object.entries(entries).slice(0, MAX_ENTRIES))};
    await AsyncStorage.setItem(OVERLAY_KEY, JSON.stringify(cache));
    if (changes) apply();
    return changes;
  })().catch(e => {logger.warn('content', 'Content refresh failed', {code: String((e as {code?: unknown})?.code ?? '')}); return 0;}).finally(() => {refreshing = null;});
  return refreshing;
}
export const contentCacheInfo = () => ({cursor: cache.cursor, checkedAt: cache.checkedAt, entries: Object.keys(cache.entries).length});
