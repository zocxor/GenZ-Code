// Instant community words + cloud restore, end to end on the web build.
// Auth: official Firebase Auth emulator. Firestore: local emulator WITHOUT security rules
// (rules are covered by firebase/rules-tests on the official emulator), so this checks the
// app's own behaviour: entry points, verification gate, publish, list/search on another device,
// hide propagation, duplicate and rate-limit messages, and restoring learning after a wipe.
import {chromium} from 'playwright';
const URL = 'http://localhost:8091/', AUTH = 'http://127.0.0.1:9099', FS = 'http://127.0.0.1:8080', PROJECT = 'gen-z-code-55caf';
const DOCS = `${FS}/v1/projects/${PROJECT}/databases/(default)/documents`;
const OUT = '/home/claude/tests-e2e/shots';
const results = [];
const check = (name, ok, info = '') => {results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${info ? ' — ' + info : ''}`);};
const owner = {Authorization: 'Bearer owner'};
await fetch(`${AUTH}/emulator/v1/projects/${PROJECT}/accounts`, {method: 'DELETE'});
await fetch(`${FS}/emulator/v1/projects/${PROJECT}/databases/(default)/documents`, {method: 'DELETE'});

const browser = await chromium.launch();
const newPhone = async () => {
  const ctx = await browser.newContext({viewport: {width: 390, height: 844}, deviceScaleFactor: 2});
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto(URL);
  await page.getByText('Start decoding').click();
  return {ctx, page, errors, body: () => page.locator('body').innerText()};
};
const banner = page => page.getByRole('button', {name: /^Suggest a word\./});

// ---------- phone A: entry points ----------
const A = await newPhone();
await A.page.waitForTimeout(800);
check('Decode tab shows the highlighted Suggest a word banner', await banner(A.page).first().isVisible());
await A.page.screenshot({path: `${OUT}/suggest-decode.png`});
await A.page.getByRole('tab', {name: /Words/}).click(); await A.page.waitForTimeout(600);
const wordsBanner = banner(A.page).filter({visible: true}).first();
check('Words tab shows the banner near the top', await wordsBanner.isVisible() && (await wordsBanner.boundingBox()).y < 420, `y=${Math.round((await wordsBanner.boundingBox()).y)}`);
await A.page.screenshot({path: `${OUT}/suggest-words.png`});
await A.page.getByRole('tab', {name: /You/}).click(); await A.page.waitForTimeout(500);
check('You tab shows the banner', await banner(A.page).filter({visible: true}).count() >= 1);

// ---------- signed out → sign in first ----------
await A.page.getByRole('tab', {name: /Words/}).click(); await A.page.waitForTimeout(300);
await banner(A.page).filter({visible: true}).first().click();
await A.page.getByText('Sign in to add a word').waitFor();
check('signed-out users are asked to sign in first', true);
await A.page.getByRole('button', {name: 'Sign in or create an account'}).last().click();
await A.page.getByText('Create an account').click();
await A.page.getByLabel('Account email').fill('maker@example.com');
await A.page.getByLabel('Account password', {exact: true}).fill('correct horse battery');
await A.page.getByLabel('Confirm account password').fill('correct horse battery');
await A.page.getByRole('button', {name: 'Create account'}).last().click();
await A.page.getByText(/Account created/).waitFor({timeout: 15000});
await A.page.getByRole('button', {name: 'Go back'}).first().click();

// ---------- unverified e-mail: clear gate, then publish ----------
await banner(A.page).filter({visible: true}).first().click();
await A.page.getByText('Goes live instantly', {exact: true}).waitFor();
await A.page.getByLabel('Suggested word').fill('zorptastic');
await A.page.getByLabel('Meaning').fill('Extremely good, in a weird way.');
await A.page.getByLabel('Example').fill('that fit is zorptastic');
await A.page.getByText('Social', {exact: true}).click();
await A.page.screenshot({path: `${OUT}/suggest-form.png`});
await A.page.getByRole('button', {name: 'Publish word'}).click();
await A.page.getByText(/Verify your e-mail to publish words/).waitFor({timeout: 15000});
check('unverified accounts get a clear verification message with actions', await A.page.getByRole('button', {name: 'I’ve verified, publish now'}).isVisible());
const codes = (await (await fetch(`${AUTH}/emulator/v1/projects/${PROJECT}/oobCodes`)).json()).oobCodes.filter(c => c.email === 'maker@example.com' && c.requestType === 'VERIFY_EMAIL');
await fetch(codes.at(-1).oobLink);
await A.page.getByRole('button', {name: 'I’ve verified, publish now'}).click();
await A.page.getByText('“zorptastic” is live!').waitFor({timeout: 15000});
check('after verifying, the word is published instantly', true);
await A.page.screenshot({path: `${OUT}/suggest-live.png`});
const stored = await (await fetch(`${DOCS}/communityWords/c-zorptastic`, {headers: owner})).json();
check('server document has the expected shape', stored.fields?.status?.stringValue === 'live' && stored.fields?.term?.stringValue === 'zorptastic' && !!stored.fields?.uid?.stringValue && Object.keys(stored.fields).sort().join() === 'category,createdAt,example,id,meaning,status,term,uid,updatedAt', Object.keys(stored.fields ?? {}).join());
await A.page.getByRole('button', {name: 'See it in Words'}).click();
await A.page.getByText('Inside the code').waitFor();
const detail = await A.body();
check('“See it in Words” opens the entry, labelled as a community word', /zorptastic/.test(detail) && /Community/.test(detail) && /Editors haven’t reviewed it yet/.test(detail));
await A.page.screenshot({path: `${OUT}/suggest-detail.png`});
await A.page.getByRole('button', {name: 'Go back'}).first().click();

// ---------- duplicates and rate limit ----------
await banner(A.page).filter({visible: true}).first().click();
await A.page.getByLabel('Suggested word').fill('IDK');
await A.page.getByLabel('Meaning').fill('Something else');
await A.page.getByRole('button', {name: 'Publish word'}).click();
await A.page.getByText(/is already in GenZ Code/).waitFor({timeout: 10000});
check('existing dictionary words are not duplicated (with an Open it button)', await A.page.getByRole('button', {name: 'Open it'}).isVisible());
await A.page.getByLabel('Suggested word').fill('blorpcore');
await A.page.getByLabel('Meaning').fill('A very chaotic aesthetic.');
await A.page.getByRole('button', {name: 'Publish word'}).click();
await A.page.getByText(/Please wait \d+ s before adding another word/).waitFor({timeout: 10000});
check('a second word within a minute gets a precise wait message', true);
await A.page.getByRole('button', {name: 'Go back'}).first().click();

// ---------- phone B (another person): sees the word without signing in ----------
// Also seed an editor-published entry: the first content download used to fail (empty cursor).
const now = new Date().toISOString();
await fetch(`${DOCS}/publishedContent?documentId=cms-flexplosion`, {method: 'POST', headers: {...owner, 'Content-Type': 'application/json'}, body: JSON.stringify({fields: {
  id: {stringValue: 'cms-flexplosion'}, term: {stringValue: 'flexplosion'}, full: {stringValue: 'An explosion of flexing'}, meaning: {stringValue: 'When someone shows off far too much at once.'}, example: {stringValue: ''},
  category: {stringValue: 'Social'}, subcategory: {stringValue: ''}, variations: {arrayValue: {}}, region: {stringValue: ''}, tone: {stringValue: ''}, language: {stringValue: 'English'},
  sensitivity: {stringValue: 'None'}, caution: {stringValue: ''}, status: {stringValue: 'published'}, version: {integerValue: '1'}, updatedAt: {timestampValue: now}}})});
const B = await newPhone();
await B.page.getByRole('tab', {name: /Words/}).click(); await B.page.waitForTimeout(2500);
await B.page.getByLabel('Search dictionary').fill('zorptastic'); await B.page.waitForTimeout(600);
check('another phone finds the new word in Words', await B.page.getByRole('button', {name: 'Open zorptastic'}).count() === 1);
await B.page.getByLabel('Search dictionary').fill('flexplosion'); await B.page.waitForTimeout(600);
check('editor-published content reaches a fresh install (first download)', await B.page.getByRole('button', {name: 'Open flexplosion'}).count() === 1);
await B.page.getByLabel('Search dictionary').fill('zorptastic'); await B.page.waitForTimeout(600);
await B.page.screenshot({path: `${OUT}/suggest-other-phone.png`});
await B.page.getByRole('tab', {name: /Decode/}).click();
await B.page.getByLabel('Message to decode').fill('ngl that was zorptastic');
await B.page.getByRole('button', {name: 'Decode message'}).click(); await B.page.waitForTimeout(400);
check('the decoder recognises it too', /Extremely good, in a weird way/.test(await B.body()));

// ---------- moderator hides it → removed from other phones on refresh ----------
await fetch(`${DOCS}/communityWords/c-zorptastic?updateMask.fieldPaths=status&updateMask.fieldPaths=updatedAt`, {method: 'PATCH', headers: {...owner, 'Content-Type': 'application/json'}, body: JSON.stringify({fields: {status: {stringValue: 'hidden'}, updatedAt: {timestampValue: new Date().toISOString()}}})});
await B.page.evaluate(() => {const c = JSON.parse(localStorage.getItem('genz-code-community-words')); c.checkedAt = 0; localStorage.setItem('genz-code-community-words', JSON.stringify(c));});
await B.page.reload(); await B.page.waitForTimeout(800);
await B.page.getByRole('tab', {name: /Words/}).click(); await B.page.waitForTimeout(2500);
await B.page.getByLabel('Search dictionary').fill('zorptastic'); await B.page.waitForTimeout(600);
check('a hidden word disappears from other phones', await B.page.getByRole('button', {name: 'Open zorptastic'}).count() === 0);

// ---------- cloud restore after wiping the phone ----------
await A.page.getByRole('tab', {name: /Words/}).click();
await A.page.getByLabel('Search dictionary').fill('rizz'); await A.page.waitForTimeout(500);
await A.page.getByRole('button', {name: /^Open rizz/}).first().click();
await A.page.getByText('Save this code').click(); await A.page.getByText('Saved — tap to remove').waitFor();
await A.page.getByRole('button', {name: 'Go back'}).first().click();
await A.page.getByRole('tab', {name: /You/}).click();
let backed = false;
for (let i = 0; i < 20 && !backed; i++) {await A.page.waitForTimeout(1000); backed = /Backed up/.test(await A.body());}
check('signed-in learning backs up to the cloud', backed);
await A.page.evaluate(() => localStorage.clear());
await A.page.reload(); await A.page.getByText('Start decoding').click();
await A.page.getByRole('tab', {name: /You/}).click(); await A.page.waitForTimeout(400);
check('after wiping, the phone starts empty', /\n0\nSaved words/.test(await A.body()));
await A.page.getByText('My account', {exact: true}).click();
await A.page.getByLabel('Account email').fill('maker@example.com');
await A.page.getByLabel('Account password', {exact: true}).fill('correct horse battery');
await A.page.getByRole('button', {name: 'Sign in with email'}).click();
await A.page.getByText(/You’re signed in/).waitFor({timeout: 15000});
await A.page.getByRole('button', {name: 'Go back'}).first().click();
let restored = false;
for (let i = 0; i < 20 && !restored; i++) {await A.page.waitForTimeout(1000); restored = /\n1\nSaved words/.test(await A.body());}
check('signing in again restores saved words from the cloud', restored);
await A.page.screenshot({path: `${OUT}/restore-after-wipe.png`});

check('no uncaught page errors', A.errors.length + B.errors.length === 0, [...A.errors, ...B.errors].slice(0, 2).join(' | '));
await browser.close();
console.log(`${results.filter(Boolean).length}/${results.length} checks passed`);
