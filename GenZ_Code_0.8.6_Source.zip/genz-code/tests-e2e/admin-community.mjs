// Admin portal without two-step verification (Spark plan): verified admin signs in with a
// password, moderates community words (hide/restore, audited) and switches instant publishing.
// Needs: Auth emulator :9099, Firestore emulator :8080, and an emulator-wired portal build at
// :8093/admin/ (VITE_FIREBASE_EMULATOR_HOST=127.0.0.1 npx vite build --outDir <dir>/admin).
import {chromium} from 'playwright';
const AUTH = 'http://127.0.0.1:9099', FS = 'http://127.0.0.1:8080', PROJECT = 'gen-z-code-55caf', PORTAL = 'http://127.0.0.1:8093/admin/';
const DOCS = `${FS}/v1/projects/${PROJECT}/databases/(default)/documents`;
const owner = {Authorization: 'Bearer owner', 'Content-Type': 'application/json'};
const results = [];
const check = (name, ok, info = '') => {results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${info ? ' — ' + info : ''}`);};
await fetch(`${AUTH}/emulator/v1/projects/${PROJECT}/accounts`, {method: 'DELETE'});
await fetch(`${FS}/emulator/v1/projects/${PROJECT}/databases/(default)/documents`, {method: 'DELETE'});

const signUp = async (email, verified) => {
  const r = await (await fetch(`${AUTH}/identitytoolkit.googleapis.com/v1/accounts:signUp?key=fake`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({email, password: 'correct horse battery', returnSecureToken: true})})).json();
  if (verified) await fetch(`${AUTH}/identitytoolkit.googleapis.com/v1/projects/${PROJECT}/accounts:update`, {method: 'POST', headers: owner, body: JSON.stringify({localId: r.localId, emailVerified: true})});
  return r.localId;
};
const put = (path, fields) => fetch(`${DOCS}/${path}`, {method: 'PATCH', headers: owner, body: JSON.stringify({fields})});
const s = v => ({stringValue: v}), ts = () => ({timestampValue: new Date().toISOString()});
const admin = await signUp('owner@example.com', true), unverified = await signUp('helper@example.com', false);
for (const [uid, email] of [[admin, 'owner@example.com'], [unverified, 'helper@example.com']]) await put(`admins/${uid}`, {role: s('super_admin'), active: {booleanValue: true}, email: s(email), updatedAt: ts(), updatedBy: s('console'), lastAuditId: s('bootstrap')});
await put('communityWords/c-zorptastic', {id: s('c-zorptastic'), term: s('zorptastic'), meaning: s('Extremely good, in a weird way.'), example: s(''), category: s('Social'), uid: s('user123'), status: s('live'), createdAt: ts(), updatedAt: ts()});

const browser = await chromium.launch();
const page = await (await browser.newContext({viewport: {width: 1280, height: 860}})).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
const body = () => page.locator('body').innerText();
const signIn = async email => {
  await page.goto(PORTAL);
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Password').fill('correct horse battery');
  await page.getByRole('button', {name: 'Sign in'}).click();
};

await signIn('helper@example.com');
await page.getByRole('heading', {name: 'Verify your e-mail'}).waitFor({timeout: 15000});
check('an admin with an unverified e-mail is asked to verify first', true);
await page.getByRole('button', {name: 'Sign out'}).click();

await signIn('owner@example.com');
await page.getByRole('navigation', {name: 'Sections'}).waitFor({timeout: 15000});
check('a verified Super Admin signs in with a password (no authenticator app needed)', /Dashboard/.test(await body()) && !/two-step/i.test(await body()));
await page.goto(PORTAL + '#moderation'); await page.reload();
await page.getByText('zorptastic', {exact: true}).waitFor({timeout: 15000});
check('Moderation lists live community words', true);
await page.screenshot({path: '/home/claude/tests-e2e/shots/admin-community.png'});
await page.getByRole('button', {name: 'Hide'}).first().click();
await page.getByText(/hidden\. Apps remove it/).waitFor({timeout: 10000});
const word = await (await fetch(`${DOCS}/communityWords/c-zorptastic`, {headers: owner})).json();
const audits = (await (await fetch(`${DOCS}/auditLogs?pageSize=50`, {headers: owner})).json()).documents ?? [];
const hideAudit = audits.find(a => a.fields.action.stringValue === 'community.hide');
check('Hide updates the word and writes a matching audit entry', word.fields.status.stringValue === 'hidden' && word.fields.lastAuditId?.stringValue === hideAudit?.name.split('/').pop() && hideAudit?.fields.target.stringValue === 'communityWords/c-zorptastic');
await page.getByRole('button', {name: 'Hidden', exact: true}).click();
await page.getByRole('button', {name: 'Restore'}).first().click();
await page.getByText(/restored\./).waitFor({timeout: 10000});
const again = await (await fetch(`${DOCS}/communityWords/c-zorptastic`, {headers: owner})).json();
check('Restore puts it back live', again.fields.status.stringValue === 'live');

await page.goto(PORTAL + '#settings'); await page.reload();
const box = page.getByLabel(/Publish suggested words instantly/);
await box.waitFor({timeout: 15000});
check('Settings has the instant-publishing switch (on by default)', await box.isChecked());
await box.uncheck();
await page.getByRole('button', {name: 'Save settings'}).click();
await page.getByText('Settings saved and audited.').waitFor({timeout: 10000});
const cfg = await (await fetch(`${DOCS}/config/app`, {headers: owner})).json();
check('turning it off is saved for the apps to read', cfg.fields.communityWordsEnabled.booleanValue === false && cfg.fields.ugcEnabled.booleanValue === true);
// Retention clean-up (replaces TTL on the free plan)
const past = {timestampValue: new Date(Date.now() - 3600_000).toISOString()}, future = {timestampValue: new Date(Date.now() + 86400_000).toISOString()};
await put('securityEvents/expired1', {uid: s('u1'), type: s('session_expired'), detail: s(''), platform: s('android'), appVersion: s('0.8.5'), at: past, expireAt: past});
await put('auditLogs/expired1', {actor: s('x'), role: s('moderator'), action: s('admin.login'), target: s('admins/x'), summary: s(''), at: past, expireAt: past});
await put('auditLogs/current1', {actor: s('x'), role: s('moderator'), action: s('admin.login'), target: s('admins/x'), summary: s(''), at: past, expireAt: future});
await page.goto(PORTAL + '#logs'); await page.reload();
await page.getByRole('button', {name: 'Delete expired entries'}).click();
await page.getByText(/Deleted 2 expired entries\./).waitFor({timeout: 10000});
const gone = async path => (await fetch(`${DOCS}/${path}`, {headers: owner})).status === 404;
check('retention clean-up deletes only expired logs and records itself', await gone('securityEvents/expired1') && await gone('auditLogs/expired1') && !(await gone('auditLogs/current1')) && ((await (await fetch(`${DOCS}/auditLogs?pageSize=50`, {headers: owner})).json()).documents ?? []).some(a => a.fields.action.stringValue === 'logs.purge'));
check('no uncaught page errors', errors.length === 0, errors.slice(0, 2).join(' | '));
await browser.close();
console.log(`${results.filter(Boolean).length}/${results.length} checks passed`);
