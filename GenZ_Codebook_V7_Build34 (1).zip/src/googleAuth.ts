/**
 * Google sign-in (Android) → Firebase Authentication.
 *
 * How it works: the native Google Sign-In flow returns an ID token for the
 * user's Google account; that token is exchanged for a Firebase credential
 * (GoogleAuthProvider.credential), so the user signs in to Firebase with
 * their Google account — no password, no separate account. The Firebase
 * account is the same account the rest of the app uses (email/password,
 * community posting, wallet sync).
 *
 * What must exist first (Firebase console, one-time setup):
 *  - The app's SHA-1 signing fingerprint must be registered for the Android
 *    app in Firebase console → Project settings → Your apps. Firebase then
 *    creates the OAuth clients for this app.
 *  - The fresh google-services.json (downloaded after adding the SHA-1)
 *    must replace android/app/google-services.json, and the app must be
 *    rebuilt — the OAuth client only exists in the fresh file.
 *  - GOOGLE_WEB_CLIENT_ID below must be the "Web client" OAuth 2.0 client ID
 *    from that fresh google-services.json (client[].oauth_client[] with
 *    client_type 3). The native sign-in requests an ID token for exactly
 *    that client; without it Google returns no ID token and Firebase auth
 *    cannot work.
 *
 * Until GOOGLE_WEB_CLIENT_ID is set, signInWithGoogle returns a clear
 * "not set up yet" result instead of attempting sign-in — the button never
 * fails cryptically and never pretends to work.
 */
import {Platform} from 'react-native';
import {GoogleAuthProvider, signInWithCredential} from 'firebase/auth';
import {GoogleSignin, isSuccessResponse, statusCodes} from '@react-native-google-signin/google-signin';
import {accountAuth} from './auth/client';

/**
 * Google OAuth web client ID for the Firebase project gen-z-code-55caf.
 * The "Web client" (client_type 3) from android/app/google-services.json, created by
 * Firebase after the SHA-1 fingerprint was added. Public value (not a secret).
 * Each signing key that installs the app (GitHub APK key, upload key, Play App
 * Signing key) needs its SHA-1 registered in Firebase for Google sign-in to work.
 */
export const GOOGLE_WEB_CLIENT_ID = '1095502586634-09bohub3v58v9f25lmssqu37na02ugpd.apps.googleusercontent.com';

export type GoogleSignInResult = {ok: true} | {ok: false; message: string};

/** True when the Google button can actually attempt a sign-in. */
export function isGoogleSignInConfigured(): boolean {
  return GOOGLE_WEB_CLIENT_ID.length > 0;
}

/**
 * Sign in with Google. Configures the native module, checks Play services,
 * runs the Google account chooser, then signs the returned ID token in to
 * Firebase. Returns a friendly message on every failure path; never throws.
 */
export async function signInWithGoogle(): Promise<GoogleSignInResult> {
  if (Platform.OS !== 'android') return {ok: false, message: 'Google sign-in is available on Android.'};
  if (!GOOGLE_WEB_CLIENT_ID) {
    return {ok: false, message: 'Google sign-in is not set up yet. Add the app’s SHA-1 fingerprint in Firebase console, download the fresh google-services.json, and set the web client ID.'};
  }
  try {
    GoogleSignin.configure({webClientId: GOOGLE_WEB_CLIENT_ID});
    await GoogleSignin.hasPlayServices();
    const response = await GoogleSignin.signIn();
    if (!isSuccessResponse(response)) {
      return {ok: false, message: 'Google sign-in was cancelled.'};
    }
    const idToken = response.data?.idToken;
    if (!idToken) {
      return {ok: false, message: 'Google did not return an ID token. Try again.'};
    }
    await signInWithCredential(accountAuth, GoogleAuthProvider.credential(idToken));
    return {ok: true};
  } catch (e) {
    const code = e && typeof e === 'object' && 'code' in e ? String((e as {code: unknown}).code) : '';
    if (code === statusCodes.SIGN_IN_CANCELLED) return {ok: false, message: 'Google sign-in was cancelled.'};
    if (code === statusCodes.IN_PROGRESS) return {ok: false, message: 'Google sign-in is already in progress.'};
    if (code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) return {ok: false, message: 'Google Play services is not available on this device.'};
    if (code === 'DEVELOPER_ERROR' || code === '10') {
      return {ok: false, message: 'Google sign-in is misconfigured (developer error). Check the SHA-1 fingerprint and the web client ID in Firebase console.'};
    }
    return {ok: false, message: 'Google sign-in failed. Try again.'};
  }
}
