/**
 * Referral system — pure logic (no React Native, no Firebase), so it is
 * unit-tested in Node.
 *
 * A user joins by EITHER a referral link OR a referral code. When a referral
 * is successfully claimed, BOTH the referrer and the new user receive
 * TOKENS.REFERRAL_REWARD (100) tokens (see shared/tokens.ts — the amount
 * lives in exactly one place there; the Firestore rules hard-code the same
 * 100 as a validation check).
 *
 * Referral code: "GZ" + 6 uppercase alphanumeric characters, derived
 * deterministically from the user's UID (same UID always yields the same
 * code, so it is stable and needs no separate storage). 36^6 is about 2.2
 * billion codes, so collisions are negligible at this scale; the
 * referrals/{code} document (create-only, one per code) is the final
 * uniqueness guard — if two UIDs ever hashed to the same code, the second
 * user simply cannot register it and gets no code (ensureReferralCode in
 * src/referral.ts returns null for that case).
 *
 * Referral link: genzcode://referral?code=GZXXXXXX (the app's existing
 * deep-link scheme; AndroidManifest already has the BROWSABLE intent
 * filter for it). The path form genzcode://referral/GZXXXXXX is also
 * accepted. Opening the link stores the code in memory (src/referral.ts)
 * and the sign-up form pre-fills it.
 */
import {PLAY_STORE_URL} from './brand';

export const REFERRAL_CODE_PREFIX = 'GZ';
export const REFERRAL_CODE_BODY_LENGTH = 6;
export const REFERRAL_CODE_RE = /^GZ[A-Z0-9]{6}$/;
export const REFERRAL_LINK_SCHEME = 'genzcode';

const REFERRAL_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

/** Two FNV-1a passes with different seeds, each contributing 3 base-36
 *  digits (36^3 = 46,656 per part, 36^6 overall). No BigInt, so it runs
 *  identically in Node, Hermes, and any other JS engine. */
function hashToCodeBody(uid: string): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < uid.length; i++) {
    const c = uid.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x811c9dc5) >>> 0;
  }
  const part = (h: number): string => {
    let out = '';
    let x = h % 46656;
    for (let i = 0; i < 3; i++) {
      out = REFERRAL_ALPHABET[x % 36] + out;
      x = Math.floor(x / 36);
    }
    return out;
  };
  return part(h1) + part(h2);
}

/** The user's referral code, derived deterministically from their UID.
 *  Returns '' for an empty UID (no code without an account). */
export function referralCodeForUid(uid: string): string {
  if (!uid) return '';
  return REFERRAL_CODE_PREFIX + hashToCodeBody(uid);
}

/** Strict format check: "GZ" + exactly 6 uppercase alphanumerics. */
export function isReferralCode(code: unknown): code is string {
  return typeof code === 'string' && REFERRAL_CODE_RE.test(code);
}

/** Trim and uppercase, so pasted or lower-case codes still match. */
export function normaliseReferralCode(code: string): string {
  return code.trim().toUpperCase();
}

/** The shareable deep link for a code. */
export function referralLink(code: string): string {
  return `${REFERRAL_LINK_SCHEME}://referral?code=${code}`;
}

/** Extract a referral code from a deep-link URL. Accepts
 *  genzcode://referral?code=GZXXXXXX (query, other params allowed) and
 *  genzcode://referral/GZXXXXXX (path). Returns null for anything else
 *  (wrong scheme, wrong path, missing or malformed code). */
export function parseReferralLink(url: string): string | null {
  if (typeof url !== 'string') return null;
  const u = url.trim();
  if (!/^genzcode:\/\/referral(?:\/|\?)/i.test(u)) return null;
  const q = /[?&]code=([A-Za-z0-9]+)/i.exec(u);
  if (q && q[1]) {
    const code = normaliseReferralCode(q[1]);
    return isReferralCode(code) ? code : null;
  }
  const p = /^genzcode:\/\/referral\/([A-Za-z0-9]+)/i.exec(u);
  if (p && p[1]) {
    const code = normaliseReferralCode(p[1]);
    return isReferralCode(code) ? code : null;
  }
  return null;
}

/**
 * Invite link for sharing: the Google Play listing, with the code as the Play install
 * referrer (utm_content). Unlike genzcode://, it is tappable in WhatsApp, Instagram,
 * SMS etc. and works for people who don't have the app yet. It opens once the app is
 * published on Google Play; the code is also written in the message, so a friend can
 * always type it in the sign-up form.
 */
export function referralInstallLink(code: string): string {
  return `${PLAY_STORE_URL}&referrer=${encodeURIComponent(`utm_source=invite&utm_medium=app&utm_content=${code}`)}`;
}

/** The message shared with a referral link (OS share sheet). */
export function referralShareMessage(code: string): string {
  return `Join me on GenZ Codebook! Decode Gen Z slang, send secret coded messages and play word games.\n\nUse my invite code ${code} when you sign up and we both get 100 Credits.\n\nGet the app: ${referralInstallLink(code)}`;
}

export type ClaimDecision = 'claimed' | 'invalid' | 'self' | 'already-claimed';
/** Pure claim decision: given a code, the new user's UID, the UID the code
 *  resolves to (null when the code is unknown), and whether the new user
 *  already has a claim, decide the outcome. The Firestore rules enforce the
 *  same checks server-side (unknown code, self-referral, double claim); this
 *  is the client-side mirror so the decision is unit-tested. */
export function decideReferralClaim(code: string, newUserUid: string, referrerUid: string | null, hasExistingClaim: boolean): ClaimDecision {
  const clean = normaliseReferralCode(code);
  if (!isReferralCode(clean) || !newUserUid || !referrerUid) return 'invalid';
  if (referrerUid === newUserUid) return 'self';
  if (hasExistingClaim) return 'already-claimed';
  return 'claimed';
}

/** Ledger document ID for the NEW user's own referral entry:
 *  users/{newUserUid}/tokenLedger/referral-<code>. One per claim (a user
 *  can only claim once), so the ID is the duplicate guard. */
export function referralClaimLedgerId(code: string): string {
  return `referral-${code}`;
}

/** Ledger document ID for the REFERRER's referral entry:
 *  users/{referrerUid}/tokenLedger/referral-<newUserUid>. One per referred
 *  friend, so the ID is the duplicate guard. */
export function referralReferrerLedgerId(newUserUid: string): string {
  return `referral-${newUserUid}`;
}

/** Key in the local tokens.credited list for a referral credit, so the
 *  referrer's app never pays the same referral twice on this device. */
export function referralCreditKey(newUserUid: string): string {
  return `referral:${newUserUid}`;
}

// ---------- display-safe referral views (privacy) ----------
// A referral view must NEVER carry another user's e-mail, phone number, UID
// or any identifier other than a display name (and, where the viewer already
// knows it, the referral code). These helpers are the single place that
// turns a raw record into what the UI may render: anything that is not a
// validated display name (or a validated code / a real timestamp) comes out
// as null, and the input type does not even accept uid/email/phone — a
// caller cannot accidentally pass them through.

/** A display name as the app stores it: 1–24 characters after trimming.
 *  Anything else (empty, whitespace-only, too long, not a string) is not a
 *  name the UI may show — returns null so the caller falls back to a
 *  generic label instead of inventing or leaking one. */
export function cleanDisplayName(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const name = value.trim();
  return name.length >= 1 && name.length <= 24 ? name : null;
}

export type SafeReferredBy = {displayName: string | null; code: string | null};
/** Display-safe "who referred this user" view. `code` is the referral code
 *  the new user themself entered (or tapped in a link) — it is public by
 *  design, so it may be shown; the referrer's UID, e-mail and phone are
 *  never part of this view. */
export function safeReferredBy(raw: {name?: unknown; code?: unknown}): SafeReferredBy {
  return {
    displayName: cleanDisplayName(raw.name),
    code: typeof raw.code === 'string' && isReferralCode(raw.code) ? raw.code : null,
  };
}

export type SafeReferredFriend = {displayName: string | null; joinedAtMs: number | null};
/** Display-safe row for one user who joined with the viewer's code: their
 *  display name (when it could be resolved from a public source) and the
 *  join date. No UID, e-mail or phone — a caller holding those must strip
 *  them before calling this; the output type has nowhere to put them. */
export function safeReferredFriend(raw: {name?: unknown; joinedAtMs?: unknown}): SafeReferredFriend {
  const ms = typeof raw.joinedAtMs === 'number' && Number.isFinite(raw.joinedAtMs) && raw.joinedAtMs > 0 ? Math.floor(raw.joinedAtMs) : null;
  return {displayName: cleanDisplayName(raw.name), joinedAtMs: ms};
}
