# GenZ Codebook — 0.8.0 upgrade

Data persistence rebuilt at the root, cloud sync, Secure Engine + Threat Shield, Firestore security rules, admin portal with CMS, elegant profile dashboard, profile photo, upgraded navigation bar. **Start with [the implementation report](docs/UPGRADE_0.8_REPORT.md)** — it lists what was verified and what was not (Firestore rules tests and device QA are still required).

- Admin/Firebase setup: [docs/ADMIN_PORTAL.md](docs/ADMIN_PORTAL.md) · Retention: [docs/DATA_RETENTION.md](docs/DATA_RETENTION.md) · Play Data safety: [docs/PLAY_DATA_SAFETY.md](docs/PLAY_DATA_SAFETY.md)
- **APK:** see [docs/BUILD_APK.md](docs/BUILD_APK.md) (GitHub Actions workflow or local Android Studio)
- **Deploy rule — one zip only:** keep exactly ONE `GenZ_Codebook_*.zip` in the repository root. The workflows now refuse to build when several are present, because they used to silently build the alphabetically-last one (which was the 1.0.0 first-release zip, not the newest billing zip).
- **First launch is login-first:** tapping "Start decoding" (or the quick-game link) on the welcome screen opens the sign-in sheet. After sign-up or sign-in, the profile page (You tab) opens automatically; the back button returns to Decode, and the app then shows with the navigation bar.
- App: `npm ci && npm run typecheck && npm test` · Rules: `npm run test:rules` (Java 21 + firebase-tools) · Scan: `npm run security:scan`
- Portal: `cd admin && npm ci && npm test && npm run build` (hosting: `firebase deploy --only hosting`)
- Browser e2e: see [tests-e2e/README.md](tests-e2e/README.md) (needs `npm i -D playwright`)
- Release bundles: always `--clear` the Metro cache and never set `EXPO_PUBLIC_FIREBASE_EMULATOR_HOST`.

The 8,584-entry library and SQLite export are unchanged. The sections below are the earlier release notes.

# GenZ Codebook — branding update 0.7.0

New glossy logo, launcher icon, welcome branding and profile assets are integrated. See [branding usage and verification](docs/BRANDING_0.7.md). This source is based on the attached 0.5.0 ZIP; historical release notes below describe that baseline. No 0.7 APK has been assembled. Regional content expansion remains pending.

# GenZ Codebook

A glassy, skeuomorphic Android-first dictionary, chat decoder and learning app. Current source revision: **0.5.0**.

## Available in source

- Offline search across 8,584 attributed references, explicit search button, numeric/emoji/phrase matching, category and content-language filters.
- On-device message decoder, saved terms, local profile, four authored stages, daily/shuffle quizzes and scheduled word review.
- Protected local persistence, retry/recovery, data deletion and validated local-learning export.
- New Firebase email account screen: sign-up/sign-in, reset, verification, sign-out and deletion using the supplied project. Native sessions use encrypted SecureStore when available; web sessions are memory-only.
- Community chat room (Community tab): one shared room for signed-in users, by nickname; messages are screened for abuse before sending and can be reported; moderators hide messages from the admin portal. Guests can read the room.
- Code Tokens (You tab): earn tokens by playing quizzes, visiting daily, watching a rewarded ad, or getting a suggested word accepted; spend them to suggest words (first one free) or unlock a quiz level early. An opt-in public leaderboard (nickname + tokens) sits at the top of the Community screen. Earned tokens live on this device only and do not sync. Bought tokens are recorded in the account's permanent transaction history (Wallet) before they are credited, so a purchase can never be credited twice.
- Buy Tokens + Wallet (You tab): seven consumable token packages sold through Google Play Billing (`react-native-iap` 12.16.4, Billing Library 7.0.0) — prices come from Play Console, shown in the user's Play country and currency. Purchases are verified locally and recorded in the Firestore ledger under the Google Play order ID; pending, cancelled and failed purchases are never credited.
- Google AdMob: one banner at the bottom of the Suggest a word sheet and the Community screen, plus a full-screen interstitial when opening either one (at most once a minute). A rewarded ad is available from the Suggest form for +10 tokens. All three ad unit IDs are configured (banner, interstitial and rewarded); new units may take up to an hour to start showing ads, and dev builds use Google's test ads for all three formats. Ads are non-personalised.

## Honest status

This source is **not a complete production release**. Firebase public configuration connectivity passed, but live account flows and native secure persistence require device verification and provider configuration. Google sign-in is unavailable because OAuth configuration is absent. Cloud progress, backend/CMS, AI, community moderation, public web deployment and full curriculum remain unfinished. Billing is implemented (Google Play Billing, seven token packages) but is **not operational until a real test purchase completes and the correct tokens are credited**. Most imported content still needs individual editorial review; the numeric category has 162 entries, not 500.

See [Firebase setup](docs/FIREBASE_SETUP.md), [security review](docs/FIREBASE_SECURITY_0.5.md), and [current validation](docs/VALIDATION_0.5.md). The accompanying APK is **0.5.0-internal**, test-signed for ARM64 Android 7+. Its signature, package identity, manifest and content were verified. It is not a production release or a device-test certification.

## Develop

`npm ci` → `npm run typecheck` → `npm test` → `npm run start`.

`npm run export:android` validates Android JavaScript bundling; it does not generate an APK.

With JDK 17, Android SDK 36, build-tools 35.0.0 and NDK 27.1.12297006 installed: `cd android && ./gradlew assembleInternal -PreactNativeArchitectures=arm64-v8a`. The maintained native project preserves app identity and signing guards; do not blindly overwrite it with Expo prebuild. SecureStore autolinks as an Expo module. Backups remain disabled.

Production release requires owner-controlled signing variables and completed evidence in `production-readiness.json`; run `npm run release:check` before `./gradlew bundleRelease`. The bundled debug keystore is only for internal test installs. See [handoff](docs/PRODUCTION_HANDOFF.md) for the remaining roadmap.

---

GenZ Codebook is a **ZTechX** product. © 2026 Zocxorian Technologies. All rights reserved.
