import {readFileSync} from 'node:fs';
const configured=JSON.parse(readFileSync(new URL('../src/auth/firebaseConfig.json',import.meta.url),'utf8')).projectId;
const project=process.env.PROJECT_ID??configured;
if(!/^[a-z][a-z0-9-]{4,62}$/.test(project))throw new Error('Invalid Firebase project ID.');
const endpoints=[
  `https://us-central1-${project}.cloudfunctions.net/communityFeature`,
  `https://${project}.web.app/api/communityFeature`,
];
let failed=false;
for(const endpoint of endpoints){
  let problem='Not checked';
  for(let attempt=0;attempt<5;attempt++){
    try{
      const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data:{action:'balance'}}),signal:AbortSignal.timeout(20000)});
      const body=await response.json().catch(()=>null);
      if(response.status===401&&body?.error?.status==='UNAUTHENTICATED'){
        problem='';console.log(`PASS: ${endpoint} is reachable and rejects unauthenticated wallet access.`);break;
      }
      problem=`HTTP ${response.status}${body?.error?.status?' '+body.error.status:''}`;
    }catch(error){problem=error instanceof Error?error.message:'Network failure';}
    if(attempt<4)await new Promise(resolve=>setTimeout(resolve,1000));
  }
  if(problem){
    failed=true;console.error(`FAIL: ${endpoint}: ${problem}.`);
  }
}
if(failed){
  console.error('Account tokens and Daily Code require a reachable communityFeature backend. Deploy target community with the correct Firebase service account. Creation, posts and chat stay free; a Hosting-only deploy does not activate paid services.');
  process.exitCode=1;
}
