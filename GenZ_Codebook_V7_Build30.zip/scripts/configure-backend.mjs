import {readFileSync,writeFileSync} from 'node:fs';
const value=process.argv[2];
if(!value){console.error('Usage: node scripts/configure-backend.mjs https://api.your-domain.com [--enable-token-purchases]');process.exit(1);}
const url=new URL(value);
if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname))throw new Error('Use your HTTPS API origin without a path.');
const enable=process.argv.includes('--enable-token-purchases');
const response=await fetch(url.origin+'/health',{signal:AbortSignal.timeout(15000)});
if(!response.ok)throw new Error('Your VPS health endpoint is not ready.');
const health=await response.json();
if(health.edition!=='hybrid-vps-28')throw new Error('The endpoint is not this GenZ backend.');
const readiness=await fetch(url.origin+'/ready',{signal:AbortSignal.timeout(12000)});
if(!readiness.ok)throw new Error('The VPS cannot access Firebase yet. Check its credentials and permissions.');
if(enable&&health.purchasesEnabled!==true)throw new Error('Enable and test Play verification on the server before enabling checkout.');
const root=new URL('../',import.meta.url);
writeFileSync(new URL('shared/backend.json',root),JSON.stringify({url:url.origin,tokenPurchasesEnabled:enable},null,2)+'\n');
const configPath=new URL('firebase.json',root),firebase=JSON.parse(readFileSync(configPath,'utf8'));
for(const group of firebase.hosting.headers??[])for(const header of group.headers??[]){
  if(header.key==='Content-Security-Policy'){
    const directives=header.value.split(';').map(s=>s.trim());
    const i=directives.findIndex(s=>s.startsWith('connect-src '));
    if(i>=0&&!directives[i].split(/\s+/).includes(url.origin))directives[i]+=' '+url.origin;
    header.value=directives.join('; ');
  }
}
writeFileSync(configPath,JSON.stringify(firebase,null,2)+'\n');
console.log('Backend configured. Commit shared/backend.json and firebase.json, then rebuild the APK/AAB and deploy Firebase target spark.');
