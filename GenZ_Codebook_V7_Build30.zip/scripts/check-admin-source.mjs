import {existsSync, readFileSync, readdirSync} from 'node:fs';
import {dirname, resolve, extname} from 'node:path';
import {fileURLToPath} from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const failures = [];
function walk(dir) {
  if (!existsSync(dir)) { failures.push(`Missing source directory: ${dir}`); return; }
  for (const entry of readdirSync(dir, {withFileTypes: true})) {
    const file = resolve(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (/\.(?:ts|tsx|mjs)$/.test(file)) {
      const source = readFileSync(file, 'utf8');
      for (const match of source.matchAll(/(?:from\s*|import\s*|import\s*\(\s*)['"](\.[^'"]+)['"]/g)) {
        const target = resolve(dirname(file), match[1]);
        const candidates = [target, ...['.ts', '.tsx', '.mjs', '.js', '.json', '/index.ts', '/index.tsx'].map(suffix => target + suffix)];
        if (extname(target) === '.js') candidates.push(target.slice(0, -3) + '.ts');
        if (!candidates.some(existsSync)) failures.push(`${file}: missing ${match[1]}`);
      }
    }
  }
}
for (const dir of ['admin/src', 'admin/tests', 'admin/site', 'shared']) walk(resolve(root, dir));
if (failures.length) {
  console.error('Incomplete project source. Upload the complete extracted source or the complete corrected ZIP.');
  console.error(failures.join('\n'));
  process.exit(1);
}
console.log('Admin source completeness check passed.');
