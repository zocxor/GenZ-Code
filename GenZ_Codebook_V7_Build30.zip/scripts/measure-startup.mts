// Measures the JS work done before the first screen can paint: `node --import tsx scripts/measure-startup.mts`
// Counts locale-sensitive String calls: on Android/Hermes each one is a JNI call into java.text
// (Collator / Normalizer / Locale), which is what makes them slow on phones even though Node is fast.
const counts = {localeCompare: 0, normalize: 0, toLocaleLowerCase: 0};
const P = String.prototype as any;
for (const name of Object.keys(counts) as (keyof typeof counts)[]) {
  const original = P[name];
  P[name] = function (this: string, ...args: unknown[]) { counts[name]++; return original.apply(this, args); };
}
const snap = () => ({...counts});
const diff = (a: typeof counts, b: typeof counts) => Object.fromEntries(Object.keys(a).map(k => [k, (b as any)[k] - (a as any)[k]]));
const t0 = performance.now(); const c0 = snap();
await import('../src/content.ts');
const t1 = performance.now(); const c1 = snap();
await import('../src/engine.ts');
const t2 = performance.now(); const c2 = snap();
await import('../src/discovery.ts');
const t3 = performance.now(); const c3 = snap();
const row = (label: string, ms: number, d: object) => console.log(label.padEnd(34), (ms.toFixed(0) + ' ms').padStart(7), JSON.stringify(d));
row('load dictionary (content.ts)', t1 - t0, diff(c0, c1));
row('engine module init', t2 - t1, diff(c1, c2));
row('discovery module init', t3 - t2, diff(c2, c3));
const total = diff(c0, c3) as Record<string, number>;
console.log('BEFORE FIRST PAINT'.padEnd(34), ((t3 - t0).toFixed(0) + ' ms').padStart(7), 'locale calls =', Object.values(total).reduce((a, b) => a + b, 0));
const t4 = performance.now(); const c4 = snap();
(await import('../src/discovery.ts')).levelStages();
(await import('../src/engine.ts')).warmIndex();
const t5 = performance.now();
row('deferred: 30 levels + index', t5 - t4, diff(c4, snap()));
