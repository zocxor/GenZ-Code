// Startup performance: Expo's default Metro config sets inlineRequires:false, so every
// imported module (the full Firebase SDK, billing, ads, all screens) was evaluated
// before the first frame. Inline requires defer each module until it is first used.
// Side-effect-only imports (import './x') are unaffected.
const {getDefaultConfig} = require('expo/metro-config');
const config = getDefaultConfig(__dirname);
const base = config.transformer.getTransformOptions;
config.transformer.getTransformOptions = async (...args) => {
  const options = base ? await base(...args) : {};
  return {...options, transform: {...(options.transform ?? {}), experimentalImportSupport: false, inlineRequires: true}};
};
module.exports = config;
