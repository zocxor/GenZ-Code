export type PublishingMode='open'|'review'|'paused';
export function publishingMode(config:Record<string,unknown>,kind:'code'|'post'):PublishingMode {
  if(config.ugcEnabled===false)return 'paused';
  const mode=config[kind==='code'?'dictionaryPostingMode':'postPostingMode'];
  if(mode==='open'||mode==='review'||mode==='paused')return mode;
  return kind==='code'&&config.communityWordsEnabled===false?'review':'open';
}
export const CONTENT_NOTICE='Keep content respectful and original. No abuse, hate, sexual content, threats, spam or private information. Violations may lead to content removal and permanent account deletion.';
