import {readFileSync} from 'node:fs';
import {createServer} from 'node:http';
import {initializeApp,getApps,applicationDefault} from 'firebase-admin/app';
import {getFirestore,Timestamp,FieldPath} from 'firebase-admin/firestore';
import {getAuth} from 'firebase-admin/auth';
import {createApi} from './app';
import {dailyReward,rewardIntent} from './rewards';
import {creditAdReward,verifiedRewardData} from '../adRewards';
import {runDailySchedule,purgeContributions} from '../communityFeatures';
import type {RequestHandler} from 'express';

const project=process.env.GCLOUD_PROJECT??'gen-z-code-55caf';
if(!getApps().length)initializeApp({projectId:project,credential:process.env.FIRESTORE_EMULATOR_HOST?undefined:applicationDefault()});
const db=getFirestore();
let purchases:RequestHandler|undefined,subscriptions:RequestHandler|undefined;
if(process.env.ENABLE_PLAY_PURCHASES==='true'){
  const file=process.env.PLAY_SERVICE_ACCOUNT_FILE;
  if(!file)throw new Error('PLAY_SERVICE_ACCOUNT_FILE is required to enable checkout.');
  const raw=readFileSync(file,'utf8'),key=JSON.parse(raw);
  if(key.type!=='service_account'||!key.private_key||!key.client_email)throw new Error('Invalid Play service account.');
  process.env.PLAY_SERVICE_ACCOUNT_JSON=raw;
  const handlers=require('../index') as typeof import('../index');
  purchases=handlers.verifyPurchaseHandler;subscriptions=handlers.verifySubscriptionHandler;
}
let busy=false,lastSuccess=0,lastFailure=0,cleanupCursor='';
const instance=process.env.HOSTNAME??'genz-vps';
async function jobs(){
  if(busy)return;busy=true;
  try{
    const now=Date.now(),lease=db.doc('serviceLocks/scheduler');
    const acquired=await db.runTransaction(async tx=>{
      const current=await tx.get(lease);
      if(current.get('until')?.toMillis()>now&&current.get('owner')!==instance)return false;
      tx.set(lease,{owner:instance,until:Timestamp.fromMillis(now+240000)});return true;
    });
    if(!acquired)return;
    await runDailySchedule(db);
    let deletedQuery=db.collection('users').where('status','==','deleted').orderBy(FieldPath.documentId()).limit(25);
    if(cleanupCursor)deletedQuery=deletedQuery.startAfter(cleanupCursor);
    const deleted=await deletedQuery.get();
    cleanupCursor=deleted.docs.at(-1)?.id??'';
    for(const user of deleted.docs){
      const done=await db.doc('serviceCleanup/'+user.id).get();if(done.exists)continue;
      await purgeContributions(db,user.id);
      try{await getAuth().deleteUser(user.id);}catch(error){if((error as {code?:string}).code!=='auth/user-not-found')throw error;}
      await done.ref.set({completedAt:Timestamp.now()});
    }
    lastSuccess=Date.now();
  }catch(error){lastFailure=Date.now();console.error('background_job_failed',{name:error instanceof Error?error.name:'unknown'});}
  finally{busy=false;}
}
const app=createApi({db,origins:(process.env.ALLOWED_ORIGINS??`https://${project}.web.app,https://${project}.firebaseapp.com`).split(',').map(s=>s.trim()).filter(Boolean),
  verifyToken:token=>getAuth().verifyIdToken(token,true),
  rewardIntent:uid=>rewardIntent(db,uid),dailyReward:uid=>dailyReward(db,uid),purchases,subscriptions,
  reward:async(req,res)=>{
    try{const data=await verifiedRewardData(req.originalUrl.split('?')[1]??'');await creditAdReward(db,data,true);res.status(200).send('OK');}
    catch{res.status(400).send('Reward not verified');}
  },jobState:()=>({busy,lastSuccess,lastFailure,enabled:process.env.DISABLE_JOBS!=='true'}),
});
const server=createServer(app);
server.requestTimeout=30000;server.headersTimeout=15000;server.keepAliveTimeout=5000;
server.listen(Number(process.env.PORT??3000),process.env.HOST??'127.0.0.1',()=>console.log('GenZ API started'));
const timer=process.env.DISABLE_JOBS==='true'?null:setInterval(()=>void jobs(),300000);
if(timer){timer.unref();void jobs();}
for(const signal of ['SIGTERM','SIGINT'] as const)process.on(signal,()=>{if(timer)clearInterval(timer);server.close(()=>process.exit(0));setTimeout(()=>process.exit(1),10000).unref();});
