import express,{type Request,type Response,type RequestHandler} from 'express';
import type {DecodedIdToken} from 'firebase-admin/auth';
import type {Firestore} from 'firebase-admin/firestore';
import {HttpsError} from 'firebase-functions/v2/https';
import {communityAction} from '../communityFeatures';

type Options={db:Firestore;origins:string[];verifyToken:(token:string)=>Promise<DecodedIdToken>;reward:RequestHandler;purchases?:RequestHandler;subscriptions?:RequestHandler;rewardIntent:(uid:string)=>Promise<Record<string,unknown>>;dailyReward:(uid:string)=>Promise<Record<string,unknown>>;jobState:()=>Record<string,unknown>};
const status:Record<string,number>={'invalid-argument':400,'unauthenticated':401,'permission-denied':403,'not-found':404,'already-exists':409,'failed-precondition':400,'resource-exhausted':429,'unavailable':503};
export function createApi(options:Options){
  const app=express(),origins=new Set(options.origins),rates=new Map<string,{count:number;until:number}>();
  app.disable('x-powered-by');app.set('trust proxy',1);
  app.use((req,res,next)=>{
    res.set({'X-Content-Type-Options':'nosniff','Cache-Control':'no-store','X-Frame-Options':'DENY'});
    const origin=req.get('Origin');
    if(origin&&!origins.has(origin)){res.status(403).json({error:{status:'PERMISSION_DENIED',message:'Origin not allowed.'}});return;}
    if(origin){res.set('Access-Control-Allow-Origin',origin);res.vary('Origin');}
    res.set({'Access-Control-Allow-Headers':'Authorization, Content-Type, X-Firebase-AppCheck','Access-Control-Allow-Methods':'GET, POST, OPTIONS'});
    if(req.method==='OPTIONS'){res.sendStatus(204);return;}
    const now=Date.now(),key=req.ip??'unknown',prior=rates.get(key);
    if(rates.size>10000)for(const [id,row]of rates){if(row.until<=now)rates.delete(id);if(rates.size<=8000)break;}
    if(!prior||prior.until<=now)rates.set(key,{count:1,until:now+60000});
    else if(++prior.count>600){res.set('Retry-After','60');res.status(429).json({error:{status:'RESOURCE_EXHAUSTED',message:'Please retry in a minute.'}});return;}
    next();
  });
  app.get('/health',(_req,res)=>res.json({ok:true,edition:'hybrid-vps-28',purchasesEnabled:!!options.purchases,scheduler:options.jobState()}));
  let readyUntil=0,ready=false,checking:Promise<boolean>|null=null;
  app.get('/ready',async(_req,res)=>{
    if(Date.now()>readyUntil){
      if(!checking)checking=Promise.race([options.db.doc('config/app').get().then(()=>true,()=>false),new Promise<boolean>(resolve=>setTimeout(()=>resolve(false),8000).unref())]).then(value=>{ready=value;readyUntil=Date.now()+60000;checking=null;return value;});
      await checking;
    }
    res.status(ready?200:503).json({ready});
  });
  app.get('/admobReward',options.reward);
  app.use(express.json({limit:'32kb',strict:true}));
  const authenticated:RequestHandler=async(req,res,next)=>{
    try{
      const bearer=req.get('Authorization')??'';
      if(!bearer.startsWith('Bearer '))throw new Error();
      res.locals.identity=await options.verifyToken(bearer.slice(7).trim());next();
    }catch{res.status(401).json({error:{status:'UNAUTHENTICATED',message:'Sign in again to continue.'}});}
  };
  app.post(['/communityFeature','/api/communityFeature'],authenticated,async(req:Request,res:Response)=>{
    try{
      const input=req.body?.data;
      if(!input||typeof input!=='object'||Array.isArray(input)||typeof input.action!=='string')throw new HttpsError('invalid-argument','Invalid request.');
      const token=res.locals.identity as DecodedIdToken;
      if(token.email_verified!==true)throw new HttpsError('permission-denied','Verify your email to use account tokens.');
      const now=Date.now(),uidKey='uid:'+token.uid,row=rates.get(uidKey);
      if(!row||row.until<=now)rates.set(uidKey,{count:1,until:now+60000});
      else if(++row.count>60)throw new HttpsError('resource-exhausted','Please wait a minute before retrying.');
      if(['create-code','create-post','chat-pass'].includes(input.action))throw new HttpsError('failed-precondition','Creation, posting and chat are free in the latest app. Please update your app.');
      const data=input.action==='reward-intent'?await options.rewardIntent(token.uid):input.action==='daily-reward'?await options.dailyReward(token.uid):await communityAction(options.db,input,{uid:token.uid,token});
      res.json({result:data});
    }catch(error){
      const known=error instanceof HttpsError;
      if(!known)console.error('community_request_failed',{name:error instanceof Error?error.name:'unknown'});
      const code=known?error.code:'internal';
      res.status(status[code]??500).json({error:{status:code.replace(/-/g,'_').toUpperCase(),message:known?error.message:'Could not complete the request. Please retry.',...(known&&error.details?{details:error.details}:{})}});
    }
  });
  const disabled:RequestHandler=(_req,res)=>{res.status(503).json({verified:false,reason:'Purchase verification is not enabled.',retryable:true});};
  app.post('/verifyPurchase',authenticated,options.purchases??disabled);
  app.post('/verifySubscription',authenticated,options.subscriptions??disabled);
  app.use((_req,res)=>{res.status(404).json({error:{status:'NOT_FOUND',message:'Route not found.'}});});
  app.use((error:unknown,_req:Request,res:Response,_next:express.NextFunction)=>{
    const large=(error as {type?:string})?.type==='entity.too.large';
    res.status(large?413:400).json({error:{status:'INVALID_ARGUMENT',message:large?'Request too large.':'Invalid JSON body.'}});
  });
  return app;
}
