const {mkdirSync, copyFileSync, writeFileSync} = require('node:fs');
const {join} = require('node:path');
const root = join(__dirname, '../..');
const dir = join(root, 'functions/src/validation');
mkdirSync(dir, {recursive: true});
for (const name of ['chat', 'community', 'contentSchema', 'publishing']) copyFileSync(join(root, 'shared', name+'.ts'), join(dir, name+'.ts'));
const entries = require(join(root, 'src/data/library.json'));
const eligible = entries.filter(e => e.sensitivity === 'None' && e.expression && e.meaning && e.category);
const dailyEntry = ({id, expression:term, meaning, category}) => ({id, term, meaning, category});
writeFileSync(join(dir, 'dictionary.json'), JSON.stringify({
  terms: entries.flatMap(e => [e.expression, ...(e.aliases ?? [])]),
  selectable: eligible.map(dailyEntry),
  featured: eligible.filter(e => e.priority >= 100 && e.example).map(dailyEntry),
}));
