const {test,before,after}=require('node:test');
const assert=require('node:assert/strict');
const {generateKeyPairSync,sign}=require('node:crypto');
const {initializeApp,deleteApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
const {getAuth}=require('firebase-admin/auth');
const {createApi}=require('../lib/vps/app');
const {rewardIntent,dailyReward}=require('../lib/vps/rewards');
const {verifyRewardQuery,creditAdReward}=require('../lib/adRewards');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST&&process.env.FIREBASE_AUTH_EMULATOR_HOST,'Run with Auth and Firestore emulators.');
const app=initializeApp({projectId:'demo-genz-feature-core'}),db=getFirestore(app),auth=getAuth(app);
const {privateKey,publicKey}=generateKeyPairSync('ec',{namedCurve:'prime256v1'});
let server,url,user,admin,unverified;
async function identity(uid,verified=true){
 await auth.createUser({uid,email:uid+'@example.test',emailVerified:verified,password:'Test-only-password-284!'});
 await db.doc('users/'+uid).set({status:'active'});
 await db.doc(`users/${uid}/sync/profile`).set({profile:{name:uid}});
 const r=await fetch(`http://${process.env.FIREBASE_AUTH_EMULATOR_HOST}/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=emulator`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:uid+'@example.test',password:'Test-only-password-284!',returnSecureToken:true})});
 const result=await r.json();assert.ok(result.idToken,JSON.stringify(result));return result.idToken;
}
async function call(token,action,data={},extra={}){
 const r=await fetch(url+'/communityFeature',{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...extra},body:JSON.stringify({data:{action,...data}})});
 return {status:r.status,body:await r.json()};
}
const ok=async(token,action,data)=>{const r=await call(token,action,data);assert.equal(r.status,200,JSON.stringify(r.body));return r.body.result;};
async function signedReward(intent,transaction='vps-ad-transaction'){
 const content=new URLSearchParams({user_id:'vps-user',custom_data:intent,transaction_id:transaction,ad_unit:'4151797642',timestamp:String(Date.now()),reward_amount:'10',reward_item:'tokens'}).toString();
 return content+'&signature='+sign('sha256',Buffer.from(content),privateKey).toString('base64url')+'&key_id=42';
}
before(async()=>{
 user=await identity('vps-user');admin=await identity('vps-admin');unverified=await identity('vps-unverified',false);
 await db.doc('admins/vps-admin').set({active:true,role:'super_admin'});
 const api=createApi({db,origins:['https://gen-z-code-55caf.web.app'],verifyToken:t=>auth.verifyIdToken(t,true),rewardIntent:uid=>rewardIntent(db,uid),dailyReward:uid=>dailyReward(db,uid),jobState:()=>({enabled:true}),reward:async(req,res)=>{try{await creditAdReward(db,verifyRewardQuery(req.originalUrl.split('?')[1],new Map([['42',publicKey]])),true);res.send('OK');}catch{res.sendStatus(400);}}});
 server=api.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));url='http://127.0.0.1:'+server.address().port;
});
after(async()=>{if(server)await new Promise(resolve=>server.close(resolve));await deleteApp(app);});
test('HTTP authentication, email verification, CORS and input boundaries',async()=>{
 assert.equal((await call(null,'balance')).status,401);
 assert.equal((await call('invalid','balance')).status,401);
 assert.equal((await call(unverified,'balance')).status,403);
 assert.equal((await call(user,'balance',{}, {Origin:'https://evil.test'})).status,403);
 const pre=await fetch(url+'/communityFeature',{method:'OPTIONS',headers:{Origin:'https://gen-z-code-55caf.web.app'}});assert.equal(pre.status,204);assert.equal(pre.headers.get('access-control-allow-origin'),'https://gen-z-code-55caf.web.app');
 assert.equal((await call(user,'unknown-action')).status,400);
 assert.equal((await call(user,'balance',{excess:'x'.repeat(40000)})).status,413);
 const malformed=await fetch(url+'/communityFeature',{method:'POST',headers:{'Content-Type':'application/json'},body:'{bad'});assert.equal(malformed.status,400);
 const health=await (await fetch(url+'/health')).json();assert.equal(health.edition,'hybrid-vps-28');assert.equal(health.purchasesEnabled,false);assert.ok(!JSON.stringify(health).includes('private_key'));
 assert.equal((await fetch(url+'/ready')).status,200);
 assert.equal((await fetch(url+'/missing')).status,404);
 const checkout=await fetch(url+'/verifyPurchase',{method:'POST',headers:{Authorization:'Bearer '+user,'Content-Type':'application/json'},body:'{}'});assert.equal(checkout.status,503);
});
test('admin grants are usable account credits, duplicate safe, and admin only',async()=>{
 assert.equal((await call(user,'grant-tokens',{uid:'vps-user',amount:500,requestId:'initial'})).status,403);
 assert.equal((await ok(admin,'grant-tokens',{uid:'vps-user',amount:500,requestId:'initial',note:'API test'})).balance,500);
 assert.equal((await ok(admin,'grant-tokens',{uid:'vps-user',amount:500,requestId:'initial'})).duplicate,true);
 assert.equal((await ok(user,'balance')).balance,500);
});
test('free contributions cannot accidentally charge through old API actions',async()=>{
 for(const action of ['create-code','create-post','chat-pass'])assert.equal((await call(user,action,{requestId:action})).status,400);
 assert.equal((await ok(user,'balance')).balance,500);
});
test('paid daily booking debits exactly 250 once and prevents permission escalation',async()=>{
 await db.doc('communityWords/vps-daily-word').set({term:'Focusglow',meaning:'A burst of concentration.',category:'Work',status:'live',uid:'vps-user',schema:3});
 const date=new Date(Date.now()+40*86400000).toISOString().slice(0,10),input={requestId:'vps-daily',wordId:'vps-daily-word',wordSource:'community',date};
 const results=await Promise.all([ok(user,'apply-daily',input),ok(user,'apply-daily',input)]);assert.equal(results.filter(r=>r.duplicate).length,1);
 assert.equal((await ok(user,'balance')).balance,250);
 assert.equal((await call(user,'daily-admin',{id:results[0].id,command:'approve'})).status,403);
 await ok(admin,'daily-admin',{id:results[0].id,command:'approve'});
 await ok(admin,'daily-admin',{id:results[0].id,command:'schedule',date});
 assert.equal((await db.doc('dailyCodeApplications/'+results[0].id).get()).get('status'),'scheduled');
 assert.equal((await call(user,'apply-verification',{requestId:'not-enough'})).status,400);
 assert.equal((await ok(user,'balance')).balance,250);
});
test('daily reward credits once, and signed rewarded ads require single-use server intent',async()=>{
 const r=await Promise.all([ok(user,'daily-reward'),ok(user,'daily-reward')]);assert.equal(r.filter(v=>v.duplicate).length,1);
 const intent=await ok(user,'reward-intent'),query=await signedReward(intent.id);
 assert.equal((await fetch(url+'/admobReward?'+query)).status,200);
 assert.equal((await fetch(url+'/admobReward?'+query)).status,200);
 assert.equal((await fetch(url+'/admobReward?'+await signedReward(intent.id,'replayed-intent'))).status,200);
 assert.equal((await fetch(url+'/admobReward?'+query.replace('vps-user','vps-admin'))).status,400);
 assert.equal((await fetch(url+'/admobReward?'+await signedReward('a'.repeat(48),'missing-intent'))).status,400);
 assert.equal((await ok(user,'balance')).balance,265);
});
test('reward attempts have a server enforced UTC daily cap',async()=>{
 for(let i=1;i<20;i++)await ok(user,'reward-intent');
 assert.equal((await call(user,'reward-intent')).status,429);
 assert.equal((await ok(user,'balance')).balance,265);
});
test('admin cancellation refunds a scheduled application once and enforced MFA cannot be bypassed',async()=>{
 const row=(await db.collection('dailyCodeApplications').where('uid','==','vps-user').get()).docs[0];
 await ok(admin,'daily-admin',{command:'cancel-schedule',date:row.get('reservedDate')});
 assert.equal((await ok(user,'balance')).balance,515);
 assert.equal((await db.doc('dailyCodeApplications/'+row.id).get()).get('payment'),'refunded');
 assert.equal((await call(admin,'daily-admin',{command:'cancel-schedule',date:row.get('reservedDate')})).status,404);
 assert.equal((await ok(user,'balance')).balance,515);
 await db.doc('config/security').set({adminMfaRequired:true});
 assert.equal((await call(admin,'grant-tokens',{uid:'vps-user',amount:5,requestId:'mfa-denied'})).status,403);
 await db.doc('config/security').delete();
});
