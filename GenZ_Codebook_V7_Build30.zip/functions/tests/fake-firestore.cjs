// Minimal in-memory stand-in for the firebase-admin Firestore API used by communityFeatures.
// Not a full emulator: transactions, doc reads/writes, simple queries and server timestamps.
const {FieldValue, FieldPath, Timestamp} = require('firebase-admin/firestore');
const SERVER = FieldValue.serverTimestamp();
const isServer = v => v && typeof v === 'object' && typeof v.isEqual === 'function' && v.isEqual(SERVER);
const isDocId = f => f && typeof f === 'object' && typeof f.isEqual === 'function' && f.isEqual(FieldPath.documentId());
function createDb(clock = () => Date.now()) {
  const store = new Map();
  class DocRef {
    constructor(path) {this.path = path; this.id = path.split('/').at(-1);}
    get parent() {return new Query(this.path.split('/').slice(0, -1).join('/'));}
    collection(name) {return new Query(this.path + '/' + name);}
    async get() {return snap(this);}
    async delete() {store.delete(this.path);}
  }
  class Query {
    constructor(path, filters = [], order = null, bounds = {}, max = Infinity) {Object.assign(this, {path, filters, order, bounds, max});}
    get parent() {const parts = this.path.split('/'); return parts.length > 1 ? new DocRef(parts.slice(0, -1).join('/')) : null;}
    doc(id = Math.random().toString(36).slice(2, 12)) {return new DocRef(this.path + '/' + id);}
    where(f, op, v) {return new Query(this.path, [...this.filters, {f, op, v}], this.order, this.bounds, this.max);}
    orderBy(f, dir = 'asc') {return new Query(this.path, this.filters, {f, dir}, this.bounds, this.max);}
    startAt(v) {return new Query(this.path, this.filters, this.order, {...this.bounds, startAt: v}, this.max);}
    startAfter(v) {return new Query(this.path, this.filters, this.order, {...this.bounds, startAfter: v}, this.max);}
    endAt(v) {return new Query(this.path, this.filters, this.order, {...this.bounds, endAt: v}, this.max);}
    limit(n) {return new Query(this.path, this.filters, this.order, this.bounds, n);}
    async get() {return run(this);}
  }
  const snap = ref => {const data = store.get(ref.path); return {id: ref.id, ref, exists: data !== undefined, data: () => data && structuredClone(data), get: f => data?.[f]};};
  const val = (d, f, id) => isDocId(f) ? id : d[f];
  const cmp = (a, b) => a < b ? -1 : a > b ? 1 : 0;
  function run(q) {
    const depth = q.path.split('/').length + 1;
    let docs = [...store.keys()].filter(k => k.startsWith(q.path + '/') && k.split('/').length === depth).map(k => snap(new DocRef(k)));
    for (const {f, op, v} of q.filters) docs = docs.filter(d => {
      const x = val(d.data(), f, d.id);
      return op === '==' ? x === v : op === 'in' ? v.includes(x) : op === '<' ? x < v : op === '>' ? x > v : op === '<=' ? x <= v : op === '>=' ? x >= v : op === '!=' ? x !== v : false;
    });
    if (q.order) {
      const key = d => val(d.data(), q.order.f, d.id);
      docs.sort((a, b) => cmp(key(a), key(b)) * (q.order.dir === 'desc' ? -1 : 1));
      if (q.bounds.startAt !== undefined) docs = docs.filter(d => key(d) >= q.bounds.startAt);
      if (q.bounds.startAfter !== undefined) docs = docs.filter(d => key(d) > q.bounds.startAfter);
      if (q.bounds.endAt !== undefined) docs = docs.filter(d => key(d) <= q.bounds.endAt);
    }
    docs = docs.slice(0, q.max);
    return {docs, size: docs.length, empty: !docs.length};
  }
  const resolve = (data, now) => Object.fromEntries(Object.entries(data).map(([k, v]) => [k, isServer(v) ? now : v]));
  async function runTransaction(fn) {
    const writes = [];
    const tx = {
      get: async r => r instanceof DocRef ? snap(r) : run(r),
      create: (r, d) => {writes.push(() => {if (store.has(r.path)) throw Object.assign(new Error('already exists: ' + r.path), {code: 6}); store.set(r.path, d);});},
      set: (r, d, o) => {writes.push(() => store.set(r.path, o?.merge ? {...(store.get(r.path) ?? {}), ...d} : d));},
      update: (r, d) => {writes.push(() => {if (!store.has(r.path)) throw new Error('no document to update: ' + r.path); store.set(r.path, {...store.get(r.path), ...d});});},
      delete: r => {writes.push(() => store.delete(r.path));},
    };
    const result = await fn(tx);
    const now = Timestamp.fromMillis(clock()), backup = new Map(store);
    try {for (const w of writes) w(); for (const [k, v] of store) if (v && typeof v === 'object') store.set(k, resolve(v, now));}
    catch (e) {store.clear(); for (const [k, v] of backup) store.set(k, v); throw e;}
    return result;
  }
  return {store, doc: p => new DocRef(p), collection: p => new Query(p), runTransaction,
    recursiveDelete: async ref => {for (const k of [...store.keys()]) if (k === ref.path || k.startsWith(ref.path + '/')) store.delete(k);}};
}
module.exports = {createDb};
