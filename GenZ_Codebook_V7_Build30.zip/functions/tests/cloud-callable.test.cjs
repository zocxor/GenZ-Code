const {test,after}=require('node:test');
const assert=require('node:assert/strict');
const {initializeApp,deleteApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
assert.ok(process.env.FIRESTORE_EMULATOR_HOST,'Use the Firestore emulator.');
const app=initializeApp({projectId:'demo-genz-feature-core'}),db=getFirestore(app);
const {communityFeature}=require('../lib/communityEndpoints');
after(()=>deleteApp(app));
const invoke=(uid,action,data={},verified=true)=>communityFeature.run({data:{action,...data},auth:uid?{uid,token:{email_verified:verified}}:undefined});
test('Cloud callable rejects unauthenticated and unverified users, and old paid core actions',async()=>{
 await assert.rejects(invoke(null,'balance'),e=>e.code==='unauthenticated');
 await assert.rejects(invoke('cloud-user','balance',{},false),e=>e.code==='permission-denied');
 for(const action of ['create-code','create-post','chat-pass'])await assert.rejects(invoke('cloud-user',action),e=>e.code==='failed-precondition');
});
test('Cloud callable exposes usable grants, idempotent daily bonuses and bounded ad intents',async()=>{
 await db.doc('users/cloud-user').set({status:'active'});
 await db.doc('users/cloud-admin').set({status:'active'});
 await db.doc('admins/cloud-admin').set({active:true,role:'super_admin'});
 await invoke('cloud-admin','grant-tokens',{uid:'cloud-user',amount:500,requestId:'cloud-opening'});
 assert.equal((await invoke('cloud-user','balance')).balance,500);
 const bonuses=await Promise.all([invoke('cloud-user','daily-reward'),invoke('cloud-user','daily-reward')]);
 assert.equal(bonuses.filter(v=>v.duplicate).length,1);
 assert.equal((await invoke('cloud-user','balance')).balance,505);
 const intent=await invoke('cloud-user','reward-intent');assert.match(intent.id,/^[a-f0-9]{48}$/);assert.equal(intent.reward,10);
 assert.equal((await db.doc('adRewardIntents/'+intent.id).get()).get('uid'),'cloud-user');
 await assert.rejects(invoke('cloud-user','grant-tokens',{uid:'cloud-user',amount:500,requestId:'forged'}),e=>e.code==='permission-denied');
 assert.equal((await invoke('cloud-user','balance')).balance,505);
});
