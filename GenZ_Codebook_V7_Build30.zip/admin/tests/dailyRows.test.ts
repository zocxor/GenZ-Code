import {test} from 'node:test';
import assert from 'node:assert/strict';
import {dailyRows} from '../src/lib/dailyRows';

const today = '2026-11-12';
test('an admin-scheduled word (HDOT) is listed as an upcoming, approved, editable entry', () => {
  const [row] = dailyRows({today, slots: [{id: '2026-11-13', status: 'scheduled', term: 'HDOT', meaning: 'Hot dog', category: 'Chat', wordSource: 'community', wordId: 'hdot'}], published: [], applications: {}, closed: []});
  assert.equal(row!.code, 'HDOT'); assert.equal(row!.approval, 'approved'); assert.equal(row!.publication, 'scheduled');
  assert.equal(row!.submittedBy, 'Administrator'); assert.ok(row!.canEdit); assert.deepEqual(row!.tabs, ['upcoming', 'approved']);
});
test('a pending user request shows the applicant and can be approved', () => {
  const [row] = dailyRows({today, slots: [{id: '2026-11-20', status: 'pending', applicationId: 'app1'}], published: [],
    applications: {app1: {status: 'pending', term: 'rizz', meaning: 'charm', category: 'Social', name: 'KBR', uid: 'u1'}}, closed: []});
  assert.equal(row!.code, 'rizz'); assert.equal(row!.approval, 'pending'); assert.ok(row!.canApprove);
  assert.ok(row!.tabs.includes('pending')); assert.match(row!.submittedBy, /KBR/);
});
test('published dates show what was published and are not editable', () => {
  const [row] = dailyRows({today, slots: [{id: '2026-11-11', status: 'published'}], published: [{id: '2026-11-11', term: 'HOD', meaning: 'Headache', category: 'Code Word'}], applications: {}, closed: []});
  assert.equal(row!.publication, 'published'); assert.equal(row!.code, 'HOD'); assert.equal(row!.canEdit, false);
});
test('an admin edit is shown instead of the original text', () => {
  const [row] = dailyRows({today, slots: [{id: '2026-11-15', status: 'scheduled', applicationId: 'a', edited: true, term: 'GOAT', meaning: 'Edited meaning', category: 'Social'}], published: [],
    applications: {a: {status: 'scheduled', term: 'GOAT', meaning: 'Original', category: 'Social'}}, closed: []});
  assert.equal(row!.meaning, 'Edited meaning'); assert.ok(row!.edited);
});
test('rejected requests appear only in the rejected tab', () => {
  const rows = dailyRows({today, slots: [], published: [], applications: {}, closed: [{id: 'x', status: 'rejected', term: 'yeet', requestedDate: '2026-11-14'}]});
  assert.deepEqual(rows[0]!.tabs, ['rejected']); assert.equal(rows[0]!.canEdit, false);
});
