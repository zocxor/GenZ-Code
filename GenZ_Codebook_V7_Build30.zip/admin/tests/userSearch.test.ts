import {test} from 'node:test';
import assert from 'node:assert/strict';
import {classifyUserSearch} from '../src/lib/userSearch';

test('admin search routes a referral code (user code) to the code lookup', () => {
  assert.deepEqual(classifyUserSearch('GZABC123'), {kind: 'referral', code: 'GZABC123'});
  assert.deepEqual(classifyUserSearch('  gzabc123  '), {kind: 'referral', code: 'GZABC123'});
  assert.deepEqual(classifyUserSearch('GZ123456'), {kind: 'referral', code: 'GZ123456'});
});

test('admin search routes e-mail (with @, with a dot, or a bare local-part fallback) to the directory prefix search', () => {
  assert.deepEqual(classifyUserSearch('kashif@example.com'), {kind: 'email', prefix: 'kashif@example.com'});
  assert.deepEqual(classifyUserSearch('KBR.Path@Gmail.com'), {kind: 'email', prefix: 'kbr.path@gmail.com'});
  // A dot can never be part of a Firebase UID, so it unambiguously means e-mail.
  assert.deepEqual(classifyUserSearch('kbr.path'), {kind: 'email', prefix: 'kbr.path'});
});

test('admin search routes a full user ID to the exact lookup', () => {
  assert.deepEqual(classifyUserSearch('Yn59ABVs14MvXyZ1234567890'), {kind: 'userId', id: 'Yn59ABVs14MvXyZ1234567890'});
  assert.deepEqual(classifyUserSearch('0Ym5Uz5BDD5t'), {kind: 'userId', id: '0Ym5Uz5BDD5t'});
});

test('a near-miss referral code (wrong length) falls through to the user-ID lookup', () => {
  // GZABC12 is 7 chars and GZABC1234 is 9 — neither is a referral code
  // (GZ + exactly 6), but both are valid user-ID shapes, so they route to
  // the exact user lookup, which simply finds nothing.
  assert.deepEqual(classifyUserSearch('GZABC12'), {kind: 'userId', id: 'GZABC12'});
  assert.deepEqual(classifyUserSearch('GZABC1234'), {kind: 'userId', id: 'GZABC1234'});
});

test('admin search rejects anything that is none of the three (short, spaces, bad chars)', () => {
  assert.deepEqual(classifyUserSearch(''), {kind: 'invalid'});
  assert.deepEqual(classifyUserSearch('   '), {kind: 'invalid'});
  assert.deepEqual(classifyUserSearch('abc'), {kind: 'invalid'});
  assert.deepEqual(classifyUserSearch('john doe'), {kind: 'invalid'});
});
