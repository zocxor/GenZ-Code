import assert from 'node:assert/strict';
import {test} from 'node:test';
import {dailyWordFromHash,dailyWordFromRecord,dailyWordLink,findDailyWords,wordKey} from '../src/lib/dailyWordPicker';

test('Daily Code search finds an exact live community word before partial matches', () => {
  const record = {term:'HDOT',meaning:'A test definition.',category:'Social',status:'live'};
  const hdot = dailyWordFromRecord('community','c-hdot',record);
  assert.ok(hdot);
  const words = [{...hdot,term:'Slashdotter',id:'reference',source:'bundled' as const},hdot];
  assert.equal(findDailyWords(words,'  hDoT  ')[0],hdot);
  assert.equal(dailyWordFromHash(dailyWordLink('community','c-hdot')),wordKey(hdot));
  assert.equal(dailyWordFromRecord('community','c-hdot',{...record,status:'hidden'}),null);
  assert.equal(dailyWordFromRecord('community','c-hdot',{...record,meaning:'See www.example.com'}),null);
  assert.equal(dailyWordFromRecord('submission','pending',{...record,status:'pending'}),null);
  assert.ok(dailyWordFromRecord('submission','accepted',{...record,status:'accepted',reviewedBy:'editor'}));
});
