import React, {useState} from 'react';
import {doc, getDoc, serverTimestamp} from 'firebase/firestore/lite';
import {multiFactor} from 'firebase/auth';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can, ROLE_LABELS} from '../rbac';
import {publishingMode,type PublishingMode} from '../../../shared/publishing';
import {BYLINE, RIGHTS, copyright} from '../../../shared/brand';
import {Card, Notice, Field, useLoad} from '../ui';

type AppConfig = {dictionaryPostingMode:'open'|'review'|'paused';postPostingMode:'open'|'review'|'paused';ugcEnabled: boolean; contentUpdatesEnabled: boolean; communityWordsEnabled: boolean; chatEnabled: boolean; minSupportedVersion: string; paidCommunity: boolean; encodeFreeDaily: number; encodeCreditCost: number};

export default function Settings() {
  const s = useSession();
  const cfg = useLoad(async (): Promise<AppConfig> => {
    const d = await getDoc(doc(db, 'config', 'app'));
    const v = d.exists() ? d.data() : {};
    return {dictionaryPostingMode:publishingMode(v,'code'),postPostingMode:publishingMode(v,'post'),ugcEnabled: v.ugcEnabled !== false, contentUpdatesEnabled: v.contentUpdatesEnabled !== false, communityWordsEnabled: v.communityWordsEnabled !== false, chatEnabled: v.chatEnabled !== false, paidCommunity: v.paidCommunity === true, encodeFreeDaily: Number.isInteger(v.encodeFreeDaily) ? v.encodeFreeDaily : 10, encodeCreditCost: Number.isInteger(v.encodeCreditCost) ? v.encodeCreditCost : 0, minSupportedVersion: typeof v.minSupportedVersion === 'string' ? v.minSupportedVersion : '0.8.3'};
  }, []);
  const [draft, setDraft] = useState<AppConfig | null>(null);
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  const value = draft ?? cfg.data;
  const save = async () => {
    if (!value) return;
    setBusy(true); setMsg(null);
    try {
      const b = newBatch();
      const lastAuditId = addAudit(b, s.uid, s.role, 'config.update', 'config/app', `ugc=${value.ugcEnabled} instant=${value.communityWordsEnabled} chat=${value.chatEnabled} paid=${value.paidCommunity} encode=${value.encodeFreeDaily}/${value.encodeCreditCost} content=${value.contentUpdatesEnabled} min=${value.minSupportedVersion}`);
      b.set(doc(db, 'config', 'app'), {...value, updatedAt: serverTimestamp(), updatedBy: s.uid, lastAuditId});
      await b.commit(); setMsg({kind: 'ok', text: 'Settings saved and audited.'}); setDraft(null); cfg.reload();
    } catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };
  const factors = multiFactor(s.user).enrolledFactors;
  return <div className="stack">
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    <Card title="Your session" index={0}>
      <dl className="grid-dl"><dt>Signed in as</dt><dd>{s.email}</dd><dt>Role</dt><dd>{ROLE_LABELS[s.role]}</dd><dt>Second factors</dt><dd>{factors.map(f => f.displayName ?? f.factorId).join(', ') || '—'}</dd><dt>Session</dt><dd>This tab only · ends after 30 minutes of inactivity</dd></dl>
    </Card>
    {can(s.role, 'config.manage') && <Card title="App controls" subtitle="Public flags read by the app and enforced by security rules. Changes are audited." index={1}>
      {cfg.error ? <Notice kind="error">{errorMessage(cfg.error)}</Notice> : value && <>
        <label className="row"><input type="checkbox" checked={value.ugcEnabled} onChange={e => setDraft({...value, ugcEnabled: e.target.checked})} /> Accept word suggestions and reports from users (kill switch for abuse)</label>
        {(['dictionaryPostingMode','postPostingMode'] as const).map(key=><Field key={key} label={key==='dictionaryPostingMode'?'Dictionary code publishing':'Community post publishing'}>
          <select value={value[key]} onChange={e=>setDraft({...value,[key]:e.target.value as PublishingMode,...(key==='dictionaryPostingMode'?{communityWordsEnabled:e.target.value==='open'}:{})})}>
            <option value="open">Open — publish immediately after payment</option><option value="review">Approval required</option><option value="paused">Paused — accept no new submissions</option>
          </select>
        </Field>)}
        <label className="row"><input type="checkbox" checked={value.chatEnabled} onChange={e => setDraft({...value, chatEnabled: e.target.checked})} /> Community chat is open (turn off to close the chat room)</label>
        <h3>Credits</h3>
        <label className="row"><input type="checkbox" checked={value.paidCommunity} onChange={e => setDraft({...value, paidCommunity: e.target.checked})} /> Charge Credits for community features: chat day pass 30 · post 50 · new dictionary code 150</label>
        <Notice kind={value.paidCommunity ? 'ok' : 'info'}>{value.paidCommunity ? 'Paid mode is on. The app and security rules require Credits for these actions; old free-posting paths are refused.' : 'Turn this on only after the V7 backend is deployed (GitHub Actions → Deploy Firebase → community) and the V7 app is installed. Older app versions cannot pay for chat or posts.'}</Notice>
        <Field label="Encode Message · free conversions per user per day (0–1000)"><input type="number" min={0} max={1000} value={value.encodeFreeDaily} onChange={e => setDraft({...value, encodeFreeDaily: Math.max(0, Math.min(1000, Math.floor(Number(e.target.value) || 0)))})} /></Field>
        <Field label="Encode Message · Credits per extra conversion (reserved — Build 30 does not charge Credits for encoding yet)"><input type="number" min={0} max={1000} value={value.encodeCreditCost} onChange={e => setDraft({...value, encodeCreditCost: Math.max(0, Math.min(1000, Math.floor(Number(e.target.value) || 0)))})} /></Field>
        <h3>Content</h3>
        <label className="row"><input type="checkbox" checked={value.contentUpdatesEnabled} onChange={e => setDraft({...value, contentUpdatesEnabled: e.target.checked})} /> Deliver published content updates to apps</label>
        <Field label="Minimum supported app version (informational)"><input value={value.minSupportedVersion} onChange={e => setDraft({...value, minSupportedVersion: e.target.value.slice(0, 20)})} /></Field>
        <button className="btn primary" disabled={busy || !draft} onClick={() => void save()}>Save settings</button>
      </>}
    </Card>}
    <Card title="About this portal" index={2}>
      <dl className="grid-dl"><dt>Product</dt><dd>GenZ Codebook Admin Portal</dd><dt>Version</dt><dd>1.0.0 — First release</dd><dt>Publisher</dt><dd>{BYLINE}</dd></dl>
      <p className="muted small">{copyright()}. {RIGHTS}</p>
    </Card>
  </div>;
}
