import React, {useState} from 'react';
import {collection, query, where, orderBy, limit, getDocs, getCount, QueryConstraint, Timestamp} from 'firebase/firestore/lite';
import {db, errorMessage, newBatch, addAudit} from '../firebase';
import {useSession} from '../App';
import {securityMetrics} from '../lib/metrics';
import {Card, Stats, Stat, Skeleton, Notice, Pill, useLoad, when} from '../ui';

const ACTIONS = ['all', 'admin.login', 'admin.role.set', 'user.suspend', 'user.reactivate', 'user.delete', 'user.note', 'tokens.send', 'tokens.deduct', 'daily-code.approve', 'daily-code.schedule', 'daily-code.edit-schedule', 'daily-code.replace-schedule', 'daily-code.cancel-schedule', 'daily-code.schedule-word', 'content.create', 'content.update', 'content.submit_review', 'content.publish', 'content.archive', 'content.rollback', 'content.import', 'submission.accept', 'submission.reject', 'report.resolve', 'report.dismiss', 'feedback.triage', 'config.update', 'community.hide', 'community.restore', 'logs.purge'];
const TYPES = ['all', 'login_succeeded_after_failures', 'session_expired', 'reauth_failed', 'sync_permission_denied', 'sync_blocked_account_status', 'content_validation_rejected', 'account_deletion_started', 'admin_access_denied'];

/** Delete audit entries and security events past expireAt (replaces Firestore TTL, which needs billing). */
async function purgeExpired(): Promise<number> {
  let removed = 0;
  for (const name of ['auditLogs', 'securityEvents']) {
    for (let round = 0; round < 25; round++) {
      const snap = await getDocs(query(collection(db, name), where('expireAt', '<', Timestamp.now()), limit(400)));
      if (snap.empty) break;
      const b = newBatch();
      snap.docs.forEach(d => b.delete(d.ref));
      await b.commit();
      removed += snap.size;
      if (snap.size < 400) break;
    }
  }
  return removed;
}

const ICO_SIGNIN = <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="7.5" cy="15.5" r="4.5" /><path d="m11 12 9-9" /><path d="M17 4l2.5 2.5" /><path d="M14 7l2 2" /></svg>;
const ICO_SHIELD = <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3 5 6v5c0 5 3 8.5 7 10 4-1.5 7-5 7-10V6Z" /><path d="m9 12 2 2 4-4" /></svg>;
const ICO_ALERT = <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3 2.5 20h19Z" /><path d="M12 10v4" /><path d="M12 17.5h.01" /></svg>;
const ICO_CLOCK = <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>;

export default function Logs() {
  const s = useSession();
  const [action, setAction] = useState('all'), [type, setType] = useState('all');
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  /** Stat-row figures, all from real queries: single-field getCount calls
      (no composite index needed), securityMetrics() for the last 7 days,
      and the newest admin.login audit entry for the last sign-in. */
  const stats = useLoad(async () => {
    const [logins, denied, reauth, sec, lastSnap] = await Promise.all([
      getCount(query(collection(db, 'auditLogs'), where('action', '==', 'admin.login'))),
      getCount(query(collection(db, 'securityEvents'), where('type', '==', 'admin_access_denied'))),
      getCount(query(collection(db, 'securityEvents'), where('type', '==', 'reauth_failed'))),
      securityMetrics(),
      getDocs(query(collection(db, 'auditLogs'), where('action', '==', 'admin.login'), orderBy('at', 'desc'), limit(1))),
    ]);
    const last = lastSnap.docs[0]?.data() as {actor: string; at: {toMillis(): number}} | undefined;
    return {
      logins: logins.data().count,
      sec7: sec.total,
      sec7Capped: sec.capped,
      failures: denied.data().count + reauth.data().count,
      lastLogin: last ? {actor: last.actor, at: last.at} : null,
    };
  }, []);
  const purge = async () => {
    setBusy(true); setMsg(null);
    try {
      const n = await purgeExpired();
      const b = newBatch(); addAudit(b, s.uid, s.role, 'logs.purge', 'auditLogs', `removed ${n} expired entries`); await b.commit();
      setMsg({kind: 'ok', text: n ? `Deleted ${n} expired entries.` : 'Nothing has expired yet.'});
      audit.reload(); sec.reload(); stats.reload();
    } catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };
  const audit = useLoad(async () => {
    const c: QueryConstraint[] = action === 'all' ? [orderBy('at', 'desc'), limit(200)] : [where('action', '==', action), orderBy('at', 'desc'), limit(200)];
    return (await getDocs(query(collection(db, 'auditLogs'), ...c))).docs.map(d => ({id: d.id, ...d.data()} as {id: string; actor: string; role: string; action: string; target: string; summary: string; at: {toMillis(): number}}));
  }, [action]);
  const sec = useLoad(async () => {
    const c: QueryConstraint[] = type === 'all' ? [orderBy('at', 'desc'), limit(200)] : [where('type', '==', type), orderBy('at', 'desc'), limit(200)];
    return (await getDocs(query(collection(db, 'securityEvents'), ...c))).docs.map(d => ({id: d.id, ...d.data()} as {id: string; uid: string; type: string; detail: string; platform: string; appVersion: string; at: {toMillis(): number}}));
  }, [type]);
  return <div className="stack">
    <Notice kind="info">Audit entries are written in the same atomic batch as the action they describe (enforced by security rules) and cannot be edited. They expire after 365 days; security events expire after 90 days and contain no e-mail, IP address or message text.</Notice>
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    {stats.loading && !stats.data ? <Skeleton rows={4} /> : stats.error ? <Notice kind="error">{errorMessage(stats.error)}</Notice> : stats.data && <Stats>
      <Stat label="Admin sign-ins (all time)" num={stats.data.logins} hint="audit log expires after 365 days" icon={ICO_SIGNIN} tint="blue" />
      <Stat label="Security events (7 days)" num={stats.data.sec7} hint={stats.data.sec7Capped ? 'last 7 days · capped at 1,000' : 'last 7 days'} icon={ICO_SHIELD} tint="purple" />
      <Stat label="Access failures (all time)" num={stats.data.failures} hint="admin_access_denied + reauth_failed" icon={ICO_ALERT} tint="red" />
      <Stat label="Last sign-in" value={stats.data.lastLogin ? <span style={{fontSize: 18}}><code>{stats.data.lastLogin.actor.slice(0, 10)}</code></span> : '—'} hint={stats.data.lastLogin ? when(stats.data.lastLogin.at) : 'No sign-ins recorded'} icon={ICO_CLOCK} tint="green" />
    </Stats>}
    {s.role === 'super_admin' && <Card title="Retention clean-up" subtitle="Run about once a month. Only entries past their expiry date can be deleted (the server enforces this), and each clean-up is itself logged." index={1}>
      <button className="btn" disabled={busy} onClick={() => void purge()}>{busy ? 'Deleting…' : 'Delete expired entries'}</button>
    </Card>}
    <Card title="Admin audit log" subtitle="Newest 200" actions={<select aria-label="Filter by action" value={action} onChange={e => setAction(e.target.value)}>{ACTIONS.map(a => <option key={a}>{a}</option>)}</select>} index={2}>
      {audit.error ? <Notice kind="error">{errorMessage(audit.error)}</Notice> : <div className="table-wrap"><table><thead><tr><th>When</th><th>Action</th><th>Actor</th><th>Target</th><th>Summary</th></tr></thead><tbody>{audit.data?.map(a => <tr key={a.id}><td>{when(a.at)}</td><td><Pill tone="info">{a.action}</Pill></td><td><code>{a.actor.slice(0, 10)}</code> <span className="small muted">{a.role}</span></td><td><code>{a.target}</code></td><td className="clip">{a.summary}</td></tr>)}</tbody></table></div>}
      {audit.loading && <p className="muted">Loading…</p>}
    </Card>
    <Card title="Security events" subtitle="Newest 200" actions={<select aria-label="Filter by type" value={type} onChange={e => setType(e.target.value)}>{TYPES.map(a => <option key={a}>{a}</option>)}</select>} index={3}>
      {sec.error ? <Notice kind="error">{errorMessage(sec.error)}</Notice> : <><div className="table-wrap"><table><thead><tr><th>When</th><th>Type</th><th>User</th><th>Detail</th><th>Client</th><th>IP</th></tr></thead><tbody>{sec.data?.map(e => <tr key={e.id}><td>{when(e.at)}</td><td><Pill tone={/denied|failed/.test(e.type) ? 'warn' : 'neutral'}>{e.type}</Pill></td><td><code>{e.uid.slice(0, 10)}</code></td><td>{e.detail || '—'}</td><td>{e.platform} · {e.appVersion}</td><td>—</td></tr>)}</tbody></table></div><p className="muted small">IP addresses are not recorded.</p></>}
      {sec.loading && <p className="muted">Loading…</p>}
    </Card>
  </div>;
}
