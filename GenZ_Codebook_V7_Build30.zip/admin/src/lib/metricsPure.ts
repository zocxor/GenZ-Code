/** Pure metric calculations (no Firebase). */
const DAY = 86400_000;
export type CohortUser = {createdAt: number; lastActiveAt: number};
/**
 * "Still active after N days": share of a sign-up cohort whose last activity is at least N
 * days after sign-up. Only users who signed up at least N days ago are eligible for day N.
 */
export function retention(users: CohortUser[], now: number, days: number[]): {day: number; eligible: number; retained: number; rate: number | null}[] {
  return days.map(d => {
    const eligible = users.filter(u => u.createdAt && now - u.createdAt >= d * DAY);
    const retained = eligible.filter(u => u.lastActiveAt - u.createdAt >= d * DAY).length;
    return {day: d, eligible: eligible.length, retained, rate: eligible.length ? retained / eligible.length : null};
  });
}
export function versionShare(versions: string[]): {version: string; count: number}[] {
  const m = new Map<string, number>();
  for (const v of versions) m.set(v || 'unknown', (m.get(v || 'unknown') ?? 0) + 1);
  return [...m.entries()].map(([version, count]) => ({version, count})).sort((a, b) => b.count - a.count);
}

/** Referral claims grouped by referrer, most referrals first. Only the
 *  referrer's UID, their public referral code and the count are kept — no
 *  e-mail, no names (names are resolved separately in the portal, from the
 *  synced profile when the role permits, and fall back to the code). */
export type ReferralClaimRow = {referrerUid: string; code: string};
export function topReferrers(claims: ReferralClaimRow[], limitN = 5): {referrerUid: string; code: string; count: number}[] {
  const m = new Map<string, {referrerUid: string; code: string; count: number}>();
  for (const c of claims) {
    if (typeof c.referrerUid !== 'string' || !c.referrerUid) continue;
    const code = typeof c.code === 'string' ? c.code : '';
    const row = m.get(c.referrerUid) ?? {referrerUid: c.referrerUid, code, count: 0};
    row.count += 1;
    if (!row.code && code) row.code = code;
    m.set(c.referrerUid, row);
  }
  return [...m.values()].sort((a, b) => b.count - a.count || a.referrerUid.localeCompare(b.referrerUid)).slice(0, Math.max(0, limitN));
}

