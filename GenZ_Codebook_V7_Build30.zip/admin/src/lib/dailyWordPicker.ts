import {screenWord} from '../../../shared/community';
import {normalizeTerm} from '../../../shared/contentSchema';

export type DailyWordSource = 'bundled' | 'submission' | 'published' | 'community';
export type DailyWord = {id:string;term:string;meaning:string;category:string;aliases?:string[];source:DailyWordSource};
export const wordSourceLabel = {bundled:'Dictionary',submission:'Approved suggestion',published:'Published entry',community:'Live community word'};
export const wordKey = (word:Pick<DailyWord,'source'|'id'>) => word.source + ':' + word.id;
export const dailyWordLink = (source:DailyWordSource,id:string) => '#daily-code?' + new URLSearchParams({word:wordKey({source,id})});
export const dailyWordFromHash = (hash:string) => new URLSearchParams(hash.split('?')[1]).get('word') ?? '';

export function dailyWordFromRecord(source:Exclude<DailyWordSource,'bundled'>,id:string,record:Record<string,unknown>):DailyWord|null {
  const {term,meaning,category,status,reviewedBy,sensitivity,variations} = record;
  if (typeof term !== 'string' || !term.trim() || typeof meaning !== 'string' || !meaning.trim() || typeof category !== 'string' || !category.trim()) return null;
  if (source === 'submission' && (status !== 'accepted' || !reviewedBy)) return null;
  if (source === 'published' && (status !== 'published' || sensitivity !== 'None')) return null;
  if (source === 'community') {
    if (status !== 'live') return null;
    const screening = screenWord({term,meaning,example:''});
    if (!screening.ok || screening.review) return null;
  }
  const aliases = Array.isArray(variations) ? variations.filter((value):value is string=>typeof value==='string') : [];
  return {source,id,term,meaning,category,aliases};
}

export function findDailyWords(words:DailyWord[],search:string) {
  const needle = normalizeTerm(search);
  if (!needle) return words;
  const exact:DailyWord[] = [], partial:DailyWord[] = [];
  for (const word of words) {
    const term = normalizeTerm(word.term);
    const aliases = (word.aliases ?? []).map(normalizeTerm);
    if (term === needle) exact.push(word);
    else if (term.includes(needle) || aliases.some(alias=>alias.includes(needle))) partial.push(word);
  }
  return [...exact,...partial];
}
