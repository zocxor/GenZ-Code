/**
 * Admin Users search routing (pure — no Firebase, unit-tested).
 *
 * One search box accepts three kinds of input, tried in this order:
 *  1. Referral code ("user code"): GZ + 6 uppercase alphanumerics
 *     (e.g. GZABC123). Resolved via the referrals/{code} document.
 *  2. E-mail: anything containing '@' or '.'. A Firebase UID never
 *     contains either, so a dot unambiguously means e-mail — this is what
 *     makes a prefix typed without '@' (e.g. "kbr.path") work instead of
 *     falling through to the user-ID branch and erroring.
 *  3. User ID: a full ID matching /^[A-Za-z0-9_-]{6,128}$/ (exact lookup).
 *     Callers fall back to an e-mail prefix search when the exact lookup
 *     finds nothing, so a bare e-mail local-part (e.g. "kashif") still
 *     resolves instead of erroring.
 * Anything else is 'invalid' — the caller shows the hint text.
 */
import {isReferralCode, normaliseReferralCode} from '../../../shared/referral';

export type UserSearch =
  | {kind: 'referral'; code: string}
  | {kind: 'email'; prefix: string}
  | {kind: 'userId'; id: string}
  | {kind: 'invalid'};

const USER_ID_RE = /^[A-Za-z0-9_-]{6,128}$/;

export function classifyUserSearch(raw: string): UserSearch {
  const q = raw.trim();
  if (!q) return {kind: 'invalid'};
  const code = normaliseReferralCode(q);
  if (isReferralCode(code)) return {kind: 'referral', code};
  if (q.includes('@') || q.includes('.')) return {kind: 'email', prefix: q.toLowerCase()};
  if (USER_ID_RE.test(q)) return {kind: 'userId', id: q};
  return {kind: 'invalid'};
}
