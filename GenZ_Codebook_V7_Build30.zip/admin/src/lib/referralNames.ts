/**
 * Display-name resolution for referral views in the admin portal.
 *
 * A user's display name lives in their synced profile
 * (users/{uid}/sync/profile → profile.name). That document is readable only
 * by the owner or a PII role (super_admin, support_admin) — the Firestore
 * rules cannot do field-level reads, so there is no way to expose just the
 * name to other roles. This helper therefore returns null for roles that
 * cannot read the profile, and callers fall back to the referral code
 * (public by design — it is printed on share links). It never returns an
 * e-mail, a UID, or any other identifier: the name is the only field read,
 * and it is validated with the same cleanDisplayName the app uses.
 */
import {doc, getDoc} from 'firebase/firestore/lite';
import {db} from '../firebase';
import {cleanDisplayName} from '../../../shared/referral';

export async function resolveReferrerName(uid: string): Promise<string | null> {
  if (!uid) return null;
  try {
    const snap = await getDoc(doc(db, 'users', uid, 'sync', 'profile'));
    if (!snap.exists()) return null;
    const d = snap.data() as {profile?: {name?: unknown}};
    return cleanDisplayName(d.profile?.name);
  } catch {
    // Permission denied for non-PII roles, or offline — the caller falls
    // back to the referral code. Never throws into the UI.
    return null;
  }
}
