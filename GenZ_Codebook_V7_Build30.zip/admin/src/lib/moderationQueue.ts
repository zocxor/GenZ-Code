import {useEffect,useRef,useState} from 'react';
import {collection,getDocs,query,where,orderBy,documentId,limit,startAfter,type QueryDocumentSnapshot} from 'firebase/firestore/lite';
import {db} from '../firebase';

export function useModerationQueue<T>(name:string,status:string,active:boolean) {
  const [data,setData]=useState<T[]>([]),[error,setError]=useState<unknown>(null),[loading,setLoading]=useState(false),[more,setMore]=useState(false),[tick,setTick]=useState(0);
  const cursor=useRef<QueryDocumentSnapshot|null>(null),generation=useRef(0),pending=useRef(false);
  const load=async(append:boolean,version:number)=>{
    if(pending.current)return;
    pending.current=true;setLoading(true);setError(null);
    try{
      const snapshot=await getDocs(query(collection(db,name),where('status','==',status),orderBy('createdAt','desc'),orderBy(documentId(),'desc'),...(append&&cursor.current?[startAfter(cursor.current)]:[]),limit(25)));
      if(generation.current!==version)return;
      const rows=snapshot.docs.map(doc=>({...doc.data(),id:doc.id}) as T);
      setData(current=>append?[...current,...rows]:rows);cursor.current=snapshot.docs.at(-1)??null;setMore(snapshot.size===25);
    }catch(cause){if(generation.current===version)setError(cause);}
    finally{if(generation.current===version){pending.current=false;setLoading(false);}}
  };
  useEffect(()=>{
    const version=++generation.current;pending.current=false;cursor.current=null;setData([]);setMore(false);setError(null);
    if(active)void load(false,version);else setLoading(false);
    return ()=>{generation.current++;};
  },[name,status,active,tick]);
  return {data,error,loading,more,reload:()=>setTick(v=>v+1),loadMore:()=>{if(active&&!pending.current&&more)void load(true,generation.current);}};
}
