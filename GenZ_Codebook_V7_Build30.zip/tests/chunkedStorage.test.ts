import {test} from 'node:test';
import assert from 'node:assert/strict';
import {chunkedStorage, CHUNK, type KeyValue} from '../src/auth/chunkedStorage';

function memory(limitBytes = Infinity) {
  const map = new Map<string, string>();
  let failAt = -1, sets = 0, broken = false;
  const kv: KeyValue = {
    get: async k => {if (broken) throw new Error('keystore'); return map.get(k) ?? null;},
    set: async (k, v) => {
      if (broken) throw new Error('keystore');
      if (sets++ === failAt) throw new Error('crash');
      if (Buffer.byteLength(v) > limitBytes) throw new Error('too large');
      map.set(k, v);
    },
    del: async k => {map.delete(k);},
  };
  return {kv, map, failOn: (n: number) => {sets = 0; failAt = n;}, breakIt: () => {broken = true;}};
}
const bigSession = JSON.stringify({uid: 'u1', stsTokenManager: {accessToken: 'x'.repeat(1200), refreshToken: 'r'.repeat(300)}, displayName: 'Zoë 😀 خان', providerData: [{providerId: 'google.com', photoURL: 'https://example.com/' + 'p'.repeat(400)}]});

test('a session larger than the SecureStore limit round-trips', async () => {
  const secure = memory(2048), fb = memory();
  const store = chunkedStorage(secure.kv, fb.kv);
  assert.ok(Buffer.byteLength(bigSession) > 2048);
  await store.setItem('firebase:authUser', bigSession);
  assert.equal(await store.getItem('firebase:authUser'), bigSession);
  assert.equal(fb.map.size, 0, 'no fallback needed');
  for (const v of secure.map.values()) assert.ok(Buffer.byteLength(v) <= 2048);
});
test('sessions stored by earlier builds (single value) are still read, then migrated', async () => {
  const secure = memory(), fb = memory();
  secure.map.set('firebase:authUser', 'legacy-json');
  const store = chunkedStorage(secure.kv, fb.kv);
  assert.equal(await store.getItem('firebase:authUser'), 'legacy-json');
  await store.setItem('firebase:authUser', 'new-json');
  assert.equal(await store.getItem('firebase:authUser'), 'new-json');
  assert.equal(secure.map.has('firebase:authUser'), false, 'legacy value removed after migration');
});
test('a crash while writing keeps the previous session', async () => {
  const secure = memory(), fb = memory();
  const store = chunkedStorage(secure.kv, fb.kv);
  await store.setItem('k', 'old-session');
  secure.failOn(1);
  const next = 'n'.repeat(CHUNK * 3);
  await store.setItem('k', next).catch(() => {});
  const value = await store.getItem('k');
  assert.ok(value === 'old-session' || value === next, 'never a mix of old and new');
});
test('if SecureStore is unavailable the session is kept in the fallback', async () => {
  const secure = memory(), fb = memory();
  secure.breakIt();
  const store = chunkedStorage(secure.kv, fb.kv);
  await store.setItem('k', bigSession);
  assert.equal(await store.getItem('k'), bigSession);
});
test('removeItem clears every copy', async () => {
  const secure = memory(), fb = memory();
  const store = chunkedStorage(secure.kv, fb.kv);
  await store.setItem('k', bigSession);
  await store.removeItem('k');
  assert.equal(await store.getItem('k'), null);
  assert.equal(secure.map.size, 0);
});
test('surrogate pairs are never split across chunks', async () => {
  const secure = memory(), fb = memory();
  const store = chunkedStorage(secure.kv, fb.kv);
  const value = 'a'.repeat(CHUNK - 1) + '😀' + 'b'.repeat(10);
  await store.setItem('k', value);
  for (const v of secure.map.values()) assert.ok(!/[\ud800-\udbff]$/.test(v) && !/^[\udc00-\udfff]/.test(v));
  assert.equal(await store.getItem('k'), value);
});
