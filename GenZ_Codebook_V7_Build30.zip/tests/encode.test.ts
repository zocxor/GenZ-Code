import {test} from 'node:test';
import assert from 'node:assert/strict';
import {encode} from '../src/encode';
import {decode} from '../src/engine';

test('hello, how are you? keeps punctuation and encodes the phrase', () => {
  const r = encode('Hello, how are you?');
  assert.equal(r.output, 'Hello, hru?');
  assert.equal(r.replaced, 1);
});
test('common phrases become their well-known codes, case-insensitively', () => {
  assert.equal(encode('BE RIGHT BACK').output, 'BRB');
  assert.equal(encode("to be honest I don't know").output, 'tbh idk');
  assert.equal(encode('talk to you later, thank you').output, 'ttyl, ty');
  assert.equal(encode('what are you doing right now').output, 'wyd rn');
});
test('unmatched words and sentence structure are preserved', () => {
  const r = encode('The meeting is at noon.');
  assert.equal(r.output, 'The meeting is at noon.');
  assert.equal(r.replaced, 0);
});
test('obscure single-word entries do not change ordinary words', () => {
  assert.equal(encode('hello').output, 'hello');
});
test('phrases never join across punctuation', () => {
  assert.equal(encode('be right, back').output, 'be right, back');
});
test('alternatives are offered and a chosen alternative is used', () => {
  const seg = encode('thank you').segments.find(s => s.code)!;
  assert.ok(seg.options!.length > 1, 'has alternatives');
  const other = seg.options!.find(o => o !== seg.code)!;
  assert.equal(encode('thank you', {[seg.phrase!]: other}).output, other);
});
test('encoded output decodes back', () => {
  assert.ok(decode(encode('be right back, to be honest').output).recognized >= 2);
});
test('long input is rejected like the decoder', () => {
  assert.throws(() => encode('x'.repeat(2001)), RangeError);
});
