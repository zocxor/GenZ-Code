import test from 'node:test';
import assert from 'node:assert/strict';
import {TOKENS, parseTokens} from '../shared/tokens';
import {referralCodeForUid, isReferralCode, normaliseReferralCode, referralLink, parseReferralLink, referralShareMessage, referralClaimLedgerId, referralReferrerLedgerId, referralCreditKey, decideReferralClaim, cleanDisplayName, safeReferredBy, safeReferredFriend} from '../shared/referral';
import {emptyState} from '../src/profile';
import {creditReferrals} from '../src/learning';

test('referral: the reward is exactly 100 tokens for each user, in one place', () => {
  assert.equal(TOKENS.REFERRAL_REWARD, 100);
});

test('referral: codes are "GZ" + 6 uppercase alphanumerics, stable per UID, unique per UID', () => {
  const a = referralCodeForUid('alice-uid-123');
  const b = referralCodeForUid('bob-uid-456');
  assert.match(a, /^GZ[A-Z0-9]{6}$/);
  assert.match(b, /^GZ[A-Z0-9]{6}$/);
  assert.equal(referralCodeForUid('alice-uid-123'), a, 'same UID always yields the same code');
  assert.notEqual(a, b, 'different UIDs yield different codes');
  assert.equal(referralCodeForUid(''), '', 'no code without an account');
  // A spread of UIDs must not collide (36^6 is ~2.2 billion codes).
  const codes = new Set(Array.from({length: 1000}, (_, i) => referralCodeForUid(`user-${i}-abcdefghijklmnopqrstuvwxyz`)));
  assert.equal(codes.size, 1000);
});

test('referral: code validation is strict, normalisation is forgiving', () => {
  assert.equal(isReferralCode('GZABC123'), true);
  assert.equal(isReferralCode('GZ000000'), true);
  assert.equal(isReferralCode('gzabc123'), false, 'lower-case is not a valid code as written');
  assert.equal(isReferralCode('GZABC12'), false, 'too short');
  assert.equal(isReferralCode('GZABC1234'), false, 'too long');
  assert.equal(isReferralCode('GXABC123'), false, 'wrong prefix');
  assert.equal(isReferralCode('GZABC12!'), false, 'punctuation is not allowed');
  assert.equal(isReferralCode(''), false);
  assert.equal(isReferralCode(42), false);
  assert.equal(normaliseReferralCode('  gzabc123 '), 'GZABC123');
  assert.equal(normaliseReferralCode('GZABC123'), 'GZABC123');
});

test('referral: links use the genzcode scheme and parse back to the code', () => {
  const code = 'GZABC123';
  assert.equal(referralLink(code), 'genzcode://referral?code=GZABC123');
  assert.equal(parseReferralLink('genzcode://referral?code=GZABC123'), code);
  assert.equal(parseReferralLink('genzcode://referral/GZABC123'), code, 'path form also works');
  assert.equal(parseReferralLink('genzcode://referral?code=gzabc123'), code, 'lower-case code in a link still resolves');
  assert.equal(parseReferralLink('genzcode://referral?code=GZABC123&utm=share'), code, 'extra query params are ignored');
  assert.equal(parseReferralLink('genzcode://referral'), null, 'no code');
  assert.equal(parseReferralLink('genzcode://referral?code=BAD'), null, 'malformed code');
  assert.equal(parseReferralLink('genzcode://words?code=GZABC123'), null, 'wrong path');
  assert.equal(parseReferralLink('https://word369.com/referral?code=GZABC123'), null, 'wrong scheme');
  assert.equal(parseReferralLink(''), null);
  const msg = referralShareMessage(code);
  assert.ok(msg.includes(code), 'share message names the code');
  assert.ok(msg.includes(referralLink(code)), 'share message carries the link');
  assert.ok(msg.includes('100 Credits'), 'share message states the reward');
});

test('referral: claim validation — invalid code, self-referral, double claim, valid claim', () => {
  // Invalid: malformed code, unknown code (resolves to no UID), empty UID.
  assert.equal(decideReferralClaim('BAD', 'new-uid', 'ref-uid', false), 'invalid');
  assert.equal(decideReferralClaim('GZABC123', 'new-uid', null, false), 'invalid', 'code that belongs to no user');
  assert.equal(decideReferralClaim('', 'new-uid', 'ref-uid', false), 'invalid');
  assert.equal(decideReferralClaim('GZABC123', '', 'ref-uid', false), 'invalid');
  // Self-referral: the code belongs to the new user themselves.
  assert.equal(decideReferralClaim('GZABC123', 'same-uid', 'same-uid', false), 'self');
  // Double claim: the new user already has a claim, even with a valid code.
  assert.equal(decideReferralClaim('GZABC123', 'new-uid', 'ref-uid', true), 'already-claimed');
  // Valid: a real code, a different referrer, no existing claim.
  assert.equal(decideReferralClaim('GZABC123', 'new-uid', 'ref-uid', false), 'claimed');
  assert.equal(decideReferralClaim('  gzabc123 ', 'new-uid', 'ref-uid', false), 'claimed', 'pasted / lower-case code still claims');
});

test('referral: the 100-token reward pays both users, exactly once', () => {
  const now = Date.now();
  const state = emptyState();
  // New user: +100, counted once even if the credit is applied twice.
  const once = creditReferrals(['friend-uid'])(state, now);
  assert.equal(once.tokens.balance, TOKENS.REFERRAL_REWARD);
  assert.ok(once.tokens.credited.includes(referralCreditKey('friend-uid')));
  const twice = creditReferrals(['friend-uid'])(once, now);
  assert.equal(twice, once, 'a second credit for the same friend is a no-op');
  assert.equal(twice.tokens.balance, TOKENS.REFERRAL_REWARD);
  // Referrer: two different friends pay +100 each; the same friend never pays twice.
  const referrer = creditReferrals(['new-1', 'new-2'])(state, now);
  assert.equal(referrer.tokens.balance, 2 * TOKENS.REFERRAL_REWARD);
  const referrerAgain = creditReferrals(['new-1', 'new-3'])(referrer, now);
  assert.equal(referrerAgain.tokens.balance, 3 * TOKENS.REFERRAL_REWARD, 'only the new friend pays again');
  // The referral credit key survives storage validation (it is not dropped
  // by parseTokens like an unknown key would be).
  const parsed = parseTokens({balance: 100, credited: [referralCreditKey('friend-uid'), 'junk']});
  assert.deepEqual(parsed.credited, [referralCreditKey('friend-uid')]);
});

test('referral: ledger document ids are the duplicate guards', () => {
  // New user's own entry: one per claimed code.
  assert.equal(referralClaimLedgerId('GZABC123'), 'referral-GZABC123');
  // Referrer's entry: one per referred friend.
  assert.equal(referralReferrerLedgerId('new-user-uid'), 'referral-new-user-uid');
  // The two entries live in different users' ledgers (the new user's vs the
  // referrer's), so their IDs are in different namespaces — the same suffix
  // can never make them the same document.
  assert.equal(referralCreditKey('new-user-uid'), 'referral:new-user-uid');
});

test('referral privacy: display names are validated — anything else is null, never shown', () => {
  assert.equal(cleanDisplayName('Amy'), 'Amy');
  assert.equal(cleanDisplayName('  Code Explorer  '), 'Code Explorer', 'surrounding spaces are trimmed');
  assert.equal(cleanDisplayName('A'), 'A', 'one character is a name');
  assert.equal(cleanDisplayName('x'.repeat(24)), 'x'.repeat(24), '24 characters is the cap');
  assert.equal(cleanDisplayName(''), null, 'empty is not a name');
  assert.equal(cleanDisplayName('   '), null, 'whitespace-only is not a name');
  assert.equal(cleanDisplayName('x'.repeat(25)), null, 'over the cap is rejected, not truncated');
  assert.equal(cleanDisplayName(42), null, 'not a string');
  assert.equal(cleanDisplayName(null), null);
  assert.equal(cleanDisplayName(undefined), null);
  assert.equal(cleanDisplayName({name: 'Amy'}), null, 'an object is not a name');
});

test('referral privacy: a referral view strips everything but a display name (and the code the viewer already knows)', () => {
  // The raw record a caller might hold — UID, e-mail and phone included.
  const raw = {name: 'Amy', code: 'GZABC123', uid: 'amy-uid-123', email: 'amy@example.com', phone: '+92 300 1234567'};
  const by = safeReferredBy(raw as unknown as {name?: unknown; code?: unknown});
  assert.deepEqual(Object.keys(by).sort(), ['code', 'displayName'], 'no uid/email/phone key exists on the view');
  assert.equal(by.displayName, 'Amy');
  assert.equal(by.code, 'GZABC123', 'the code is public by design — the viewer entered it');
  assert.equal(JSON.stringify(by).includes('amy-uid-123'), false, 'UID never leaks into the view');
  assert.equal(JSON.stringify(by).includes('amy@example.com'), false, 'e-mail never leaks into the view');
  assert.equal(JSON.stringify(by).includes('+92'), false, 'phone never leaks into the view');
  // An unresolvable name and a bad code both become null — the UI falls back
  // to "Referred by a user" instead of inventing or leaking anything.
  assert.deepEqual(safeReferredBy({name: '', code: 'GZABC123'}), {displayName: null, code: 'GZABC123'});
  assert.deepEqual(safeReferredBy({name: 'Amy', code: 'BAD'}), {displayName: 'Amy', code: null});
  assert.deepEqual(safeReferredBy({}), {displayName: null, code: null});
});

test('referral privacy: a referred-friend row carries only a display name and a join date', () => {
  const row = safeReferredFriend({name: 'Bob', joinedAtMs: 1762764000000, uid: 'bob-uid', email: 'bob@example.com'} as unknown as {name?: unknown; joinedAtMs?: unknown});
  assert.deepEqual(Object.keys(row).sort(), ['displayName', 'joinedAtMs'], 'no uid/email/phone key exists on the row');
  assert.equal(row.displayName, 'Bob');
  assert.equal(row.joinedAtMs, 1762764000000);
  assert.equal(JSON.stringify(row).includes('bob-uid'), false, 'UID never leaks into the row');
  assert.equal(JSON.stringify(row).includes('bob@example.com'), false, 'e-mail never leaks into the row');
  // Bad dates become null (the UI omits the date) rather than a wrong one.
  assert.deepEqual(safeReferredFriend({name: 'Bob', joinedAtMs: 0}), {displayName: 'Bob', joinedAtMs: null});
  assert.deepEqual(safeReferredFriend({name: 'Bob', joinedAtMs: -5}), {displayName: 'Bob', joinedAtMs: null});
  assert.deepEqual(safeReferredFriend({name: 'Bob', joinedAtMs: Number.NaN}), {displayName: 'Bob', joinedAtMs: null});
  assert.deepEqual(safeReferredFriend({name: 'Bob', joinedAtMs: 'yesterday'}), {displayName: 'Bob', joinedAtMs: null});
  assert.deepEqual(safeReferredFriend({name: 'x'.repeat(25), joinedAtMs: 1762764000000}), {displayName: null, joinedAtMs: 1762764000000}, 'an over-long name is dropped, not shown');
  assert.deepEqual(safeReferredFriend({}), {displayName: null, joinedAtMs: null});
});
