// Community posts: validation, the 25-token price, and the wiring that ties
// the posts feature together (service, screen, rules). The posts themselves
// live in Firestore (communityPosts); the emulator rules tests cover the
// server-side checks, and these tests cover the pure parts that run locally.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {screenPost, toCommunityPost, POST_MAX_LENGTH, POST_RATE_LIMIT_SECONDS, POST_PAGE_SIZE} from '../shared/chat';

test('post filter: ordinary posts pass, empty and oversize posts are refused', () => {
  assert.deepEqual(screenPost('Hot take: “rizz” is just confidence with Wi-Fi.'), {ok: true});
  assert.deepEqual(screenPost('  hello everyone  '), {ok: true});
  assert.equal(screenPost('').ok, false);
  assert.equal(screenPost('   ').ok, false);
  assert.equal(screenPost('x'.repeat(POST_MAX_LENGTH + 1)).ok, false);
  assert.equal(screenPost('x'.repeat(POST_MAX_LENGTH)).ok, true);
  assert.equal(POST_MAX_LENGTH, 500);
  assert.equal(POST_RATE_LIMIT_SECONDS, 10);
  assert.equal(POST_PAGE_SIZE, 50);
});

test('post filter: sexual content, abuse, hate and threats are blocked, including leet-speak', () => {
  for (const bad of [
    'check out this porn link', 'you are a stupid slut', 'fuck you',
    'i hate you, nigger', 'you retard', 'send nudes pls',
    'kys', 'kill yourself', 'go die', 'i will kill you',
    'sh!t happens', 'b!tch please', 'sh1t happens', 'bhenchod', 'g4ndu',
  ]) {
    assert.equal(screenPost(bad).ok, false, bad);
  }
  assert.equal(screenPost('what does rizz mean?').ok, true);
  assert.equal(screenPost('that fit is fire, no cap').ok, true);
});

test('post filter: links, e-mail addresses and phone numbers are refused', () => {
  for (const bad of ['see https://x.example', 'visit www.spam.example', 'mail me@spam.io', 'call 0300 1234567']) {
    assert.equal(screenPost(bad).ok, false, bad);
  }
  assert.equal(screenPost('my number is 143').ok, true);
});

test('posts are validated before they are shown', () => {
  const at = {toMillis: () => 1780000000000};
  const good = {hidden: false, uid: 'u1', name: 'Aya', text: 'hi', likeCount: 3, createdAt: at};
  assert.deepEqual(toCommunityPost('p1', good), {id: 'p1', uid: 'u1', name: 'Aya', text: 'hi', at: 1780000000000, likeCount: 3});
  assert.equal(toCommunityPost('p1', {...good, hidden: true}), null, 'hidden posts never render');
  assert.equal(toCommunityPost('p1', {...good, likeCount: -1}), null, 'negative likeCount is invalid');
  assert.equal(toCommunityPost('p1', {...good, likeCount: 1.5}), null, 'fractional likeCount is invalid');
  assert.equal(toCommunityPost('p1', {...good, likeCount: '3'}), null, 'likeCount must be a number');
  assert.equal(toCommunityPost('p1', {...good, name: 'x'.repeat(25)}), null);
  assert.equal(toCommunityPost('p1', {...good, text: 'x'.repeat(POST_MAX_LENGTH + 1)}), null);
  assert.equal(toCommunityPost('p1', {...good, text: '   '}), null);
  assert.equal(toCommunityPost('p1', {...good, createdAt: undefined}), null, 'no timestamp, no post');
  assert.equal(toCommunityPost('p1', null), null);
});

test('posts: reviewed feed and fee are wired to the callable backend', () => {
  const policy = JSON.parse(readFileSync('functions/src/communityPolicy.json', 'utf8'));
  assert.equal(policy.postFee, 50, 'V7 price list: one community post costs 50 Credits');
  assert.equal(policy.dailyFee, 250);
  assert.equal(policy.verificationFee, 5000);
  const panel = readFileSync('src/CommunityPostsPanel.tsx', 'utf8');
  assert.match(panel, /feature\('create-post'/);
  assert.doesNotMatch(panel, /spendTokens/);
  const service = readFileSync('src/communityFeatures.ts', 'utf8');
  assert.match(service, /where\('status','==','approved'\)/);
  const screen = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.match(screen, /label="Posts"/);
  assert.match(screen, /label="Chat"/);
  assert.match(screen, /chat-pass/);
});
