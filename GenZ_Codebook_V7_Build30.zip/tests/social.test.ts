import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {SOCIAL_LINKS, SUPPORT_EMAIL, supportMailto} from '../shared/brand';

test('official social links are exactly the owner-supplied https URLs', () => {
  assert.deepEqual(SOCIAL_LINKS.map(l => l.url), [
    'https://www.instagram.com/genzcodebook?obrf=ZHA0emMyMDU1dW5u',
    'https://web.facebook.com/genzcodebook/',
    'https://whatsapp.com/channel/0029VbE6AvH6mYPDrpkjjy3N',
  ]);
  for (const l of SOCIAL_LINKS) assert.equal(new URL(l.url).protocol, 'https:');
});
test('Help & Support opens a mail to the support address', () => {
  assert.equal(SUPPORT_EMAIL, 'genzcodebook@gmail.com');
  assert.match(supportMailto('Help'), /^mailto:genzcodebook@gmail\.com\?subject=Help$/);
});
test('Stay connected appears in Settings and About and opens only allow-listed links', () => {
  for (const f of ['src/SettingsScreen.tsx', 'src/AboutScreen.tsx']) assert.match(readFileSync(f, 'utf8'), /<FollowUs \/>/);
  const c = readFileSync('src/FollowUs.tsx', 'utf8');
  assert.match(c, /if\(!allowed\.has\(url\)&&!url\.startsWith\(`mailto:\$\{SUPPORT_EMAIL\}`\)\)return;/);
});
