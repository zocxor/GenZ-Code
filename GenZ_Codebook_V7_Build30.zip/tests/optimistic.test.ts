import {test} from 'node:test';
import assert from 'node:assert/strict';
import {confirm, isOn, prune, rollback, shownCount, tap, type OptimisticMap} from '../src/optimistic';

test('a like shows immediately with the count raised by one', () => {
  const r = tap('p1', 4, new Set(), {}, false);
  assert.equal(r.send, true);
  assert.equal(r.desired, true);
  assert.equal(isOn('p1', new Set(), r.map), true);
  assert.equal(shownCount('p1', 4, r.map), 5);
});
test('unliking a confirmed like lowers the count immediately', () => {
  const r = tap('p1', 5, new Set(['p1']), {}, false);
  assert.equal(r.desired, false);
  assert.equal(shownCount('p1', 5, r.map), 4);
});
test('rapid taps while a request is in flight collapse into one follow-up', () => {
  let m: OptimisticMap = tap('p1', 4, new Set(), {}, false).map;
  const second = tap('p1', 4, new Set(), m, true);
  assert.equal(second.send, false);
  m = second.map;
  assert.equal(shownCount('p1', 4, m), 4);
  assert.equal(confirm('p1', true, m).resend, false, 'must send the final unlike');
});
test('the server count wins once the feed reflects the write', () => {
  let m = tap('p1', 4, new Set(), {}, false).map;
  m = confirm('p1', true, m).map;
  assert.equal(shownCount('p1', 4, m), 5, 'feed has not caught up yet');
  m = prune(m, {p1: 5});
  assert.deepEqual(m, {});
  assert.equal(shownCount('p1', 5, m), 5, 'no double counting');
});
test('a rejected write rolls back to the confirmed state', () => {
  let m = tap('p1', 4, new Set(), {}, false).map;
  m = rollback('p1', m);
  assert.equal(isOn('p1', new Set(), m), false);
  assert.equal(shownCount('p1', 4, m), 4);
});
test('counts never go negative', () => {
  assert.equal(shownCount('p1', 0, tap('p1', 0, new Set(['p1']), {}, false).map), 0);
});
