# Build 29 — Firebase Blaze conversion and checks

This release replaces the active VPS connection with Firebase Cloud Functions for the existing project `gen-z-code-55caf`, region `us-central1`. Your website stays at https://gen-z-code-55caf.web.app/ . No VPS, DuckDNS or purchased domain is required. Historical VPS files are retained as an optional fallback; do not run their workflow for this release.

## What changed

- Public backend configuration points to `https://us-central1-gen-z-code-55caf.cloudfunctions.net`, used by both Android and the admin portal. Existing Firebase data and user IDs stay in place.
- Restored deployment choices `community`, `daily-code`, `everything`, `functions`, `admin-portal`, `rules-and-indexes`, and `spark`; default is **community**.
- Restored the `/api/communityFeature` Hosting rewrite and added the Cloud Functions origin to the Hosting connection policy.
- The Cloud callable now supports verified ad reward intents and the idempotent daily +5 account reward, reusing the existing reward implementation. It rejects old paid create/post/chat actions; current creation, posts and chat remain free.
- Signed AdMob callbacks now require the server-issued, single-use reward intent on Firebase as well as VPS. A client callback cannot mint account tokens.
- Account token balance, admin grants, 250-token Daily Code booking/refunds, 5,000-token manual badge review and scheduling reuse the existing trusted ledger. Device-only learning points remain separate.
- Scheduled publication/catch-up runs every five minutes in UTC with retries. The callable and reward endpoint allow scale-to-zero and cap instances at three; these caps are not a monetary spending limit.
- Existing deletion trigger cleans up contributions when an account is marked deleted.
- Android version code is **29**, so the rebuilt app can update Build 28.
- One-time Play token checkout remains **disabled** until its separate Play API credentials, products and internal-track testing are ready. Blaze alone does not configure Google Play Billing. New recurring subscriptions remain disabled.

## Deploy from GitHub

1. Download and extract this release ZIP. Upload/commit the extracted contents into the existing repository root, including hidden `.github/workflows/`. Uploading a ZIP alone does not replace GitHub's workflow definitions.
2. Keep repository Actions secret `FIREBASE_SERVICE_ACCOUNT`. It must be a valid deploy credential for **gen-z-code-55caf**. Never commit it or paste it into chat.
3. Verify Blaze is active on this same Firebase project. Enable Cloud Functions, Cloud Build and Artifact Registry if the deployment reports a disabled API. Scheduled jobs and Firestore triggers may also require Cloud Scheduler/Eventarc/Pub/Sub/Cloud Run APIs. A project owner may need to enable these or grant the deploy service account suitable deployment permissions. Blaze activation does not automatically fix IAM permission errors.
4. Open **Actions → Deploy Firebase → Run workflow → What to deploy: community**. Leave the optional TOTP checkbox off unless you intentionally configured Firebase Authentication/Identity Platform MFA. Blaze does not itself enable TOTP for your administrators.
5. This target deploys rules, indexes, Hosting, `communityFeature`, `publishDailyCodes`, `cleanupContributions` and `admobReward`. It deliberately avoids Play-secret-dependent purchase/subscription functions. Wait for indexes and Functions to become ready; the workflow checks the public callable rejects unauthenticated wallet requests with HTTP 401.
6. Rebuild with **Actions → Android APK** and install the new Build 29. Old installed APKs retain their old backend configuration. Use the existing signed AAB release process for Play publishing; the checked JavaScript export is not a signed release.
7. Open admin Users, grant a small test amount to the correct Firebase user ID, and check the same account in Android. Test a Daily Code application and refund before opening the feature publicly.

If `community` is missing from the dropdown, the workflow file has not been updated on the selected GitHub branch. Replace `.github/workflows/deploy-firebase.yml` from this release and commit it first.

### AdMob setup

Set the existing rewarded ad unit's SSV callback to:

```
https://us-central1-gen-z-code-55caf.cloudfunctions.net/admobReward
```

Confirm ownership of ad unit `ca-app-pub-9776667186789824/4151797642`. The app supplies user ID and random custom data automatically. Verified rewards add +10 account tokens; the server allows 20 intent reservations per user per UTC day. No-fill/failed attempts consume a reservation in this edition. Tokens may arrive after the ad closes because SSV is asynchronous. Test with real Android test devices/ads and configure consent as appropriate.

### Optional token pack purchases

Do not select `everything`/`functions` just to activate Community: those targets include Play verification and subscription handlers bound to `PLAY_SERVICE_ACCOUNT_JSON`. First create/configure that Firebase Functions secret securely, authorize its service account in Play Console, verify the exact product IDs and test on an internal track. Then deploy the purchase functions and explicitly enable `tokenPurchasesEnabled` in the public config, rebuild and retest. Prices are one-time Google Play pack prices, not daily/monthly/yearly fees.

## Checks and limits

Validation: app TypeScript passed; Functions TypeScript build passed; admin TypeScript and production admin/public builds passed; Android JavaScript/Hermes export passed. App tests: 127 passed. Admin tests: 15 passed. Backend core/HTTP/Cloud callable emulator tests: 20 passed. Targeted client security scan: 131 files, no findings; not a penetration test. Firestore security-rules emulator tests: 61 passed. Total automated tests: 223 passed. Source completeness and ZIP integrity checks passed. Cloud endpoint metadata confirms us-central1, maximum three callable instances and a five-minute scheduler. No native signed APK/AAB or real-device advertising/purchase test was performed. The project was converted and checked locally; this workspace has no authenticated Firebase/GitHub deployment access. It cannot confirm your billing linkage, IAM, deployment success, live token grants or real AdMob/Play transactions. Rebuilding and running the selected GitHub workflow are still required.

Set Google Cloud billing budget alerts and monitor usage; alerts are notifications, not a hard spending cap. Cloud Functions execution, scheduling, Firestore and artifact storage may incur charges beyond applicable allowances. Keep Firebase's recommended artifact cleanup policy configured. Existing data is reused, not reset.

Relevant official documentation:
- https://firebase.google.com/docs/functions/get-started
- https://firebase.google.com/docs/functions/manage-functions
- https://firebase.google.com/docs/functions/schedule-functions

## Modified files for this conversion

- `shared/backend.json`
- `functions/src/accountRewards.ts` (shared reward implementation)
- `functions/src/vps/rewards.ts` (compatibility re-export)
- `functions/src/communityEndpoints.ts`
- `functions/src/adRewards.ts`
- `functions/tests/cloud-callable.test.cjs`
- `firebase.json`
- `.github/workflows/deploy-firebase.yml`
- `src/communityFeatures.ts`
- `admin/src/pages/CommunityWorkflow.tsx`
- `scripts/check-community-service.mjs`
- `app.json`, `android/app/build.gradle`
- `README.md`, this report

Earlier Build 28 setup instructions are historical for the VPS alternative. Follow this file for the active release.

## Live endpoint check before deployment

An unauthenticated POST probe returned **HTTP 404** at both the direct `communityFeature` URL and the Hosting `/api/communityFeature` URL during this conversion. This confirms the backend is not reachable yet; it does not verify account billing or IAM. Deploy the updated **community** target. After successful deployment these same unauthenticated probes should return **HTTP 401 / UNAUTHENTICATED**, which is the correct protected-service result. Do not interpret a browser GET error or a failed unauthenticated request as a failed wallet payment.

## Spending-limit screen shown during setup

The service-level spend cap screen is optional cost control, not a subscription fee. For this project, **Cloud Run Functions (Functions)** is the relevant row. An owner can choose an affordable monthly amount, for example EUR 5 for initial testing, and click Configure. That amount is not charged upfront or a prediction of usage. AI Logic and Cloud Run App Hosting are not used by this release and need not be configured to deploy it.

A Functions spend cap can pause new service usage for the rest of the month after its threshold is reached, so paid token operations, callbacks and scheduling can become unavailable until the cap is lifted or the period resets. Enforcement is delayed by reporting latency and overages are still billable. Other services, such as Firestore, artifact storage and scheduling, are not all covered by this one cap. Also configure a project-wide alerts-only budget and monitor actual charges. Existing free Firestore features remain separate, within their own availability/quotas.

Official spend-cap documentation: https://firebase.google.com/docs/projects/billing/spend-caps . This is distinct from alerts-only budgets, which do not pause services.

## Deployment retry-policy patch

GitHub deployment stopped with `Pass the --force option to deploy functions with a failure policy`. The cleanup trigger intentionally has retry enabled so transient failures do not leave deleted-account content behind. The workflow now adds `--force` for the explicitly scoped `community` and `daily-code` deployments to acknowledge that policy in non-interactive CI. It does not add the flag to unrestricted/full Functions deployments. Retried executions can incur normal execution charges.

Replace the actual repository-root `.github/workflows/deploy-firebase.yml`, commit it, then run a new workflow on that commit with target `community`. Rerunning the previous failed job uses the old workflow and will repeat the error. No new secret or IAM change is required for this specific error. Live deployment has not been performed here.
