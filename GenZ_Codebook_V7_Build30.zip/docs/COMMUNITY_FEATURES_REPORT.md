# GenZ Codebook · Community and Daily Code · Build 21

## Implemented

| Area | Workflow |
| --- | --- |
| Daily Code | Choose **Request review for Daily Code eligibility** in the existing dictionary suggestion form. After staff accepts it, select it from **Apply for Daily Code** on Decode or You. Confirm a UTC date and 250 eligible tokens. Staff can approve, edit the feature meaning, schedule, reschedule, reject or publish. |
| Publication | A date reservation and fee are committed together. One UTC date has one slot. Competing requests receive the next free date when one exists. The scheduler publishes the scheduled word or generates the default from the bundled dictionary. Offline clients use the bundled fallback for that UTC date. |
| Refunds | A Daily Code application is refunded in full on rejection, a missed slot, or owner cancellation before approval. The same transaction records the refund and releases the slot. Published applications and owner cancellations after approval are closed to further action. |
| Posts | Chat remains a separate tab. The reviewed feed has Latest, Trending, Code Words, Slangs and Saved views. Trending uses server-maintained likes plus comments. Structured submissions cost 25 eligible tokens and enter Pending. Users can copy, share, save, comment, like, report or remove their own post. Post fees cover submission review and are non-refundable. |
| Moderation | The Posts queue includes status, date and loaded-record search, edits, approval, rejection, removals and report decisions. Daily Code management includes a UTC calendar, decisions, history and CSV export of loaded records. Firebase roles and optional staff MFA are checked in each privileged backend action. |
| Verification | An application costs 5,000 eligible tokens and buys manual review. Rejected applications are non-refundable. Super Admins can approve, reject or revoke badges. The app reads the current public badge state beside names in chat, posts, comments, leaderboard and the profile. Profile photos stay device-local, so the feed uses initials. |
| Startup and keyboard | The startup splash waits at most 850 ms for the learning snapshot. Other reads, cloud refresh and billing move off that gate. The full-screen post composer hides the underlying navigation, has a scrollable form and a separate payment footer. Android uses resize behavior for the activity and React Native modal. |

## Payment compatibility

The existing account ledger remains the transaction record. The new features authorize charges using server-verifiable purchases, subscription credits, validated referral claims and audited administrator grants, less previous feature charges plus refunds. A client-writable wallet cache or a migrated device balance alone never authorizes a payment. The legacy wallet cache is updated when a new fee or refund is recorded. Device-only ad, quiz, streak and daily rewards still work for legacy activities. Those rewards need independent server verification before they can fund these new fees. Historical grants whose audit proof has expired and purchases without a verified server receipt are excluded from the eligible balance.

This release preserves the existing separate legacy token-earning model. Its device-local activity spends do not alter the verified-credit calculation for new features. A single authoritative balance for all legacy offline actions would require a separate migration to server-verified earnings and spends.

## Deployment

1. Extract the archive at the root of the existing private repository. Keep its Actions secrets and commit the workflow files.
2. Deploy to a staging project before production. The callable, Firestore rules and indexes, and the scheduled publisher are required. The existing GitHub **Deploy Firebase** workflow can deploy them with **everything**. The Firebase project must support Cloud Functions and Cloud Scheduler on Blaze. Keep the existing Play verification secret configured for the purchase functions.
3. Verify that new composite indexes have finished building. Use a verified test user and the existing **Send tokens** action from a Super Admin account to exercise the eligible-balance flow.
4. Run **Android APK** and distribute the build with version code 21 in coordination with the rules rollout. The updated rules block older clients from creating unreviewed posts or directly writing likes. Historical unreviewed posts are retained in Posts Moderation for an explicit approval decision.
5. On an Android device, test cold startup, sign-in, field focus with the keyboard open, the payment footer, clipboard, native sharing and the three complete user-to-admin journeys. Confirm the UTC publisher and refund worker against staging records.

Admin filters and CSV export operate on the loaded pages. User history shows the latest 100 records per section. The public feed and comments load up to 50 results per view.

## Validation

- App and portal TypeScript checks, 124 app tests and 14 portal tests, Android bundle export and portal production build.
- A local HTTP callable smoke test with real Auth-emulator ID tokens and Firestore verified authentication, the exact 25-token debit, retry safety, a refused non-admin decision and public approval. The standalone HTTP harness bypassed a Unix-socket restriction in the Functions emulator.
- The 56 Firestore rules and backend integration tests passed. The Firestore rules emulator verifies direct client payment/status/engagement forgery is refused. Pending and rejected posts and applications remain private, while approved posts are public.
- Backend integration tests exercise concurrent date reservations, idempotency, verified-credit eligibility, dictionary approval eligibility, rescheduling, refunds, automatic publication, post review and engagement, badge approval, non-refunded rejection and revocation.
- Physical Android keyboard, launch timing, clipboard and share UI, APK assembly, and deployment to the live Firebase project remain to be verified.

## Modified files

- `.github/workflows/deploy-firebase.yml`
- `App.tsx`
- `README.md`
- `admin/src/App.tsx`
- `admin/src/pages/CommunityWorkflow.tsx`
- `admin/src/rbac.ts`
- `admin/src/styles.css`
- `android/app/build.gradle`
- `app.json`
- `docs/BUILD_APK.md`
- `docs/COMMUNITY_FEATURES_REPORT.md`
- `docs/PLAY_PRODUCTION_READINESS.md`
- `firebase.json`
- `firebase/firestore.indexes.json`
- `firebase/firestore.rules`
- `firebase/rules-tests/rules.test.mjs`
- `functions/.gitignore`
- `functions/package.json`
- `functions/scripts/prepare-community.cjs`
- `functions/src/communityEndpoints.ts`
- `functions/src/communityFeatures.ts`
- `functions/src/communityPolicy.json`
- `functions/src/index.ts`
- `functions/tests/community-features.test.cjs`
- `package-lock.json`
- `package.json`
- `shared/tokens.ts`
- `src/CommunityPostsPanel.tsx`
- `src/CommunityScreen.tsx`
- `src/ContributionScreens.tsx`
- `src/ProfileDashboard.tsx`
- `src/SubmitForms.tsx`
- `src/VerifiedBadge.tsx`
- `src/WalletScreen.tsx`
- `src/communityFeatures.ts`
- `src/communityPosts.ts`
- `src/services.ts`
- `src/ugc.ts`
- `tests/chat.test.ts`
- `tests/posts.test.ts`
