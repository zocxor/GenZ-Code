GenZ Codebook Build 26

Version name 1.0.0. Android version code 26.

**Implemented behavior**

| Area | Result |
|---|---|
| Dictionary codes | Add / Create Your Own Code charges 150 account tokens atomically. Open publishing is the default. Admins can require approval or pause creation. Existing words are protected against duplicate creation. |
| Community posts | Posts cost 25 account tokens. Open-mode posts appear immediately. A post can reference an existing dictionary code such as HDOT. Duplicate posts by the same author are blocked. |
| Content rules | The composer and Chat Pass show the content disclaimer. Automatic screening rejects prohibited content. Admins can hide, restore, remove or permanently delete posts. Codes retain edit, hide, restore and delete controls. |
| Account removal | The existing admin deletion action writes the account tombstone. The contribution cleanup trigger also deletes the Firebase Auth user. Moderation decisions remain manual. |
| Daily Code applications | Users search public dictionary codes, preview a selection, choose a future UTC date and pay 250 account tokens. The suggestion shortcut has been removed from this page. The admin still reviews and schedules paid Daily Code applications. |
| HDOT scheduling | The admin callable uses the same hosting origin through /api/communityFeature. The callable permits public invocation while authenticating every action and checking admin roles. The deployment workflow checks the endpoint after release. |
| Chat | A 30-token pass opens chat until the next 00:00 UTC boundary. Messages then have no per-message charge. The entry interaction is a Vibe Check agreement to the community rules. Pass retries and simultaneous requests charge once. |
| Badge | Visible labels use Verified Badge. The application retains its 5,000-token manual-review fee. A clearly labeled KBR preview uses the existing shield/check artwork. No new badge asset was supplied in this request. |
| Feed | The creation banner is replaced by a compact Post Slang button. Latest, Trending, category filters, Saved and My Posts are in the options menu. Account tokens appear above the feed and in the composer. |
| Navigation and Play | Navigation labels are Home and Codes. Play has a daily challenge, three compact modes, category chips, review access and an expandable learning path. |
| Admin mobile | A native page selector replaces the mobile sidebar section menu. Cards, forms, statistics and the calendar use compact responsive spacing. Wide tables scroll within their panels. |
| Moderation performance | Only the selected section loads initially. Each query loads 25 records with stable cursor pagination. Opening Moderation no longer fetches six queues and all summary aggregations together. |
| Rewarded ads | Completed ads add 10 device tokens. The signed-in UID is included in AdMob server verification options. Verified callbacks add 10 usable account tokens once, using a signed callback and immutable receipt. |
| Interstitials | Natural completion points are used after successful posts or finished rounds. At least three completed activities and a two-minute interval are required between shows. |

**Activation in your project**

1. Extract this ZIP and commit its contents to the root of the existing GitHub repository, including .github/workflows.
2. Use GitHub Actions → Deploy Firebase → community. This publishes the rules, indexes, moderation portal, communityFeature, publication scheduler, account cleanup and admobReward. Cloud Functions require Firebase Blaze. The existing FIREBASE_SERVICE_ACCOUNT repository secret is required. This target does not deploy the Play billing verifier or require its secret.
3. In AdMob, enable server-side verification on rewarded ad unit ca-app-pub-9776667186789824/4151797642. Set the callback URL to https://us-central1-gen-z-code-55caf.cloudfunctions.net/admobReward. Configure a 10-token reward. Use a signed-in test account UID in AdMob's verification test tool.
4. Open Admin → Settings. Set Dictionary code publishing and Community post publishing to Open, Approval required or Paused. A legacy restriction or global kill switch remains effective until the admin changes it.
5. Build the new APK using GitHub Actions → Android APK and install the resulting internal APK for device testing. Publishing source changes alone does not update an installed APK.

**Why the screenshots show a balance but posting is unavailable**

The screenshot shows the Community callable failing before account credits can be checked. Updating styles cannot activate an absent or inaccessible backend. The new deployment target and endpoint check address this setup path. Production access and logs were unavailable during this task, so the live project's deployed state could not be verified.

The existing 508 device tokens are preserved as legacy local earnings. They are not proof of usable account credit. A Super Admin can use Users → Send tokens to grant an equivalent account balance after review. This is a new grant, so check existing account credits first to avoid paying the same balance twice. New signed-in ad rewards can fund posts, code creation, Chat Passes and Daily Code fees after AdMob confirms them. Signed-out rewards remain device-local. Old ad earnings cannot be retrospectively verified from a client-reported balance.

**Testing**

- App TypeScript checking and 126 app tests passed.
- Admin TypeScript checking, production build and 15 tests passed.
- Functions TypeScript build and 10 Firestore emulator integration tests passed, covering code fees, open/review/paused modes, existing-word posts, hide/restore/delete, Daily Code reservations, refunds, publication, verification, daily pass idempotency and signed ad reward receipts.
- All 53 Firestore rules tests passed, including refusal of forged ad rewards, unpaid direct code publication, forged passes, and messages without an unexpired Chat Pass.
- An authenticated HTTP callable journey passed through HDOT creation, immediate post publication, 150/25/250-token deductions, a Daily Code application, admin HDOT scheduling and one 30-token chat charge.
- The Android JavaScript bundle exported successfully.

**Remaining validation**

Production deployment, real AdMob callbacks, native APK keyboard behavior and mobile browser visual checks remain to be verified on the deployed project and devices. A browser launch was attempted but the runtime could not start Chromium. No native APK binary is included. The GitHub workflow builds it from this source. The existing badge art was retained for the KBR preview. Daily Code reservations that become invalid use the established refund/fallback policy.

**Suggested token economy**

| Activity | Implemented tokens | Rewarded ads from a zero balance, ignoring other earnings |
|---|---:|---:|
| Complete one voluntary rewarded ad | +10 | 1 |
| Read Home or Codes | 0 | 0 |
| Community post | 25 | 3 |
| Create or edit a dictionary code | 150 | 15 |
| Daily Chat Pass | 30 | 3 |
| Daily Code promotion application | 250 | 25 |
| Verified Badge application and review | 5,000 | 500 |

Retain +10 per rewarded ad as a starting point, with free browsing and earning through games. Measure repeat use before raising fees. The 150-token creation fee follows the request but represents a long ad-only path, so monitor completed submissions and returning users. A later test could lower the badge application to 1,000–2,000 tokens with a contribution requirement; that proposal is not implemented.

Revenue depends on filled impressions and observed eCPM. Estimate each ad format's revenue as impressions × eCPM ÷ 1,000, then subtract operating costs. Token amounts alone cannot predict profit. Use your AdMob reports for the app's country and format mix. Place interstitials at natural breaks and use voluntary rewarded ads for earning.

Official references

- https://developers.google.com/admob/android/ssv
- https://support.google.com/admob/answer/6201362
- https://support.google.com/admob/answer/15337570

**Modified and added files**

- .github/workflows/deploy-firebase.yml
- App.tsx
- README.md
- admin/src/App.tsx
- admin/src/lib/moderationQueue.ts
- admin/src/pages/CommunityWorkflow.tsx
- admin/src/pages/Moderation.tsx
- admin/src/pages/Settings.tsx
- admin/src/styles.css
- android/app/build.gradle
- app.json
- docs/BUILD26_REPORT.md
- docs/BUILD_APK.md
- firebase.json
- firebase/firestore.rules
- firebase/rules-tests/rules.test.mjs
- functions/scripts/prepare-community.cjs
- functions/src/adRewards.ts
- functions/src/communityEndpoints.ts
- functions/src/communityFeatures.ts
- functions/src/communityPolicy.json
- functions/src/index.ts
- functions/tests/community-features.test.cjs
- shared/communityErrors.ts
- shared/publishing.ts
- shared/tokens.ts
- src/AdRewardButton.tsx
- src/CommunityPostsPanel.tsx
- src/CommunityScreen.tsx
- src/ContributionScreens.tsx
- src/DictionaryScreen.tsx
- src/NavBar.tsx
- src/PlayHub.tsx
- src/ProfileDashboard.tsx
- src/SubmitForms.tsx
- src/SuggestBanner.tsx
- src/VerifiedBadge.tsx
- src/ads.tsx
- src/communityFeatures.ts
- src/publishing.ts
- src/ugc.ts
- tests/chat.test.ts
- tests/community.test.ts
- tests/posts.test.ts
- tests/tokens.test.ts
