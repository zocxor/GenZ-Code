# Build 28 implementation and testing report

## Result and boundaries

Prepared a hybrid release: Firebase Spark retains free core services, and the same backend business logic runs on your VPS rather than requiring a Cloud Functions deployment. The backend is not deployed yet. `shared/backend.json` intentionally contains an empty URL and disabled checkout until your real server passes readiness checks.

The existing user IDs, dictionary, profiles, Firestore collections, account transaction ledger, Play verification logic, authentication, chat and navigation are reused. No replacement database, test users, fabricated balances or dummy feed content is included in the delivered app.

## Feature ownership and pricing

| Activity | Release behavior |
| --- | --- |
| Read/learn/search codes | Free; bundled dictionary remains available offline |
| Create/suggest or edit a code | Free, Firebase rules validated; admin can require review or pause |
| Community chat | Free; verified account and respect/content rules apply |
| Community posts, likes, comments, saves and reports | Free, Firestore data and moderation; open/review/paused controls retained |
| Daily Code promotion | 250 account tokens, server transaction and one date reservation; refund if rejected, missed or admin-cancelled; users can cancel pending applications |
| Verified Badge application | 5,000 account tokens for manual review, not guaranteed approval; rejected applications non-refundable |
| Admin award/revoke badge | Free, authorized and audited |
| Rewarded ad, signed-in configured account | +10 account tokens after signed AdMob verification, maximum 20 reserved attempts per UTC day |
| Daily account reward | +5 account tokens, server enforced once per UTC day |
| Guest/unconfigured rewarded ad | +10 local learning points; these are not spendable account-token proof |
| Game progression | Existing local learning points; early level unlock costs 50 points |
| Token purchases | Optional one-time Play packs; checkout disabled until Play verification and catalog testing are configured |
| New recurring subscriptions | Disabled |

Keeping core participation free avoids forcing users to watch ads before creating words, posting or chatting. Optional rewards and restrained interstitials provide monetization opportunities. Tokens are in-app credits, not cash or withdrawable earnings.

## Implemented changes

- Added rules-validated Spark word/post creation and interactions, with zero fees, duplicate handling, timestamps and rate limits. Admin publishing restrictions remain enforceable in rules. Successful posting no longer depends on a missing Community Cloud Function or account balance endpoint.
- Kept Chat separate from Posts, removed the paid daily chat gate in this edition, and retained reports, moderation and verified badges.
- Kept compact community navigation/composer, reduced header/card layouts, registration code copy, distinct level names/icons and prior profile grouping fixes.
- Added a configured HTTPS VPS endpoint shared by Android and the admin portal. Paid operations fail safely when unavailable; free features continue using Firebase.
- Added Express HTTP transport with Firebase token verification, verified-email checks, existing admin/MFA checks, origin allowlist, request-size limits, rate limits and safe errors. Paid receipts and private service records remain inaccessible to direct client writes.
- Reused the trusted ledger for grants, Daily Code fees, booking conflicts, refunds, badge applications and purchase receipts. Audited old admin grants with valid proof remain eligible; arbitrary cached or device-only balances do not become paid credits.
- Added idempotent VPS admin grants, daily +5 reward and bounded, random ad intents. Account rewards require Google's signed SSV callback; a client completion event alone cannot mint paid credits.
- Added UTC publication/catch-up/refund jobs with a Firestore lease and deleted-account contribution cleanup. Reused existing daily scheduling and moderation logic. Added admin schedule cancellation/refund and retained free manual scheduling when no VPS is configured.
- Added non-root Docker API, Caddy HTTPS, private credential mounts, health/readiness, server setup/deploy scripts, and a GitHub VPS deployment workflow. Firebase deployment defaults to `spark` and excludes Cloud Functions.
- Kept one-time pack prices from real Play product metadata; new purchase checkout remains off by default. Extracted the existing Play HTTP handlers for VPS reuse instead of duplicating purchase-validation logic.
- Kept rewarded quiz hints optional and dependent on the earned-reward event; guarded against late callbacks applying to a different question. Interstitials occur only after completed activities with frequency limits.
- Added source packaging exclusions for private keys, runtime settings, dependencies and generated output while preserving required `admin/src/lib` source files.

## Verification performed in this workspace

| Check | Result |
| --- | --- |
| App TypeScript | Passed |
| Backend TypeScript build | Passed |
| Admin TypeScript and production admin/public web builds | Passed |
| App automated tests | 127 passed |
| Admin automated tests | 15 passed |
| Firestore security-rules emulator tests | 61 passed |
| Backend business logic + actual HTTP API with Auth/Firestore emulators | 18 passed |
| Android JavaScript/Hermes export | Passed; this is not a native APK/AAB build |
| Setup/deploy shell syntax and admin source completeness | Passed |
| Targeted security scan | 131 files checked; no findings (not a penetration test) |
| Production release gate | Blocked as expected: live/device/signing evidence and release signing variables are not supplied |
| Source ZIP integrity and required source inclusion | Checked during packaging |

The backend core suite covers simultaneous booking, duplicate payment, rescheduling, automatic publication, refunds, grant eligibility, badge approval/rejection/revocation, signed ad tampering and existing paid legacy behavior. Legacy fee tests intentionally remain regression coverage for old server business logic; this edition's public VPS route refuses paid create-code/create-post/chat-pass actions so they cannot charge accidentally.

New HTTP tests use real emulator Firebase ID tokens, an actual local HTTP server and locally signed EC reward fixtures. They check unauthenticated/invalid-token/unknown-action rejection, unverified-email and CORS denial, request bounds, checkout disabled, readiness, authorized grants, duplicated 250-token application, permission escalation, daily bonus duplication, signed ad credits/replays/forgery, daily reward-intent cap, admin cancellation refund and enforced MFA.

## Ad revenue: illustrative arithmetic, not a forecast

Google defines eCPM as earnings per thousand impressions. Your actual eCPM, ad fill and valid impressions are unknown. The assumed $1–$3 figures below are examples, not a claim about Pakistan or your app's current rates.

Assuming **three served ad impressions per active user per day for 30 days**:

| Daily active users | Monthly impressions | Gross at assumed $1 eCPM | Gross at assumed $3 eCPM |
| --- | ---: | ---: | ---: |
| 100 | 9,000 | $9 | $27 |
| 1,000 | 90,000 | $90 | $270 |
| 5,000 | 450,000 | $450 | $1,350 |

Gross ad revenue = impressions / 1,000 × actual eCPM. Subtract VPS, domain, taxes, any other service costs and adjustments. Fewer filled ads or returning users can reduce earnings substantially. Token pack sales are additional only if real purchases occur; no sales forecast is included. Start with conservative ad frequency and measure retention, valid impressions, revenue and VPS/Firebase usage before changing rewards or prices.

Official references:
- eCPM calculation: https://support.google.com/admob/answer/15337570
- Optional rewarded ads and rewards policy: https://support.google.com/admob/answer/7313578
- Server-side reward verification: https://developers.google.com/admob/android/ssv
- Firebase Admin SDK on a trusted server: https://firebase.google.com/docs/admin/setup
- Firebase pricing/quotas: https://firebase.google.com/pricing

## Remaining limitations / owner setup

1. No live VPS address, domain or credentials were supplied. Docker image execution, production HTTPS, real Firebase IAM and live scheduling remain deployment checks. Docker was unavailable in this workspace; shell syntax and Node builds were checked instead.
2. No signed native APK/AAB was built or physically tested here. Android keyboard behavior, consent, real ad delivery, SSV network callbacks and Play purchase/restore flows need real-device/internal-track testing.
3. Firebase Spark limits still apply to all Firestore reads/writes, including VPS Admin SDK traffic. The trusted wallet currently validates the ledger, so read cost grows with transaction history. Monitor quotas; the VPS does not provide unlimited Firebase usage.
4. Ad-intent/receipt records are retained for verification; a long-running deployment needs a planned retention/cleanup policy that preserves anti-replay guarantees. No paid Firebase TTL policy was enabled.
5. Existing custom pages, old installed APKs and old workflow files do not update automatically. Commit the extracted source/workflows, deploy Spark rules/indexes, configure the VPS URL and rebuild the app.
6. Historical paid posts remain in existing collections; schema-3 free posts use direct Spark moderation and historical paid posts fall back to the configured VPS moderation path. Do not bulk-reset existing data.
7. Refund policy is automatic for Daily Code; badge rejection deliberately does not refund. Use the review disclosures before enabling these paid screens.

Follow [VPS_SETUP.md](VPS_SETUP.md) for exact setup and deployment order. Do not publish as fully verified until live checks above pass.

## Changed/added files

Compared with the supplied earlier deployment snapshot; this list includes accumulated Build 27 fixes as well as this hybrid release. Generated build output and dependencies are excluded.

- `.dockerignore`
- `.github/workflows/android-apk.yml`
- `.github/workflows/deploy-firebase.yml`
- `.github/workflows/deploy-vps.yml`
- `.github/workflows/quality.yml`
- `.github/workflows/rules-tests.yml`
- `.gitignore`
- `App.tsx`
- `README.md`
- `admin/src/lib/sparkAdmin.ts`
- `admin/src/pages/CommunityWorkflow.tsx`
- `admin/src/pages/Users.tsx`
- `android/app/build.gradle`
- `app.json`
- `docs/BUILD27_REPORT.md`
- `docs/BUILD28_REPORT.md`
- `docs/VPS_SETUP.md`
- `firebase.json`
- `firebase/firestore.indexes.json`
- `firebase/firestore.rules`
- `firebase/rules-tests/rules.test.mjs`
- `functions/package-lock.json`
- `functions/package.json`
- `functions/src/adRewards.ts`
- `functions/src/communityFeatures.ts`
- `functions/src/index.ts`
- `functions/src/vps/app.ts`
- `functions/src/vps/rewards.ts`
- `functions/src/vps/server.ts`
- `functions/tests/community-features.test.cjs`
- `functions/tests/vps-api.test.cjs`
- `scripts/check-community-service.mjs`
- `scripts/configure-backend.mjs`
- `scripts/package-source.py`
- `shared/backend.json`
- `shared/communityErrors.ts`
- `shared/deployment.ts`
- `shared/tokens.ts`
- `src/AccountTokens.tsx`
- `src/AdRewardButton.tsx`
- `src/CommunityPostsPanel.tsx`
- `src/CommunityScreen.tsx`
- `src/ContributionScreens.tsx`
- `src/MySuggestionsScreen.tsx`
- `src/PlayHub.tsx`
- `src/ProfileDashboard.tsx`
- `src/SubmitForms.tsx`
- `src/SuggestBanner.tsx`
- `src/TokenShopScreen.tsx`
- `src/WalletScreen.tsx`
- `src/ads.tsx`
- `src/backend.ts`
- `src/billing.ts`
- `src/communityFeatures.ts`
- `src/discovery.ts`
- `src/games.ts`
- `src/profile.ts`
- `src/sparkCommunity.ts`
- `src/subscription.ts`
- `src/sync/firestoreCloud.ts`
- `src/ugc.ts`
- `tests/community.test.ts`
- `tests/storage.test.ts`
- `tests/tokens.test.ts`
- `vps/Caddyfile`
- `vps/Dockerfile`
- `vps/compose.yml`
- `vps/deploy.sh`
- `vps/setup.sh`
- `vps/vps.env.example`
