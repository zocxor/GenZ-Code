# Build 26 Firebase deployment correction

The supplied deployment log failed before Firebase credentials or deployment: three admin test modules could not import files from admin/src/lib. Seven existing source files were omitted from the previous source ZIP during packaging. They are restored in this archive; no test or security gate was removed.

The Firebase deployment workflow now uses Node 24, matching the installed Firebase client SDK requirement (>=24.12.0). Cloud Functions production runtime stays Node 22. Added an admin source completeness check before installation and before admin tests.

Upload all extracted source files, including admin/src/lib and .github/workflows/deploy-firebase.yml, to the repository root. Alternatively replace the sole source ZIP at the root AND update the repository workflow file from this archive: GitHub executes the committed workflow, not a workflow embedded in a ZIP. Remove older project ZIPs to avoid ambiguity.

Run Actions → Deploy Firebase → admin-portal for hosting only. Use community for the account-token, posting and daily code backend (Blaze required). Everything includes purchase verification setup as documented previously. This packaging correction does not require changing existing Firebase credentials.

Verification: fresh archive extraction, admin source import check, clean npm ci, all 15 admin tests, admin TypeScript check and both Vite production builds. Live deployment requires your repository credentials and has not been executed here.
