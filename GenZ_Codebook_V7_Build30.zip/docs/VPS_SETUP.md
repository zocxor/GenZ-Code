# Build 28: Firebase Spark + your VPS

The source is prepared; no live server has been deployed. Your API hostname is intentionally blank in `shared/backend.json`. Free features work without it; account-token services require it. Do not enter an example hostname in a release build.

## What stays where

| Firebase Spark, within its quotas | VPS backend |
| --- | --- |
| Firebase Authentication and verified-email login | Firebase ID-token and admin-role checks |
| Firestore dictionary, free word submissions, chat and posts | Trusted account-token balance from the existing ledger |
| Posting modes: open, review or paused; moderation and reports | Atomic Daily Code payments, booking conflicts, refunds and scheduling |
| Firebase Hosting for admin and public pages | Badge review applications, token grants and signed AdMob rewards |
| Existing learning data and account deletion requests | Optional Google Play purchase verification and deletion cleanup |

VPS hosting replaces Cloud Functions execution; it does not remove Firestore usage or Spark limits. This edition does not deploy Cloud Functions or Cloud Storage. Firebase Auth upgrades such as TOTP MFA can have separate plan requirements: leave the workflow's optional MFA-enabling setting off if not available on Spark. Existing enforced MFA rules still apply to administrators; do not disable an established security policy merely to bypass a sign-in error.

## 1. VPS and hostname

A reasonable starting server is Ubuntu 24.04 LTS, 2 vCPU, 4 GB RAM and 40 GB SSD; actual capacity depends on traffic. Purchase from your chosen provider. You do not already have a VPS merely because this guide exists.

Choose a hostname such as `api.YOUR-DOMAIN.com`, point its DNS A record to the VPS IPv4 address, and allow inbound TCP 80 and 443 (plus your SSH port). Remove incorrect AAAA records. Keep port 3000 and the Docker API private. Caddy obtains HTTPS certificates automatically after DNS and ports work. No domain is configured in this source.

Install Docker Engine and the Compose plugin using the official Ubuntu guide: https://docs.docker.com/engine/install/ubuntu/ . Docker access is effectively root access; limit it to trusted deployment users. Install Python 3, rsync and unzip if absent.

## 2. Private Firebase server credential

Use the existing project `gen-z-code-55caf`. Create a dedicated server service account, with **Cloud Datastore User** and **Firebase Authentication Admin**, rather than Project Owner. Enable the relevant existing Firebase APIs if necessary. Generate its JSON key and upload it directly to the VPS at:

```
/opt/genz-codebook/secrets/firebase-admin.json
```

Create that private directory first as root. Never put this key in source code, the ZIP, GitHub commits, an APK or chat. The setup script checks the project ID and sets runtime ownership/permissions. The service account calls Firebase from your server; it is not a Cloud Functions deployment.

Official Admin SDK guide: https://firebase.google.com/docs/admin/setup . Existing Firebase project data stays in place; there is no database reset or bulk migration.

## 3. Upload and start the source

Extract this project to `/opt/genz-codebook/source`. The extracted root must contain `functions/`, `shared/` and `vps/`. From that root, substitute your real hostname and certificate contact email:

```bash
sudo bash vps/setup.sh api.YOUR-DOMAIN.com YOUR-EMAIL@example.com
sudo bash vps/deploy.sh
```

The setup creates `/opt/genz-codebook/vps.env`, outside the synchronized source directory. It preserves an existing file. The deployment builds a non-root API container and a Caddy HTTPS proxy. Private credentials are mounted read-only, not baked into images.

Check `https://YOUR-API-HOST/health` and `/ready`. Both must return HTTP 200. Health shows scheduler timestamps without credentials; readiness checks Firestore connectivity. The scheduler starts at boot and checks approximately every five minutes. Watch `scheduler.lastSuccess` and `lastFailure`; health alone does not prove background jobs are successful.

Useful commands from the project root:

```bash
sudo docker compose --env-file /opt/genz-codebook/vps.env -f vps/compose.yml ps
sudo docker compose --env-file /opt/genz-codebook/vps.env -f vps/compose.yml logs --tail=100 api proxy
```

## 4. Connect Android and the admin portal

On the computer holding your extracted project, once the real server is reachable:

```bash
node scripts/configure-backend.mjs https://YOUR-API-HOST
```

This checks server identity and readiness, writes the public API URL to `shared/backend.json`, and allows that origin in the Hosting CSP. No credential goes in this file. Use this script instead of configuring only an Android environment variable, so the admin portal uses the same server.

Commit the extracted source, including hidden `.github/workflows/` files, to your existing GitHub repository. A ZIP uploaded alone does not update GitHub workflow definitions. Keep existing GitHub secrets and Android signing settings.

1. **Actions → Deploy Firebase → Run workflow → spark** publishes rules, indexes, admin and public pages. It does not deploy Cloud Functions. Do not enable optional MFA setup unless your Firebase plan supports it.
2. Wait for Firestore indexes to become ready.
3. Rebuild using the existing **Android APK** workflow. For Google Play use your existing signed release/AAB publishing process; the JavaScript export tested here is not a signed AAB.
4. Install the rebuilt app. Sign in with a verified email. The header and wallet should show **account tokens**, separately from learning points.
5. Grant a small amount through admin Users and test a Daily Code payment/refund before public release.

For custom web domains, also add their HTTPS origins to `ALLOWED_ORIGINS` in the private VPS env file, restart the deployment, and preserve Firebase Auth's authorized-domain settings.

## 5. AdMob and secure rewards

The existing rewarded ad unit is `ca-app-pub-9776667186789824/4151797642`. Confirm ownership and configure its AdMob server-side verification callback:

```
https://YOUR-API-HOST/admobReward
```

Signed-in users reserve a random short-lived reward intent on the VPS before an ad. Google sends the signed reward callback; only then does the backend add 10 account tokens. Duplicate callbacks and reused intents cannot add another reward. A maximum of 20 token-ad attempts per user per UTC day is enforced; failed/no-fill attempts also consume this reservation allowance in this edition. A delayed callback can make tokens appear after the ad screen closes.

Guest/unconfigured ads grant local learning points instead. Quiz hints remove one wrong answer only after the rewarded completion event; if the account-token backend is unavailable, a hint ad can still work without promising account tokens. Rewarded ads are optional; free creation, chat and posting do not require one. Interstitials appear after completed activities with a three-activity/120-second cap, not on entering Community or opening a creation form.

Test on physical Android devices with AdMob test ads/test devices before production. Consent, ad serving approval, policy review, geography and ad fill remain external requirements. This source does not guarantee ad revenue.

Policy: https://support.google.com/admob/answer/7313578 . Caddy HTTPS: https://caddyserver.com/docs/automatic-https .

## 6. Optional one-time token purchases

Checkout defaults **off**. Free services and rewarded tokens do not need token purchases enabled. Monthly/yearly subscriptions are not offered as new purchases in this edition.

Before enabling token packs, configure the existing Play Console product IDs and service-account permissions, and test purchase, cancellation, pending payment, restore and duplicate callbacks on an internal testing track. Upload a dedicated Play API credential directly as `/opt/genz-codebook/secrets/play-admin.json`; set owner UID/GID 10001 and mode 400, as with the Firebase credential. Do not upload it to GitHub.

Set `ENABLE_PLAY_PURCHASES=true` in the VPS env file and redeploy. Then run:

```bash
node scripts/configure-backend.mjs https://YOUR-API-HOST --enable-token-purchases
```

Commit the updated public config, redeploy Hosting and rebuild Android. Prices remain Google Play's localized, one-time product prices. Existing subscription verification/restoration code is retained on the server; no new recurring subscription checkout is enabled.

## 7. Optional GitHub VPS deployment

After initial server setup, configure repository Actions secrets:

- `VPS_HOST`: VPS hostname or IPv4.
- `VPS_USER`: trusted SSH deployment user with Docker access and ownership of `/opt/genz-codebook/source`; root also works but a restricted deployment account is preferable.
- `VPS_SSH_KEY`: deployment private SSH key, stored only as an Actions secret.
- `VPS_KNOWN_HOSTS`: SSH host-key line verified against your provider console. Do not blindly trust an unverified `ssh-keyscan` result.

Run **Deploy VPS backend**. It builds and tests, synchronizes only `/opt/genz-codebook/source/`, and restarts the containers. Its rsync deletion is scoped to that source directory; private credentials, runtime env and Docker volumes live outside it. No Firebase Cloud Functions deploy is required.

## 8. Operations and release checks

Keep private credential backups offline, rotate compromised keys, patch the VPS/Docker, and monitor disk, logs, Firestore quotas and scheduler health. Preserve Caddy volumes and the private env file during upgrades. Firestore holds the application data; VPS backups alone are not a database backup. Apply an appropriate Firebase data backup/export process supported by your plan before risky migrations.

Before public release, check free creation/chat/posts, moderation modes, account grants, Daily booking conflicts/refunds, badge review/revocation, real AdMob SSV callbacks, consent, Play Billing if enabled, keyboard layout and a signed Android build. Live VPS/HTTPS, real ad delivery and Play transactions have not been tested in this workspace.
