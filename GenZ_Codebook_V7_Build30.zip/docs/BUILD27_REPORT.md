# Build 27: live service diagnosis, Play categories and profile code

## Confirmed live blocker
Both https://gen-z-code-55caf.web.app/api/communityFeature and https://us-central1-gen-z-code-55caf.cloudfunctions.net/communityFeature returned HTTP 404 during this session. The account payment/scheduling callable is not reachable at either configured URL. This is why account balance checks, Chat Pass, Posts and admin Daily Code commands cannot work, even when a valid admin grant exists. A new APK or hosting-only deployment cannot activate a missing server function.

## Activation steps
1. If the Firebase project is still on Spark, enable Blaze for gen-z-code-55caf. Cloud Functions and the scheduled publication task require it. A Play developer account does not enable Firebase billing.
2. Commit the complete extracted source, including .github/workflows/deploy-firebase.yml, at the repository root. Alternatively keep exactly one source ZIP at the root AND update the committed workflow file separately; GitHub does not load workflows from inside ZIPs.
3. Keep the existing FIREBASE_SERVICE_ACCOUNT repository secret for the correct project. Do not add private credentials to source.
4. Run GitHub Actions → Deploy Firebase → target community. This is now the default. It deploys rules/indexes, communityFeature, scheduled publication, contribution cleanup, verified AdMob reward handler and hosting. This target does not require the separate Play purchase-verification secret.
5. The deployment must finish green, including Verify community callable is reachable. The new check calls both the direct function and Hosting route and requires a structured 401 UNAUTHENTICATED response. That response proves the service is present while wallet access remains protected. A 404/403 or an HTML response fails the check.
6. Reopen the app and use Retry account token check / Retry balance check. The existing valid account grant becomes spendable; do not issue a duplicate grant just to work around the 404.
7. Rebuild/install the APK or signed AAB for the Play category fix and profile code feature. Verify the live paid journey on a device before publishing.

## Changes
- Play offered All but the persisted preference validator rejected it. All is now a valid saved/synced category; Play uses the same category list as validation. Category selection survives restart. Invalid action input no longer masquerades as a full-storage error.
- All 30 generated game levels have unique curiosity-led names (for example Inbox Insider, The Skull Mystery, The Locked Vault). Every generated level has a relevant rendered vector icon, with gradient tiles for unlocked levels and muted tiles for locked levels. The learning path numbers all 34 levels continuously; stable IDs, question seeds, scores and unlock requirements are preserved. Profile history uses these same names.
- Main You/profile hero now shows the existing GZ registration/referral code directly beneath the username, with accessible copy action, confirmation and copy failure feedback. It reuses the deterministic existing account code; it does not expose a second identifier or invent a new registration system.
- Chat has a retry action for failed account token checks. Account payment errors explain that the balance was not checked and no tokens were charged.
- Admin missing-endpoint errors explain the required community deployment. Hosting-only deployments explicitly warn that they do not activate the backend.
- Added a deployment readiness probe for both live endpoints. No client-side payment fallback or permission bypass was added.
- Native default versionCode increased from 26 to 27; the Play workflow continues using its increasing CI version code.

## Validation completed
- App TypeScript check and 127 tests passed. New regression covers every Play category through real repository save/reopen, including All.
- Admin TypeScript check, all 15 tests and both Vite production builds passed.
- Functions build and typecheck passed.
- All 11 backend tests passed on the official Firestore emulator. New test creates the same audited grant format as the admin portal, funds 500 tokens, pays code creation 150 + post 25 + daily Chat Pass 30 + Daily Code 250, and verifies final balance 45. Repeated/concurrent requests produce no duplicate charges. The Daily Code application is approved and scheduled by admin. Existing scheduling/conflict/refund, moderation, verified badge and ad-signature tests also passed.
- All 34 display names checked for uniqueness; level IDs and ordering remain unchanged.
- Android production JavaScript export passed.
- Source archive integrity and required admin modules checked.

## Remaining limitations
No production credentials or connected authenticated browser were available, so the live backend was not deployed from this session. Actual iPhone/Android UI, native clipboard and real ad/purchase testing were not run here. This deliverable is source, not a signed AAB/APK. Live account payments must not be declared active until the deployment probe and a real signed-in payment journey pass. The live readiness script was run and correctly failed both production URLs with HTTP 404; this confirms activation is still pending. Prior Build 26 reports are historical.

## Modified files relative to corrected Build 26
- .github/workflows/deploy-firebase.yml
- App.tsx
- README.md
- admin/src/pages/CommunityWorkflow.tsx
- android/app/build.gradle
- app.json
- docs/BUILD27_REPORT.md (new)
- functions/tests/community-features.test.cjs
- scripts/check-community-service.mjs (new)
- scripts/package-source.py (new, reproducible source archive with scoped exclusions; preserves admin/src/lib)
- shared/communityErrors.ts
- src/CommunityScreen.tsx
- src/PlayHub.tsx
- src/ProfileDashboard.tsx
- src/profile.ts
- tests/storage.test.ts
- src/discovery.ts
- src/games.ts
