import {SPARK_MODE} from './deployment';
/**
 * Code Tokens: the earn-and-spend currency of GenZ Codebook.
 *
 * Pure logic only — no React Native, no Firebase — so the rules are unit-tested
 * in Node. The live balance lives in the learning state (profile.ts) on this
 * device. Earned and spent tokens stay device-local, because a wallet cannot
 * be merged last-writer-wins without losing concurrent earns/spends. PURCHASED
 * tokens are different: every purchase is also written to the account's
 * Firestore ledger (users/{uid}/tokenLedger, src/tokenLedger.ts), keyed by the
 * Google Play order ID, so a purchase can never be credited twice and the
 * history survives logout, reinstall and device change. The public leaderboard
 * (src/tokensSync.ts) mirrors the balance, opt-in only.
 *
 * Earning (all local, all free):
 *  - Rewarded ad, watched by choice: +10
 *  - First activity of a new day: +5, plus +25 every 7th day of a streak
 *  - Daily reward, collected by tap once a day: +10
 *  - Quiz: +1 per point a new personal best improves by; a perfect round: +10
 *  - Daily Five finished: +15, once per day
 *  - A suggested word a moderator accepts: +20
 *  - A friend signs up with your referral code or link: +100 to each of
 *    you (REFERRAL_REWARD; see shared/referral.ts and src/referral.ts).
 *    The reward is the only token amount that also has a server-side
 *    ledger entry written by another user — the Firestore rules validate
 *    it against the referral claim, so it cannot be forged.
 *  - Buying a token package on Google Play: see TOKEN_PRODUCTS below
 * Spending:
 *  - Create a code: 150 — earn them by watching ads, playing quizzes, or
 *    buying a package. The account service validates creation fees.
 *  - Edit one of your own suggested words: 150 per edit, charged only
 *    after the new wording is saved. Everyone pays, staff included.
 *  - Chat: 30 tokens for a UTC day pass; messages are free.
 *  - Unlock a quiz level early: 50 (skips the 60% requirement for one level)
 */
export const TOKENS = {
  REWARDED_AD: 10,
  DAILY_VISIT: 5,
  DAILY_COLLECT: 10,
  STREAK_WEEK_BONUS: 25,
  ACCEPTED_WORD: 20,
  // A referral that is successfully claimed pays this amount to BOTH the
  // referrer and the new user. Single source of truth for the reward — the
  // Firestore rules validate the same 100 as a literal (rules cannot import
  // this constant), so if this ever changes, update firestore.rules too.
  REFERRAL_REWARD: 100,
  SUGGEST_COST: SPARK_MODE?0:150,
  // Editing one of your own suggested words costs 150 tokens per edit (see
  // src/MySuggestionsScreen.tsx). The charge happens only after the new
  // wording is saved to the server, never on a failed save.
  EDIT_SUGGESTION_COST: SPARK_MODE?0:150,
  CHAT_MESSAGE_COST: 0,
  // Community posts use the server-enforced review fee. Chat stays local.
  POST_COST: SPARK_MODE?0:25,
  CHAT_DAILY_COST: SPARK_MODE?0:30,
  UNLOCK_LEVEL_COST: 50,
  DAILY_FIVE: 15,
  PERFECT_ROUND: 10,
  MAX_BALANCE: 1_000_000,
  CREDITED_LIMIT: 400,
} as const;

/** Tokens levels. Same shape as the XP ranks, different ladder: tokens are a currency, XP is skill. */
export const TOKEN_LEVELS: [number, string][] = [[0, 'Rookie'], [100, 'Chatter'], [250, 'Word Explorer'], [500, 'Slang Star'], [900, 'Code Master'], [1500, 'Code Legend']];
export function levelFor(balance: number): {level: number; name: string; floor: number; next: {tokens: number; name: string} | null; progress: number} {
  let i = 0;
  const b = Math.max(0, Math.floor(balance));
  while (i + 1 < TOKEN_LEVELS.length && b >= TOKEN_LEVELS[i + 1]![0]) i++;
  const [floor, name] = TOKEN_LEVELS[i]!;
  const next = TOKEN_LEVELS[i + 1];
  return {level: i + 1, name, floor, next: next ? {tokens: next[0], name: next[1]} : null, progress: next ? (b - floor) / (next[0] - floor) : 1};
}

export type TokensState = {
  balance: number;
  /** YYYY-MM-DD the daily-visit bonus was last paid, so it pays once per day. */
  lastDaily: string;
  /** YYYY-MM-DD the daily reward was last COLLECTED by tap, so it pays once per day. */
  lastDailyCollect: string;
  /** YYYY-MM-DD the Daily Five bonus was last paid. */
  lastDailyFive: string;
  /** Keys already paid the accepted-word bonus: `sub:<submission doc id>`. */
  credited: string[];
  /** Quiz stage ids unlocked early with tokens. */
  unlockedLevels: string[];
  /** Opted in to the public leaderboard (nickname + tokens, nothing else). */
  leaderboard: boolean;
  /** Update stamp (wall-clock ms). */
  u: number;
};

export function emptyTokens(): TokensState {
  return {balance: 0, lastDaily: '', lastDailyCollect: '', lastDailyFive: '', credited: [], unlockedLevels: [], leaderboard: false, u: 0};
}

const DAY = /^\d{4}-\d{2}-\d{2}$/;
const STAGE_ID = /^(?:chat|emoji|campus|context|shuffle-[a-z]{1,20}|daily-\d{4}-\d{2}-\d{2}|(?:chat|emoji|numbers)-\d{1,2})$/;
const CREDIT_KEY = /^(?:sub|word|referral):[A-Za-z0-9_-]{1,100}$/;
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const num = (v: unknown, min: number = 0, max: number = TOKENS.MAX_BALANCE): v is number => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;

/** Strictly parse stored tokens. Never throws; invalid parts fall back to defaults. */
export function parseTokens(input: unknown): TokensState {
  const p = emptyTokens();
  if (!isObj(input)) return p;
  p.balance = num(input.balance) ? Math.floor(input.balance) : 0;
  p.lastDaily = typeof input.lastDaily === 'string' && DAY.test(input.lastDaily) ? input.lastDaily : '';
  p.lastDailyCollect = typeof input.lastDailyCollect === 'string' && DAY.test(input.lastDailyCollect) ? input.lastDailyCollect : '';
  p.lastDailyFive = typeof input.lastDailyFive === 'string' && DAY.test(input.lastDailyFive) ? input.lastDailyFive : '';
  if (Array.isArray(input.credited)) p.credited = input.credited.filter((k): k is string => typeof k === 'string' && CREDIT_KEY.test(k)).slice(-TOKENS.CREDITED_LIMIT);
  if (Array.isArray(input.unlockedLevels)) p.unlockedLevels = [...new Set(input.unlockedLevels.filter((id): id is string => typeof id === 'string' && STAGE_ID.test(id)))];
  p.leaderboard = input.leaderboard === true;
  p.u = num(input.u, 0, 8.64e15) ? Math.floor(input.u) : 0;
  return p;
}

/** What suggesting a word costs right now: SUGGEST_COST, unless the user is
 *  all accounts. */
export function suggestCost(_p: TokensState, _isStaff = false): number {
  return TOKENS.SUGGEST_COST;
}
export function canSuggest(p: TokensState, isStaff = false): boolean {
  return p.balance >= suggestCost(p, isStaff);
}
/** What editing one of your own suggested words costs: EDIT_SUGGESTION_COST,
 *  for everyone — there is no staff exception for edits. */
export function editSuggestionCost(_p: TokensState): number {
  return TOKENS.EDIT_SUGGESTION_COST;
}
export function canEditSuggestion(p: TokensState): boolean {
  return p.balance >= TOKENS.EDIT_SUGGESTION_COST;
}
export function canUnlockLevel(p: TokensState, stageId: string): boolean {
  return !p.unlockedLevels.includes(stageId) && p.balance >= TOKENS.UNLOCK_LEVEL_COST;
}

// ---------- Google Play token packages (consumable in-app products) ----------

/** The seven consumable token packages sold through Google Play Billing.
 *  Prices are NOT in code: they live in Play Console (per-country pricing)
 *  and the app shows Play's localized price at runtime. The token counts here
 *  are the single source of truth for crediting — the Firestore rules enforce
 *  the same table, so a ledger entry can only credit the exact amount for its
 *  product. Product IDs must match Play Console exactly. */
export const TOKEN_PRODUCTS = [
  {id: 'tokens_1000', tokens: 1000, price: '$1.99'},
  {id: 'tokens_2500', tokens: 2500, price: '$2.99'},
  {id: 'tokens_5000', tokens: 5000, price: '$3.99'},
  {id: 'tokens_10000', tokens: 10000, price: '$5.99'},
  {id: 'tokens_25000', tokens: 25000, price: '$10.99'},
  {id: 'tokens_50000', tokens: 50000, price: '$15.99'},
  {id: 'tokens_100000', tokens: 100000, price: '$25.99'},
] as const;
export type TokenProductId = (typeof TOKEN_PRODUCTS)[number]['id'];
export function tokensForProduct(productId: string): number | null {
  const found = TOKEN_PRODUCTS.find(p => p.id === productId);
  return found ? found.tokens : null;
}

/** Ledger transaction kinds (users/{uid}/tokenLedger). `purchase` is the only
 *  kind that moves real money; the rest are the local earn/spend history.
 *  `referral` is the only kind another user may write to your ledger (the
 *  referrer's entry, keyed referral-<newUserUid>) — the rules tie it to a
 *  matching referral claim, so it cannot be forged. */
export type TokenTxnType = 'purchase' | 'subscription' | 'daily' | 'ad' | 'game' | 'spend' | 'adjustment' | 'migration' | 'referral' | 'feature_fee' | 'feature_refund';

/** The Firestore document ID for a purchase ledger entry. One document per
 *  Google Play order ID: a second credit for the same order writes the same
 *  ID, and the rules (create-only) refuse it — that is the duplicate guard. */
export function purchaseTxnId(orderId: string): string {
  return `order-${orderId}`;
}
/** The one-time opening-balance entry written when an existing local balance
 *  is first recorded in the ledger (the pre-ledger balance had no history). */
export const MIGRATION_TXN_ID = 'migration-v1';
