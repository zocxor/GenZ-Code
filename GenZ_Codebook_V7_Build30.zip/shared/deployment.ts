/** This release uses free, rules-validated Firestore contributions on Spark. */
export const SPARK_MODE = true;
