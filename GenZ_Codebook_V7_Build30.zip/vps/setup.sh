#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -ne 2 ]; then
  echo 'Usage: sudo bash vps/setup.sh api.your-domain.com certificate-contact@example.com'
  exit 1
fi
[[ "$1" =~ ^[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || { echo 'Use a valid API domain, with DNS pointing to this VPS.'; exit 1; }
[[ "$2" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]] || { echo 'Use a valid certificate contact email.'; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo 'Run the initial setup with sudo.'; exit 1; }
docker compose version >/dev/null
SECRETS_DIR=/opt/genz-codebook/secrets
[ -f "$SECRETS_DIR/firebase-admin.json" ] || { echo "Upload the Firebase server credential to $SECRETS_DIR/firebase-admin.json first."; exit 1; }
python3 - "$SECRETS_DIR/firebase-admin.json" <<'PY'
import json,sys
key=json.load(open(sys.argv[1]))
assert key.get('type')=='service_account' and key.get('project_id')=='gen-z-code-55caf', 'Use a service account for gen-z-code-55caf'
assert key.get('private_key') and key.get('client_email'), 'Incomplete credential'
PY
chown 10001:10001 "$SECRETS_DIR" "$SECRETS_DIR/firebase-admin.json"
chmod 500 "$SECRETS_DIR"
chmod 400 "$SECRETS_DIR/firebase-admin.json"
umask 077
if [ -e /opt/genz-codebook/vps.env ]; then
  echo 'Existing vps.env preserved. Review it before deploying; no settings were overwritten.'
else
  printf '%s\n' "API_DOMAIN=$1" "ACME_EMAIL=$2" "SECRETS_DIR=$SECRETS_DIR" 'ENABLE_PLAY_PURCHASES=false' 'ALLOWED_ORIGINS=https://gen-z-code-55caf.web.app,https://gen-z-code-55caf.firebaseapp.com' > /opt/genz-codebook/vps.env
fi
echo 'Credentials and runtime settings prepared. Run bash vps/deploy.sh from the project root.'
