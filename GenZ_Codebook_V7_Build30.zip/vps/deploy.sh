#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ENV_FILE=/opt/genz-codebook/vps.env
[ -f "$ENV_FILE" ] || { echo 'Complete vps/setup.sh first.'; exit 1; }
docker compose --env-file "$ENV_FILE" -f vps/compose.yml config --quiet
docker compose --env-file "$ENV_FILE" -f vps/compose.yml up -d --build --remove-orphans
for attempt in $(seq 1 12); do
  if docker compose --env-file "$ENV_FILE" -f vps/compose.yml exec -T api node -e "fetch('http://127.0.0.1:3000/ready').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"; then
    echo 'Backend is ready and can access Firebase.'
    exit 0
  fi
  sleep 5
done
docker compose --env-file "$ENV_FILE" -f vps/compose.yml logs --tail=60 api
echo 'Backend readiness failed. Check credentials, Firebase APIs and VPS network access.'
exit 1
