/**
 * Optimistic like/save state for community posts.
 *
 * The UI shows the user's tap immediately; the server write runs in the background.
 * `base` is the server count seen when the user first tapped. While the feed still
 * reports that same count, the displayed count is adjusted locally; as soon as the
 * feed reports a different count (the server applied the write, or someone else
 * liked the post), the server value is shown again. Pure functions, no React.
 */
export type Optimistic = {desired: boolean; wasOn: boolean; base: number; settled: boolean};
export type OptimisticMap = Readonly<Record<string, Optimistic>>;

export const isOn = (id: string, confirmed: ReadonlySet<string>, map: OptimisticMap) =>
  map[id]?.desired ?? confirmed.has(id);

export function shownCount(id: string, serverCount: number | undefined, map: OptimisticMap): number {
  const count = Math.max(0, serverCount ?? 0), o = map[id];
  if (!o || count !== o.base) return count;
  return Math.max(0, o.base + (o.desired ? 1 : 0) - (o.wasOn ? 1 : 0));
}

/** Record a tap. Returns the next map and whether a request must be started now. */
export function tap(id: string, serverCount: number | undefined, confirmed: ReadonlySet<string>, map: OptimisticMap, inFlight: boolean) {
  const current = map[id];
  const desired = !isOn(id, confirmed, map);
  const next: Optimistic = current && !current.settled
    ? {...current, desired}
    : {desired, wasOn: confirmed.has(id), base: Math.max(0, serverCount ?? 0), settled: false};
  return {map: {...map, [id]: next}, send: !inFlight, desired};
}

/** Server confirmed `value`. Returns the next map and a follow-up value to send if the user changed their mind meanwhile. */
export function confirm(id: string, value: boolean, map: OptimisticMap) {
  const o = map[id];
  if (!o) return {map, resend: null as boolean | null};
  if (o.desired !== value) return {map, resend: o.desired};
  return {map: {...map, [id]: {...o, settled: true}}, resend: null as boolean | null};
}

/** Server rejected the write: drop the optimistic entry so the confirmed state shows again. */
export function rollback(id: string, map: OptimisticMap): OptimisticMap {
  if (!map[id]) return map;
  const next = {...map};
  delete next[id];
  return next;
}

/** Drop settled entries whose server count has moved on (the feed now reflects the write). */
export function prune(map: OptimisticMap, counts: Readonly<Record<string, number | undefined>>): OptimisticMap {
  let changed = false;
  const next: Record<string, Optimistic> = {};
  for (const [id, o] of Object.entries(map)) {
    const count = counts[id];
    if (o.settled && (count === undefined || Math.max(0, count) !== o.base)) {changed = true; continue;}
    next[id] = o;
  }
  return changed ? next : map;
}
