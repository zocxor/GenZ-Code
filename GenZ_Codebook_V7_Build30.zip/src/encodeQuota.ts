/**
 * Encode Message daily allowance, kept on this device.
 * The free amount comes from the admin setting config/app.encodeFreeDaily; an optional
 * rewarded ad adds +5. A conversion is counted only when it actually encoded something.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import {localDay} from './discovery';
const KEY = 'genz.encode.v1';
export type Quota = {day: string; used: number; bonus: number};
export const AD_BONUS = 5;
export function remaining(q: Quota, freeDaily: number, today = localDay()) {
  return q.day === today ? Math.max(0, freeDaily + q.bonus - q.used) : freeDaily;
}
export function spend(q: Quota, today = localDay()): Quota {return q.day === today ? {...q, used: q.used + 1} : {day: today, used: 1, bonus: 0};}
export function addBonus(q: Quota, today = localDay()): Quota {return q.day === today ? {...q, bonus: q.bonus + AD_BONUS} : {day: today, used: 0, bonus: AD_BONUS};}
export async function loadQuota(): Promise<Quota> {
  try {const v = JSON.parse((await AsyncStorage.getItem(KEY)) ?? 'null'); if (v && typeof v.day === 'string' && Number.isInteger(v.used) && Number.isInteger(v.bonus)) return v;} catch {}
  return {day: localDay(), used: 0, bonus: 0};
}
export async function saveQuota(q: Quota) {try {await AsyncStorage.setItem(KEY, JSON.stringify(q));} catch {}}
