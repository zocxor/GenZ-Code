import type {IconName} from './ui';
export type Question={prompt:string;context:string;answers:string[];correct:number;why:string;termId?:string};
export type Stage={id:string;name:string;subtitle:string;icon:IconName;color:string;questions:Question[]};
export const stages:Stage[]=[
{id:'chat',name:'Chat starter',subtitle:'Crack your first five codes',icon:'chatbubbles',color:'#2c6bea',questions:[
{prompt:'What does IDK mean?',context:'“IDK when the lecture starts.”',answers:['I don’t know','I do know','I don’t care'],correct:0,why:'IDK means “I don’t know.” It usually expresses uncertainty.',termId:'idk'},
{prompt:'Your friend says “brb”. What next?',context:'You are chatting while playing a game.',answers:['They are leaving forever','They expect to return soon','They need an apology'],correct:1,why:'BRB means “be right back.” A simple “no problem” fits.',termId:'brb'},
{prompt:'What is happening rn?',context:'“I’m studying rn.”',answers:['Tomorrow','Every day','Right now'],correct:2,why:'rn is a short way to write “right now.”',termId:'rn'},
{prompt:'How would you answer WYD?',context:'A classmate asks what you are doing.',answers:['Working on my assignment. You?','You love me!','It means goodbye.'],correct:0,why:'WYD asks “what are you doing?” It doesn’t establish romantic interest.',termId:'wyd'},
{prompt:'Translate this goodbye.',context:'“Busy rn, ttyl.”',answers:['Talk to you later','Thank you for listening','Try your luck'],correct:0,why:'TTYL means “talk to you later,” with no promised time.',termId:'ttyl'}]},
{id:'emoji',name:'Emoji detective',subtitle:'Read the reaction, not just the face',icon:'happy',color:'#a344b7',questions:[
{prompt:'Is this person necessarily sad?',context:'“That video is so funny 😭”',answers:['Yes, always','Probably laughing in this context','Definitely angry'],correct:1,why:'The words “so funny” suggest laughter. 😭 does not always mean sadness.',termId:'cry'},
{prompt:'What might 💀 mean here?',context:'“That joke 💀”',answers:['Figurative laughter or shock','An actual danger alert, for certain','An appointment'],correct:0,why:'The skull often exaggerates laughter or shock, but surrounding context still matters.',termId:'skull'},
{prompt:'What is a likely reading?',context:'“On it 🫡” after you ask for help.',answers:['A refusal','Acknowledgment','A love confession'],correct:1,why:'A salute can mean “got it” or respectful acknowledgment.',termId:'salute'},
{prompt:'Can you know the exact emotion?',context:'“Another deadline 🙃”',answers:['Yes: joy, certainly','Yes: hostility, certainly','No; irony or frustration is possible'],correct:2,why:'🙃 can suggest irony, awkwardness, or playful frustration. It is ambiguous.',termId:'upside'},
{prompt:'Choose a helpful response.',context:'“I’m overwhelmed 😭”',answers:['You’re clearly laughing.','Want to talk about it?','Stop being dramatic.'],correct:1,why:'Respond to what they say. A gentle question is more helpful than assuming their emotion.'}]},
{id:'campus',name:'Campus quest',subtitle:'Survive the group chat',icon:'school',color:'#00806c',questions:[
{prompt:'Decode the plan.',context:'“Aaj kya scene hai?”',answers:['What’s the plan today?','Delete the scene','Where is the cinema?'],correct:0,why:'In a casual Roman Urdu conversation, this often asks about today’s plan.',termId:'scene'},
{prompt:'Where are they going?',context:'“Heading to uni.”',answers:['The airport','University','An online match'],correct:1,why:'“Uni” is a shortened word for university.',termId:'uni'},
{prompt:'Which response fits?',context:'“Meet at the library at six?” “Bet.”',answers:['They probably agree','They definitely want to gamble','They are angry'],correct:0,why:'“Bet” commonly means okay or deal in this context.',termId:'bet'},
{prompt:'What should you clarify?',context:'A teammate asks for a draft “by EOD”.',answers:['Their favorite emoji','Exact time and time zone','Their relationship status'],correct:1,why:'End of day is not precise. Confirm the deadline.',termId:'eod'},
{prompt:'Choose a neutral acknowledgment.',context:'“FYI, the lecture moved to room 4.”',answers:['Thanks for the update.','Why are you flirting?','Good game.'],correct:0,why:'FYI introduces information. A simple acknowledgment fits.',termId:'fyi'}]},
{id:'context',name:'Context boss',subtitle:'Beat assumptions, not people',icon:'sparkles',color:'#d77e20',questions:[
{prompt:'What can you safely conclude?',context:'“lowkey cooked rn 😭”',answers:['They are definitely joking','They may feel exhausted or in difficulty','They are definitely cooking'],correct:1,why:'“Cooked” can mean exhausted or in trouble. You cannot tell the exact situation from this alone.',termId:'cooked'},
{prompt:'Does “143” always mean love?',context:'You see the number in a message.',answers:['Yes, everywhere','No; it may be a code or just a number','It always means goodbye'],correct:1,why:'“I love you” is one number-code interpretation, not a universal meaning.',termId:'143'},
{prompt:'How do you read “Okay.”?',context:'There is no other context.',answers:['Definitely angry','Definitely delighted','Neutral, firm, or cold are all possible'],correct:2,why:'A period cannot reveal someone’s exact feelings.'},
{prompt:'A player says “GG”. What is certain?',context:'Their tone is unclear.',answers:['They mean it sincerely','The expansion is “good game”; tone may vary','They are insulting you'],correct:1,why:'The expansion is stable; sincere or sarcastic intent still depends on context.',termId:'gg'},
{prompt:'Best response to uncertainty?',context:'“idk if I can make it, I’m cooked.”',answers:['You’re obviously joking.','What’s going on? Are you okay?','You must come.'],correct:1,why:'Ask gently for context instead of guessing or pressuring them.'}]}];
export const unlockedIn=(list:Stage[],index:number,best:Record<string,number>,unlockedLevels:string[]=[])=>
  index===0||(best[list[index-1]?.id??'']??0)>=60||unlockedLevels.includes(list[index]?.id??'');
export const unlocked=(index:number,best:Record<string,number>,unlockedLevels:string[]=[])=>
  unlockedIn(stages,index,best,unlockedLevels);
