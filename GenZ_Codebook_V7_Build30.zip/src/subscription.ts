import {SPARK_MODE} from '../shared/deployment';
import {BACKEND_URL} from './backend';
/**
 * GenZ Codebook Premium subscriptions (Google Play subscriptions).
 *
 * Client side. The backend (functions/verifySubscription + the RTDN
 * handler) is the only writer of the subscription entitlement — the client
 * never grants premium itself. The flow:
 *  1. Buy: the app fetches the subscription products (Play's localized
 *     price), then opens the official Google Play subscription dialog with
 *     the base plan's offer token.
 *  2. Verify: the purchase is POSTed to verifySubscription. The backend
 *     calls the Play Developer API (purchases.subscriptionsv2.get), checks
 *     the state is ACTIVE (or IN_GRACE_PERIOD), writes the entitlement
 *     document and grants the period's tokens — atomically, exactly once.
 *  3. Acknowledge: only after the backend verifies, the client acknowledges
 *     the purchase with Google Play (acknowledgePurchaseAndroid). A
 *     subscription that is never acknowledged is refunded by Google after
 *     3 days, so this step must not be skipped.
 *  4. Entitlement: the app reads users/{uid}/subscription/current from
 *     Firestore. Premium is active while the state is ACTIVE or
 *     IN_GRACE_PERIOD and the expiry time is in the future.
 *
 * There is NO local-only fallback for subscriptions — not even in debug
 * builds. If SUBSCRIPTION_VERIFY_URL is empty, a subscription purchase
 * cannot be activated and the client says so plainly. The purchase stays
 * unacknowledged (Google refunds it after 3 days if it is never verified),
 * so no one pays for a benefit they did not receive.
 *
 * Renewals, cancellations, expirations and refunds are delivered by
 * Real-time Developer Notifications (RTDN) to the backend, which updates
 * the entitlement document. The app also re-verifies owned subscriptions on
 * start and on Wallet open (reconcile), so a status change is picked up
 * even if an RTDN message was missed.
 */
import {Platform} from 'react-native';
import {
  fetchProducts,
  requestPurchase,
  getAvailablePurchases,
  acknowledgePurchaseAndroid,
  type ProductSubscription,
  type Purchase,
} from 'react-native-iap';
import {SUBSCRIPTION_PRODUCTS, isSubscriptionProduct, type SubscriptionDoc} from '../shared/subscriptions';
import {currentUid} from './tokenLedger';
import {accountAuth} from './firebase/app';

/**
 * Server verification endpoint for subscriptions (functions/verifySubscription).
 * Empty = not configured: subscription purchases cannot be activated.
 * Set it to the deployed function URL after `firebase deploy --only functions`.
 * The token endpoint (BILLING_VERIFY_URL in src/billing.ts) is separate.
 */
export const SUBSCRIPTION_VERIFY_URL = BACKEND_URL?BACKEND_URL+'/verifySubscription':'';

/**
 * True when a subscription purchase can actually be accepted: the secure
 * verification backend is deployed and its URL is set. Until then Premium
 * shows a "Not available yet" status and no purchase is accepted — the
 * screens and integration stay in place for later activation.
 */
export function isSubscriptionPurchaseEnabled(): boolean {
  if(SPARK_MODE)return false;
  return SUBSCRIPTION_VERIFY_URL.length > 0;
}

export type SubscriptionProduct = {
  productId: string;
  basePlanId: string;
  tokensPerPeriod: number;
  periodLabel: string;
  localizedPrice: string;
  price: string;
  currency: string;
  title: string;
  description: string;
  /** The offer token for this product's base plan (needed to buy it). */
  offerToken: string;
};

export type SubscriptionEvent =
  | {kind: 'products'}
  | {kind: 'subscribed'; productId: string; tokens: number; expiryTime: string}
  | {kind: 'already-subscribed'; productId: string}
  | {kind: 'pending'; productId: string}
  | {kind: 'failed'; message: string}
  | {kind: 'cancelled'}
  | {kind: 'restored'; count: number}
  | {kind: 'signin-required'}
  | {kind: 'unavailable'; message: string};

const listeners = new Set<(e: SubscriptionEvent) => void>();
function emit(e: SubscriptionEvent): void {
  listeners.forEach(cb => {
    try {cb(e);} catch {/* a listener must never break subscriptions */}
  });
}
export function onSubscriptionEvent(cb: (e: SubscriptionEvent) => void): () => void {
  listeners.add(cb);
  return () => {listeners.delete(cb);};
}

const SUBSCRIPTION_IDS = SUBSCRIPTION_PRODUCTS.map(p => p.id);

let cachedProducts: SubscriptionProduct[] = [];
let cachedMissing: string[] = [...SUBSCRIPTION_IDS];
let cachedAvailable = false;

function toSubscriptionProduct(p: ProductSubscription): SubscriptionProduct | null {
  const catalog = SUBSCRIPTION_PRODUCTS.find(c => c.id === p.id);
  if (!catalog) return null;
  // The base-plan offer token: the first offer detail for this product's
  // base plan. Without it, Play cannot start the subscription purchase.
  const offers = (p as unknown as {subscriptionOfferDetailsAndroid?: Array<{basePlanId: string; offerToken: string}>}).subscriptionOfferDetailsAndroid ?? [];
  const offer = offers.find(o => o.basePlanId === catalog.basePlanId) ?? offers[0];
  if (!offer?.offerToken) return null;
  return {
    productId: p.id,
    basePlanId: catalog.basePlanId,
    tokensPerPeriod: catalog.tokensPerPeriod,
    periodLabel: catalog.periodLabel,
    localizedPrice: p.displayPrice,
    price: p.price != null ? String(p.price) : '',
    currency: p.currency,
    title: p.title,
    description: p.description,
    offerToken: offer.offerToken,
  };
}

type ServerSubVerify =
  | {verified: true; duplicate: boolean; productId: string; tokens: number; expiryTime: string; state: string}
  | {verified: false; reason: string; retryable: boolean};

async function verifySubscriptionWithServer(p: {productId: string; purchaseToken: string}): Promise<ServerSubVerify | null> {
  if (!SUBSCRIPTION_VERIFY_URL) return null;
  try {
    const idToken = await accountAuth.currentUser?.getIdToken().catch(() => null);
    if (!idToken) return {verified: false, reason: 'Sign in first — subscriptions are recorded on your account.', retryable: false};
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch(SUBSCRIPTION_VERIFY_URL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json', Authorization: `Bearer ${idToken}`},
      body: JSON.stringify(p),
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    const body = (await res.json().catch(() => null)) as ServerSubVerify | null;
    if (!body || typeof body.verified !== 'boolean') {
      return {verified: false, reason: 'Google Play could not verify this subscription. No benefits were granted.', retryable: true};
    }
    return body;
  } catch {
    return {verified: false, reason: 'Google Play could not verify this subscription. No benefits were granted.', retryable: true};
  }
}

/** Run one owned subscription purchase through verify -> acknowledge. Returns what happened. */
export async function handleSubscriptionPurchase(purchase: Purchase): Promise<'subscribed' | 'duplicate' | 'pending' | 'failed'> {
  if (purchase.platform !== 'android') return 'failed';
  if (!isSubscriptionProduct(purchase.productId)) return 'failed';
  // Android subscription purchases always carry a purchaseToken; without
  // it there is nothing to verify, so fail rather than guess.
  if (!purchase.purchaseToken) return 'failed';
  const uid = currentUid();
  if (!uid) {
    emit({kind: 'signin-required'});
    return 'failed';
  }
  // No backend configured: subscriptions cannot be activated at all.
  // Do NOT acknowledge — an unacknowledged subscription is refunded by
  // Google after 3 days, so the user never pays for a benefit they did
  // not receive.
  if (!SUBSCRIPTION_VERIFY_URL) {
    emit({kind: 'failed', message: 'Server verification is not configured for subscriptions. Deploy the verification backend and set SUBSCRIPTION_VERIFY_URL first.'});
    return 'failed';
  }
  const server = await verifySubscriptionWithServer({productId: purchase.productId, purchaseToken: purchase.purchaseToken});
  if (!server) {
    emit({kind: 'failed', message: 'Server verification is not configured for subscriptions.'});
    return 'failed';
  }
  if (!server.verified) {
    emit({kind: 'failed', message: server.reason});
    return 'failed';
  }
  // Verified: acknowledge with Google Play so the subscription is not
  // refunded after 3 days. The backend also acknowledges server-side as a
  // safety net, so a failure here is not fatal — reconcile retries it.
  try {
    await acknowledgePurchaseAndroid(purchase.purchaseToken);
  } catch {/* the backend already acknowledged server-side; reconcile retries */}
  if (server.duplicate) {
    emit({kind: 'already-subscribed', productId: purchase.productId});
    return 'duplicate';
  }
  emit({kind: 'subscribed', productId: purchase.productId, tokens: server.tokens, expiryTime: server.expiryTime});
  return 'subscribed';
}

/** Load the subscription products from Play. Returns what Play returned. */
export async function loadSubscriptionProducts(): Promise<{available: boolean; products: SubscriptionProduct[]; missing: string[]}> {
  if (Platform.OS !== 'android') {
    cachedAvailable = false;
    cachedProducts = [];
    cachedMissing = [...SUBSCRIPTION_IDS];
    return {available: false, products: [], missing: [...SUBSCRIPTION_IDS]};
  }
  try {
    const all = (await fetchProducts({skus: SUBSCRIPTION_IDS, type: 'subs'})) ?? [];
    // fetchProducts returns a ProductOrSubscription union; keep only the
    // subscriptions (type 'subs') for the Premium plans.
    const products = all.filter((p): p is ProductSubscription => p.type === 'subs');
    cachedProducts = products.map(toSubscriptionProduct).filter((p): p is SubscriptionProduct => p !== null);
    cachedMissing = SUBSCRIPTION_IDS.filter(id => !cachedProducts.some(p => p.productId === id));
    cachedAvailable = true;
    emit({kind: 'products'});
    return {available: true, products: cachedProducts, missing: cachedMissing};
  } catch {
    cachedAvailable = false;
    cachedProducts = [];
    cachedMissing = [...SUBSCRIPTION_IDS];
    emit({kind: 'unavailable', message: 'Google Play billing is not available right now.'});
    return {available: false, products: [], missing: [...SUBSCRIPTION_IDS]};
  }
}

export function getSubscriptionProducts(): SubscriptionProduct[] {
  return cachedProducts;
}

export function getSubscriptionStatus(): {available: boolean; missing: string[]} {
  return {available: cachedAvailable, missing: cachedMissing};
}

/** Launch the official Google Play subscription dialog for one plan. */
export async function buySubscription(productId: string): Promise<{started: boolean; error?: string}> {
  if (!currentUid()) {
    emit({kind: 'signin-required'});
    return {started: false, error: 'Sign in first — subscriptions are recorded on your account.'};
  }
  const product = cachedProducts.find(p => p.productId === productId);
  if (!product) return {started: false, error: 'That subscription is not available right now.'};
  if (!SUBSCRIPTION_VERIFY_URL) {
    emit({kind: 'failed', message: 'Server verification is not configured for subscriptions yet.'});
    return {started: false, error: 'Subscriptions are not available yet — server verification is not configured.'};
  }
  try {
    await requestPurchase({
      request: {android: {skus: [productId], subscriptionOffers: [{sku: productId, offerToken: product.offerToken}]}},
      type: 'subs',
    });
    return {started: true};
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'The subscription could not be started.';
    if (msg.toLowerCase().includes('cancel')) {
      emit({kind: 'cancelled'});
      return {started: false, error: 'Subscription cancelled.'};
    }
    emit({kind: 'failed', message: msg});
    return {started: false, error: msg};
  }
}

/** Re-verify every owned subscription (app start, Wallet open). Returns how many were (re)confirmed. */
export async function reconcileSubscriptions(): Promise<number> {
  let confirmed = 0;
  try {
    const owned = await getAvailablePurchases();
    for (const purchase of owned) {
      if (!isSubscriptionProduct(purchase.productId)) continue;
      try {
        const result = await handleSubscriptionPurchase(purchase);
        if (result === 'subscribed' || result === 'duplicate') confirmed += 1;
      } catch {/* one bad purchase must not block the others */}
    }
  } catch {/* billing unavailable or Play unreachable; the shop reports it */}
  if (confirmed > 0) emit({kind: 'restored', count: confirmed});
  return confirmed;
}

/** Read the subscription entitlement for the current account (backend-written). */
export async function fetchSubscription(): Promise<SubscriptionDoc | null> {
  const uid = currentUid();
  if (!uid) return null;
  try {
    const [{doc, getDoc}, {cloudDb: dbFn}] = await Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);
    const snap = await getDoc(doc(dbFn(), 'users', uid, 'subscription', 'current'));
    if (!snap.exists()) return null;
    return snap.data() as SubscriptionDoc;
  } catch {
    return null;
  }
}
