import React,{useEffect,useRef,useState} from 'react';
import {Platform,Pressable,Share,StyleSheet,Text,TextInput,View} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import {Button,C,Glass,Icon,IconTile,type IconName} from './ui';
import {encode,type EncodeResult} from './encode';
import {useAppConfig} from './appConfig';
import {addBonus,AD_BONUS,loadQuota,remaining,saveQuota,spend,type Quota} from './encodeQuota';
import {watchRewardedAd} from './ads';

/** Encode Message – Convert your words into Gen Z codes (Home). */
export default function EncodePanel({onDecode}:{onDecode:(text:string)=>void}){
  const config=useAppConfig();
  const [text,setText]=useState(''),[result,setResult]=useState<EncodeResult|null>(null),[choices,setChoices]=useState<Record<string,string>>({});
  const [quota,setQuota]=useState<Quota|null>(null),[note,setNote]=useState(''),[busy,setBusy]=useState(false);
  const input=useRef<TextInput>(null);
  useEffect(()=>{void loadQuota().then(setQuota);},[]);
  const free=config.encodeFreeDaily;
  const left=quota?remaining(quota,free):free;
  const canConvert=left>0;
  const run=()=>{
    setNote('');
    if(!text.trim()){setNote('Type a message to encode.');return;}
    if(!canConvert){setNote('You have used today’s free conversions.');return;}
    const r=encode(text,choices);
    setResult(r);
    // Count only a conversion that actually changed something.
    if(r.replaced>0&&quota){const next=spend(quota);setQuota(next);void saveQuota(next);}
    if(r.replaced===0)setNote('No dictionary codes matched yet. Try everyday phrases like “be right back” or “to be honest”.');
  };
  const cycle=(phrase:string,options:string[],current:string)=>{
    const next={...choices,[phrase]:options[(options.indexOf(current)+1)%options.length]!};
    setChoices(next);setResult(encode(text,next));   // switching alternatives is free
  };
  const unlock=async()=>{
    if(busy||!quota)return;setBusy(true);setNote('');
    try{if(await watchRewardedAd()){const q=addBonus(quota);setQuota(q);void saveQuota(q);setNote(`+${AD_BONUS} conversions unlocked for today.`);}else setNote('No ad is available right now. Try again later.');}
    finally{setBusy(false);}
  };
  const share=async()=>{if(!result)return;if(Platform.OS==='web'){await Clipboard.setStringAsync(result.output);setNote('Copied for sharing.');}else await Share.share({message:result.output});};
  return <Glass>
    <View style={s.row}><IconTile icon="code-slash-outline" from="#8B3FE0" to="#4B3BDB" size={44} iconSize={22}/><View style={{flex:1}}><Text style={s.title}>Encode Message</Text><Text style={s.sub}>Convert your words into Gen Z codes</Text></View></View>
    <TextInput ref={input} accessibilityLabel="Message to encode" multiline maxLength={2000} value={text} onChangeText={v=>{setText(v);setResult(null);setChoices({});}} placeholder="e.g. Hello, how are you? Be right back" placeholderTextColor={C.muted} style={s.input} textAlignVertical="top"/>
    <Text style={s.cost} accessibilityLiveRegion="polite">{left>0?`Free · ${left} conversion${left===1?'':'s'} left today`:'Free conversions used for today'}</Text>
    {canConvert?<Button title="Encode message" icon="sparkles" onPress={run}/>:<Button title={busy?'Loading ad…':`Watch an optional ad · +${AD_BONUS} conversions`} icon="play-circle-outline" disabled={busy} onPress={()=>void unlock()}/>}
    {!!note&&<Text accessibilityRole="alert" style={s.sub}>{note}</Text>}
    {result&&result.replaced>0&&<View style={{gap:10}}>
      <View style={s.output}><Text selectable style={s.outputText}>{result.output}</Text></View>
      <Text style={s.sub}>Tap a code to try another option.</Text>
      <View style={s.wrap}>{result.segments.filter(x=>x.code).map((x,i)=><Pressable key={i+(x.phrase??'')} accessibilityRole="button" accessibilityLabel={`${x.text} encoded as ${x.code}.${x.options!.length>1?' Tap for another option.':''}`} onPress={()=>x.options!.length>1&&cycle(x.phrase!,x.options!,x.code!)} style={s.chip}>
        <Text style={s.chipFrom} numberOfLines={1}>{x.text}</Text><Icon name="arrow-forward" size={13} color={C.muted}/><Text style={s.chipTo}>{x.code}</Text>{x.options!.length>1&&<Icon name="swap-horizontal" size={14} color={C.purple}/>}
      </Pressable>)}</View>
      <View style={s.wrap}>
        <Action icon="copy-outline" label="Copy" onPress={()=>void Clipboard.setStringAsync(result.output).then(()=>setNote('Copied.'))}/>
        <Action icon="share-social-outline" label="Share" onPress={()=>void share()}/>
        <Action icon="create-outline" label="Edit" onPress={()=>input.current?.focus()}/>
        <Action icon="scan-outline" label="Decode it" onPress={()=>onDecode(result.output)}/>
      </View>
    </View>}
  </Glass>;
}
function Action({icon,label,onPress}:{icon:IconName;label:string;onPress:()=>void}){
  return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({pressed})=>[s.action,pressed&&{opacity:.75}]}><Icon name={icon} size={16} color={C.ink}/><Text style={s.actionText}>{label}</Text></Pressable>;
}
const s=StyleSheet.create({
  row:{flexDirection:'row',alignItems:'center',gap:10},title:{fontSize:17,fontWeight:'900',color:C.ink},sub:{fontSize:13,lineHeight:18,color:C.muted},
  input:{minHeight:84,borderWidth:1,borderColor:C.line,borderRadius:14,padding:12,fontSize:16,color:C.ink,backgroundColor:'#fff'},
  cost:{fontSize:12.5,fontWeight:'800',color:'#6D28D9'},
  output:{borderRadius:14,padding:14,backgroundColor:'#F3EDFF',borderWidth:1,borderColor:'#DDD0FF'},outputText:{fontSize:18,fontWeight:'800',color:'#2E1065',lineHeight:25},
  wrap:{flexDirection:'row',flexWrap:'wrap',gap:6},chip:{flexDirection:'row',alignItems:'center',gap:5,paddingHorizontal:10,minHeight:34,borderRadius:17,backgroundColor:'#fff',borderWidth:1,borderColor:'#DDD6FE',maxWidth:'100%'},
  chipFrom:{fontSize:12.5,color:C.muted,flexShrink:1},chipTo:{fontSize:13.5,fontWeight:'900',color:'#5B21B6'},
  action:{flexDirection:'row',alignItems:'center',gap:5,minHeight:36,paddingHorizontal:11,borderRadius:18,backgroundColor:'#E3EAFB'},actionText:{fontWeight:'800',fontSize:12.5,color:C.ink},
});
