import React, {createContext, useContext, useEffect, useState} from 'react';
import {AccessibilityInfo} from 'react-native';

const ReducedMotion = createContext(true);

export function MotionPreferences({children}: {children: React.ReactNode}) {
  const [reduced, setReduced] = useState(true);

  useEffect(() => {
    let current = true;
    let changed = false;
    const subscription = AccessibilityInfo.addEventListener('reduceMotionChanged', value => {
      changed = true;
      setReduced(value);
    });
    void AccessibilityInfo.isReduceMotionEnabled().then(value => {
      if (current && !changed) setReduced(value);
    }).catch(() => {});
    return () => {
      current = false;
      subscription?.remove();
    };
  }, []);

  return <ReducedMotion.Provider value={reduced}>{children}</ReducedMotion.Provider>;
}

export const useReducedMotion = () => useContext(ReducedMotion);
