import {SPARK_MODE} from '../shared/deployment';
import React,{useEffect,useRef,useState} from 'react';
import {Keyboard,Modal,Platform,Pressable,ScrollView,Share,StyleSheet,Text,TextInput,View,useWindowDimensions} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import * as Clipboard from 'expo-clipboard';
import {Button,C,Chip,Glass,LiquidHero,Icon,RoundIcon,confirmAction,type IconName} from './ui';
import {useEligibleBalance} from './ContributionScreens';
import {KeyboardDock,useKeyboardVisible} from './KeyboardDock';
import AdRewardButton from './AdRewardButton';
import {errorOf,feature,interactions,ms,policy,requestKey,savedPosts,watchComments,watchPosts,type FeedFilter,type FeatureRow} from './communityFeatures';
import {reportPost} from './communityPosts';
import {useAccountUser,useAuthPhase} from './services';
import {useReducedMotion} from './motion';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {screenPost} from '../shared/chat';
import {showInterstitialIfReady} from './ads';
import {REPORT_REASONS} from './ugc';
import {usePublishingMode} from './publishing';
import {useAppConfig} from './appConfig';
import {confirm as confirmTap,isOn,prune,rollback,shownCount,tap,type OptimisticMap} from './optimistic';
import {LinearGradient} from 'expo-linear-gradient';
import {CONTENT_NOTICE} from '../shared/publishing';

const filters:FeedFilter[]=['Latest','Trending','Code Words','Slangs'];
const nameOf=(row:FeatureRow)=>row.name||'Code Explorer';
const dateOf=(row:FeatureRow)=>ms(row.createdAt)?new Date(ms(row.createdAt)).toLocaleDateString(undefined,{month:'short',day:'numeric'}):'';
const avatarPalette:[string,string][]=[['#FF9A62','#F2547D'],['#7C5CFF','#3BA4FF'],['#16C2A3','#3B82F6'],['#F59E0B','#EF4444'],['#A855F7','#EC4899'],['#06B6D4','#6366F1']];
const avatarColors=(uid?:string):[string,string]=>avatarPalette[[...(uid??'x')].reduce((a,c)=>a+c.charCodeAt(0),0)%avatarPalette.length]!;
const copyText=(row:FeatureRow)=>row.term?`${row.term}: ${row.meaning??''}`:row.text??'';

export default function CommunityPostsPanel({active,onSignIn,onHistory,visibleBalance}:{active:boolean;onSignIn:()=>void;onHistory:()=>void;visibleBalance:number}) {
  const uid=useAccountUser()?.uid, phase=useAuthPhase();
  const posting=usePublishingMode('post');
  const paid=useAppConfig().paidCommunity;
  const accountCredits=useEligibleBalance(paid&&active?uid:undefined);
  const [options,setOptions]=useState(false);
  const [filter,setFilter]=useState<FeedFilter>('Latest'),[showSaved,setShowSaved]=useState(false);
  const [rows,setRows]=useState<FeatureRow[]>([]),[savedRows,setSavedRows]=useState<FeatureRow[]>([]);
  const [liked,setLiked]=useState<Set<string>>(new Set()),[saved,setSaved]=useState<Set<string>>(new Set());
  const [notice,setNotice]=useState(''),[loading,setLoading]=useState(true),[refresh,setRefresh]=useState(0);
  const [mode,setMode]=useState<'create'|'comments'|'report'|null>(null),[selected,setSelected]=useState<FeatureRow|null>(null);
  const [menu,setMenu]=useState('');
  const pending=useRef(new Set<string>());
  const visible=showSaved?savedRows:rows;
  const verified=useBadges(active?visible.map(r=>r.uid):[]);
  const reduced=useReducedMotion();
  const narrow=useWindowDimensions().width<400;
  useEffect(()=>{
    if(!active)return;
    setLoading(true);setRows([]);setNotice('');
    return watchPosts(filter,data=>{setRows(data);setLoading(false);},()=>{setNotice('Could not load posts. Check your connection and retry.');setLoading(false);});
  },[filter,active,refresh]);
  useEffect(()=>{
    let mounted=true;
    setLiked(new Set());setSaved(new Set());setShowSaved(false);
    if(uid&&active)void interactions(uid).then(r=>{if(mounted){setLiked(r.liked);setSaved(r.saved);}},()=>{});
    return ()=>{mounted=false;};
  },[uid,active]);
  useEffect(()=>{
    if(!showSaved||!active)return;
    let live=true;
    void savedPosts(saved).then(r=>{if(live)setSavedRows(r);});
    return ()=>{live=false;};
  },[showSaved,active,saved,refresh]);
  const signed=(fn:()=>void)=>{if(uid)fn();else if(phase==='restoring')setNotice('Checking your account… try again in a moment.');else onSignIn();};
  const act=(key:string,task:()=>Promise<void>)=>{
    if(pending.current.has(key))return;
    pending.current.add(key);
    void task().catch(e=>setNotice(errorOf(e))).finally(()=>pending.current.delete(key));
  };
  // Instant like/save: the tap shows immediately, the server write runs in the
  // background, rapid taps collapse into one final state, and a rejected write
  // rolls back with a message. (Previously the UI waited for a Firestore
  // transaction plus the next feed snapshot: 2–3 s per tap.)
  const [likeOpt,setLikeOpt]=useState<OptimisticMap>({}),[saveOpt,setSaveOpt]=useState<OptimisticMap>({});
  const inFlight=useRef(new Set<string>());
  useEffect(()=>{setLikeOpt(m=>prune(m,Object.fromEntries(rows.map(r=>[r.id,r.likeCount]))));},[rows]);
  const send=(row:FeatureRow,type:'like'|'save',value:boolean)=>{
    const key=type+row.id,setOpt=type==='like'?setLikeOpt:setSaveOpt,setConfirmed=type==='like'?setLiked:setSaved;
    inFlight.current.add(key);
    void feature(type+'-post',{id:row.id,enabled:value}).then(()=>{
      setConfirmed(prev=>{const next=new Set(prev);if(value)next.add(row.id);else next.delete(row.id);return next;});
      let resend:boolean|null=null;
      setOpt(m=>{const r=confirmTap(row.id,value,m);resend=r.resend;return type==='save'&&r.resend===null?rollback(row.id,r.map):r.map;});
      inFlight.current.delete(key);
      if(resend!==null)send(row,type,resend);
    },e=>{
      inFlight.current.delete(key);
      setOpt(m=>rollback(row.id,m));
      setNotice(errorOf(e));
    });
  };
  const toggle=(row:FeatureRow,type:'like'|'save')=>signed(()=>{
    const key=type+row.id,confirmed=type==='like'?liked:saved,map=type==='like'?likeOpt:saveOpt,setOpt=type==='like'?setLikeOpt:setSaveOpt;
    const r=tap(row.id,row.likeCount,confirmed,map,inFlight.current.has(key));
    setOpt(r.map);
    if(r.send)send(row,type,r.desired);
    if(type==='save')setNotice(r.desired?'Saved to your collection.':'Removed from saved posts.');
  });
  const open=(next:'comments'|'report',row:FeatureRow)=>{setMenu('');setSelected(row);setMode(next);};
  return <View style={{flex:1}}>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={s.feed}>
      <View style={s.toolbar}>
        <Text style={[s.body,{flex:1}]}>{paid&&uid?'Credits: '+(accountCredits.balance===null?'—':accountCredits.balance.toLocaleString()):'Community posts'}</Text>
        <Pressable accessibilityRole="button" accessibilityLabel="Post Slang" disabled={posting.mode===null||posting.mode==='paused'} onPress={()=>signed(()=>setMode('create'))} style={s.newPost}><Icon name="add" size={17} color="#fff"/><Text style={s.newPostText}>Post Slang</Text></Pressable>
        <Pressable accessibilityRole="button" accessibilityLabel="Feed filters and saved posts" accessibilityState={{expanded:options}} onPress={()=>setOptions(v=>!v)} style={s.action}><Icon name="ellipsis-vertical" size={20}/></Pressable>
      </View>
      {options&&<Glass style={{padding:10,gap:7}}><View style={s.actions}>{filters.map(f=><Chip key={f} label={f} selected={!showSaved&&filter===f} onPress={()=>{setShowSaved(false);setFilter(f);setOptions(false);}}/>)}</View><View style={s.actions}><Chip label="Saved" icon="bookmark-outline" selected={showSaved} onPress={()=>signed(()=>{setShowSaved(v=>!v);setOptions(false);})}/><Chip label="My Posts" icon="albums-outline" onPress={()=>signed(onHistory)}/></View></Glass>}
      {!!posting.error&&<Text accessibilityRole="alert" style={s.body}>{posting.error}</Text>}
      {posting.mode==='paused'&&<Text style={s.body}>Posting is temporarily paused by the administrator.</Text>}
      {accountCredits.error&&<View style={s.actions}><Text style={[s.body,{flex:1}]}>{accountCredits.error}</Text><Chip label="Retry" onPress={accountCredits.reload}/></View>}
      {!!notice&&<Text accessibilityRole="alert" style={s.body}>{notice}</Text>}
      {!showSaved&&notice.startsWith('Could not load')&&<Button light title="Retry feed" onPress={()=>setRefresh(x=>x+1)}/>}
      {loading&&!showSaved&&<Text style={s.body}>Loading posts…</Text>}
      {(!loading||showSaved)&&!visible.length&&<Glass><Text style={s.title}>{showSaved?'No saved posts yet':'No posts in this view'}</Text><Text style={s.body}>{showSaved?'Save a useful word from the feed to find it here.':'Share a code or slang to start the conversation.'}</Text></Glass>}
      {visible.map(row=>{
        const isLiked=isOn(row.id,liked,likeOpt),isSaved=isOn(row.id,saved,saveOpt),likes=shownCount(row.id,row.likeCount,likeOpt);
        return <Glass key={row.id} style={s.card}>
        <View style={s.cardRow}>
          <LinearGradient colors={avatarColors(row.uid)} start={{x:0,y:0}} end={{x:1,y:1}} style={s.avatar}><Text style={s.avatarText}>{nameOf(row).charAt(0).toUpperCase()}</Text></LinearGradient>
          <View style={{flex:1,gap:6,minWidth:0}}>
            <View style={s.row}>
              <View style={[s.row,{flex:1,minWidth:0,gap:5}]}><Text style={s.author} numberOfLines={1}>{nameOf(row)}</Text><VerifiedBadge verified={verified.has(row.uid)}/><Text style={s.time} numberOfLines={1}>· {dateOf(row)}</Text></View>
              <Pressable accessibilityRole="button" accessibilityLabel="Post options" accessibilityState={{expanded:menu===row.id}} hitSlop={8} onPress={()=>setMenu(menu===row.id?'':row.id)} style={s.more}><Icon name="ellipsis-vertical" size={18} color={C.ink}/></Pressable>
            </View>
            {menu===row.id&&<View style={s.actions}>{uid===row.uid?
              <Chip label="Remove my post" icon="trash-outline" onPress={()=>confirmAction('Remove this post?', 'It will no longer be public.',()=>act(row.id,async()=>{await feature('delete-post',{id:row.id});setMenu('');setNotice('Post removed.');}))}/>:
              <Chip label="Report" icon="flag-outline" onPress={()=>signed(()=>open('report',row))}/>}</View>}
            {!!row.term&&<View style={s.actions}>
              <LinearGradient colors={['#8B3FE0','#4B3BDB']} start={{x:0,y:0}} end={{x:1,y:1}} style={s.termChip}><Icon name="layers" size={14} color="#fff"/><Text selectable style={s.term}>{row.term}</Text></LinearGradient>
              {!!row.category&&<Text style={s.category}># {row.category}</Text>}
            </View>}
            <Text selectable style={s.meaning}>{row.term?<Text style={s.meaningLabel}>Meaning: </Text>:null}{row.meaning??row.text}</Text>
            {!!row.example&&<Text selectable style={s.body}>Example: {row.example}</Text>}
          </View>
        </View>
        <View style={s.engage}>
          <Pressable accessibilityRole="button" accessibilityLabel={`${isLiked?'Unlike':'Like'} · ${likes} likes`} accessibilityState={{selected:isLiked}} hitSlop={6} onPress={()=>toggle(row,'like')} style={s.stat}><Icon name={isLiked?'heart':'heart-outline'} size={21} color={isLiked?'#F0283C':C.ink}/><Text style={s.statText}>{likes.toLocaleString()}</Text></Pressable>
          <Pressable accessibilityRole="button" accessibilityLabel={`Comments · ${row.commentCount??0}`} hitSlop={6} onPress={()=>open('comments',row)} style={s.stat}><Icon name="chatbubble-outline" size={19} color={C.ink}/><Text style={s.statText}>{(row.commentCount??0).toLocaleString()}</Text></Pressable>
          <View style={{flex:1}}/>
          <Action compact={narrow} icon={isSaved?'bookmark':'bookmark-outline'} label={isSaved?'Saved':'Save'} selected={isSaved} onPress={()=>toggle(row,'save')}/>
          <Action compact={narrow} icon="copy-outline" label="Copy" onPress={()=>act('copy',async()=>{await Clipboard.setStringAsync(copyText(row));setNotice('Copied word and meaning.');})}/>
          <Action compact={narrow} icon="share-social-outline" label="Share" onPress={()=>act('share',async()=>{
            if(Platform.OS==='web'){await Clipboard.setStringAsync(copyText(row));setNotice('Copied for sharing.');}
            else await Share.share({message:copyText(row)+'\n\nvia GenZ Codebook'});
          })}/>
        </View>
      </Glass>;})}
    </ScrollView>
    <Modal visible={mode!==null} animationType={reduced?'none':'slide'} onRequestClose={()=>setMode(null)}>
      {mode&&<SafeAreaView style={s.screen}>
        <KeyboardDock>
          <View style={s.bar}><RoundIcon name="arrow-back" label="Close" onPress={()=>setMode(null)}/><Text style={[s.title,{flex:1}]}>{mode==='create'?'Create post':mode==='report'?'Report post':'Comments'}</Text><AdRewardButton compact/></View>
          {mode==='create'?<Composer uid={uid} postingMode={posting.mode} visibleBalance={visibleBalance} onDone={status=>{setMode(null);setNotice(status==='approved'?'Your post is live.':status==='pending'?'Submitted for review. Track it in My Posts.':'Check My Posts for the current status.');accountCredits.reload();showInterstitialIfReady();}}/>:selected&&
            <PostThread key={selected.id+mode} row={selected} report={mode==='report'} uid={uid} onDone={()=>{setMode(null);setNotice('Report sent.');}}/>}
        </KeyboardDock>
      </SafeAreaView>}
    </Modal>
  </View>;
}

function Action({icon,label,selected,onPress,compact=false}:{icon:IconName;label:string;selected?:boolean;onPress:()=>void;compact?:boolean}) {
  return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{selected}} hitSlop={4} style={[s.action,compact&&s.actionIcon,selected&&s.on]} onPress={onPress}>
    <Icon name={icon} size={compact?17:15} color={selected?C.purple:C.ink}/>{!compact&&<Text style={s.actionText} numberOfLines={1}>{label}</Text>}
  </Pressable>;
}

function Composer({uid,visibleBalance,postingMode,onDone}:{uid?:string;visibleBalance:number;postingMode:'open'|'review'|'paused'|null;onDone:(status?:string)=>void}) {
  const [term,setTerm]=useState(''),[meaning,setMeaning]=useState(''),[example,setExample]=useState(''),[category,setCategory]=useState('');
  const [error,setError]=useState(''),[busy,setBusy]=useState(false);
  const busyRef=useRef(false), key=useRef(requestKey()), scroller=useRef<ScrollView>(null);
  const paid=useAppConfig().paidCommunity;
  const credit=useEligibleBalance(paid?uid:undefined);
  const positions=useRef<Record<string,number>>({});
  const focused=useRef('');
  const keyboardOpen=useKeyboardVisible();
  const keepFieldVisible=()=>{
    const y=positions.current[focused.current];
    if(y!==undefined)scroller.current?.scrollTo({y:Math.max(0,y-8),animated:false});
  };
  useEffect(()=>{if(keyboardOpen)keepFieldVisible();},[keyboardOpen]);
  const update=(fn:(v:string)=>void)=>(v:string)=>{key.current=requestKey();setError('');fn(v);};

  const ready=!!term.trim()&&!!meaning.trim()&&!!category&&(postingMode==='open'||postingMode==='review');
  const canPay=!paid||(credit.balance!==null&&credit.balance>=policy.postFee);
  const send=async()=>{
    if(!ready||!canPay||busyRef.current)return;
    const check=screenPost([term,meaning,example].filter(Boolean).join('\n'));
    if(!check.ok){setError(check.message);return;}
    busyRef.current=true;setBusy(true);setError('');
    try {const result=await feature('create-post',{term,meaning,example,category,requestId:key.current});onDone(result.status);}
    catch(e){
      setError(errorOf(e));
      if((e as {code?:string})?.code==='functions/failed-precondition')credit.reload();
    }
    finally {busyRef.current=false;setBusy(false);}
  };
  return <>
    <ScrollView ref={scroller} contentContainerStyle={s.feed} keyboardShouldPersistTaps="handled" onLayout={()=>{if(keyboardOpen)keepFieldVisible();}}>
      <Glass>
        <Text style={s.title}>Share a new code word</Text>
        <Text style={s.body}>{postingMode==='review'?'New posts currently require administrator approval.':!paid?'Posting is free. Keep it original and respectful.':'Your post is published immediately after payment.'}</Text>
        {([['Word / Term',term,setTerm,30],['Meaning / Explanation',meaning,setMeaning,200],['Example (optional)',example,setExample,200]] as const).map(([label,value,setter,max])=>
          <View key={label} style={{gap:4}} onLayout={e=>{positions.current[label]=e.nativeEvent.layout.y;}}>
            <Text style={s.author}>{label} · {value.length}/{max}</Text>
            <TextInput accessibilityLabel={label} value={value} onChangeText={update(setter)} maxLength={max} editable={!busy} onFocus={()=>{focused.current=label;if(keyboardOpen)keepFieldVisible();}}
              multiline={max>30} style={[s.input,max>30&&{minHeight:64}]} placeholderTextColor={C.muted}/>
          </View>)}
        <Text style={s.author}>Category</Text>
        <View style={s.actions}>{policy.postCategories.map(c=><Chip key={c} label={c} selected={category===c} onPress={()=>{if(!busy)update(setCategory)(c);}}/>)}</View>
        <Text style={s.body}>{!paid?'Free submission.':'Posting costs '+policy.postFee+' Credits.'} {postingMode==='review'?'Your post will wait for review.':'Your post goes live immediately.'}</Text>
        <Text style={s.body}>{CONTENT_NOTICE}</Text>
        {paid&&credit.balance!==null&&credit.balance<policy.postFee&&<Text style={s.body}>This device shows {visibleBalance.toLocaleString()} tokens. Posting uses account tokens from verified ads, purchases, referrals or admin grants. Signed-in ad rewards become usable after verification. Older device tokens remain available for offline learning.</Text>}
      </Glass>
    </ScrollView>
    <View style={s.footer}>
      {!!error&&<Text accessibilityRole="alert" style={s.body}>{error}</Text>}
      {credit.error?<><Text accessibilityRole="alert" style={s.body}>{credit.error}</Text>{!keyboardOpen&&<Text style={s.body}>{visibleBalance.toLocaleString()} tokens shown on this device · Account credits unconfirmed</Text>}<Button light title="Retry balance check" onPress={credit.reload}/></>:<>
        <Text accessibilityLiveRegion="polite" style={s.body}>{!paid?'Free posting':credit.balance===null?'Checking your Credits…':`Eligible credits: ${credit.balance.toLocaleString()} · Cost: ${policy.postFee}`}</Text>
        <Button title={busy?'Submitting…':credit.balance!==null&&!canPay?'Not enough Credits':!paid?'Post Slang · Free':`Post · ${policy.postFee} Credens`} icon="paper-plane-outline" disabled={!ready||!canPay||busy}
          onPress={()=>{Keyboard.dismiss();confirmAction('Confirm post?',!paid?`Publish “${term}” for free?`:`Submit “${term}” for ${policy.postFee} Credits. The fee is non-refundable.`,()=>void send(),'Submit');}}/>
      </>}
    </View>
  </>;
}

function PostThread({row,report,uid,onDone}:{row:FeatureRow;report:boolean;uid?:string;onDone:()=>void}) {
  const [rows,setRows]=useState<FeatureRow[]>([]),[value,setValue]=useState(''),[reason,setReason]=useState('');
  const [error,setError]=useState(''),[busy,setBusy]=useState(false);
  const lock=useRef(false);
  const badges=useBadges(rows.map(r=>r.uid));
  useEffect(()=>{if(!report)return watchComments(row.id,setRows,()=>setError('Could not load comments.'));},[row.id,report]);
  const send=async()=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setError('');
    try {
      if(report){const result=await reportPost(row.id,reason,value);if(!result.ok)throw new Error(result.message);onDone();}
      else {await feature('comment-post',{id:row.id,text:value});setValue('');}
    } catch(e){setError(errorOf(e));}
    finally {lock.current=false;setBusy(false);}
  };
  return <>
    <ScrollView contentContainerStyle={s.feed} keyboardShouldPersistTaps="handled">
      <Text style={s.title}>{row.term??'Community post'}</Text>
      {report?<View style={s.actions}>{REPORT_REASONS.map(r=><Chip key={r} label={r} selected={reason===r} onPress={()=>setReason(r)}/>)}</View>:
        rows.length?rows.map(r=>r.status==='removed'?<Text key={r.id} style={s.body}>Comment removed</Text>:<Glass key={r.id}><View style={s.row}><Text style={s.author}>{nameOf(r)}</Text><VerifiedBadge verified={badges.has(r.uid)}/><Text style={s.body}>{dateOf(r)}</Text></View><Text style={s.meaning}>{r.text}</Text></Glass>):
          <Text style={s.body}>No comments yet.</Text>}
    </ScrollView>
    <View style={s.footer}>
      {!!error&&<Text accessibilityRole="alert" style={s.body}>{error}</Text>}
      {uid?<><TextInput accessibilityLabel={report?'Report details':'Your comment'} value={value} onChangeText={setValue} maxLength={report?300:200} multiline style={s.input}/>
        <Button title={report?'Send report':'Add comment'} disabled={busy||(report?!reason:!value.trim())} onPress={()=>void send()}/></>:
        <Text style={s.body}>Sign in to join the discussion.</Text>}
    </View>
  </>;
}

const s=StyleSheet.create({
  toolbar:{flexDirection:'row',alignItems:'center',gap:7},newPost:{minHeight:40,paddingHorizontal:10,borderRadius:12,backgroundColor:C.accent,flexDirection:'row',alignItems:'center',gap:3},newPostText:{fontSize:13,fontWeight:'800',color:'#fff'},
  feed:{padding:14,gap:12,paddingBottom:22,maxWidth:620,width:'100%',alignSelf:'center'},actions:{flexDirection:'row',flexWrap:'wrap',gap:6},
  row:{flexDirection:'row',alignItems:'center',gap:7},title:{fontSize:20,fontWeight:'900',color:C.ink},author:{fontSize:14,fontWeight:'800',color:C.ink},
  body:{fontSize:13,lineHeight:18,color:C.muted},meaning:{fontSize:14.5,lineHeight:20,color:C.ink},meaningLabel:{fontWeight:'800'},avatar:{width:42,height:42,borderRadius:14,alignItems:'center',justifyContent:'center'},avatarText:{fontWeight:'900',color:'#fff',fontSize:17},
  card:{padding:12,gap:0},cardRow:{flexDirection:'row',gap:10,alignItems:'flex-start'},time:{fontSize:12.5,color:C.muted,flexShrink:1},more:{width:30,height:30,alignItems:'center',justifyContent:'center',borderRadius:10},
  termChip:{flexDirection:'row',alignItems:'center',gap:6,borderRadius:12,paddingHorizontal:10,paddingVertical:5},engage:{flexDirection:'row',alignItems:'center',gap:6,marginTop:8,paddingLeft:2},stat:{flexDirection:'row',alignItems:'center',gap:4,minHeight:36,paddingRight:8},statText:{fontWeight:'800',fontSize:14,color:C.ink},
  callout:{padding:13,borderRadius:16,flexDirection:'row',gap:8,alignItems:'center'},calloutTitle:{fontSize:15,fontWeight:'900',color:'#fff'},cost:{backgroundColor:'#FFE2A1',color:'#63400C',padding:6,borderRadius:9,fontWeight:'800',overflow:'hidden'},
  term:{color:'#fff',fontWeight:'900',fontSize:16},
  category:{color:'#E11D61',backgroundColor:'#FFE4EE',fontWeight:'800',fontSize:12.5,paddingHorizontal:10,paddingVertical:6,borderRadius:12,overflow:'hidden'},
  action:{minHeight:34,paddingHorizontal:9,flexDirection:'row',alignItems:'center',gap:4,borderRadius:17,backgroundColor:'#E3EAFB'},actionText:{fontWeight:'800',fontSize:12,color:C.ink},on:{backgroundColor:'#EBE2FF'},actionIcon:{width:36,paddingHorizontal:0,justifyContent:'center'},
  screen:{flex:1,backgroundColor:C.bg},bar:{padding:10,paddingHorizontal:14,flexDirection:'row',alignItems:'center',gap:12,borderBottomWidth:1,borderBottomColor:C.line},
  footer:{padding:10,paddingHorizontal:14,gap:5,backgroundColor:'#fff',borderTopWidth:1,borderTopColor:C.line},input:{backgroundColor:'#fff',borderColor:C.line,borderWidth:1,borderRadius:12,padding:9,color:C.ink,minHeight:42},
});
