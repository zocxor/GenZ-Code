import React, {useEffect,useState} from 'react';
import {StyleSheet} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {collection,documentId,onSnapshot,query,where} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {Icon} from './ui';

export function useBadges(uids:string[]) {
  const key=JSON.stringify([...new Set(uids.filter(Boolean))].sort());
  const [verified,setVerified]=useState<Set<string>>(new Set());
  useEffect(()=>{
    setVerified(new Set());
    const ids=JSON.parse(key) as string[];
    const snapshots=new Map<number,string[]>();
    const stops:(()=>void)[]=[];
    for(let i=0;i<ids.length;i+=30) {
      stops.push(onSnapshot(query(collection(cloudDbLive(),'verifiedContributors'),where(documentId(),'in',ids.slice(i,i+30))),snap=>{
        snapshots.set(i,snap.docs.filter(d=>d.get('verified')===true).map(d=>d.id));
        setVerified(new Set([...snapshots.values()].flat()));
      },()=>{
        snapshots.delete(i);
        setVerified(new Set([...snapshots.values()].flat()));
      }));
    }
    return ()=>stops.forEach(stop=>stop());
  },[key]);
  return verified;
}

export function VerifiedBadge({verified}:{verified:boolean}) {
  if(!verified)return null;
  return <LinearGradient colors={['#2449CF','#692EC3']} style={s.badge} accessible accessibilityLabel="Verified Badge"><Icon name="checkmark" size={12} color="#fff"/></LinearGradient>;
}
const s=StyleSheet.create({badge:{width:18,height:18,borderTopLeftRadius:5,borderTopRightRadius:5,borderBottomLeftRadius:9,borderBottomRightRadius:9,alignItems:'center',justifyContent:'center',flexShrink:0}});
