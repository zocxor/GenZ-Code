import {SPARK_MODE} from '../shared/deployment';
import {BACKEND_URL} from './backend';
import React,{useEffect,useMemo,useRef,useState} from 'react';
import {collection,query,orderBy,limit,onSnapshot} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';
import {AppState,Pressable,StyleSheet,Text,TextInput,View} from 'react-native';
import {Button,C,Chip,Glass,LiquidHero,Icon,SectionHeader,confirmAction} from './ui';
import {datesAhead,errorOf,feature,ms,myRows,policy,requestKey,slots,utcDate,watchDaily,type DailyEntry,type FeatureRow} from './communityFeatures';
import {useAccountUser,useAuthPhase} from './services';
import {terms,bundledTerms,onContentChange,contentRevision} from './content';
import {refreshCommunity} from './contentSync';
import {dailyTerm} from './discovery';
import {VerifiedBadge,useBadges} from './VerifiedBadge';

const money = (value:number) => value.toLocaleString();
type SlotState='open'|'reserved'|'pending'|'closed';
/** Calendar colours: approved/scheduled/published reservations are green, pending requests amber. */
export const slotState=(status:string|undefined,isToday:boolean):SlotState=>isToday?'closed':!status?'open':status==='pending'?'pending':'reserved';
const slotLabel:Record<SlotState,string>={open:'Available',reserved:'Reserved',pending:'Pending request',closed:'Unavailable'};
const dayStyle:Record<SlotState,object>={open:{backgroundColor:'#fff',borderColor:'#D6DDF0'},reserved:{backgroundColor:'#DCFCE7',borderColor:'#22C55E'},pending:{backgroundColor:'#FEF3C7',borderColor:'#F59E0B'},closed:{backgroundColor:'#F1F3F8',borderColor:'#E3E7F0'}};
const dayText:Record<SlotState,string>={open:'#0F172A',reserved:'#166534',pending:'#92400E',closed:'#94A3B8'};
const refundPolicy = 'Full refund if rejected, missed, or cancelled before approval. Scheduled dates use UTC.';
const reviewPolicy = 'The fee pays for manual review. Approval is discretionary and rejected applications are non-refundable.';
const verifiedCredits = 'Paid activities use Credits. Verified ad rewards appear after confirmation.';

export function useDailyCode(active:boolean):DailyEntry {
  const [day,setDay]=useState(utcDate);
  const [live,setLive]=useState<DailyEntry|null>(null);
  useEffect(()=>{
    if(!active)return;
    const refresh=()=>setDay(utcDate());
    refresh();
    const timer=setInterval(refresh,15_000);
    const foreground=AppState.addEventListener('change',state=>{if(state==='active')refresh();});
    return ()=>{clearInterval(timer);foreground.remove();};
  },[active]);
  useEffect(()=>{
    if(!active)return;
    return watchDaily(day,setLive);
  },[active,day]);
  const fallback=useMemo(()=>dailyTerm(day),[day]);
  return live?.date===day?live:{term:fallback.expression,meaning:fallback.meaning,category:fallback.category,date:day};
}

export function DailyCodeBanner({entry,compact=false,onApply}:{entry:DailyEntry;compact?:boolean;onApply?:()=>void}) {
  return <LiquidHero style={[s.hero,compact&&s.compactHero]}>
    <View style={s.row}><Icon name="calendar-outline" color="#BCDEFF" size={19}/><Text style={s.eyebrow}>DAILY CODE</Text><Text style={s.date}>{entry.date} UTC</Text></View>
    <Text accessibilityRole="header" selectable style={[s.word,compact&&s.compactWord]}>{entry.term}</Text>
    <Text selectable style={s.meaning}>{entry.meaning}</Text>
    <View style={[s.row,{justifyContent:'space-between',flexWrap:'wrap'}]}>
      <Text style={s.category}>{entry.category}</Text>
      {onApply&&<Pressable accessibilityRole="button" accessibilityLabel="Apply for Daily Code" onPress={onApply} style={s.apply}>
        <Text style={s.applyText}>Apply</Text><Icon name="chevron-forward" size={15} color="#fff"/>
      </Pressable>}
    </View>
  </LiquidHero>;
}
export function Status({status}:{status:string}) {
  const good=['approved','published','accepted'].includes(status);
  const bad=['rejected','cancelled','revoked','removed'].includes(status);
  return <Text style={[s.status,good?s.good:bad?s.bad:s.wait]}>{status.charAt(0).toUpperCase()+status.slice(1)}</Text>;
}

export function useContributionData(collection:string,uid?:string) {
  const [rows,setRows]=useState<FeatureRow[]>([]);
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(!!uid);
  const [epoch,reload]=useState(0);
  useEffect(()=>{
    let current=true;
    if(!uid){setRows([]);setError('');setLoading(false);return;}
    setLoading(true);setError('');
    void myRows(collection,uid).then(data=>{if(current)setRows(data);},e=>{if(current)setError(errorOf(e));}).finally(()=>{if(current)setLoading(false);});
    return ()=>{current=false;};
  },[uid,collection,epoch]);
  return {rows,error,loading,reload:()=>reload(e=>e+1)};
}

export function useEligibleBalance(uid?:string) {
  const [balance,setBalance]=useState<number|null>(null),[error,setError]=useState('');
  const [epoch,setEpoch]=useState(0);
  const lastUid=useRef(uid);
  useEffect(()=>{
    let current=true;
    // Keep showing the last confirmed balance while refreshing; reset only when the account changes.
    if(lastUid.current!==uid){lastUid.current=uid;setBalance(null);}
    setError('');
    if(uid&&BACKEND_URL) void feature('balance').then(r=>{
      const balance=r.balance;
      if(typeof balance!=='number'||!Number.isSafeInteger(balance)||balance<0)throw new Error('Account credits could not be confirmed. Please retry.');
      if(current)setBalance(balance);
    }).catch(e=>{if(current)setError(errorOf(e));});
    return ()=>{current=false;};
  },[uid,epoch]);
  useEffect(()=>{
    if(!uid||!BACKEND_URL)return;
    return onSnapshot(query(collection(cloudDbLive(),'users',uid,'tokenLedger'),orderBy('createdAt','desc'),limit(1)),()=>setEpoch(e=>e+1),()=>{});
  },[uid]);
  return {balance,error,reload:()=>setEpoch(e=>e+1),setBalance};
}

/** Why a paid action can't be confirmed yet, in the order the user should fix them. */
export function feeBlockers({fee,balance,missing=[]}:{fee:number;balance:number|null;missing?:string[]}):string[]{
  const reasons=[...missing];
  if(balance===null)reasons.push('Checking your Credit balance…');
  else if(balance<fee)reasons.push(`You need ${money(fee-balance)} more Credits.`);
  return reasons;
}
export function ConfirmFee({fee,balance,summary,onConfirm,disabled=false,missing=[],onGetCredits}:{fee:number;balance:number|null;summary:string;onConfirm:()=>void;disabled?:boolean;missing?:string[];onGetCredits?:()=>void}) {
  const blockers=feeBlockers({fee,balance,missing});
  const short=balance!==null&&balance<fee;
  return <>
    <View style={s.fee}><Icon name="wallet-outline" size={20} color={C.goldDeep}/><Text style={s.label}>Cost: {money(fee)} Credits</Text></View>
    <Text style={s.body}>{balance===null?'Checking your Credit balance…':`Credit balance: ${money(balance)}${balance>=fee?` · ${money(balance-fee)} left after this`:''}`}</Text>
    {blockers.length>0&&<View style={s.blockers} accessibilityLiveRegion="polite">{blockers.map(b=><View key={b} style={s.row}><Icon name="alert-circle-outline" size={16} color="#B45309"/><Text style={[s.body,{flex:1,color:'#7C4A03'}]}>{b}</Text></View>)}</View>}
    {short&&onGetCredits&&<Button light title="Get Credits" icon="add-circle-outline" onPress={onGetCredits}/>}
    <Button title={`Confirm · ${money(fee)} Credits`} icon="checkmark-circle-outline" disabled={disabled||blockers.length>0}
      onPress={()=>confirmAction('Confirm Credit payment',`${summary}\n\nPay ${money(fee)} Credits. Your balance after payment will be ${money(Math.max(0,(balance??0)-fee))}.`,onConfirm,'Pay Credits')}/>
  </>;
}

function RowHistory({rows,kind,cancel}:{rows:FeatureRow[];kind:'daily'|'posts'|'verification';cancel?:(row:FeatureRow)=>void}) {
  const [filter,setFilter]=useState('all');
  const filters=kind==='daily'?['all','pending','approved','scheduled','published','rejected']:kind==='posts'?['all','pending','approved','rejected']:['all'];
  const filtered=rows.filter(row=>filter==='all'||row.status===filter);
  return <>
    {filters.length>1&&<View style={s.wrap}>{filters.map(f=><Chip key={f} label={f.charAt(0).toUpperCase()+f.slice(1)} selected={f===filter} onPress={()=>setFilter(f)}/>)}</View>}
    {!filtered.length&&<Text style={s.body}>No matching submissions.</Text>}
    {filtered.map(row=><Glass key={row.id}>
      <View style={s.row}><Text style={[s.label,{flex:1}]}>{row.term??(kind==='verification'?'Verified Badge application':row.text??'Community post')}</Text><Status status={row.status}/></View>
      {!!row.meaning&&<Text style={s.body}>{row.meaning}</Text>}
      <Text style={s.body}>{ms(row.createdAt)>0?new Date(ms(row.createdAt)).toLocaleDateString():''}{row.fee? ` · ${money(row.fee)} Credits · ${row.payment}`:''}</Text>
      {kind==='daily'&&<Text style={s.body}>Requested {row.requestedDate??'—'} · Confirmed {row.publicationDate??'—'} UTC</Text>}
      {!!row.reason&&<Text style={s.body}>{row.reason}</Text>}
      {cancel&&kind==='daily'&&row.status==='pending'&&<Button light title="Cancel and refund" icon="close-circle-outline" onPress={()=>confirmAction('Cancel this application?',`Your ${policy.dailyFee} Credits will be refunded.`,()=>cancel(row))}/>}
      {cancel&&kind==='posts'&&['pending','approved'].includes(row.status)&&<Button light title="Remove my post" icon="trash-outline" onPress={()=>confirmAction('Remove this post?', SPARK_MODE?'Remove this free post?':'The post fee is non-refundable.',()=>cancel(row))}/>}
    </Glass>)}
  </>;
}

export function ContributionScreen({mode,onSignIn,onSuggest,onGetCredits}:{mode:'daily-apply'|'daily-history'|'verification'|'my-posts';onSignIn:()=>void;onSuggest:()=>void;onGetCredits?:()=>void}) {
  const user=useAccountUser(), uid=user?.uid, phase=useAuthPhase();
  const kind=mode.startsWith('daily')?'daily':mode==='my-posts'?'posts':'verification';
  const collection=mode==='daily-apply'?'dailyCodeApplications':kind==='daily'?'dailyCodeApplications':kind==='posts'?'communityPosts':'verificationApplications';
  const data=useContributionData(collection,uid);
  const paid=mode==='daily-apply'||mode==='verification';
  const credits=useEligibleBalance(paid?uid:undefined);
  const [word,setWord]=useState(''),[day,setDay]=useState(''),[calendar,setCalendar]=useState<Record<string,string>>({}),[calendarReady,setCalendarReady]=useState(false);
  const [month,setMonth]=useState('');
  const [msg,setMsg]=useState(''),[busy,setBusy]=useState(false);
  const lock=useRef(false), key=useRef(requestKey());
  const today=utcDate(), dates=[today,...datesAhead()], rangeStart=today, rangeEnd=dates.at(-1)!;
  const months=[...new Set(dates.map(d=>d.slice(0,7)))];
  const [search,setSearch]=useState('');
  const [revision,setRevision]=useState(contentRevision);
  useEffect(()=>{if(mode!=='daily-apply')return;void refreshCommunity(true);return onContentChange(()=>setRevision(contentRevision));},[mode]);
  const bundledIds=useMemo(()=>new Set(bundledTerms.map(t=>t.id)),[]);
  const approved=useMemo(()=>terms.filter(t=>t.sensitivity==='None').map(t=>({id:t.id,term:t.expression,meaning:t.meaning,category:t.category,wordSource:t.status==='Community'?'community':bundledIds.has(t.id)?'bundled':'published'})),[revision,bundledIds]);
  const matches=approved.filter(r=>r.term.toLowerCase().includes(search.trim().toLowerCase())).slice(0,search.trim()?20:0);
  const selected=approved.find(r=>r.id===word);
  // An exact search match is selected automatically, so the user isn't left with a
  // disabled Confirm button and no idea that a word chip had to be tapped.
  useEffect(()=>{
    const q=search.trim().toLowerCase();if(!q)return;
    const exact=matches.filter(r=>r.term.toLowerCase()===q);
    if(exact.length===1&&word!==exact[0]!.id){setWord(exact[0]!.id);key.current=requestKey();}
  },[search,matches.length]);
  const reloadDates=()=>{
    setCalendarReady(false);
    return slots(rangeStart,rangeEnd).then(rows=>{setCalendar(rows);setCalendarReady(true);});
  };
  useEffect(()=>{
    if(mode!=='daily-apply'||!uid)return;
    let current=true;
    void slots(rangeStart,rangeEnd).then(rows=>{if(current){setCalendar(rows);setCalendarReady(true);}},e=>{if(current)setMsg(errorOf(e));});
    return ()=>{current=false;};
  },[uid,mode,rangeStart,rangeEnd]);
  const badges=useBadges(mode==='verification'&&uid?[uid]:[]);
  const submit=async(action:string,fields:Record<string,unknown>)=>{
    if(lock.current)return;
    lock.current=true;setBusy(true);setMsg('');
    try {
      const result=await feature(action,{...fields,requestId:key.current});
      key.current=requestKey();
      if(typeof result.balance==='number')credits.setBalance(result.balance);
      else if(paid)credits.reload();
      setMsg(action==='cancel-daily'?'Application cancelled. Refund recorded in your Wallet.':action==='delete-post'?'Post removed.':'Application received. Your payment is recorded in your Wallet.');
      if(mode==='daily-apply'){setWord('');setDay('');await reloadDates();}
      data.reload();
    } catch(e){
      const next=(e as {details?:{next?:string}})?.details?.next;
      if(next){setDay(next);setMonth(next.slice(0,7));void reloadDates().catch(()=>{});}
      setMsg(errorOf(e)+(next?` Next available: ${next} UTC. Confirm again to reserve it.`:''));
    } finally {lock.current=false;setBusy(false);}
  };
  if(!uid&&phase==='restoring')return <Glass><Text style={s.label}>Checking your account…</Text><Text style={s.body}>Restoring your saved sign-in.</Text></Glass>;
  if(!uid)return <Glass><Text style={s.label}>Sign in to continue</Text><Button title="Sign in" onPress={onSignIn}/></Glass>;
  if(!BACKEND_URL&&(mode==='daily-apply'||mode==='verification'))return <Glass><Text style={s.label}>{mode==='verification'?'Verified Badge':'Daily Code'}</Text><Text style={s.body}>Credit services are not connected yet. Free contributions and games remain available.</Text></Glass>;
  return <>
    <SectionHeader title={mode==='daily-apply'?'Feature your word':mode==='daily-history'?'My Daily Code applications':mode==='my-posts'?'My posts':'Verified Badge'} eyebrow="GENZ CODEBOOK"/>
    {!!msg&&<Text accessibilityRole="alert" style={s.body}>{msg}</Text>}
    {!!data.error&&<Text accessibilityRole="alert" style={s.body}>{data.error}</Text>}
    {(data.loading||data.error)&&<Button light title={data.loading?'Loading…':'Retry'} disabled={data.loading} onPress={()=>data.reload()}/>}
    {mode==='daily-apply'?<>
      <Text style={s.body}>Choose a word from Codes and an available date. Your word appears at the top of Home and Codes on that day.</Text>
      <Text style={s.step}>1 · Choose your word</Text>
      <TextInput accessibilityLabel="Search dictionary codes" placeholder="Search a word, e.g. HDOT" value={search} onChangeText={setSearch} autoCapitalize="none" autoCorrect={false} style={{minHeight:44,borderWidth:1,borderColor:C.line,borderRadius:12,padding:10,color:C.ink,backgroundColor:'#fff'}}/>
      {!!search.trim()&&!matches.length&&<Text style={s.body}>No matching code. Try a different spelling, or create it first from Codes.</Text>}
      {!!matches.length&&<Text style={s.fine}>Tap a word to select it.</Text>}
      <View style={s.wrap}>{matches.map(r=><Chip key={r.id} label={(word===r.id?'✓ ':'')+r.term} selected={word===r.id} onPress={()=>{setWord(r.id);key.current=requestKey();}}/>)}</View>
      {selected&&<Glass><View style={s.row}><Icon name="checkmark-circle" size={20} color="#16A34A"/><Text style={[s.label,{flex:1}]}>{selected.term} · {selected.category}</Text><Pressable accessibilityRole="button" accessibilityLabel="Change word" onPress={()=>setWord('')}><Text style={s.link}>Change</Text></Pressable></View><Text style={s.body}>{selected.meaning}</Text></Glass>}
      <Text style={s.step}>2 · Choose a date (UTC)</Text>
      {!calendarReady&&<Button light title="Load available dates" onPress={()=>void reloadDates().catch(e=>setMsg(errorOf(e)))}/>}
      {calendarReady&&<>
        <View style={s.wrap}>{months.map(m=><Chip key={m} label={m} selected={(month||months[0])===m} onPress={()=>setMonth(m)}/>)}</View>
        <View style={s.calendar}>{dates.filter(d=>d.startsWith(month||months[0]!)).map(d=>{
          const state=slotState(calendar[d],d===today);
          return <Pressable key={d} accessibilityRole="button" accessibilityLabel={`${d} ${slotLabel[state]}`} accessibilityState={{selected:day===d,disabled:state!=='open'}} disabled={state!=='open'} onPress={()=>{setDay(d);key.current=requestKey();}} style={[s.day,dayStyle[state],day===d&&{backgroundColor:C.accent,borderColor:C.accent}]}>
            <Text style={{fontWeight:'800',color:day===d?'#fff':dayText[state]}}>{d.slice(-2)}</Text>
          </Pressable>;})}</View>
        <View style={[s.wrap,{gap:12}]}>{(['open','reserved','pending','closed'] as SlotState[]).map(k=><View key={k} style={s.row}><View style={[s.dot,dayStyle[k]]}/><Text style={s.fine}>{slotLabel[k]}</Text></View>)}</View>
      </>}
      <Text style={s.body}>{day? `Selected date: ${day} UTC`:'Select an available date.'}</Text>
      <Text style={s.fine}>{refundPolicy}</Text>
      {!!credits.error&&<Button light title="Retry balance check" onPress={credits.reload}/>}
      <ConfirmFee fee={policy.dailyFee} balance={credits.balance} onGetCredits={onGetCredits} summary={`Apply to feature “${selected?.term??''}” on ${day} UTC. ${refundPolicy}`}
        missing={[...(!selected?['Choose a word in step 1.']:[]),...(!calendarReady?['Load the available dates.']:!day?['Choose a date in step 2.']:calendar[day]?['That date is already taken. Choose another date.']:[])]}
        disabled={busy} onConfirm={()=>void submit('apply-daily',{wordId:word,wordSource:selected?.wordSource,date:day})}/>
    </>:<>
      {mode==='verification'&&<Glass>
        <View style={s.row}><Text style={s.label}>Verified Badge</Text><VerifiedBadge verified={badges.has(uid)}/></View>
        <View style={s.row}><Text style={s.label}>Preview · KBR</Text><VerifiedBadge verified/></View>
        <Text style={s.body}>{reviewPolicy}</Text>
        {!!credits.error&&<Text style={s.body}>{credits.error}</Text>}
        {!data.loading&&!data.error&&!data.rows.some(r=>['pending','approved'].includes(r.status))&&
          <ConfirmFee fee={policy.verificationFee} balance={credits.balance} summary={reviewPolicy} disabled={busy} onConfirm={()=>void submit('apply-verification',{})}/>}
      </Glass>}
      <Button light title="Refresh status" onPress={data.reload} disabled={data.loading||busy}/>
      <RowHistory rows={data.rows} kind={kind} cancel={mode==='daily-history'?r=>void submit('cancel-daily',{id:r.id}):mode==='my-posts'?r=>void submit('delete-post',{id:r.id}):undefined}/>
    </>}
  </>;
}

const s=StyleSheet.create({
  calendar:{flexDirection:'row',flexWrap:'wrap',gap:5},day:{width:'12.8%',minHeight:38,borderWidth:1,borderColor:C.line,borderRadius:9,alignItems:'center',justifyContent:'center',backgroundColor:'#fff'},
  hero:{padding:16,borderRadius:21,gap:8},compactHero:{padding:11,borderRadius:16,gap:3},compactWord:{fontSize:23},
  apply:{minHeight:42,paddingHorizontal:8,flexDirection:'row',alignItems:'center',gap:4},applyText:{fontSize:13,fontWeight:'800',color:'#fff'},row:{flexDirection:'row',alignItems:'center',gap:8},wrap:{flexDirection:'row',flexWrap:'wrap',gap:8},
  eyebrow:{fontSize:12,letterSpacing:1.4,fontWeight:'900',color:'#E0E9FF',flex:1},
  date:{color:'#E0E9FF',fontSize:11},word:{fontSize:34,fontWeight:'900',color:'#fff'},meaning:{fontSize:16,lineHeight:23,color:'#fff'},
  category:{alignSelf:'flex-start',borderRadius:12,paddingHorizontal:10,paddingVertical:5,color:'#19234B',backgroundColor:'#DFE7FF',fontWeight:'800'},
  label:{fontSize:16,fontWeight:'800',color:C.ink},body:{fontSize:14,lineHeight:20,color:C.muted},fee:{backgroundColor:'#FFF0C7',borderRadius:13,padding:12,flexDirection:'row',alignItems:'center',gap:8},
  unavailable:{backgroundColor:'#E8EDF7',borderRadius:12,padding:9,justifyContent:'center'},status:{paddingHorizontal:8,paddingVertical:4,borderRadius:10,fontSize:12,fontWeight:'800',overflow:'hidden'},
  good:{color:'#09583E',backgroundColor:'#DDF6EA'},bad:{color:'#8E2634',backgroundColor:'#FEE5EB'},wait:{color:'#73501A',backgroundColor:'#FFF0CD'},
  step:{fontSize:15,fontWeight:'900',color:C.ink,marginTop:4},fine:{fontSize:12.5,lineHeight:17,color:C.muted},link:{fontWeight:'800',color:C.accent},
  dot:{width:14,height:14,borderRadius:5,borderWidth:1},blockers:{backgroundColor:'#FFF7E6',borderRadius:12,padding:10,gap:6,borderWidth:1,borderColor:'#FCD9A0'},
});
