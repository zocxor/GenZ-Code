/**
 * V7 top header (reference: GenZ_Codebook_App_Header.png).
 * One row that never wraps or overlaps: brand mark + wordmark (+ tagline on wider
 * phones), gold Credit balance pill, blue "Ad +10" pill, notifications bell and the
 * profile avatar with a gradient ring. Signed out, the avatar opens sign-in (no extra
 * button that pushes the row onto two lines). While Firebase is restoring the saved
 * session, the Credit pill shows a placeholder instead of a wrong number.
 */
import React,{useEffect,useRef} from 'react';
import {Animated,Image,Pressable,StyleSheet,Text,View,useWindowDimensions} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C,Icon} from './ui';
import AdRewardButton from './AdRewardButton';
import type {AuthPhase} from './services';

export default function AppHeader({phase,credits,caption,avatar,onCredits,onNotifications,onProfile,onSignIn,reduceMotion}:{
  phase:AuthPhase;credits:number|null;caption?:string;avatar:React.ReactNode;
  onCredits:()=>void;onNotifications:()=>void;onProfile:()=>void;onSignIn:()=>void;reduceMotion:boolean;
}){
  const width=useWindowDimensions().width;
  const roomy=width>=400,tight=width<370;
  // Small "pop" when the balance changes (native driver, no layout work).
  const scale=useRef(new Animated.Value(1)).current,previous=useRef(credits);
  useEffect(()=>{
    if(reduceMotion||previous.current===credits||previous.current===null||credits===null){previous.current=credits;return;}
    previous.current=credits;
    const a=Animated.sequence([Animated.timing(scale,{toValue:1.08,duration:110,useNativeDriver:true}),Animated.spring(scale,{toValue:1,useNativeDriver:true,friction:5})]);
    a.start();return()=>a.stop();
  },[credits,reduceMotion,scale]);
  const signedIn=phase==='signed-in';
  const creditText=phase==='restoring'?'…':signedIn?(credits===null?'—':compact(credits)):'0';
  return <View style={s.bar}>
    <View style={s.brand}>
      <Image source={require('../assets/brand/genz-code-mark.png')} resizeMode="contain" accessibilityIgnoresInvertColors accessible={false} style={{width:tight?30:36,height:tight?30:36}}/>
      {roomy&&<View style={s.divider}/>}
      <View style={{flexShrink:1,minWidth:0}}>
        <Text accessibilityRole="header" numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.75} style={[s.name,tight&&{fontSize:15}]}>GenZ <Text style={{color:'#1FA8F5'}}>Codebook</Text></Text>
        {roomy?<Text numberOfLines={1} style={s.tagline}>CODE • SLANG • GENZ TERMS</Text>:!!caption&&!tight&&<Text numberOfLines={1} style={s.caption}>{caption}</Text>}
      </View>
    </View>
    <Pressable accessibilityRole="button" accessibilityLabel={signedIn?`Credit balance ${credits??'unavailable'}. Open wallet.`:phase==='restoring'?'Checking your account':'Sign in to use Credits'} hitSlop={4}
      onPress={signedIn?onCredits:phase==='signed-out'?onSignIn:undefined} style={({pressed})=>pressed&&{opacity:.85}}>
      <Animated.View style={{transform:[{scale}]}}>
        <LinearGradient colors={['#FFE27A','#FFC23A','#F59E0B']} start={{x:0,y:0}} end={{x:1,y:1}} style={s.credit}>
          <Icon name="star" size={17} color="#B45309"/>
          <Text numberOfLines={1} style={s.creditText}>{creditText}</Text>
        </LinearGradient>
      </Animated.View>
    </Pressable>
    <AdRewardButton variant="pill" compact={!roomy}/>
    <Pressable accessibilityRole="button" accessibilityLabel="Notifications" hitSlop={4} onPress={onNotifications} style={({pressed})=>[s.bell,pressed&&{opacity:.8}]}>
      <Icon name="notifications-outline" size={20} color={C.accent}/>
    </Pressable>
    <Pressable accessibilityRole="button" accessibilityLabel={signedIn?'Your profile':phase==='restoring'?'Checking your account':'Sign in or create an account'} hitSlop={4}
      onPress={phase==='signed-out'?onSignIn:onProfile}>
      <LinearGradient colors={['#22D3EE','#6366F1','#C026D3']} start={{x:0,y:0}} end={{x:1,y:1}} style={s.ring}>
        <View style={s.ringInner}>{phase==='signed-out'?<Icon name="person" size={18} color={C.accent}/>:avatar}</View>
      </LinearGradient>
    </Pressable>
  </View>;
}
const compact=(n:number)=>n>=100000?Math.floor(n/1000)+'k':n.toLocaleString();
const s=StyleSheet.create({
  bar:{flexDirection:'row',alignItems:'center',gap:6,paddingHorizontal:12,paddingTop:6,paddingBottom:8},
  brand:{flex:1,minWidth:0,flexDirection:'row',alignItems:'center',gap:6},
  divider:{width:1,height:30,backgroundColor:'#CBD5E1',marginHorizontal:2},
  name:{fontSize:17,fontWeight:'900',color:'#16135C',letterSpacing:-.2},
  tagline:{fontSize:9,fontWeight:'700',letterSpacing:1.2,color:'#64748B',marginTop:1},
  caption:{fontSize:11,color:C.muted,marginTop:1},
  credit:{height:36,minWidth:56,paddingHorizontal:10,borderRadius:18,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:4,borderWidth:1,borderColor:'rgba(255,255,255,.6)'},
  creditText:{fontSize:14.5,fontWeight:'900',color:'#5B3500'},
  bell:{width:36,height:36,borderRadius:12,backgroundColor:'#fff',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#E2E8F5'},
  ring:{width:40,height:40,borderRadius:20,padding:2},
  ringInner:{flex:1,borderRadius:18,backgroundColor:'#fff',alignItems:'center',justifyContent:'center',overflow:'hidden'},
});
