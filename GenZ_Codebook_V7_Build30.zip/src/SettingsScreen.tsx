/**
 * Settings: only rows that do something real.
 *
 * Account opens the account sheet, language changes the dictionary language
 * (the same LANGUAGES list and setLanguage action the Words tab uses),
 * Privacy & Security opens Threat Shield, Help & Support opens the feedback
 * form, Rate the App opens the real Play Store listing, and About opens the
 * About page. There is deliberately NO notifications toggle or any other
 * setting with no real effect behind it.
 */
import React from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet, Linking} from 'react-native';
import FollowUs from './FollowUs';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Button, Chip, FadeIn, Icon, IconName, IconTile, SectionHeader} from './ui';
import {LANGUAGES} from './profile';

const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.genzmode.app';

export default function SettingsScreen({onClose, onOpen, onAccount, onOpenAbout, signedInEmail, language, onLanguageChange}: {
  onClose: () => void;
  onOpen: (sheet: 'login' | 'privacy' | 'feedback') => void;
  onAccount: (mode: 'signin' | 'create') => void;
  onOpenAbout: () => void;
  signedInEmail: string | null;
  language: string;
  onLanguageChange: (language: string) => void;
}) {
  return (
    <ScrollView contentContainerStyle={s.content}>
      <FadeIn>
        <LinearGradient colors={[C.navy, '#1E2A6B', C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.hero}>
          <Text style={s.heroEyebrow}>SETTINGS</Text>
          <Text style={s.heroTitle}>Settings</Text>
          <Text style={s.heroSub}>Your preferences, all in one place.</Text>
          {signedInEmail ? (
            <View style={s.heroBadge}>
              <View style={s.heroDot} />
              <Text style={s.heroBadgeText} numberOfLines={1}>Signed in as {signedInEmail}</Text>
            </View>
          ) : (
            <View style={s.heroBadge}>
              <Icon name="person-outline" size={14} color="#fff" />
              <Text style={s.heroBadgeText}>Not signed in yet</Text>
            </View>
          )}
        </LinearGradient>
      </FadeIn>

      <FadeIn delay={60}>
        <SectionHeader eyebrow="ACCOUNT" title="Your account" />
        <View style={s.group}>
          <Row icon="person-circle-outline" tileFrom={C.accent} tileTo={C.purple} title="Account" description={signedInEmail ? `Signed in as ${signedInEmail}` : 'Sign in or create an account'} badge={signedInEmail ? 'Signed in' : undefined} onPress={() => (signedInEmail ? onOpen('login') : onAccount('signin'))} last />
        </View>
      </FadeIn>

      <FadeIn delay={120}>
        <SectionHeader eyebrow="PREFERENCES" title="Dictionary language" />
        <View style={s.group}>
          <View style={s.pad}>
            <View style={s.wrap}>
              {LANGUAGES.map(l => <Chip key={l} label={l} selected={language === l} onPress={() => onLanguageChange(l)} />)}
            </View>
          </View>
        </View>
      </FadeIn>

      <FadeIn delay={180}>
        <SectionHeader eyebrow="SUPPORT" title="Help & security" />
        <View style={s.group}>
          <Row icon="shield-checkmark-outline" tileFrom={C.accent} tileTo="#2E9BFF" title="Privacy & Security" description="Your data and Threat Shield" onPress={() => onOpen('privacy')} />
          <Row icon="chatbubble-ellipses-outline" tileFrom={C.purple} tileTo="#9B7BFF" title="Help & Support" description="FAQs and contact us" onPress={() => onOpen('feedback')} />
          <Row icon="star-outline" tileFrom={C.gold} tileTo="#F5C94C" title="Rate the App" description="On Google Play" onPress={() => void Linking.openURL(PLAY_STORE_URL).catch(() => {})} last />
        </View>
      </FadeIn>

      <FadeIn delay={210}>
        <FollowUs />
      </FadeIn>

      <FadeIn delay={240}>
        <SectionHeader eyebrow="ABOUT" title="About the app" />
        <View style={s.group}>
          <Row icon="information-circle-outline" tileFrom={C.navy} tileTo={C.accent} title="About" description="Version, terms and licences" onPress={onOpenAbout} last />
        </View>
      </FadeIn>

      <Text style={s.fine}>Learning stays on this device unless you sign in to back it up.</Text>
      <Button title="Done" icon="checkmark-outline" onPress={onClose} />
    </ScrollView>
  );
}

function Row({icon, tileFrom, tileTo, title, description, badge, onPress, last}: {icon: IconName; tileFrom: string; tileTo: string; title: string; description: string; badge?: string; onPress: () => void; last?: boolean}) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={({pressed}) => [s.settingRow, last && {borderBottomWidth: 0}, pressed && {opacity: 0.7, backgroundColor: C.soft}]}>
      <IconTile icon={icon} from={tileFrom} to={tileTo} size={44} iconSize={22} />
      <View style={{flex: 1, gap: 3}}>
        <View style={s.rowTitleWrap}>
          <Text style={s.rowTitle}>{title}</Text>
          {badge ? <View style={s.badge}><Text style={s.badgeText}>{badge}</Text></View> : null}
        </View>
        <Text style={s.caption} numberOfLines={1}>{description}</Text>
      </View>
      <Icon name="chevron-forward" size={17} color={C.muted} />
    </Pressable>
  );
}

const s = StyleSheet.create({
  content: {gap: 14, paddingBottom: 8},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  rowTitle: {fontSize: 16, fontWeight: '800', color: C.navy},
  rowTitleWrap: {flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap'},
  badge: {backgroundColor: '#DCFCE7', borderWidth: 1, borderColor: '#bbf7d0', borderRadius: 9, paddingHorizontal: 7, paddingVertical: 2},
  badgeText: {fontSize: 10, fontWeight: '800', color: C.success},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  hero: {borderRadius: 22, padding: 18, gap: 8, overflow: 'hidden', shadowColor: '#101A3A', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.25, shadowRadius: 16, elevation: 5},
  heroEyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.8, color: 'rgba(255,255,255,.75)'},
  heroTitle: {fontSize: 30, lineHeight: 35, fontWeight: '900', letterSpacing: -1, color: '#fff'},
  heroSub: {fontSize: 14, lineHeight: 20, color: 'rgba(255,255,255,.82)'},
  heroBadge: {flexDirection: 'row', alignItems: 'center', gap: 7, alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,.14)', borderWidth: 1, borderColor: 'rgba(255,255,255,.25)', borderRadius: 16, paddingVertical: 6, paddingHorizontal: 12, maxWidth: '100%'},
  heroDot: {width: 8, height: 8, borderRadius: 4, backgroundColor: '#4ade80'},
  heroBadgeText: {fontSize: 12, fontWeight: '700', color: '#fff', flexShrink: 1},
  group: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 20, marginTop: 8, paddingHorizontal: 6, paddingVertical: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.1, shadowRadius: 14, elevation: 3, overflow: 'hidden'},
  pad: {padding: 12, gap: 8},
  settingRow: {paddingVertical: 12, paddingHorizontal: 10, minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 13, borderBottomWidth: 1, borderBottomColor: '#e3eefb', borderRadius: 20},
});
