import {BACKEND_URL} from './backend';
import {useAccountUser} from './services';
import React,{useRef,useState} from 'react';
import {ActivityIndicator,Alert,Platform,Pressable,StyleSheet,Text} from 'react-native';
import {TOKENS} from '../shared/tokens';
import {watchRewardedAd} from './ads';
import {earnTokens} from './learning';
import {repository} from './services';
import {C,Icon} from './ui';
import {LinearGradient} from 'expo-linear-gradient';

/** variant 'pill' is the V7 header control (blue gradient "Ad +10"). */
export default function AdRewardButton({compact=false,variant='plain'}:{compact?:boolean;variant?:'plain'|'pill'}) {
  const user=useAccountUser(),accountReward=!!BACKEND_URL&&!!user;
  const [busy,setBusy]=useState(false);
  const pending=useRef(false);
  if(Platform.OS!=='android')return null;
  const watch=async()=>{
    if(pending.current)return;
    pending.current=true;
    setBusy(true);
    try {
      if(await watchRewardedAd()){
        if(!accountReward)await repository.mutate(earnTokens(TOKENS.REWARDED_AD));
        Alert.alert('Ad completed',accountReward?`+${TOKENS.REWARDED_AD} Credits will appear after secure ad verification.`:`+${TOKENS.REWARDED_AD} learning points for game level unlocks. Sign in to earn Credits.`);
      }else{
        Alert.alert('No reward yet','The ad may be unavailable or your daily allowance may be used. No reward was charged. Try again later.');
      }
    }catch{
      Alert.alert('Reward could not be saved','Your device balance could not be updated. Please try again later.');
    }finally{
      pending.current=false;
      setBusy(false);
    }
  };
  if(variant==='pill')return <Pressable accessibilityRole="button" accessibilityLabel={`Optional: watch an ad to earn ${TOKENS.REWARDED_AD} ${accountReward?'Credits':'points'}`}
    accessibilityState={{busy,disabled:busy}} disabled={busy} hitSlop={4} onPress={()=>void watch()} style={({pressed})=>[(pressed||busy)&&{opacity:.8,transform:[{scale:.97}]}]}>
    <LinearGradient colors={['#4D7BFF','#2F3BEA']} start={{x:0,y:0}} end={{x:1,y:1}} style={s.pill}>
      <Icon name={busy?'hourglass':'play-circle'} size={18} color="#fff"/>
      <Text numberOfLines={1} style={s.pillText}>{compact?`+${TOKENS.REWARDED_AD}`:`Ad +${TOKENS.REWARDED_AD}`}</Text>
    </LinearGradient>
  </Pressable>;
  return <Pressable accessibilityRole="button" accessibilityLabel={`Watch an ad to earn ${TOKENS.REWARDED_AD} ${accountReward?'Credits':'points'}`}
    accessibilityState={{busy,disabled:busy}} disabled={busy} onPress={()=>void watch()}
    style={({pressed})=>[s.button,compact&&s.compact,(pressed||busy)&&{opacity:.72}]}>
    {busy?<ActivityIndicator size="small" color={C.blue}/>:<Icon name="play-circle-outline" size={18} color={C.blue}/>}
    <Text numberOfLines={1} style={s.label}>{compact?`Ad +${TOKENS.REWARDED_AD}`:`Watch ad · +${TOKENS.REWARDED_AD} ${accountReward?'Credits':'points'}`}</Text>
  </Pressable>;
}

const s=StyleSheet.create({
  button:{flexDirection:'row',alignItems:'center',justifyContent:'center',alignSelf:'flex-start',gap:4,minHeight:44,paddingHorizontal:8,borderRadius:12,backgroundColor:C.soft,borderWidth:1,borderColor:C.line},
  compact:{paddingHorizontal:5},
  label:{fontSize:12,fontWeight:'800',color:C.blue},
  pill:{height:36,paddingHorizontal:10,borderRadius:18,flexDirection:'row',alignItems:'center',gap:4,borderWidth:1,borderColor:'rgba(255,255,255,.35)'},
  pillText:{fontSize:13.5,fontWeight:'900',color:'#fff'},
});
