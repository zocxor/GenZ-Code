/**
 * Owner-controlled public app settings (Firestore config/app), shared by every screen
 * through ONE realtime listener that starts when the first screen needs it.
 * - paidCommunity: when true, the chat day pass (30), posts (50) and new dictionary
 *   codes (150) are charged in Credits through the Cloud Function. The admin portal
 *   sets it after the backend is deployed and checked; Firestore rules enforce it too.
 * - encodeFreeDaily / encodeCreditCost: Encode Message limits (see encodeQuota.ts).
 */
import {useSyncExternalStore} from 'react';
import {publishingMode,type PublishingMode} from '../shared/publishing';

export type AppConfig = {loaded: boolean; error: boolean; raw: Record<string, unknown>; paidCommunity: boolean; encodeFreeDaily: number; encodeCreditCost: number};
const intIn = (v: unknown, min: number, max: number, fallback: number) => Number.isInteger(v) && (v as number) >= min && (v as number) <= max ? v as number : fallback;
export function parseAppConfig(raw: Record<string, unknown>, loaded = true, error = false): AppConfig {
  return {loaded, error, raw, paidCommunity: raw.paidCommunity === true, encodeFreeDaily: intIn(raw.encodeFreeDaily, 0, 1000, 10), encodeCreditCost: intIn(raw.encodeCreditCost, 0, 1000, 0)};
}
let current: AppConfig = parseAppConfig({}, false);
const listeners = new Set<() => void>();
let stop: (() => void) | null = null;
function start() {
  if (stop) return;
  stop = () => {};
  void Promise.all([import('firebase/firestore'), import('./firebase/app')]).then(([{doc, onSnapshot}, {cloudDbLive}]) => {
    stop = onSnapshot(doc(cloudDbLive(), 'config/app'), snap => {
      current = parseAppConfig(snap.data() ?? {});
      listeners.forEach(f => f());
    }, () => {current = {...current, loaded: false, error: true}; listeners.forEach(f => f());});
  }).catch(() => {current = {...current, error: true}; stop = null; listeners.forEach(f => f());});
}
function subscribe(fn: () => void) {listeners.add(fn); start(); return () => {listeners.delete(fn);};}
export const getAppConfig = () => current;
export const useAppConfig = () => useSyncExternalStore(subscribe, getAppConfig);
export function usePublishingModeFromConfig(kind: 'code' | 'post'): {mode: PublishingMode | null; error: string} {
  const c = useAppConfig();
  return {mode: c.loaded ? publishingMode(c.raw, kind) : null, error: c.error ? 'Publishing settings could not be loaded. Please reconnect.' : ''};
}
