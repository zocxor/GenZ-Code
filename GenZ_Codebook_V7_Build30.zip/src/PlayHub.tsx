import React,{useState} from 'react';
import {Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {C,Glass,Icon,IconTile,LiquidHero,ProgressBar,Chip} from './ui';
import {unlockedIn,type Stage} from './games';
import {QUIZ_CATEGORIES} from './profile';

type Props={xp:number;completed:number;stages:Stage[];best:Record<string,number>;unlockedLevels:string[];category:string;due:number;onCategory:(value:string)=>void;onQuiz:(category:string,daily?:boolean)=>void;onStart:(stage:Stage,available:boolean)=>void;onReview:()=>void};
export default function PlayHub({xp,completed,stages,best,unlockedLevels,category,due,onCategory,onQuiz,onStart,onReview}:Props){
  const [levelsOpen,setLevelsOpen]=useState(false);
  return <View style={s.stack}>
    <View style={s.between}><Text accessibilityRole="header" style={s.title}>Play & learn</Text><Text style={s.xp}>{xp.toLocaleString()} XP</Text></View>
    <Pressable accessibilityRole="button" accessibilityLabel="Start today's Quick Challenge" onPress={()=>onQuiz('All',true)}>
      <LiquidHero style={s.daily}><View style={s.between}><View style={{flex:1,gap:5}}><Text style={s.eyebrow}>DAILY FIVE</Text><Text style={s.dailyTitle}>Crack today’s codes</Text><Text style={s.dailyCaption}>Five questions. A fresh challenge.</Text></View><View style={s.play}><Icon name="play" color={C.navy} size={22}/></View></View></LiquidHero>
    </Pressable>
    <View style={s.modes}>
      {[{title:'Word Quiz',icon:'game-controller' as const,category},{title:'Meanings',icon:'chatbubbles' as const,category:'Chat'},{title:'Emoji',icon:'happy' as const,category:'Emoji'}].map(mode=><Pressable key={mode.title} accessibilityRole="button" accessibilityLabel={'Play '+mode.title} onPress={()=>onQuiz(mode.category)} style={s.mode}><IconTile icon={mode.icon} from={C.accent} to={C.purple} size={35} iconSize={18}/><Text style={s.modeText}>{mode.title}</Text></Pressable>)}
    </View>
    <View style={s.between}><Text style={s.section}>Choose a category</Text><Pressable accessibilityRole="button" accessibilityLabel="Shuffle a quiz" onPress={()=>onQuiz(category)} style={s.link}><Icon name="shuffle" color={C.accent} size={18}/><Text style={s.linkText}>Shuffle</Text></Pressable></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false}><View style={s.filters}>{QUIZ_CATEGORIES.map(value=><Chip key={value} label={value} selected={value===category} onPress={()=>onCategory(value)}/>)}</View></ScrollView>
    {due>0&&<Pressable accessibilityRole="button" onPress={onReview} style={s.review}><Icon name="repeat" color={C.accent}/><Text style={s.reviewText}>{due} codes ready to review</Text><Icon name="chevron-forward" color={C.accent} size={17}/></Pressable>}
    <Glass style={{padding:12,gap:8}}>
      <Pressable accessibilityRole="button" accessibilityState={{expanded:levelsOpen}} onPress={()=>setLevelsOpen(v=>!v)} style={s.between}><View><Text style={s.section}>Your learning path</Text><Text style={s.caption}>{completed} of {stages.length} levels played</Text></View><Icon name={levelsOpen?'chevron-up':'chevron-down'} color={C.accent}/></Pressable>
      <ProgressBar value={stages.length?completed/stages.length:0}/>
      {levelsOpen&&stages.map((stage,index)=>{const available=unlockedIn(stages,index,best,unlockedLevels);return <Pressable key={stage.id} accessibilityRole="button" onPress={()=>onStart(stage,available)} style={s.level}><IconTile icon={stage.icon} from={available?stage.color:'#8D9AB2'} to={available?C.purple:'#A6B0C3'} size={40} iconSize={17}/><View style={{flex:1}}><Text style={s.modeText}>{stage.name}</Text><Text style={s.caption}>Level {index+1} · {best[stage.id]===undefined?available?'Ready to play':'Pass the previous level':String(best[stage.id])+'% best'}</Text></View><Icon name={available?'play-circle-outline':'lock-closed-outline'} color={C.accent} size={22}/></Pressable>;})}
    </Glass>
  </View>;
}
const s=StyleSheet.create({stack:{gap:12},between:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:8},title:{fontSize:25,fontWeight:'900',color:C.navy},xp:{fontSize:13,fontWeight:'800',color:C.accent},daily:{padding:16,borderRadius:20},eyebrow:{fontSize:10,letterSpacing:1.5,color:'#CEE2FF',fontWeight:'800'},dailyTitle:{fontSize:21,fontWeight:'900',color:'#fff'},dailyCaption:{fontSize:12,color:'#E2EAFF'},play:{width:43,height:43,borderRadius:15,backgroundColor:'#fff',alignItems:'center',justifyContent:'center'},modes:{flexDirection:'row',gap:8},mode:{flex:1,gap:6,alignItems:'center',backgroundColor:'#fff',paddingVertical:12,borderRadius:15,borderWidth:1,borderColor:C.line},modeText:{fontSize:13,fontWeight:'800',color:C.navy},section:{fontSize:15,fontWeight:'800',color:C.navy},caption:{fontSize:11,lineHeight:16,color:C.muted},filters:{flexDirection:'row',gap:6},link:{flexDirection:'row',alignItems:'center',gap:4,minHeight:40},linkText:{fontSize:12,fontWeight:'800',color:C.accent},review:{flexDirection:'row',alignItems:'center',gap:7,padding:12,borderRadius:14,backgroundColor:'#E9EFFF'},reviewText:{flex:1,fontSize:13,fontWeight:'700',color:C.navy},level:{flexDirection:'row',gap:8,alignItems:'center',borderTopWidth:1,borderTopColor:C.line,paddingVertical:8}});
