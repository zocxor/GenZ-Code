import config from '../shared/backend.json';
const raw=process.env.EXPO_PUBLIC_BACKEND_URL??config.url;
export const BACKEND_URL=raw.replace(/\/+$/,'');
if(BACKEND_URL&&!/^https:\/\/[^\s/?#]+(?:\/api)?$/.test(BACKEND_URL))throw new Error('Configure a valid HTTPS backend origin.');
export const TOKEN_CHECKOUT_ENABLED=!!BACKEND_URL&&config.tokenPurchasesEnabled;
