import * as Auth from 'firebase/auth';
import type {Persistence} from 'firebase/auth';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {secureStorageKey} from './policy';
import {chunkedStorage} from './chunkedStorage';
type Storage={getItem:(key:string)=>Promise<string|null>;setItem:(key:string,value:string)=>Promise<void>;removeItem:(key:string)=>Promise<void>};
const secure={
 get:(key:string)=>SecureStore.getItemAsync(secureStorageKey(key)),
 set:(key:string,value:string)=>SecureStore.setItemAsync(secureStorageKey(key),value,{keychainAccessible:SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY}),
 del:(key:string)=>SecureStore.deleteItemAsync(secureStorageKey(key)),
};
const fallback={
 get:(key:string)=>AsyncStorage.getItem('genz.authfb.'+key),
 set:(key:string,value:string)=>AsyncStorage.setItem('genz.authfb.'+key,value),
 del:(key:string)=>AsyncStorage.removeItem('genz.authfb.'+key),
};
// Chunked so sessions larger than SecureStore's ~2 KB value limit survive restarts (see chunkedStorage.ts).
const storage:Storage=chunkedStorage(secure,fallback);
// Firebase exports this only under the React Native conditional entry point.
const native=Auth as typeof Auth&{getReactNativePersistence:(storage:Storage)=>Persistence};
export const persistence=native.getReactNativePersistence(storage);
