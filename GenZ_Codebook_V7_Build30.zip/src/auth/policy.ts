/** No raw server errors (which can include addresses or configuration) in UI/logs. */
export function accountError(error:unknown):string{
 const code=error&&typeof error==='object'&&'code' in error?String(error.code):'';
 switch(code){
 case 'auth/invalid-credential':case 'auth/user-not-found':case 'auth/wrong-password':return 'The email or password is incorrect.';
 case 'auth/invalid-email':return 'Enter a valid email address.';
 case 'auth/email-already-in-use':return 'Unable to create this account. Try signing in or resetting your password.';
 case 'auth/weak-password':case 'auth/password-does-not-meet-requirements':return 'Choose a stronger password that meets the project’s password policy.';
 case 'auth/too-many-requests':return 'Too many attempts. Please wait before trying again.';
 case 'auth/network-request-failed':return 'Couldn’t reach Firebase. Check your connection and try again. Offline learning still works.';
 case 'auth/operation-not-allowed':case 'auth/admin-restricted-operation':return 'Email/password sign-in must be enabled by the project owner in Firebase Authentication.';
 case 'auth/api-key-not-valid.-please-pass-a-valid-api-key.':case 'auth/invalid-api-key':case 'auth/app-not-authorized':case 'auth/configuration-not-found':return 'Firebase needs an owner configuration check. Confirm Authentication is initialized and this API key allows the app.';
 case 'auth/requires-recent-login':return 'Sign in again, then retry this action.';
 case 'auth/user-disabled':return 'This account is unavailable. Contact the app owner.';
 case 'genz/email-exists':return 'An account with this email already exists, so we switched to Sign in. Enter its password, or tap “Forgot password?”.';
 case 'genz/cloud-deletion-failed':return 'Couldn’t delete your cloud data, so nothing was deleted. Check your connection and try again.';
 case 'genz/auth-deletion-incomplete':return 'Your cloud learning data was deleted, but the sign-in account still exists. Sign in again and repeat deletion to finish.';
 default:return 'Couldn’t complete that action. Please retry. Your offline learning remains available.';
 }
}
export function validateCredentials(email:string,password:string,creating=false):string|null{
 if(email.trim().length>254||!/^\S+@\S+\.\S+$/.test(email.trim()))return 'Enter a valid email address.';
 if(!password)return 'Enter your password.';
 if(password.length>4096)return 'This password is too long.';
 if(creating&&password.length<12)return 'Use at least 12 characters for your new password.';
 return null;
}
/** Minimum length for a new password chosen from the change-password form. */
export const MIN_NEW_PASSWORD_LENGTH = 8;
/**
 * Change-password field validation. Returns per-field messages; an empty
 * object means the form is valid. The new password must be at least 8
 * characters, differ from the current one, and match its confirmation.
 */
export function validatePasswordChange(current:string,next:string,confirm:string):{current?:string;next?:string;confirm?:string}{
 const errors:{current?:string;next?:string;confirm?:string}={};
 if(!current)errors.current='Enter your current password.';
 if(next.length<MIN_NEW_PASSWORD_LENGTH)errors.next=`Use at least ${MIN_NEW_PASSWORD_LENGTH} characters for your new password.`;
 else if(next.length>4096)errors.next='This password is too long.';
 else if(current&&next===current)errors.next='Your new password must be different from your current password.';
 if(confirm!==next)errors.confirm='The new passwords do not match.';
 return errors;
}
/** True when the account has an email/password provider (a password exists to change). */
export function hasPasswordProvider(providerData:readonly {providerId:string}[]):boolean{
 return providerData.some(p=>p.providerId==='password');
}
/**
 * The one message shown after a password-reset request, whether or not the
 * address has an account — revealing the difference would let anyone probe
 * which email addresses are registered.
 */
export function passwordResetSentMessage(email:string):string{
 return `Reset link sent to ${email.trim()} — check your inbox (and spam folder).`;
}
/**
 * Firebase error codes that must not change the password-reset response:
 * the caller shows the generic "sent" message for these, so the response
 * never reveals whether the address has an account.
 */
export function isResetEnumerationError(code:string):boolean{
 return code==='auth/user-not-found';
}
export const secureStorageKey=(key:string)=>'genz.auth.'+[...key].map(c=>/^[a-zA-Z0-9]$/.test(c)?c:'_'+c.codePointAt(0)!.toString(16)+'_').join('');
