/**
 * Session storage for Firebase Auth on native.
 *
 * Why: expo-secure-store documents a ~2048-byte limit per value. A serialized Firebase
 * user (ID token, refresh token, provider data, photo URL) can exceed it, so some
 * sessions were not restored after the app restarted and signed-in users were asked to
 * sign in again. Values are now split into small encrypted chunks.
 *
 * Crash safety: chunks are written to the slot that is NOT currently active, then the
 * header ("a:3" = slot a, 3 chunks) is switched as the single commit point, then the
 * old slot is cleaned up. A crash mid-write leaves the previous session intact.
 *
 * Compatibility: sessions stored by earlier builds as one SecureStore value are still
 * read, and are migrated on the next write. If SecureStore itself fails (for example
 * the Android Keystore is unavailable), the value is kept in app-private AsyncStorage
 * (Firebase's default React Native persistence; Android backups are disabled for this
 * app) rather than silently signing the user out.
 */
export type KeyValue = {
  get: (key: string) => Promise<string | null>;
  set: (key: string, value: string) => Promise<void>;
  del: (key: string) => Promise<void>;
};

/** 600 UTF-16 units is at most 1,800 UTF-8 bytes, safely under the 2,048-byte limit. */
export const CHUNK = 600;
const MAX_CHUNKS = 64;
type Header = {slot: 'a' | 'b'; count: number};

function parseHeader(raw: string | null): Header | null {
  const m = raw ? /^([ab]):(\d{1,2})$/.exec(raw) : null;
  if (!m) return null;
  const count = Number(m[2]);
  return count >= 1 && count <= MAX_CHUNKS ? {slot: m[1] as 'a' | 'b', count} : null;
}
function split(value: string): string[] {
  const parts: string[] = [];
  for (let i = 0; i < value.length;) {
    // Never split a surrogate pair across chunks.
    let end = Math.min(value.length, i + CHUNK);
    const code = value.charCodeAt(end - 1);
    if (end < value.length && code >= 0xd800 && code <= 0xdbff) end--;
    parts.push(value.slice(i, end));
    i = end;
  }
  return parts.length ? parts : [''];
}
const range = (n: number) => Array.from({length: n}, (_, i) => i);

export function chunkedStorage(secure: KeyValue, fallback: KeyValue) {
  const head = (key: string) => key + '.h';
  const part = (key: string, slot: string, i: number) => `${key}.${slot}${i}`;
  const quiet = async (task: Promise<void>) => {try {await task;} catch {/* best effort cleanup */}};
  async function readHeader(key: string) {
    try {return parseHeader(await secure.get(head(key)));} catch {return null;}
  }
  async function dropSlot(key: string, h: Header | null) {
    if (h) await Promise.all(range(h.count).map(i => quiet(secure.del(part(key, h.slot, i)))));
  }
  return {
    async getItem(key: string): Promise<string | null> {
      try {
        const h = parseHeader(await secure.get(head(key)));
        if (h) {
          const parts = await Promise.all(range(h.count).map(i => secure.get(part(key, h.slot, i))));
          if (parts.every(p => p !== null)) return parts.join('');
        } else {
          const legacy = await secure.get(key);
          if (legacy !== null) return legacy;
        }
      } catch {/* fall through to the fallback copy */}
      try {return await fallback.get(key);} catch {return null;}
    },
    async setItem(key: string, value: string): Promise<void> {
      const previous = await readHeader(key);
      const slot: 'a' | 'b' = previous?.slot === 'a' ? 'b' : 'a';
      const parts = split(value);
      if (parts.length > MAX_CHUNKS) {await fallback.set(key, value); return;}
      try {
        for (const [i, chunk] of parts.entries()) await secure.set(part(key, slot, i), chunk);
        await secure.set(head(key), `${slot}:${parts.length}`);
      } catch {
        await fallback.set(key, value);
        return;
      }
      await dropSlot(key, previous);
      await quiet(secure.del(key));
      await quiet(fallback.del(key));
    },
    async removeItem(key: string): Promise<void> {
      const h = await readHeader(key);
      await quiet(secure.del(head(key)));
      await dropSlot(key, h);
      await quiet(secure.del(key));
      await quiet(fallback.del(key));
    },
  };
}
