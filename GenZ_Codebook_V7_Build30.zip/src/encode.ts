/**
 * Encode Message: plain text → Gen Z codes, using the GenZ Codebook dictionary.
 * - Case-insensitive, punctuation-insensitive phrase matching (up to 6 words), longest match first.
 * - Never joins words across punctuation, so "hello, how are you?" keeps its comma and question mark.
 * - Unmatched words stay exactly as typed.
 * - Conservative: a single everyday word is only replaced by a well-known code, so meaning
 *   isn't changed by obscure entries. Each replaced phrase carries alternative codes.
 * Runs on the device; nothing is sent to a server.
 */
import {terms, onContentChange, type Term} from './content';

export type EncodeSegment = {text: string; code?: string; phrase?: string; options?: string[]};
export type EncodeResult = {segments: EncodeSegment[]; output: string; replaced: number};
type Candidate = {code: string; score: number};

/** Everyday codes people actually type; preferred when the dictionary offers several. */
const POPULAR = new Set(['lol','brb','ttyl','tbh','idk','u','ur','r','thx','ty','yw','pls','plz','bc','omg','cu','2nite','<3','fr','np','rn','hru','hbu','wyd','wbu','ily','gn','gm','imo','imho','smh','ngl','btw','irl','nvm','l8r','gr8','b4','2day','tmrw','idc','jk','bff','afaik','fyi','asap','ikr','gtg','g2g','k','ok','ppl','msg','txt','abt','cuz','tho','w8','sry','gg','dm','lmk','hmu','omw','ofc','bday']);
const MAX_WORDS = 6;
const fold = (s: string) => s.toLowerCase().replace(/[’‘]/g, "'").replace(/[^\p{L}\p{N}' ]+/gu, ' ').replace(/\s+/g, ' ').trim();

function candidateFor(t: Term): Candidate | null {
  if (t.sensitivity !== 'None' || !t.expression || t.expression.length > 12) return null;
  const code = t.expression, lower = code.toLowerCase();
  let score = t.priority;
  if (POPULAR.has(lower)) score += 300;
  if (t.decode) score += 40;                 // round-trips through Decode
  if (t.language === 'English' || t.language === 'Universal') score += 60;
  if (t.category === 'Chat') score += 15;
  if (/^[a-z]{2,5}$/i.test(code)) score += 10;
  if (t.category === 'Emoji') score -= 30;   // keep text readable unless nothing else fits
  return {code, score};
}

type Index = Map<string, Candidate[]>;
let built: Index | null = null;
onContentChange(() => {built = null;});
function index(): Index {
  if (built) return built;
  const map: Index = new Map();
  for (const t of terms) {
    const c = candidateFor(t);
    if (!c) continue;
    // Meanings list alternatives with "/", ";" or "or". Commas stay: "I know, right?" is one meaning.
    for (const raw of t.full.split(/\s*[/;]\s*|\s+or\s+/)) {
      const key = fold(raw);
      if (!key || key.split(' ').length > MAX_WORDS || fold(t.expression) === key) continue;
      for (const k of new Set([key, key.replace(/ /g, '')])) {
        const list = map.get(k) ?? [];
        if (!list.some(x => x.code.toLowerCase() === c.code.toLowerCase())) list.push(c);
        map.set(k, list);
      }
    }
  }
  for (const list of map.values()) list.sort((a, b) => b.score - a.score || a.code.length - b.code.length);
  return built = map;
}

/** A phrase is replaced only if its best code is trustworthy enough for its length. */
const acceptable = (words: number, best: Candidate) => words > 1 ? best.score >= 80 : best.score >= 260;
/** Gen Z texting is lowercase; keep caps only when the user typed in caps. */
function styled(code: string, original: string) {
  if (!/[a-z]/i.test(code)) return code;
  return original.length > 1 && original === original.toUpperCase() && /[A-Z]/.test(original) ? code.toUpperCase() : code.toLowerCase();
}

/** @param choices optional per-phrase overrides (folded phrase → chosen code), from the alternatives UI. */
export function encode(message: string, choices: Readonly<Record<string, string>> = {}): EncodeResult {
  if (message.length > 2000) throw new RangeError('Message exceeds 2000 characters');
  const tokens = message.match(/[\p{L}\p{N}']+|[^\p{L}\p{N}']+/gu) ?? [];
  const map = index();
  const segments: EncodeSegment[] = [];
  let replaced = 0;
  for (let i = 0; i < tokens.length;) {
    const tok = tokens[i]!;
    if (!/[\p{L}\p{N}]/u.test(tok)) {segments.push({text: tok}); i++; continue;}
    let hit: {end: number; phrase: string; list: Candidate[]} | null = null;
    // Words i, i+2, i+4… separated only by plain spaces form a phrase.
    let words = 0, phraseText = '';
    for (let j = i; j < tokens.length && words < MAX_WORDS; j += 2) {
      const w = tokens[j]!;
      if (!/[\p{L}\p{N}]/u.test(w)) break;
      words++; phraseText = phraseText ? phraseText + ' ' + w : w;
      const key = fold(phraseText);
      const list = map.get(key) ?? map.get(key.replace(/ /g, ''));
      if (list?.length && acceptable(words, list[0]!)) hit = {end: j, phrase: key, list};
      const sep = tokens[j + 1];
      if (sep === undefined || !/^[ \t]+$/.test(sep)) break;
    }
    if (hit) {
      const original = tokens.slice(i, hit.end + 1).join('');
      const options = [...new Set(hit.list.slice(0, 5).map(c => styled(c.code, original)))];
      const chosen = choices[hit.phrase] && options.includes(choices[hit.phrase]!) ? choices[hit.phrase]! : options[0]!;
      segments.push({text: original, code: chosen, phrase: hit.phrase, options});
      replaced++;
      i = hit.end + 1;
    } else {segments.push({text: tok}); i++;}
  }
  return {segments, output: segments.map(s => s.code ?? s.text).join(''), replaced};
}
