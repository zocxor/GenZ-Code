import {usePublishingModeFromConfig} from './appConfig';
/** Posting mode for codes/posts. Shares the single config/app listener in appConfig.ts. */
export function usePublishingMode(kind:'code'|'post') {
  return usePublishingModeFromConfig(kind);
}
