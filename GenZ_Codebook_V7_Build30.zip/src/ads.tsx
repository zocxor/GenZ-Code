import {BACKEND_URL} from './backend';
import {SPARK_MODE} from '../shared/deployment';
/** AdMob: optional rewarded learning benefits and nonblocking natural-break
 * interstitials after three completed activities and at least two minutes.
 * No advertisements are triggered by opening a form or entering Community.
 * Unavailable ads never prevent normal app use. */
import {Platform} from 'react-native';
import {AdEventType, InterstitialAd, MobileAds, RewardedAd, RewardedAdEventType, TestIds} from 'react-native-google-mobile-ads';
import {accountAuth} from './firebase/app';
import {IS_DEV} from './secure/config';
const getRewardUserId=()=>accountAuth.currentUser?.uid;

export const ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074';
/** Rewarded unit (created in AdMob 2026-11-08). Pays only on the SDK's EARNED_REWARD callback; dev builds use Google's test rewarded ad. */
export const REWARDED_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4151797642';
/** Rewarded interstitial unit (created in AdMob 2026-11-08). NOT wired yet: the app has no RewardedInterstitialAd format code — it lands with a future 25-token "Watch Ad & Earn" button. Do not use it as a plain interstitial. */
export const REWARDED_INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/6311057124';
/** Interstitial unit (created in AdMob 2026-11-08). Full-screen ad, preloaded at boot and shown when opening Suggest/Community, at most once a minute. Never gates a feature. */
export const INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4760116398';
/** Minimum gap between two interstitial shows (120 seconds). */
export const INTERSTITIAL_COOLDOWN_MS = 120_000;

/** Interstitial ad unit ID: Google's test interstitial in dev; the real one in release builds. */
export function interstitialAdUnitId(): string | null {
  if (IS_DEV) return TestIds.INTERSTITIAL;
  return INTERSTITIAL_AD_UNIT_ID || null;
}

/** Rewarded ad unit ID: Google's test rewarded ad in dev; the real one in release builds, or null until one is created in AdMob. */
export function rewardedAdUnitId(): string | null {
  if (IS_DEV) return TestIds.REWARDED;
  return REWARDED_AD_UNIT_ID || null;
}

let adsStarted = false;
let adsDisabled = false;
let rewardedActive = false;
const adsDisabledListeners = new Set<(disabled: boolean) => void>();
/**
 * Premium (ad-free) switch. App.tsx sets this from the subscription
 * entitlement (users/{uid}/subscription/current). While it is on, no
 * interstitial is preloaded or shown. Rewarded ads stay available — they
 * are opt-in earning, not an interruption. Defaults to ads on; a failed
 * subscription read leaves ads on.
 */
export function setAdsDisabled(disabled: boolean): void {
  if (adsDisabled === disabled) return;
  adsDisabled = disabled;
  adsDisabledListeners.forEach(cb => {
    try {cb(disabled);} catch {/* ignore */}
  });
}
export function onAdsDisabledChange(cb: (disabled: boolean) => void): () => void {
  adsDisabledListeners.add(cb);
  return () => {adsDisabledListeners.delete(cb);};
}
export function isAdsDisabled(): boolean {
  return adsDisabled;
}

/** Initialise the SDK once, Android only, and preload one interstitial. Safe to call on every launch; a failure only means no ads. */
export function initAds(): void {
  if (adsStarted || Platform.OS !== 'android') return;
  adsStarted = true;
  void MobileAds().initialize().catch(() => undefined);
  preloadInterstitial();
}

/**
 * The preloaded interstitial, if any. A fresh instance is created per load:
 * once an interstitial is shown it cannot be shown again, so the CLOSED
 * listener clears it and preloads the next one.
 */
let interstitial: InterstitialAd | null = null;
let interstitialLoaded = false;
let lastInterstitialShownAt = 0;
let completedBreaks=0;

/**
 * Preload one interstitial so it is ready when the user opens Suggest or
 * Community. No-op when ads are disabled (Premium), when there is no unit
 * ID, or when one is already loaded or loading. A failed load simply leaves
 * nothing ready — the next launch (or the next close) retries.
 */
export function preloadInterstitial(): void {
  if (Platform.OS !== 'android' || adsDisabled) return;
  const unitId = interstitialAdUnitId();
  if (!unitId) return;
  if (interstitial) return;
  // Constructing the interstitial touches the native ads module. If that
  // module is not ready this throws synchronously — and preloadInterstitial
  // runs from a setTimeout / ad-event listener that no ErrorBoundary covers,
  // so a throw here kills the app process. Never throw: a failed preload
  // just means no interstitial is ready.
  let ad: InterstitialAd;
  try {
    ad = InterstitialAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
  } catch {
    interstitial = null;
    interstitialLoaded = false;
    return;
  }
  interstitial = ad;
  const unsubs: (() => void)[] = [];
  const clear = () => {
    for (const u of unsubs) {try {u();} catch {/* ignore */}}
    unsubs.length = 0;
  };
  unsubs.push(
    ad.addAdEventListener(AdEventType.LOADED, () => {interstitialLoaded = true;}),
    ad.addAdEventListener(AdEventType.CLOSED, () => {
      clear();
      interstitial = null;
      interstitialLoaded = false;
      preloadInterstitial();
    }),
    ad.addAdEventListener(AdEventType.ERROR, () => {
      clear();
      interstitial = null;
      interstitialLoaded = false;
    }),
  );
  try { ad.load(); } catch { interstitial = null; interstitialLoaded = false; }
}

/**
 * Show the preloaded interstitial, if one is ready and at least a minute
 * has passed since the last show. Fire-and-forget: it never blocks, never
 * awaits, and never gates the feature the user opened — when nothing is
 * ready, when ads are disabled (Premium), or inside the cooldown, it
 * silently does nothing and the feature proceeds as normal.
 */
export function showInterstitialIfReady(): void {
  if (Platform.OS !== 'android' || adsDisabled || rewardedActive) return;
  completedBreaks++;
  if(completedBreaks<3)return;
  if (Date.now() - lastInterstitialShownAt < INTERSTITIAL_COOLDOWN_MS) return;
  if (!interstitial || !interstitialLoaded) return;
  completedBreaks=0;
  lastInterstitialShownAt = Date.now();
  interstitialLoaded = false;
  try {interstitial.show();} catch {/* ignore */}
}

/**
 * Show one rewarded ad. Resolves true only when the user actually earned the
 * reward (watched to the end); closing early, an error, or no ad unit ID
 * resolves false and pays nothing. The caller credits the tokens.
 */
export async function watchRewardedAd(canShow:()=>boolean=()=>true,benefit:'tokens'|'hint'='tokens'): Promise<boolean> {
  if (Platform.OS !== 'android' || rewardedActive) return Promise.resolve(false);
  const unitId = rewardedAdUnitId();
  if (!unitId) return Promise.resolve(false);
  rewardedActive = true;
  let userId=BACKEND_URL?getRewardUserId():undefined,customData:string|undefined;
  if(userId){
    try{const result=await (await import('./communityFeatures')).feature('reward-intent');customData=result.id;}
    catch{if(benefit==='tokens'){rewardedActive=false;return false;}userId=undefined;}
  }
  if(!canShow()){rewardedActive=false;return false;}
  return new Promise(resolve => {
    let done = false;
    let earned = false;
    const unsubs: (() => void)[] = [];
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(loadTimeout);
      rewardedActive = false;
      for (const u of unsubs) {try {u();} catch {/* ignore */}}
      resolve(earned);
    };
    const loadTimeout = setTimeout(finish, 15_000);
    try {
      const ad = RewardedAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true,...(userId?{serverSideVerificationOptions:{userId,...(customData?{customData}:{})}}:{})});
      unsubs.push(ad.addAdEventListener(RewardedAdEventType.LOADED, () => {
        clearTimeout(loadTimeout);
        if(!canShow()){finish();return;}
        try {void ad.show().catch(finish);} catch {finish();}
      }));
      unsubs.push(ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => {earned = true;}));
      unsubs.push(ad.addAdEventListener(AdEventType.CLOSED, finish));
      unsubs.push(ad.addAdEventListener(AdEventType.ERROR, finish));
      ad.load();
    } catch {finish();}
  });
}
