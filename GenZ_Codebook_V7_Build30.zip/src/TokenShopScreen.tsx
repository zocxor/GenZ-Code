/** One-time token purchases. All live prices come from Google Play. */
import {SPARK_MODE} from '../shared/deployment';
import {TOKEN_CHECKOUT_ENABLED} from './backend';
import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {C,Button,Glass,LiquidHero,Icon,SectionHeader} from './ui';
import {useAccountUser} from './services';
import {buyTokens,getBillingProducts,getBillingStatus,isTokenPurchaseEnabled,onBillingEvent,retryBilling} from './billing';
import {TOKEN_PRODUCTS,type TokensState} from '../shared/tokens';
import policy from '../functions/src/communityPolicy.json';

export default function TokenShopScreen({tokens,onSignIn,onOpenWallet}:{
  tokens:TokensState;
  onSignIn:()=>void;
  onOpenWallet:()=>void;
}) {
  const user=useAccountUser();
  const [products,setProducts]=useState(getBillingProducts);
  const [status,setStatus]=useState(getBillingStatus);
  const [buying,setBuying]=useState<string|null>(null);
  const [retrying,setRetrying]=useState(false);
  const [message,setMessage]=useState('');
  const busy=useRef(false);
  const checkout=isTokenPurchaseEnabled();

  useEffect(()=>{
    const sync=()=>{setProducts(getBillingProducts());setStatus(getBillingStatus());};
    const stop=onBillingEvent(event=>{
      if(event.kind==='products'||event.kind==='unavailable'){sync();return;}
      if(event.kind==='restored'){setMessage(`${event.count} earlier purchases restored.`);return;}
      busy.current=false;
      setBuying(null);
      switch(event.kind){
        case 'credited':setMessage(`${event.tokens.toLocaleString()} Credits added to your wallet.`);break;
        case 'already-credited':setMessage('This purchase is already in your wallet.');break;
        case 'pending':setMessage('Payment is pending in Google Play.');break;
        case 'failed':setMessage(event.message);break;
        case 'cancelled':setMessage('Purchase cancelled.');break;
        case 'signin-required':setMessage('Sign in to buy Credits.');break;
      }
    });
    sync();
    return stop;
  },[]);

  const buy=async(productId:string)=>{
    if(busy.current||!checkout)return;
    busy.current=true;
    setMessage('');setBuying(productId);
    const result=await buyTokens(productId);
    if(!result.started){busy.current=false;setBuying(null);setMessage(result.error??'Could not start checkout.');}
  };
  const retry=async()=>{
    setRetrying(true);setMessage('');
    try {await retryBilling();setProducts(getBillingProducts());setStatus(getBillingStatus());}
    catch {setMessage('Could not refresh Google Play prices. Try again.');}
    finally {setRetrying(false);}
  };

  if(!TOKEN_CHECKOUT_ENABLED)return <Glass><Text style={s.sectionTitle}>Credit purchases are unavailable</Text><Text style={s.body}>Creation, posting and community chat are free. Checkout opens only after server verification is configured and tested. You can still earn learning points in games.</Text><Button light title="Open wallet" onPress={onOpenWallet}/></Glass>;
  return <ScrollView contentContainerStyle={s.content}>
    <LiquidHero style={s.hero}>
      <Text style={s.heroTitle}>Buy once. Use when you need.</Text>
      <Text style={s.heroBody}>Add Credits to your account and spend them on the features you choose.</Text>
      <Text style={s.heroBody}>Device balance · {tokens.balance.toLocaleString()} tokens</Text>
    </LiquidHero>
    <Glass>
      <Text style={s.sectionTitle}>What Credits cover</Text>
      <Text style={s.body}>Post review · {policy.postFee}    Daily Code · {policy.dailyFee}</Text>
      <Text style={s.body}>Contributor review · {policy.verificationFee.toLocaleString()}</Text>
      <Text style={s.body}>These three fees use eligible account credits.</Text>
    </Glass>
    <SectionHeader eyebrow="PAY ONCE" title="Credit packs"/>
    {!checkout ? <Text accessibilityLiveRegion="polite" style={s.notice}>Checkout is paused. You can browse the pack sizes below.</Text> :
      !status.loaded ? <Text style={s.body}>Loading Google Play prices…</Text> :
      !status.available ? <View style={s.notice}>
        <Text style={s.body}>{status.error??'Google Play billing is unavailable on this device.'}</Text>
        <Button light title={retrying?'Refreshing…':'Refresh prices'} disabled={retrying} onPress={()=>void retry()}/>
      </View> : null}
    {checkout&&status.available&&products.length>0&&!user&&
      <Button light title="Sign in to buy Credits" icon="log-in-outline" onPress={onSignIn}/>}
    {!!message&&<Text accessibilityRole="alert" style={s.notice}>{message}</Text>}
    <View style={s.catalog}>
      {TOKEN_PRODUCTS.map(pack=>{
        const product=checkout&&status.available?products.find(p=>p.productId===pack.id):undefined;
        const disabled=!product||!user||buying!==null;
        return <View style={s.pack} key={pack.id}>
          <Icon name="star" size={19} color={C.goldDeep}/>
          <Text style={s.amount}>{pack.tokens.toLocaleString()} tokens</Text>
          {product?<Pressable accessibilityRole="button" accessibilityLabel={`Buy ${pack.tokens.toLocaleString()} Credits for ${product.localizedPrice}, one-time purchase`}
            accessibilityState={{disabled,busy:buying===pack.id}} disabled={disabled} onPress={()=>void buy(pack.id)} style={[s.price,disabled&&s.disabled]}>
            {buying===pack.id?<ActivityIndicator color={C.blue}/>:<Text style={[s.priceText,disabled&&{color:C.ink}]}>{product.localizedPrice}</Text>}
          </Pressable>:<Text style={s.body}>{checkout&&status.loaded&&status.available?'Unavailable':'—'}</Text>}
        </View>;
      })}
    </View>
    {checkout&&<Text style={s.body}>One-time payment through Google Play. Prices are shown in your Play currency.</Text>}
    <Button light title="View my wallet" icon="wallet-outline" onPress={onOpenWallet}/>
  </ScrollView>;
}

const s=StyleSheet.create({
  content:{gap:12,paddingBottom:8},
  hero:{borderRadius:18,padding:15,gap:6},
  heroTitle:{color:'#fff',fontSize:21,fontWeight:'900'},
  heroBody:{color:'#E8EEFF',fontSize:14,lineHeight:20},
  sectionTitle:{color:C.ink,fontSize:15,fontWeight:'800'},
  body:{color:C.muted,fontSize:13,lineHeight:19},
  notice:{backgroundColor:'#E8EFFF',borderRadius:12,padding:10,color:C.ink,gap:6},
  catalog:{borderWidth:1,borderColor:C.line,borderRadius:16,overflow:'hidden',backgroundColor:'#fff'},
  pack:{flexDirection:'row',alignItems:'center',flexWrap:'wrap',gap:8,paddingHorizontal:12,paddingVertical:6,minHeight:52,borderBottomWidth:StyleSheet.hairlineWidth,borderColor:C.line},
  amount:{fontSize:16,color:C.ink,fontWeight:'800',flexGrow:1,flexShrink:1},
  price:{minWidth:70,minHeight:44,justifyContent:'center',alignItems:'center',paddingHorizontal:10,backgroundColor:C.blue,borderRadius:12},
  priceText:{color:'#fff',fontSize:14,fontWeight:'800'},
  disabled:{backgroundColor:'#E9EFF8'},
});
