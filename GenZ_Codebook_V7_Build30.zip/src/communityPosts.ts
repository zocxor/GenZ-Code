/** Report an approved community post through the existing moderation report collection. */
import {Platform} from 'react-native';
import {cleanText} from '../shared/contentSchema';
import {APP_VERSION} from './secure/config';
import {REPORT_REASONS} from './ugc';

type PostResult = {ok:true}|{ok:false;message:string;wait?:number};
const fail = (message:string, extra:{wait?:number}={}):PostResult => ({ok:false,message,...extra});
const libs = () => Promise.all([import('firebase/firestore/lite'), import('firebase/firestore'), import('./firebase/app'), import('./sync/firestoreCloud'), import('./sync/engine')]);

function errorText(e: unknown, CloudError: typeof import('./sync/engine').CloudError):string {
  if (e instanceof CloudError && e.code === 'offline') return 'Connect to the internet and try again.';
  if (e instanceof CloudError && e.code === 'permission-denied') return 'Only public posts can be reported.';
  return 'Could not send the report. Please try again.';
}

/** Report one community post. Same reasons and rate limit as chat reports. */
export async function reportPost(postId: string, reason: string, note: string): Promise<PostResult> {
  if (!(REPORT_REASONS as readonly string[]).includes(reason)) return fail('Choose a reason.');
  if (typeof postId !== 'string' || !postId) return fail('That post no longer exists.');
  const [{doc, collection, writeBatch, serverTimestamp, getDoc}, , {cloudDb, accountAuth}, {firestoreCloud, toCloudError}, {CloudError}] = await libs();
  try {
    const user = accountAuth.currentUser;
    if (!user) return fail('Sign in to report a post.');
    const status = await firestoreCloud.ensureAccount(user.uid, {appVersion: APP_VERSION, platform: Platform.OS});
    if (status === 'suspended') return fail('Your account is restricted, so it can’t report. Contact support if you think this is a mistake.');
    if (status === 'deleted') return fail('This account is being deleted.');
    const stamp = await getDoc(doc(cloudDb(), 'users', user.uid, 'limits', 'ugc'));
    const last = stamp.exists() && typeof stamp.data().last?.toMillis === 'function' ? stamp.data().last.toMillis() : 0;
    const wait = Math.min(60, Math.ceil((last + 61_000 - Date.now()) / 1000));
    if (wait > 0) return fail(`Please wait ${wait} s before sending another report.`, {wait});
    const db = cloudDb(), batch = writeBatch(db);
    batch.set(doc(db, 'users', user.uid, 'limits', 'ugc'), {last: serverTimestamp()});
    batch.set(doc(collection(db, 'postReports')), {postId, reason, note: cleanText(note, 300), uid: user.uid, status: 'open', createdAt: serverTimestamp()});
    await batch.commit();
    return {ok: true};
  } catch (e) {return fail(errorText(toCloudError(e), CloudError));}
}
