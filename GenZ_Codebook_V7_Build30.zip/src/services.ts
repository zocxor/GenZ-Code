/**
 * App service container. Local services start immediately; Firebase-backed services are
 * started after the first render so cloud code never delays opening the app.
 */
import {useSyncExternalStore} from 'react';
import {AppState, Platform} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {LearningStore} from './storage';
import {LearningRepository} from './repository';
import {SecurityEventLog} from './secure/events';
import {LoginGuard} from './shield/loginGuard';
import type {SyncEngine, SyncStatus} from './sync/engine';
import type {User} from 'firebase/auth';
import {APP_VERSION} from './secure/config';
import {loadContentOverlay, refreshContent, refreshCommunity} from './contentSync';
import {loadPhoto} from './avatarPhoto';

export const repository = new LearningRepository(new LearningStore(AsyncStorage));
export const securityLog = new SecurityEventLog(AsyncStorage);
export const loginGuard = new LoginGuard(AsyncStorage);

type CloudServices = {engine: SyncEngine; getUser: () => User | null; isRestored: () => boolean; onUser: (fn: () => void) => () => void};
let cloud: CloudServices | null = null;
let cloudStarting: Promise<CloudServices> | null = null;
const cloudListeners = new Set<() => void>();

/** Lazily start Firebase Auth + sync. Safe to call many times. */
export function startCloud(): Promise<CloudServices> {
  if (cloud) return Promise.resolve(cloud);
  if (!cloudStarting) cloudStarting = (async () => {
    const [{SyncEngine}, {firestoreCloud}, {startSession}] = await Promise.all([import('./sync/engine'), import('./sync/firestoreCloud'), import('./secure/session')]);
    const engine = new SyncEngine(repository, firestoreCloud, {appVersion: APP_VERSION, platform: Platform.OS, onSecurityEvent: (t, d) => void securityLog.record(t, d)});
    const session = startSession(engine, securityLog);
    cloud = {engine, getUser: session.getUser, isRestored: session.isRestored, onUser: session.onUser};
    engine.subscribe(() => cloudListeners.forEach(f => f()));
    session.onUser(() => cloudListeners.forEach(f => f()));
    cloudListeners.forEach(f => f());
    AppState.addEventListener('change', s => {if (s === 'active') {engine.requestSync(); void refreshContent(securityLog); void refreshCommunity();}});
    return cloud;
  })();
  return cloudStarting;
}
export const getCloud = () => cloud;

/** Boot sequence: local data first; the content overlay and cloud start in the background so they can never delay the first paint. */
/** Upper bound for showing "checking your account" before treating the user as signed out. */
const RESTORE_LIMIT_MS = 12_000;
let restoreExpired = false;
export async function bootServices() {
  setTimeout(() => {restoreExpired = true; cloudListeners.forEach(f => f());}, RESTORE_LIMIT_MS);
  // Only the learning snapshot influences the first screen. The other
  // local reads and cloud work do not hold the startup splash.
  const learning = repository.load();
  void Promise.allSettled([securityLog.load(), loginGuard.load(), loadPhoto()]);
  let timer: ReturnType<typeof setTimeout> | undefined;
  await Promise.race([learning, new Promise<void>(resolve=>{timer=setTimeout(resolve,850);})]);
  if (timer) clearTimeout(timer);
  setTimeout(() => { void loadContentOverlay().catch(() => {}); }, 0);
  setTimeout(() => {
    void learning.then(() => startCloud()).then(() => Promise.all([refreshContent(securityLog), refreshCommunity()])).catch(() => {});
  }, 250);

}

// ---------- React bindings ----------
export const useLearningState = () => useSyncExternalStore(repository.subscribe, repository.getState);
export const useStorageHealth = () => useSyncExternalStore(repository.subscribe, repository.getHealth);
export const useSecurityEvents = () => useSyncExternalStore(securityLog.subscribe, securityLog.list);
const subscribeCloud = (fn: () => void) => {cloudListeners.add(fn); return () => {cloudListeners.delete(fn);};};
const signedOut: SyncStatus = {phase: 'signed-out', uid: null, account: null, lastError: null, nextRetryAt: 0, lastSyncAt: 0, pending: false};
export const useSyncStatus = () => useSyncExternalStore(subscribeCloud, () => cloud?.engine.getStatus() ?? signedOut);
export const useAccountUser = () => useSyncExternalStore(subscribeCloud, () => cloud?.getUser() ?? null);
/**
 * One consistent auth state for every screen. 'restoring' means Firebase has not finished
 * reading the saved session yet: screens show a short "checking your account" state
 * instead of asking an already signed-in user to sign in again.
 */
export type AuthPhase = 'restoring' | 'signed-in' | 'signed-out';
export function authPhase(): AuthPhase {
  if (cloud?.getUser()) return 'signed-in';
  if (cloud?.isRestored() || restoreExpired) return 'signed-out';
  return 'restoring';
}
export const useAuthPhase = () => useSyncExternalStore(subscribeCloud, authPhase);
