import {Platform} from 'react-native';
import {collection,doc,getDoc,runTransaction,serverTimestamp} from 'firebase/firestore';
import {accountAuth,cloudDbLive} from './firebase/app';
import {firestoreCloud} from './sync/firestoreCloud';
import {APP_VERSION} from './secure/config';
import {cleanText} from '../shared/contentSchema';
import {screenPost} from '../shared/chat';
import {communityId} from '../shared/community';
import {publishingMode} from '../shared/publishing';

export type FeatureReply={id?:string;balance?:number;duplicate?:boolean;liked?:boolean;active?:boolean;live?:boolean;termId?:string;status?:string};
export async function sparkFeature(action:string,input:Record<string,unknown>):Promise<FeatureReply>{
  const user=accountAuth.currentUser;
  if(!user)throw new Error('Sign in to continue.');
  const account=await firestoreCloud.ensureAccount(user.uid,{appVersion:APP_VERSION,platform:Platform.OS});
  if(account!=='active')throw new Error('Your account cannot contribute right now.');
  if((await user.getIdTokenResult(true)).claims.email_verified!==true)throw new Error('Verify your email before contributing.');
  if(action==='create-code'){
    const {suggestWord}=await import('./ugc');
    const result=await suggestWord({term:String(input.term??''),meaning:String(input.meaning??''),example:String(input.example??''),category:String(input.category??'Chat')});
    if(!result.ok)throw new Error(result.message);
    return {live:result.live,termId:result.termId};
  }
  if(!['create-post','like-post','save-post','comment-post','delete-post'].includes(action))throw new Error('This paid feature is not available in the free edition.');
  const db=cloudDbLive();
  const name=cleanText((await getDoc(doc(db,'users',user.uid,'sync','profile'))).get('profile.name')??user.displayName??'Code Explorer',24).trim()||'Code Explorer';
  const term=cleanText(String(input.term??''),30).trim(),meaning=cleanText(String(input.meaning??''),200).trim(),example=cleanText(String(input.example??''),200).trim();
  const text=cleanText(String(input.text??''),200).trim();
  if(action==='create-post'){
    if(!term||!meaning||!['Code Word','Slang','General Term'].includes(String(input.category)))throw new Error('Enter a word, meaning and category.');
    const screened=screenPost([term,meaning,example].join('\n'));if(!screened.ok)throw new Error(screened.message);
  }
  if(action==='comment-post'){const screened=screenPost(text);if(!screened.ok)throw new Error(screened.message);}
  const postId=action==='create-post'?communityId(user.uid+' '+term):String(input.id??'');
  if(!postId||postId.includes('/')||postId.length>128)throw new Error('Choose a valid post.');
  const ref=doc(db,'communityPosts',postId);
  return runTransaction(db,async tx=>{
    const snapshot=await tx.get(ref),data=snapshot.data();
    if(action==='create-post'){
      if(snapshot.exists())return {id:postId,duplicate:true,status:data?.status};
      const config=await tx.get(doc(db,'config','app')),mode=publishingMode(config.data()??{},'post');
      if(mode==='paused')throw new Error('Posting is paused by the administrator.');
      const status=mode==='review'?'pending':'approved',now=serverTimestamp();
      tx.set(doc(db,'users',user.uid,'limits','post'),{last:now});
      tx.set(ref,{schema:3,uid:user.uid,name,term,meaning,example,category:input.category,status,hidden:status!=='approved',fee:0,payment:'free',createdAt:now,updatedAt:now,publishedAt:now,likeCount:0,commentCount:0,engagementScore:0});
      return {id:postId,status};
    }
    if(!data)throw new Error('This post no longer exists.');
    if(action==='delete-post'){
      if(data.uid!==user.uid)throw new Error('Only the author can remove this post.');
      tx.update(ref,{status:'removed',hidden:true,updatedAt:serverTimestamp()});return {id:postId};
    }
    const saved=doc(db,'users',user.uid,'savedCommunityPosts',postId);
    if(action==='save-post'&&input.enabled===false){tx.delete(saved);return {id:postId};}
    if(data.hidden||data.status!=='approved')throw new Error('This post is not public.');
    if(action==='save-post'){tx.set(saved,{postId,createdAt:serverTimestamp()});return {id:postId};}
    if(action==='like-post'){
      const like=doc(db,'communityPostLikes',postId+'_'+user.uid),existing=await tx.get(like),enabled=input.enabled===true;
      if(existing.exists()!==enabled){
        if(enabled)tx.set(like,{postId,uid:user.uid,createdAt:serverTimestamp()});else tx.delete(like);
        const count=Math.max(0,Number(data.likeCount??0)+(enabled?1:-1));
        tx.update(ref,{likeCount:count,engagementScore:count+Number(data.commentCount??0)});
      }
      return {id:postId,liked:enabled};
    }
    const comment=doc(collection(ref,'comments'),communityId(user.uid+' '+text)),prior=await tx.get(comment);
    if(prior.exists())return {id:comment.id,duplicate:true};
    tx.set(doc(db,'users',user.uid,'limits','post'),{last:serverTimestamp()});
    tx.set(comment,{uid:user.uid,name,text,status:'approved',createdAt:serverTimestamp()});
    const count=Number(data.commentCount??0)+1;
    tx.update(ref,{commentCount:count,engagementScore:count+Number(data.likeCount??0),lastCommentId:comment.id});
    return {id:comment.id};
  });
}
