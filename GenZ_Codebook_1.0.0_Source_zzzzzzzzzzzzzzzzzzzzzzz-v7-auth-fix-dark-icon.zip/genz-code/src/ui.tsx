import React from 'react';
import {View,Text,Image,Pressable,StyleSheet,StyleProp,ViewStyle,Animated} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {LinearGradient} from 'expo-linear-gradient';
import {BYLINE, RIGHTS, copyright} from '../shared/brand';
export type IconName=React.ComponentProps<typeof Ionicons>['name'];
export const C={ink:'#162d4b',muted:'#536984',blue:'#245ee6',teal:'#007c91',line:'#c4d6e8',glass:'#ffffff',navy:'#101A3A',accent:'#1769F5',purple:'#7654F6',soft:'#EAF4FF',gold:'#F5B82E',goldDeep:'#8a5a00',success:'#0d7a4a',warn:'#b45309',danger:'#b42318',bg:'#EDF4FF'};
export function Icon({name,size=22,color=C.ink}:{name:IconName;size?:number;color?:string}){return <Ionicons name={name} size={size} color={color} accessible={false} accessibilityElementsHidden importantForAccessibility="no-hide-descendants"/>}
export function Glass({children,style}:{children:React.ReactNode;style?:StyleProp<ViewStyle>}){return <View style={[u.glass,style]}><View pointerEvents="none" style={u.topshine}/>{children}</View>}
export function Button({title,icon,onPress,light=false,disabled=false}:{title:string;icon?:IconName;onPress:()=>void;light?:boolean;disabled?:boolean}){return <Pressable accessibilityRole="button" accessibilityState={{disabled}} disabled={disabled} onPress={onPress} style={({pressed})=>[{opacity:disabled?.5:pressed?.85:1,transform:[{translateY:pressed?2:0}]}]}><LinearGradient colors={light?['#ffffff','#e3eefb']:['#5289ff','#245fe9','#184bc9']} style={[u.button,light&&u.lightButton]}>{icon&&<Icon name={icon} color={light?C.blue:'#fff'}/>}<Text style={[u.buttonText,light&&{color:C.ink}]}>{title}</Text></LinearGradient></Pressable>}
export function RoundIcon({name,onPress,label,selected=false}:{name:IconName;onPress:()=>void;label:string;selected?:boolean}){return <Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{selected}} onPress={onPress} style={[u.round,selected&&{backgroundColor:'#dbeaff'}]}><Icon name={name} color={C.blue}/></Pressable>}
export function Chip({label,icon,selected,onPress}:{label:string;icon?:IconName;selected?:boolean;onPress:()=>void}){
  // A selected chip pops gently (scale 1 -> 1.07 -> 1) so a category or
  // mode change reads as a selection, not an instant swap. Mount never
  // animates: wasSelected starts at the initial value.
  const pop=React.useRef(new Animated.Value(1)).current;
  const wasSelected=React.useRef(selected);
  React.useEffect(()=>{
    if(selected&&!wasSelected.current){
      Animated.sequence([
        Animated.timing(pop,{toValue:1.07,duration:120,useNativeDriver:true}),
        Animated.spring(pop,{toValue:1,friction:6,tension:200,useNativeDriver:true}),
      ]).start();
    }
    wasSelected.current=selected;
  },[selected]);
  return <Pressable accessibilityRole="button" accessibilityState={{selected:!!selected}} onPress={onPress} style={[u.chip,selected&&u.selected,{transform:[{scale:pop}]}]}>{icon&&<Icon name={icon} size={16} color={selected?'#fff':C.muted}/>}<Text style={[u.chipText,selected&&{color:'#fff'}]}>{label}</Text></Pressable>;
}
/** Coloured gradient tile with a white icon — category and game tiles. */
export function IconTile({icon,from,to,size=48,iconSize=24}:{icon:IconName;from:string;to:string;size?:number;iconSize?:number}){return <LinearGradient colors={[from,to]} start={{x:0,y:0}} end={{x:1,y:1}} style={{width:size,height:size,borderRadius:Math.round(size*.34),alignItems:'center',justifyContent:'center'}}><Icon name={icon} size={iconSize} color="#fff"/></LinearGradient>}
/** Animated progress bar (0..1). Width animates on value change. */
export function ProgressBar({value,color=C.blue,height=8}:{value:number;color?:string;height?:number}){const v=React.useRef(new Animated.Value(0)).current;React.useEffect(()=>{Animated.timing(v,{toValue:Math.max(0,Math.min(1,value)),duration:500,useNativeDriver:false}).start();},[value]);const width=v.interpolate({inputRange:[0,1],outputRange:['0%','100%']});return <View style={{height,borderRadius:height/2,backgroundColor:'#d7e5f7',overflow:'hidden'}}><Animated.View style={{height,width,backgroundColor:color,borderRadius:height/2}}/></View>}
/** Eyebrow + title + optional right-side action. */
export function SectionHeader({eyebrow,title,action}:{eyebrow?:string;title:string;action?:React.ReactNode}){return <View style={{flexDirection:'row',alignItems:'flex-end',justifyContent:'space-between',gap:10}}><View style={{flex:1,gap:4}}>{eyebrow&&<Text style={{fontSize:10,fontWeight:'800',letterSpacing:1.6,color:C.blue}}>{eyebrow}</Text>}<Text style={{fontSize:20,fontWeight:'800',letterSpacing:-.4,color:C.ink}}>{title}</Text></View>{action}</View>}
/** Small stat block: icon tile + value + label. */
export function Stat({icon,value,label,tint=C.blue}:{icon:IconName;value:string;label:string;tint?:string}){return <View style={{flex:1,alignItems:'center',gap:6}}><IconTile icon={icon} from={tint} to={tint} size={40} iconSize={20}/><Text style={{fontSize:22,fontWeight:'900',color:C.ink}}>{value}</Text><Text style={{fontSize:11,fontWeight:'700',color:C.muted,textAlign:'center'}}>{label}</Text></View>}
/** Pressable white card with a subtle scale-down on press. */
export function PressableCard({onPress,children,style,label}:{onPress:()=>void;children:React.ReactNode;style?:StyleProp<ViewStyle>;label?:string}){const s=React.useRef(new Animated.Value(1)).current;const down=()=>Animated.spring(s,{toValue:.97,friction:8,tension:200,useNativeDriver:true}).start();const up=()=>Animated.spring(s,{toValue:1,friction:6,tension:150,useNativeDriver:true}).start();return <Animated.View style={[{transform:[{scale:s}]},style]}><Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} onPressIn={down} onPressOut={up} style={u.pressCard}>{children}</Pressable></Animated.View>}
/** Fade + rise in on mount. Lightweight staggered entry for screen content. */
export function FadeIn({children,delay=0,style}:{children:React.ReactNode;delay?:number;style?:StyleProp<ViewStyle>}){const o=React.useRef(new Animated.Value(0)).current;const y=React.useRef(new Animated.Value(10)).current;React.useEffect(()=>{Animated.parallel([Animated.timing(o,{toValue:1,duration:350,delay,useNativeDriver:true}),Animated.timing(y,{toValue:0,duration:350,delay,useNativeDriver:true})]).start();},[]);return <Animated.View style={[{opacity:o,transform:[{translateY:y}]},style]}>{children}</Animated.View>}
/** Pulsing placeholder bar for loading states. */
export function Skeleton({width='100%',height=16,radius=8}:{width?:number|`${number}%`;height?:number;radius?:number}){const o=React.useRef(new Animated.Value(.4)).current;React.useEffect(()=>{const loop=Animated.loop(Animated.sequence([Animated.timing(o,{toValue:.9,duration:700,useNativeDriver:true}),Animated.timing(o,{toValue:.4,duration:700,useNativeDriver:true})]));loop.start();return()=>loop.stop();},[]);return <Animated.View style={{width,height,borderRadius:radius,backgroundColor:'#dbe7f5',opacity:o}}/>}
export function Mark({large=false}:{large?:boolean}){return <Image source={require('../assets/brand/genz-code-mark.png')} resizeMode="contain" accessible={false} style={{width:large?148:52,height:large?148:52}}/>}
export function BrandLogo(){return <Image source={require('../assets/brand/genz-code-logo.png')} resizeMode="contain" accessibilityLabel="GenZ Codebook" style={{width:'100%',maxWidth:270,height:90,alignSelf:'center'}}/>}
export function BrandSplash(){return <Image source={require('../assets/brand/genz-code-splash.png')} resizeMode="contain" accessible={false} style={{width:'100%',maxWidth:320,aspectRatio:1,alignSelf:'center'}}/>}
/** Animated loading splash: the monogram springs in, the wordmark and the
 * tagline fade up after it, then the monogram gently pulses while loading.
 * Pure React Native Animated (useNativeDriver) — no new dependency. The
 * loading screen only shows while the app boots, so this never delays ready.
 */
export function AnimatedSplash(){
  const scale=React.useRef(new Animated.Value(0.8)).current;
  const fade=React.useRef(new Animated.Value(0)).current;
  const word=React.useRef(new Animated.Value(0)).current;
  const tag=React.useRef(new Animated.Value(0)).current;
  const pulse=React.useRef(new Animated.Value(1)).current;
  React.useEffect(()=>{
    Animated.parallel([
      Animated.spring(scale,{toValue:1,friction:6,tension:120,useNativeDriver:true}),
      Animated.timing(fade,{toValue:1,duration:350,useNativeDriver:true}),
      Animated.timing(word,{toValue:1,duration:350,delay:250,useNativeDriver:true}),
      Animated.timing(tag,{toValue:1,duration:350,delay:450,useNativeDriver:true}),
    ]).start();
    const loop=Animated.loop(Animated.sequence([
      Animated.timing(pulse,{toValue:1.03,duration:600,useNativeDriver:true}),
      Animated.timing(pulse,{toValue:1,duration:600,useNativeDriver:true}),
    ]));
    const t=setTimeout(()=>loop.start(),700);
    return()=>{clearTimeout(t);loop.stop();};
  },[]);
  return <View style={{alignItems:'center',gap:16}}>
    <Animated.View style={{opacity:fade,transform:[{scale:Animated.multiply(scale,pulse)}]}}><Mark large/></Animated.View>
    <Animated.View style={{opacity:word,transform:[{translateY:word.interpolate({inputRange:[0,1],outputRange:[12,0]})}]}}><BrandLogo/></Animated.View>
    <Animated.View style={{opacity:tag}}><Text style={{fontSize:15,lineHeight:22,color:C.muted,textAlign:'center'}}>A little context. A lot more clarity.</Text></Animated.View>
  </View>;
}
export function BrandWordmark(){return <Image source={require('../assets/brand/genz-code-wordmark.png')} resizeMode="contain" accessibilityLabel="GenZ Codebook" style={{width:'100%',maxWidth:250,height:28,alignSelf:'flex-start'}}/>}
const profileIcons:IconName[]=['person','rocket','headset','happy','flash','flower','hardware-chip','game-controller','musical-notes','trophy','paw','camera'];
const profileColors=['#6d28d9','#a92f85','#6d43ab','#b65a17','#365993','#9c3570','#0e7490','#334155','#be185d','#b45309','#15803d','#0369a1'];
export function BrandAvatar({index=0,size=48,photo}:{index?:number;size?:number;photo?:string|null}){
 if(photo)return <Image source={{uri:photo}} accessibilityIgnoresInvertColors accessible={false} style={{width:size,height:size,borderRadius:size/2,borderWidth:1.5,borderColor:'#f4ddff'}}/>;
 const i=Number.isInteger(index)&&index>=0&&index<profileIcons.length?index:0;
 if(i===0)return <Image source={require('../assets/brand/genz-code-avatar.png')} resizeMode="contain" accessible={false} style={{width:size,height:size}}/>;
 return <LinearGradient colors={['#d5adff',profileColors[i]!,'#41126b']} style={{width:size,height:size,borderRadius:size/2,alignItems:'center',justifyContent:'center',borderWidth:1.5,borderColor:'#f4ddff',overflow:'hidden'}}><View pointerEvents="none" style={{position:'absolute',top:2,left:size*.16,right:size*.16,height:size*.33,borderRadius:size/2,backgroundColor:'rgba(255,255,255,.2)'}}/><Icon name={profileIcons[i]!} size={Math.round(size*.5)} color="#fff"/></LinearGradient>;
}

/** Publisher footer: "A ZTechX product" + "© 2026 Zocxorian Technologies. All rights reserved." */
export function CompanyFooter({style}:{style?:StyleProp<ViewStyle>}){return <View accessible accessibilityLabel={`${BYLINE}. ${copyright()}. ${RIGHTS}`} style={[u.footer,style]}><Text style={u.footerBrand}>{BYLINE}</Text><Text style={u.footerText}>{copyright()}. {RIGHTS}</Text></View>}
const u=StyleSheet.create({footer:{alignItems:'center',gap:2,paddingTop:6,paddingBottom:4},footerBrand:{fontSize:11,fontWeight:'800',letterSpacing:.6,color:'#4a6380'},footerText:{fontSize:10,lineHeight:15,color:'#5c7189',textAlign:'center'},glass:{backgroundColor:C.glass,borderColor:'#dce8f5',borderWidth:1.5,borderRadius:28,padding:16,gap:10,shadowColor:'#3e6c9a',shadowOffset:{width:0,height:8},shadowOpacity:.11,shadowRadius:18,elevation:3,overflow:'hidden'},pressCard:{backgroundColor:'#fff',borderColor:'#dce8f5',borderWidth:1.5,borderRadius:20,padding:12,shadowColor:'#3e6c9a',shadowOffset:{width:0,height:6},shadowOpacity:.09,shadowRadius:14,elevation:3},topshine:{position:'absolute',top:1,left:20,right:20,height:1,backgroundColor:'#fff'},button:{minHeight:56,borderRadius:19,paddingHorizontal:20,paddingVertical:16,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:10,borderTopWidth:1,borderTopColor:'#a4c6ff',borderBottomWidth:3,borderBottomColor:'#1344b8'},lightButton:{borderTopColor:'#fff',borderBottomColor:'#c7d8ec',borderWidth:1,borderColor:'#c7d8ec'},buttonText:{fontSize:16,color:'#fff',fontWeight:'800'},round:{minWidth:48,minHeight:48,borderRadius:17,backgroundColor:'#f5f9ff',borderWidth:1,borderColor:'#fff',alignItems:'center',justifyContent:'center'},chip:{minHeight:44,paddingVertical:11,paddingHorizontal:15,borderRadius:16,borderWidth:1,borderColor:'#c6d6e7',backgroundColor:'#f5faff',flexDirection:'row',alignItems:'center',gap:7},selected:{backgroundColor:C.blue,borderColor:C.blue},chipText:{fontSize:13,fontWeight:'700',color:C.muted},mark:{width:48,height:48,borderRadius:17,padding:5,borderWidth:1.5,borderColor:'#fff',shadowColor:'#2267a2',shadowOffset:{width:0,height:8},shadowOpacity:.18,shadowRadius:12,elevation:7},largeMark:{width:132,height:132,borderRadius:40,padding:12},markInner:{flex:1,backgroundColor:'rgba(255,255,255,.5)',borderRadius:12,borderTopWidth:2,borderTopColor:'#fff',alignItems:'center',justifyContent:'center'},spark:{position:'absolute',right:-5,top:-5,backgroundColor:'#426ce1',width:20,height:20,borderRadius:8,borderWidth:1,borderColor:'#bfd5ff',alignItems:'center',justifyContent:'center'}});

/** Confirmation dialog that also works on web (react-native-web's Alert is a no-op). */
export function confirmAction(title: string, body: string, onConfirm: () => void, confirmLabel = 'Continue') {
  const {Alert, Platform} = require('react-native') as typeof import('react-native');
  if (Platform.OS === 'web') {if (typeof window !== 'undefined' && window.confirm(`${title}\n\n${body}`)) onConfirm(); return;}
  Alert.alert(title, body, [{text: 'Cancel', style: 'cancel'}, {text: confirmLabel, style: 'destructive', onPress: onConfirm}]);
}
