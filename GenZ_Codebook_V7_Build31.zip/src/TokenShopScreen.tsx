/** One-time token purchases. All live prices come from Google Play. */
import {SPARK_MODE} from '../shared/deployment';
import {TOKEN_CHECKOUT_ENABLED} from './backend';
import React,{useEffect,useRef,useState} from 'react';
import {ActivityIndicator,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {C,Button,LiquidHero,Icon,SectionHeader,type IconName} from './ui';
import {useEligibleBalance} from './ContributionScreens';
import {useAppConfig} from './appConfig';
import {SUBSCRIPTION_PRODUCTS} from '../shared/subscriptions';
import {useAccountUser} from './services';
import {buyTokens,getBillingProducts,getBillingStatus,isTokenPurchaseEnabled,onBillingEvent,retryBilling} from './billing';
import {TOKEN_PRODUCTS,type TokensState} from '../shared/tokens';

export default function TokenShopScreen({tokens,onSignIn,onOpenWallet}:{
  tokens:TokensState;
  onSignIn:()=>void;
  onOpenWallet:()=>void;
}) {
  const user=useAccountUser();
  const [products,setProducts]=useState(getBillingProducts);
  const [status,setStatus]=useState(getBillingStatus);
  const [buying,setBuying]=useState<string|null>(null);
  const [retrying,setRetrying]=useState(false);
  const [message,setMessage]=useState('');
  const busy=useRef(false);
  const checkout=isTokenPurchaseEnabled();

  useEffect(()=>{
    const sync=()=>{setProducts(getBillingProducts());setStatus(getBillingStatus());};
    const stop=onBillingEvent(event=>{
      if(event.kind==='products'||event.kind==='unavailable'){sync();return;}
      if(event.kind==='restored'){setMessage(`${event.count} earlier purchases restored.`);return;}
      busy.current=false;
      setBuying(null);
      switch(event.kind){
        case 'credited':setMessage(`${event.tokens.toLocaleString()} Credits added to your wallet.`);break;
        case 'already-credited':setMessage('This purchase is already in your wallet.');break;
        case 'pending':setMessage('Payment is pending in Google Play.');break;
        case 'failed':setMessage(event.message);break;
        case 'cancelled':setMessage('Purchase cancelled.');break;
        case 'signin-required':setMessage('Sign in to buy Credits.');break;
      }
    });
    sync();
    return stop;
  },[]);

  const buy=async(productId:string)=>{
    if(busy.current||!checkout)return;
    busy.current=true;
    setMessage('');setBuying(productId);
    const result=await buyTokens(productId);
    if(!result.started){busy.current=false;setBuying(null);setMessage(result.error??'Could not start checkout.');}
  };
  const retry=async()=>{
    setRetrying(true);setMessage('');
    try {await retryBilling();setProducts(getBillingProducts());setStatus(getBillingStatus());}
    catch {setMessage('Could not refresh Google Play prices. Try again.');}
    finally {setRetrying(false);}
  };

  const credits=useEligibleBalance(user?.uid);
  const cfg=useAppConfig();
  const live=TOKEN_CHECKOUT_ENABLED&&checkout;
  const costs:[IconName,string,string][]=[
    ['chatbubbles-outline','Community chat',`${cfg.fees.chat} / day`],
    ['create-outline','Publish a post',`${cfg.fees.post}`],
    ['add-circle-outline','Create a dictionary word',`${cfg.fees.code}`],
    ['calendar-outline','Your own Daily Code',`${cfg.fees.daily}`],
    ['code-slash-outline','Extra Encode / Decode',cfg.fees.encode||cfg.fees.decode?`${cfg.fees.encode} / ${cfg.fees.decode}`:'Free'],
  ];
  return <ScrollView contentContainerStyle={s.content}>
    <LiquidHero style={s.hero}>
      <Text style={s.heroEyebrow}>GENZ CODEBOOK CREDITS</Text>
      <Text style={s.heroTitle}>One balance for everything you unlock.</Text>
      <View style={s.balance}><Icon name="star" size={18} color="#FFD45C"/><Text style={s.balanceText}>{user?(credits.balance===null?'—':credits.balance.toLocaleString()):'Sign in'} Credits</Text></View>
    </LiquidHero>
    {!live&&<View style={s.soon} accessibilityLiveRegion="polite"><Icon name="time-outline" size={20} color="#92400E"/><Text style={[s.body,{flex:1,color:'#7C4A03'}]}>Checkout opens soon. Packs and plans below are shown for planning; nothing can be charged yet. Earn free Credits meanwhile.</Text></View>}
    {live&&!status.loaded&&<Text style={s.body}>Loading Google Play prices…</Text>}
    {live&&status.loaded&&!status.available&&<View style={s.soon}><Text style={[s.body,{flex:1}]}>{status.error??'Google Play billing is unavailable on this device.'}</Text><Button light title={retrying?'Refreshing…':'Refresh'} disabled={retrying} onPress={()=>void retry()}/></View>}
    {live&&!user&&<Button light title="Sign in to buy Credits" icon="log-in-outline" onPress={onSignIn}/>}
    {!!message&&<Text accessibilityRole="alert" style={s.notice}>{message}</Text>}

    <SectionHeader eyebrow="PRICES" title="What Credits buy"/>
    <View style={s.costGrid}>{costs.map(([icon,label,value])=><View key={label} style={s.cost}><Icon name={icon} size={18} color={C.accent}/><Text style={s.costLabel} numberOfLines={2}>{label}</Text><Text style={s.costValue}>{value}</Text></View>)}</View>

    <SectionHeader eyebrow="FREE" title="Earn Credits"/>
    <View style={s.costGrid}>
      <View style={s.earn}><Icon name="play-circle" size={20} color="#2F3BEA"/><Text style={s.costLabel}>Watch an optional ad</Text><Text style={s.earnValue}>+10</Text></View>
      <View style={s.earn}><Icon name="gift" size={20} color="#D97706"/><Text style={s.costLabel}>Daily account reward</Text><Text style={s.earnValue}>+5</Text></View>
      <View style={s.earn}><Icon name="people" size={20} color="#16A34A"/><Text style={s.costLabel}>A friend joins with your code</Text><Text style={s.earnValue}>+100</Text></View>
    </View>

    <SectionHeader eyebrow="PAY ONCE" title="Credit packs"/>
    <View style={s.catalog}>
      {TOKEN_PRODUCTS.map((pack,i)=>{
        const product=live&&status.available?products.find(p=>p.productId===pack.id):undefined;
        const disabled=!product||!user||buying!==null;
        const tag=i===2?'Popular':i===TOKEN_PRODUCTS.length-1?'Best value':i===0?'Starter':'';
        return <View style={[s.pack,i===2&&s.packFeatured]} key={pack.id}>
          {!!tag&&<Text style={[s.tag,i===2&&s.tagFeatured]}>{tag}</Text>}
          <Icon name="star" size={22} color="#E0A100"/>
          <Text style={s.amount}>{pack.tokens.toLocaleString()}</Text>
          <Text style={s.unit}>Credits</Text>
          <Text style={s.refPrice}>{product?product.localizedPrice:pack.price}</Text>
          <Pressable accessibilityRole="button" accessibilityLabel={product?`Buy ${pack.tokens.toLocaleString()} Credits for ${product.localizedPrice}, one-time purchase`:`${pack.tokens.toLocaleString()} Credits, checkout opens soon`}
            accessibilityState={{disabled,busy:buying===pack.id}} disabled={disabled} onPress={()=>void buy(pack.id)} style={[s.buy,disabled&&s.buyDisabled]}>
            {buying===pack.id?<ActivityIndicator color="#fff"/>:<Text style={[s.buyText,disabled&&{color:C.muted}]}>{product?'Buy':live?'Unavailable':'Opens soon'}</Text>}
          </Pressable>
        </View>;
      })}
    </View>
    <Text style={s.fine}>One-time Google Play payment. Credits are added only after Google Play confirms the purchase, never twice for the same order. Prices shown are the planned US prices; Google Play shows the final price in your currency at checkout. Credit packs do not remove ads.</Text>

    <SectionHeader eyebrow="AD-FREE" title="Premium"/>
    {SUBSCRIPTION_PRODUCTS.map(plan=><View key={plan.id} style={s.plan}>
      <View style={{flex:1,gap:3}}>
        <Text style={s.planTitle}>Premium {plan.basePlanId==='yearly'?'yearly':'monthly'}</Text>
        <Text style={s.body}>No ads anywhere in the app · +{plan.tokensPerPeriod.toLocaleString()} Credits {plan.periodLabel}</Text>
        <Text style={s.fine}>Renews {plan.periodLabel.replace('per ','every ')} until cancelled in Google Play.</Text>
      </View>
      <View style={s.planBadge}><Text style={s.planBadgeText}>Coming soon</Text></View>
    </View>)}
    <Button light title="View my wallet" icon="wallet-outline" onPress={onOpenWallet}/>
  </ScrollView>;
}

const s=StyleSheet.create({
  content:{padding:16,gap:12,paddingBottom:30},
  hero:{padding:18,borderRadius:22,gap:8},heroEyebrow:{color:'#BFD3FF',fontSize:11,fontWeight:'900',letterSpacing:1.4},
  heroTitle:{color:'#fff',fontSize:22,fontWeight:'900',lineHeight:28},
  balance:{flexDirection:'row',alignItems:'center',gap:6,alignSelf:'flex-start',backgroundColor:'rgba(255,255,255,.14)',borderRadius:16,paddingHorizontal:12,paddingVertical:7,borderWidth:1,borderColor:'rgba(255,255,255,.25)'},
  balanceText:{color:'#fff',fontWeight:'900',fontSize:15},
  soon:{flexDirection:'row',alignItems:'center',gap:10,padding:12,borderRadius:14,backgroundColor:'#FFF7E6',borderWidth:1,borderColor:'#FCD9A0'},
  sectionTitle:{fontSize:18,fontWeight:'900',color:C.ink},body:{fontSize:13.5,lineHeight:19,color:C.muted},fine:{fontSize:12,lineHeight:17,color:C.muted},
  notice:{fontSize:13.5,color:C.ink,backgroundColor:C.soft,padding:10,borderRadius:12},
  costGrid:{flexDirection:'row',flexWrap:'wrap',gap:8},
  cost:{flexGrow:1,flexBasis:'45%',minHeight:58,flexDirection:'row',alignItems:'center',gap:8,padding:10,borderRadius:14,backgroundColor:'#fff',borderWidth:1,borderColor:'#E2E8F5'},
  costLabel:{flex:1,fontSize:13,fontWeight:'700',color:C.ink},costValue:{fontSize:14,fontWeight:'900',color:'#B45309'},
  earn:{flexGrow:1,flexBasis:'45%',minHeight:58,flexDirection:'row',alignItems:'center',gap:8,padding:10,borderRadius:14,backgroundColor:'#F3F7FF',borderWidth:1,borderColor:'#DCE6FB'},
  earnValue:{fontSize:15,fontWeight:'900',color:'#16A34A'},
  catalog:{flexDirection:'row',flexWrap:'wrap',gap:10},
  pack:{flexGrow:1,flexBasis:'30%',minWidth:100,alignItems:'center',gap:2,paddingTop:14,paddingBottom:10,paddingHorizontal:8,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#E7E2F7'},
  packFeatured:{borderColor:'#8B5CF6',borderWidth:2,backgroundColor:'#FAF7FF'},
  tag:{position:'absolute',top:-9,fontSize:10.5,fontWeight:'900',color:'#5B21B6',backgroundColor:'#EDE7FF',paddingHorizontal:8,paddingVertical:2,borderRadius:8,overflow:'hidden'},
  tagFeatured:{color:'#fff',backgroundColor:'#7C3AED'},
  refPrice:{fontSize:14,fontWeight:'900',color:'#1E3A8A',marginTop:2},amount:{fontSize:20,fontWeight:'900',color:C.ink,marginTop:4},unit:{fontSize:12,color:C.muted,fontWeight:'700'},
  buy:{marginTop:8,alignSelf:'stretch',minHeight:38,borderRadius:12,backgroundColor:'#2F3BEA',alignItems:'center',justifyContent:'center',paddingHorizontal:6},
  buyDisabled:{backgroundColor:'#EEF1F8'},buyText:{color:'#fff',fontWeight:'900',fontSize:13},
  plan:{flexDirection:'row',alignItems:'center',gap:10,padding:14,borderRadius:18,backgroundColor:'#fff',borderWidth:1,borderColor:'#F3D27A'},
  planTitle:{fontSize:16,fontWeight:'900',color:C.ink},
  planBadge:{backgroundColor:'#FFF3D1',borderRadius:10,paddingHorizontal:9,paddingVertical:5},planBadgeText:{fontSize:11.5,fontWeight:'900',color:'#8A5A00'},
});
