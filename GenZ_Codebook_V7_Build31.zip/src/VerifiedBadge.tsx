import React, {useEffect,useState} from 'react';
import {View} from 'react-native';
import {MaterialCommunityIcons} from '@expo/vector-icons';
import {collection,documentId,onSnapshot,query,where} from 'firebase/firestore';
import {cloudDbLive} from './firebase/app';

export type BadgeTier = 'blue' | 'gold';
/** Set of verified user IDs, plus each one's badge tier (blue = verified user, gold = owner/staff). */
export class BadgeSet extends Set<string> {
  tiers = new Map<string, BadgeTier>();
  tier(uid?: string | null): BadgeTier {return (uid && this.tiers.get(uid)) || 'blue';}
}
export function useBadges(uids:string[]) {
  const key=JSON.stringify([...new Set(uids.filter(Boolean))].sort());
  const [verified,setVerified]=useState<BadgeSet>(()=>new BadgeSet());
  useEffect(()=>{
    setVerified(new BadgeSet());
    const ids=JSON.parse(key) as string[];
    const snapshots=new Map<number,[string,BadgeTier][]>();
    const publish=()=>{const next=new BadgeSet();for(const [id,tier] of [...snapshots.values()].flat()){next.add(id);next.tiers.set(id,tier);}setVerified(next);};
    const stops:(()=>void)[]=[];
    for(let i=0;i<ids.length;i+=30) {
      stops.push(onSnapshot(query(collection(cloudDbLive(),'verifiedContributors'),where(documentId(),'in',ids.slice(i,i+30))),snap=>{
        snapshots.set(i,snap.docs.filter(d=>d.get('verified')===true).map(d=>[d.id,d.get('tier')==='gold'?'gold':'blue'] as [string,BadgeTier]));
        publish();
      },()=>{snapshots.delete(i);publish();}));
    }
    return ()=>stops.forEach(stop=>stop());
  },[key]);
  return verified;
}

/** Seal-shaped verified check: blue for verified users, gold for the owner and authorised staff. */
export function VerifiedBadge({verified,tier='blue',size=18}:{verified:boolean;tier?:BadgeTier;size?:number}) {
  if(!verified)return null;
  const gold=tier==='gold';
  return <View accessible accessibilityLabel={gold?'Gold verified badge: GenZ Codebook team':'Verified badge'} style={{width:size,height:size,alignItems:'center',justifyContent:'center',flexShrink:0}}>
    <View style={{position:'absolute',width:size*.5,height:size*.5,borderRadius:size,backgroundColor:'#fff'}}/>
    <MaterialCommunityIcons name="check-decagram" size={size} color={gold?'#E0A100':'#1D8CF0'}/>
  </View>;
}
