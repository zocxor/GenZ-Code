/** Community keeps the existing live chat and shows reviewed term posts in a separate pane. */
import {BACKEND_URL} from './backend';
import {SPARK_MODE} from '../shared/deployment';
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, ScrollView, Pressable, StyleSheet, Keyboard, AppState} from 'react-native';
import {LinearGradient} from 'expo-linear-gradient';
import {C, Glass, Button, Chip, Icon, IconName, IconTile, FadeIn, confirmAction} from './ui';
import {KeyboardDock,useKeyboardVisible} from './KeyboardDock';
import {useAccountUser,useAuthPhase} from './services';
import {useAppConfig} from './appConfig';
import {subscribeChat, sendChatMessage, deleteOwnMessage} from './chat';
import CommunityPostsPanel from './CommunityPostsPanel';
import {VerifiedBadge,useBadges} from './VerifiedBadge';
import {reportChatMessage, REPORT_REASONS} from './ugc';
import {CHAT_MAX_LENGTH, type ChatMessage} from '../shared/chat';
import {watchRewardedAd} from './ads';
import {fetchLeaderboard, publishLeaderboard, leaveLeaderboard, type LeaderboardRow} from './tokensSync';
import {earnTokens, setLeaderboardOptIn, type Action} from './learning';
import {feature,errorOf,policy,utcDate} from './communityFeatures';
import {useEligibleBalance} from './ContributionScreens';
import {CONTENT_NOTICE} from '../shared/publishing';
import {TOKENS, type TokensState} from '../shared/tokens';

const timeOf = (at: number) => new Date(at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});

export default function CommunityScreen({active, nickname, onSignIn, onOpenShop, onOpenDaily, onGoToPlay, onMyPosts, tokens, onTokensAction}: {active: boolean; nickname: string; onSignIn: () => void; onOpenShop: () => void; onOpenDaily: () => void; onGoToPlay: () => void; onMyPosts: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  const user = useAccountUser(), phase = useAuthPhase(), paid = useAppConfig().paidCommunity;
  const [view, setView] = useState<'chat' | 'posts'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [earning, setEarning] = useState(false);
  const [earnNote, setEarnNote] = useState('');
  const [day,setDay]=useState(utcDate);
  const [passDate,setPassDate]=useState('');
  const [passBusy,setPassBusy]=useState(false),[pledge,setPledge]=useState(false);
  const passPending=useRef(false);
  const credits=useEligibleBalance(paid&&active&&view==='chat'?user?.uid:undefined);
  const needsTokens=paid&&passDate!==day;
  useEffect(()=>{
    const timer=setInterval(()=>setDay(utcDate()),15000);
    const foreground=AppState.addEventListener('change',value=>{if(value==='active')setDay(utcDate());});
    return ()=>{clearInterval(timer);foreground.remove();};
  },[]);
  useEffect(()=>{
    if(!paid||!active||!user)return;
    let alive=true;setPassDate('');
    void feature('chat-pass-status').then(r=>{if(alive&&r.active)setPassDate(r.id??'');},e=>{if(alive)setSendError(errorOf(e));});
    return ()=>{alive=false;};
  },[active,user?.uid,day,paid]);
  const enter=async()=>{
    if(passPending.current||!pledge)return;
    passPending.current=true;setPassBusy(true);setSendError('');
    try{const result=await feature('chat-pass');setPassDate(result.id??'');credits.reload();}
    catch(e){setSendError(errorOf(e));}
    finally{passPending.current=false;setPassBusy(false);}
  };
  const [reporting, setReporting] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportNote, setReportNote] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportSent, setReportSent] = useState('');
  const [board, setBoard] = useState<LeaderboardRow[]>([]);
  const [boardBusy, setBoardBusy] = useState(false);
  const badges = useBadges(active && view==='chat' ? [...messages.map(m=>m.uid),...board.map(r=>r.uid)] : []);
  const scrollRef = useRef<ScrollView>(null);
  const keyboardOpen = useKeyboardVisible();
  const [boardOpen, setBoardOpen] = useState(false);
  const followLatest = useRef(true);
  const showBoard = boardOpen && !keyboardOpen;

  useEffect(() => {
    if (!active || view !== 'chat') return;
    setLoadError('');
    return subscribeChat(setMessages, setLoadError);
  }, [active,view]);
  useEffect(() => {
    if (!active) return;
    let live = true;
    void fetchLeaderboard().then(rows => {if (live) setBoard(rows);});
    return () => {live = false;};
  }, [active]);
  useEffect(() => {
    if (active && view === 'chat' && keyboardOpen) scrollRef.current?.scrollToEnd({animated:false});
  }, [active,view,keyboardOpen]);

  const send = async () => {
    if (sending || !text.trim()) return;
    if(needsTokens){setSendError('Open today’s Chat Pass first.');return;}
    setSending(true); setSendError('');
    const r = await sendChatMessage(nickname, text);
    setSending(false);
    if (r.ok) {
      // Deduct only after the message is accepted — never twice for one send
      // (the `sending` guard above blocks a second tap while this runs).

      followLatest.current = true;
      scrollRef.current?.scrollToEnd({animated:false});
      setText('');
    } else setSendError(r.message);
  };

  const earn = async () => {
    if (earning) return;
    setEarning(true); setEarnNote('');
    const rewarded = await watchRewardedAd();
    setEarning(false);
    if (rewarded) {if(BACKEND_URL&&user)setEarnNote('10 Credits will appear after ad verification.');else {onTokensAction(earnTokens(TOKENS.REWARDED_AD));setEarnNote(`+${TOKENS.REWARDED_AD} learning points earned for level unlocks.`);}}
    else setEarnNote('No Credits this time — the ad closed early. Try again when you like.');
    credits.reload();
  };

  const report = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportChatMessage(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this message.'); setReporting(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const remove = async (id: string) => {
    const r = await deleteOwnMessage(id);
    if (!r.ok) setSendError(r.message);
  };
  const openReport = (id:string) => {
    setReporting(current=>current===id?null:id);
    setReportReason('');setReportNote('');setReportSent('');
  };

  const toggleBoard = async (on: boolean) => {
    if (boardBusy || !user) return;
    setBoardBusy(true);
    onTokensAction(setLeaderboardOptIn(on));
    if (on) await publishLeaderboard(nickname, tokens.balance);
    else await leaveLeaderboard();
    setBoard(await fetchLeaderboard());
    setBoardBusy(false);
  };

  const gateCard = <Glass style={{gap:10}}>
    <Text style={s.rowTitle}>Daily Chat Pass</Text>
    <Text style={s.body}>One entry, unlimited messages until 00:00 UTC. {policy.chatDailyFee} account tokens per day.</Text>
    <Text style={s.body}>Account tokens: {credits.balance===null?'—':credits.balance.toLocaleString()}</Text>
    <Chip label={pledge?'Vibe checked ✓':'Vibe check · I agree to be respectful'} selected={pledge} onPress={()=>setPledge(v=>!v)}/>
    <Text style={s.body}>{CONTENT_NOTICE}</Text>
    {!!(sendError||credits.error)&&<Text accessibilityRole="alert" style={s.err}>{sendError||credits.error}</Text>}
    {!!(sendError||credits.error)&&<Button light title="Retry Credit check" icon="refresh-outline" onPress={()=>{setSendError('');credits.reload();}}/>}
    {!!earnNote&&<Text style={s.ok}>{earnNote}</Text>}
    {user||phase==='restoring'?<Button title={phase==='restoring'?'Checking your account…':passBusy?'Opening…':'Enter for today · '+policy.chatDailyFee+' Credits'} icon="chatbubbles-outline" disabled={!user||passBusy||!pledge||credits.balance===null||credits.balance<policy.chatDailyFee} onPress={()=>void enter()}/>:<Button title="Sign in to enter" onPress={onSignIn}/>}
    <Button light title={earning?'Showing ad…':`Watch an ad · +${TOKENS.REWARDED_AD} Credits`} disabled={earning} onPress={()=>void earn()}/>
    <Button light title="Daily reward" icon="gift-outline" onPress={onOpenDaily}/>
    {paid&&<Button light title="Get Credits" icon="wallet-outline" onPress={onOpenShop}/>}
  </Glass>;

  const reportBox = (title: string, onSubmit: () => void) => <Glass style={s.reportBox}>
    <Text style={s.label}>{title}</Text>
    <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reportReason === r} onPress={() => setReportReason(r)} />)}</View>
    <TextInput accessibilityLabel="Report details" value={reportNote} onChangeText={setReportNote} maxLength={300} multiline style={s.input} placeholder="Details (optional)" placeholderTextColor={C.muted} />
    {!!reportSent && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    <View style={s.reportButtons}>
      <Button title={reportBusy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={reportBusy || !reportReason} onPress={() => void onSubmit()} />
      <Button light title="Cancel" icon="close-outline" onPress={() => {setReporting(null);}} />
    </View>
  </Glass>;

  const chatDisabled = sending || !text.trim() || needsTokens;

  return <KeyboardDock>
  <View style={s.fill}>
    {!keyboardOpen && <View style={s.head}>
      <View style={s.headingRow}>
        <View style={{flex:1}}>
          <Text accessibilityRole="header" style={s.title}>Community</Text>
          <Text style={s.body}>Chat, share and discuss words.</Text>
        </View>
        {paid&&view==='chat' && <Pressable accessibilityRole="button" accessibilityLabel="Get Credits" onPress={onOpenShop} style={s.boardButton}>
          <Icon name="wallet-outline" size={20} color={C.accent}/>
        </Pressable>}
        {view==='chat' && <Pressable accessibilityRole="button" accessibilityLabel={showBoard?'Back to chat':'Credit leaderboard'} accessibilityState={{selected:showBoard}} onPress={()=>{Keyboard.dismiss();setBoardOpen(!boardOpen);}} style={[s.boardButton,showBoard&&s.boardButtonOn]}>
          <Icon name={showBoard?'chatbubbles-outline':'trophy-outline'} size={20} color={C.accent}/>
        </Pressable>}
      </View>
      <View style={s.switcher}>
        <Segment label="Chat" icon="chatbubbles-outline" selected={view === 'chat'} onPress={() => {setBoardOpen(false);setView('chat');}} />
        <Segment label="Posts" icon="newspaper-outline" selected={view === 'posts'} onPress={() => setView('posts')} />
      </View>
    </View>}
    {view==='posts' ? <CommunityPostsPanel active={active} onSignIn={onSignIn} onHistory={onMyPosts} visibleBalance={tokens.balance}/> : <>
    {showBoard ? <ScrollView style={s.scroll} contentContainerStyle={s.list}>
      <View style={s.card}>
        <View style={s.boardHead}>
          <IconTile icon="trophy-outline" from={C.gold} to="#DE8F0E" size={38} iconSize={20} />
          <View style={{flex:1}}><Text style={s.rowTitle}>Top Credit earners</Text><Text style={s.body}>Nicknames only</Text></View>
        </View>
        {board.length === 0 ? <Text style={s.body}>No one has joined yet.</Text> : board.slice(0, 5).map((r, i, arr) => (
          <View key={r.uid} style={[s.boardRow, i === arr.length - 1 && s.boardRowLast, user && r.uid === user.uid && s.boardRowMe]}>
            <View style={[s.rankBadge, i === 0 && s.rankFirst, i === 1 && s.rankSecond, i === 2 && s.rankThird]}><Text style={[s.rankText, i === 2 && s.rankTextLight]}>{i + 1}</Text></View>
            <Text style={[s.boardName, user && r.uid === user.uid && s.boardMe]} numberOfLines={1}>{user && r.uid === user.uid ? 'You' : r.name}</Text><VerifiedBadge verified={badges.has(r.uid)} tier={badges.tier(r.uid)}/>
            <Text style={s.boardTokens}>{r.tokens.toLocaleString()} tokens</Text>
          </View>
        ))}
        <Button light title={user?(tokens.leaderboard?'Leave leaderboard':'Join leaderboard'):'Sign in to join'} icon="trophy-outline" disabled={boardBusy} onPress={()=>user?void toggleBoard(!tokens.leaderboard):onSignIn()}/>
      </View>
    </ScrollView> : <View style={s.room}>
      <View style={s.roomHead}>
        <View style={s.roomTitleRow}><Text accessibilityRole="header" style={s.rowTitle}>Chat Room</Text><View style={[s.liveDot,!!loadError&&{backgroundColor:C.warn}]}/><Text style={s.liveLabel}>{loadError?'Offline':'Live'}</Text></View>
        {!keyboardOpen&&!needsTokens&&<Text style={s.count}>{messages.length} {messages.length===1?'message':'messages'}</Text>}
      </View>
      {!!loadError&&<Text accessibilityRole="alert" style={[s.err,s.roomNotice]}>{loadError}</Text>}
      <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" style={s.scroll} contentContainerStyle={s.roomList}
        scrollEventThrottle={32} onScroll={e=>{const {contentOffset,contentSize,layoutMeasurement}=e.nativeEvent;followLatest.current=contentSize.height-contentOffset.y-layoutMeasurement.height<72;}}
        onContentSizeChange={()=>{if(followLatest.current)scrollRef.current?.scrollToEnd({animated:false});}}>
        {!paid&&<Text style={s.body}>Free chat. No abuse, spam or private information. Violations may lead to account removal.</Text>}
        {needsTokens ? gateCard : <>
          {!messages.length && !loadError && <View style={s.emptyCard}>
            <Icon name="chatbubbles-outline" color={C.accent} size={26}/>
            <Text style={s.rowTitle}>No messages yet</Text><Text style={s.body}>Say hi and start the conversation.</Text>
          </View>}
          {messages.map(m=>{
            const mine=!!user&&m.uid===user.uid;
            return <View key={m.id} style={s.msgWrap}>
              <View style={s.msgHeader}>
                <View style={s.metaRow}>
                  <Text style={s.name} numberOfLines={1}>{mine?'You':m.name}</Text><VerifiedBadge verified={badges.has(m.uid)} tier={badges.tier(m.uid)}/>
                  <Text style={s.time}>{timeOf(m.at)}</Text>
                </View>
                {!!user&&<Pressable accessibilityRole="button" accessibilityLabel={mine?'Delete my message':`Report message from ${m.name}`} style={s.mini}
                  onPress={()=>mine?confirmAction('Delete this message?','It will be removed from the chat room.',()=>void remove(m.id),'Delete'):openReport(m.id)}>
                  <Icon name={mine?'trash-outline':'flag-outline'} size={17} color={C.muted}/>
                </Pressable>}
              </View>
              <Text selectable style={s.text}>{m.text}</Text>
              {reporting===m.id&&reportBox('What’s wrong with this message?',()=>void report(m.id))}
            </View>;
          })}
        </>}
      </ScrollView>
    </View>}
    {!!reportSent && reporting === null && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    {needsTokens || showBoard ? null : user ? <View style={s.composer}>
      <View style={s.composerBar}>
        <TextInput accessibilityLabel="Message to the community" value={text} onChangeText={v => {setText(v); setSendError('');}} onFocus={() => {followLatest.current=true;scrollRef.current?.scrollToEnd({animated:false});}} maxLength={CHAT_MAX_LENGTH} multiline style={s.composerInput} placeholder={`Chat as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
        <Pressable accessibilityRole="button" accessibilityLabel="Send message" disabled={chatDisabled} onPress={() => void send()} style={s.sendBtn}>
          <LinearGradient colors={chatDisabled ? ['#d7e5f7', '#d7e5f7'] : [C.accent, C.purple]} start={{x: 0, y: 0}} end={{x: 1, y: 1}} style={s.sendBtnGrad}>
            <Icon name="paper-plane" size={20} color={chatDisabled ? C.muted : '#fff'} />
          </LinearGradient>
        </Pressable>
      </View>
      <View style={s.composerMeta}>
        <Text style={s.costText}>Free community chat · be respectful</Text>
        <Text style={s.count}>{text.trim().length}/{CHAT_MAX_LENGTH}</Text>
      </View>
      {!!sendError && <Text accessibilityRole="alert" style={s.err}>{sendError}</Text>}
    </View> : phase === 'restoring' ? <View style={[s.card, s.signInCard]}>
      <IconTile icon="sync-outline" from={C.accent} to={C.purple} size={44} iconSize={22} />
      <Text style={s.rowTitle}>Checking your account…</Text>
      <Text style={s.body}>Restoring your saved sign-in. This only takes a moment.</Text>
    </View> : <View style={[s.card, s.signInCard]}>
      <IconTile icon="person-circle-outline" from={C.accent} to={C.purple} size={44} iconSize={22} />
      <Text style={s.rowTitle}>Sign in to chat</Text>
      <Text style={s.body}>Reading is free.</Text>
      <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
    </View>}
    </>}
  </View>
  </KeyboardDock>;
}

/** Segmented Chat / Posts switcher — active half is an accent→purple gradient. */
function Segment({label, icon, selected, onPress}: {label: string; icon: IconName; selected: boolean; onPress: () => void}) {
  return (
    <Pressable accessibilityRole="button" accessibilityState={{selected}} onPress={onPress} style={s.segment}>
      <LinearGradient colors={selected ? [C.accent, C.purple] : ['rgba(0,0,0,0)', 'rgba(0,0,0,0)']} start={{x: 0, y: 0}} end={{x: 1, y: 0}} style={s.segmentFill}>
        <Icon name={icon} size={17} color={selected ? '#fff' : C.muted} />
        <Text style={[s.segmentText, selected && s.segmentTextOn]}>{label}</Text>
      </LinearGradient>
    </Pressable>
  );
}

const s = StyleSheet.create({
  fill: {flex:1,minHeight:0,backgroundColor:C.bg},
  scroll: {flex:1,minHeight:0},
  head: {paddingHorizontal:12,paddingTop:8,paddingBottom:5,gap:8},
  headingRow: {flexDirection:'row',alignItems:'center',gap:8,paddingHorizontal:5},
  boardButton: {width:44,height:44,borderRadius:15,backgroundColor:'#fff',borderWidth:1,borderColor:C.line,alignItems:'center',justifyContent:'center'},
  boardButtonOn: {backgroundColor:'#E3E8FF',borderColor:'#BAC8F4'},
  room: {flex:1,minHeight:0,marginHorizontal:12,marginVertical:5,borderRadius:18,borderWidth:1,borderColor:'#DCE8F5',backgroundColor:'#fff',overflow:'hidden'},
  roomHead: {paddingHorizontal:13,paddingVertical:9,flexDirection:'row',justifyContent:'space-between',alignItems:'center',flexWrap:'wrap',gap:4,borderBottomWidth:1,borderBottomColor:'#E8EFF8'},
  roomTitleRow: {flexDirection:'row',alignItems:'center',gap:7},
  liveDot: {width:7,height:7,borderRadius:4,backgroundColor:'#138659'},
  liveLabel: {fontSize:12,color:C.muted,fontWeight:'700'},
  roomNotice: {paddingHorizontal:13,paddingTop:6},
  roomList: {paddingHorizontal:13,paddingVertical:4},
  switcher: {flexDirection: 'row', backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 18, padding: 4, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 4}, shadowOpacity: 0.08, shadowRadius: 12, elevation: 2},
  segment: {flex: 1, borderRadius: 14, overflow: 'hidden'},
  segmentFill: {flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, minHeight: 44, borderRadius: 14},
  segmentText: {fontSize: 14, fontWeight: '800', color: C.muted},
  segmentTextOn: {color: '#fff'},
  title: {fontSize: 24, lineHeight: 29, fontWeight: '900', letterSpacing: -0.8, color: C.navy},
  body: {fontSize: 14, lineHeight: 20, color: C.muted},
  card: {backgroundColor: '#fff', borderColor: '#dce8f5', borderWidth: 1.5, borderRadius: 20, padding: 14, gap: 10, shadowColor: '#3e6c9a', shadowOffset: {width: 0, height: 6}, shadowOpacity: 0.1, shadowRadius: 14, elevation: 3},
  signInCard: {marginHorizontal: 16, marginBottom: 10},
  emptyCard: {alignItems: 'center', padding: 20, gap: 8},
  gate: {borderRadius: 20, padding: 18, gap: 10, overflow: 'hidden', shadowColor: '#7654F6', shadowOffset: {width: 0, height: 8}, shadowOpacity: 0.3, shadowRadius: 16, elevation: 5},
  gateTitle: {fontSize: 20, fontWeight: '900', letterSpacing: -0.4, color: '#fff'},
  gateBody: {fontSize: 14, lineHeight: 20, color: 'rgba(255,255,255,.85)'},
  gateOk: {fontSize: 13, lineHeight: 19, color: '#fff', fontWeight: '700'},
  boardHead: {flexDirection: 'row', alignItems: 'center', gap: 12},
  boardRow: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderBottomWidth: 1, borderColor: '#eef3fa'},
  boardRowLast: {borderBottomWidth: 0, paddingBottom: 0},
  boardRowMe: {backgroundColor: C.soft, borderRadius: 12, paddingHorizontal: 8, marginHorizontal: -8},
  rankBadge: {width: 28, height: 28, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center'},
  rankFirst: {backgroundColor: C.gold},
  rankSecond: {backgroundColor: '#cbd5e1'},
  rankThird: {backgroundColor: '#d08a4a'},
  rankText: {fontSize: 13, fontWeight: '900', color: C.navy},
  rankTextLight: {color: '#fff'},
  boardName: {flex: 1, fontSize: 15, fontWeight: '700', color: C.navy},
  boardMe: {color: C.accent},
  boardTokens: {fontSize: 14, fontWeight: '800', color: C.goldDeep},
  list: {padding: 12, gap: 10, paddingBottom: 12},
  msgWrap: {paddingTop:5,paddingBottom:9,borderBottomWidth:1,borderBottomColor:'#E8EFF8'},
  msgHeader: {flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:5},
  metaRow: {flex:1,minWidth:0,flexDirection:'row',gap:6,alignItems:'center',minHeight:30},
  name: {flexShrink:1,fontSize:14,fontWeight:'800',color:C.navy},
  time: {fontSize:11,color:C.muted},
  text: {fontSize:15,lineHeight:21,color:C.navy},
  mini: {width:44,minHeight:40,alignItems:'center',justifyContent:'center'},
  reportBox: {width: '100%', marginTop: 8},
  label: {fontSize: 14, color: C.navy, fontWeight: '800'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  reportButtons: {gap: 10},
  ok: {fontSize: 13, lineHeight: 19, color: '#0d6e4a'},
  err: {fontSize: 13, lineHeight: 19, color: '#a23842'},
  composer: {flexShrink:0,backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#dce8f5', paddingHorizontal: 12, paddingTop: 10, paddingBottom: 10, gap: 6},
  composerBar: {flexDirection: 'row', alignItems: 'flex-end', gap: 10},
  composerInput: {flex: 1, minHeight: 48, maxHeight: 120, borderRadius: 22, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  sendBtn: {width: 48, height: 48, borderRadius: 24, overflow: 'hidden', flexShrink: 0},
  sendBtnGrad: {width: 48, height: 48, borderRadius: 24, alignItems: 'center', justifyContent: 'center'},
  composerMeta: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4},
  costText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  costWarn: {color: C.warn},
  count: {fontSize: 12, color: C.muted},
  input: {minHeight: 48, borderRadius: 18, borderWidth: 1, borderColor: '#dce8f5', paddingHorizontal: 16, paddingVertical: 12, fontSize: 16, color: C.navy, backgroundColor: '#F2F7FF'},
  rowTitle: {fontSize: 17, fontWeight: '800', color: C.navy},
});
