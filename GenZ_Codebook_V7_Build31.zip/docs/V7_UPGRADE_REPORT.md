# GenZ Codebook V7 — Build 31 update (after device testing of Build 30)

| Reported | Fix |
|---|---|
| Admin calendar showed no colours | Reserved/scheduled and published dates are green, pending requests amber, past dates grey, with a legend. |
| Portal not V7 / "liquid glass" | New glass theme: frosted cards and top bar, gradient sidebar and buttons, soft colour background, focus rings; reduced-motion respected. |
| Empty dark squares in the portal | The logos were served from `public/` and, when missing, came back as the portal page through the `/admin/**` rewrite. They are now bundled build assets. |
| Portal pages open after a long pause (follow-up) | Root causes: `firebase.json` sent `Cache-Control: no-store` for all of `/admin/**`, so the portal code was re-downloaded on every visit; the Dashboard downloaded the whole 4.9 MB dictionary (~0.44 MB compressed) just to show the entry count; every page switch remounted the page and re-ran all its queries; and card/number animations took up to ~1 s. Fixes: hashed code files are cached for a year (new deploys use new file names), entry pages and the dictionary revalidate via ETag; the Dashboard count comes from the bundled manifest; the dictionary downloads at most once per session; opened pages stay mounted; other pages' code is prefetched after sign-in; animations shortened to ~0.2–0.35 s. A repeat Dashboard visit now downloads only a revalidation check instead of ~640 KB. |
| Portal slow to open | Startup checks run in parallel (admin role + email reload; token + two-step setting), the login audit write no longer blocks, and each page loads on demand (Dashboard prefetched while the session is checked). |
| Encode: weak results, "you → j00", "headach" not converted | The encoder now converts every word or phrase with a sensible code, including community words (HOD), and never uses leetspeak or emoji except everyday codes. The result card highlights codes, with copy and share buttons; tap a code to switch it. |
| 10 free each for Encode and Decode, then Credits | Each has its own free daily allowance (admin: default 10), then a Credit price per conversion (admin: default 5; 0 = free). Charged by the server only after a successful conversion, once per request; an optional ad gives +5. |
| Change Credit prices | Admin Settings → Prices: chat day, post, new word, Daily Code, badge review, Encode, Decode. The server charges the same live price; refunds return what was actually paid. |
| Buy Credits page empty | Always shows what Credits buy, free ways to earn, all 7 packs with their planned prices ($1.99–$25.99) and the Premium (ad-free) monthly/yearly plans. Buttons say "Opens soon" until checkout is enabled. |
| Badge error with an email | The badge box accepts an email or a user ID. Badges are **blue** (verified users) or **gold** (owner/staff, Super Admin only). |
| Badge/profile colour | Seal-style badge beside the name; the profile card is gold for gold badges and blue for blue badges. "Verified badge" is the first row of the profile list. |
| Profile photo missing on posts | Posts and comments show the author's avatar icon and, if they opt in ("Show my photo on my posts"), a 96 px photo from `publicProfiles/{uid}` (owner-written, public read, deleted with the account). The privacy policy and About text were updated. **Also update the Play Data safety form: Photos — optional, shared publicly by user choice.** |

Version code **31**. Firebase changes in this update: `communityFeature` (prices, `convert-fee`, refunds use the paid amount, public card removed on account deletion), Firestore rules (`config/app.prices`, `decodeFreeDaily`, `publicProfiles`, badge `tier`). Deploy **community** again, then rebuild the APK.

Checks for this update: app 154/154 tests, admin 20/20 + production build, backend 11/11 (in-memory Firestore), security scan clean, Android Hermes bundle export passed. Firestore rules and the backend emulator suite run in your GitHub deploy workflow.

---

# GenZ Codebook V7 — Build 30 upgrade report

Source: Build 29 (`GenZ_Codebook_Build29_Deploy_Fix`). Android version code **30** (version name 1.0.0). Package, signing and release credentials are unchanged.

This build fixes the ten priorities in order and adds the parts of the V7 brief listed below. **It is not the whole V7 brief.** Section 8 lists exactly what is still open and what each item needs. Nothing was deployed from this workspace.

## 1. Modifications

| Area | Files |
|---|---|
| Startup speed | `metro.config.js` (new), `src/engine.ts`, `src/discovery.ts`, `src/reviewQueue.ts`, `App.tsx`, `scripts/measure-startup.mts` (new) |
| Sign-in persistence | `src/auth/chunkedStorage.ts` (new), `src/auth/persistence.native.ts`, `src/secure/session.ts`, `src/services.ts` |
| Community | `src/optimistic.ts` (new), `src/CommunityPostsPanel.tsx`, `src/CommunityScreen.tsx` |
| Daily Code (app) | `src/ContributionScreens.tsx` |
| Credits / paid mode | `src/appConfig.ts` (new), `src/publishing.ts`, `src/communityFeatures.ts`, `src/SubmitForms.tsx`, `functions/src/communityPolicy.json` |
| V7 header | `src/AppHeader.tsx` (new), `src/AdRewardButton.tsx`, `App.tsx` |
| Encode Message | `src/encode.ts`, `src/encodeQuota.ts`, `src/EncodePanel.tsx` (new), `App.tsx` |
| Social & support | `shared/brand.ts`, `src/FollowUs.tsx` (new), `src/SettingsScreen.tsx`, `src/AboutScreen.tsx` |
| Wording (Tokens → Credits) | 85 user-facing strings across `src/`, `admin/src/pages/`, `shared/`, `functions/src/` |
| Backend | `functions/src/communityFeatures.ts`, `functions/src/communityEndpoints.ts` |
| Security rules and indexes | `firebase/firestore.rules`, `firebase/firestore.indexes.json` |
| Admin portal | `admin/src/lib/metrics.ts`, `admin/src/pages/Dashboard.tsx`, `admin/src/firebase.ts`, `admin/src/pages/Users.tsx`, `CommunityWorkflow.tsx`, `DailyCodesList.tsx` (new), `Settings.tsx`, `Logs.tsx`, `admin/src/lib/dailyRows.ts` (new) |
| Browser favicon only | `admin/public/favicon.{ico,svg}`, `admin/site/public/favicon.{ico,svg}`, `assets/favicon.png` (Expo **web** favicon), cache-busting `?v=8` in the HTML pages. Android launcher, adaptive and splash icons are untouched. |
| Version | `app.json` versionCode 30, `android/app/build.gradle` default 30 |
| Tests | `functions/tests/community-features.test.cjs` (balances updated for the 50-Credit post), `tests/{optimistic,chunkedStorage,encode,social}.test.ts`, `admin/tests/dailyRows.test.ts`, `functions/tests/{fake-firestore.cjs,credits-daily.fake.test.cjs}` (new); wording/fee/header assertions updated in `tests/{posts,chat,notifications,referral}.test.ts` |

## 2. Fixed bugs and root causes

1. **30-second Home startup.** Before the first frame, the app built all 30 quiz levels (re-sorting ~5,000 words with `localeCompare` for each level) and the full search/decoder index (`normalize` + `toLocaleLowerCase` on every entry): **232,990 locale-sensitive string calls**. On Android, Hermes runs each through a JNI call into java.text, which is why phones took tens of seconds while desktop measurements looked small. All five tabs were also mounted, hidden, at launch, and Expo's default Metro setting (`inlineRequires: false`) evaluated every module (Firebase SDK, billing, ads, all screens) before the first frame.
   *Fix:* ASCII fast path and lazy index (built 1.2 s after Home appears), one ordinal sort, quiz levels generated when Play first opens, each tab mounted on first visit, inline requires on.
2. **Admin 500-Credit grant "did not work".** The admin page showed "Something went wrong" for every Cloud Function error, because its error mapper only knew Firestore error codes. The real reason was never visible. The grant logic itself works: a test grants 500, rejects the duplicate request and spends the Credits on a Daily Code. The portal already requires a verified email, so the remaining server refusals are wrong role, two-step sign-in required (`config/security.adminMfaRequired`) or an inactive target account. Each now shows its own message, and the server separates the role and two-step messages.
3. **Daily Code Confirm button greyed out.** In the app, Confirm stayed disabled until a word *chip* was tapped. Typing "HDOT" in the search box did not select it, and nothing said why the button was disabled. A taken date or a low balance were also silent. In the admin portal, scheduled words such as HDOT appeared only as a calendar cell, with no list or actions.
4. **Chatroom asking signed-in users to sign in.** Screens could not tell "still restoring the saved session" from "signed out", so during startup they showed "Sign in to chat". The session was also stored as one SecureStore value; SecureStore documents a ~2 KB limit per value and a Firebase session can exceed it, so some sessions were not restored after a restart.
6. **Admin Dashboard "This report needs a database index" / "Platform status: Unavailable".** The Users report's learning totals (sum/average of five `stats.*` fields) need a composite index, but the index was never declared in `firebase/firestore.indexes.json`; a code comment wrongly said none was needed. It was created by hand in the console, and the **community** deploy runs with `--force`, which removes indexes that are not in the file. *Fix:* the index is now declared, so every deploy creates and keeps it. The totals are also optional, so user counts and platform status load while the index builds.
5. **Likes and saves taking 2–3 s.** The UI waited for a Firestore transaction plus the next feed snapshot before changing the heart.

## 3. New features

- **Encode Message (Home → Encode).** Converts plain text into codes from the GenZ Codebook dictionary, on the device. "Hello, how are you?" becomes "Hello, hru?" and "to be honest I don't know" becomes "tbh idk". Matching is case-insensitive; punctuation and unmatched words are kept; phrases never join across punctuation. Ordinary single words change only to well-known codes. Tap a code to cycle through alternatives. Copy, Share, Edit and "Decode it" are included. A free daily limit is set by the admin (default 10), and an optional rewarded ad gives +5. A conversion is counted only when something was encoded.
- **V7 header** (per the reference image): GZ mark + wordmark, with the tagline on wider phones; gold Credit pill; blue "Ad +10" pill; bell; avatar with a gradient ring. It stays on one row on narrow phones, and the Credit balance shows on every tab.
- **V7 post card:** gradient avatar, verified badge, time, code chip, "# category" chip, "Meaning:", red heart with count, comment count, and Save/Copy/Share pills (icon-only under 400 px). Likes and saves update instantly and roll back if the server refuses.
- **Daily Code form:** numbered steps; an exact search match is selected automatically; the calendar shows green = reserved, amber = pending, grey = unavailable; the reason Confirm is disabled is shown in a list, with a **Get Credits** button when short.
- **Admin Daily Codes list** with Upcoming / Pending / Approved & scheduled / Published / Rejected / All tabs, and per-row ✓ Approve (with date), ✎ Edit, ⇄ Replace (refunds the requester) and 🗑 Delete (refunds the requester). The applications queue has one-step **Approve & schedule**. Every disabled button explains itself.
- **Admin Credits card:** grant and **deduct** (reason required, never below zero), both with confirmation and idempotent request IDs. If the backend is unreachable, the grant falls back to the audited ledger write.
- **Paid community switch** (admin Settings → Credits): chat day pass 30 · post 50 · new dictionary code 150. It is enforced by the Cloud Function, the app and the Firestore rules. It is **off by default**.
- **Stay connected** (Settings and About): Instagram, Facebook, WhatsApp Channel and Help & Support email. Only these fixed https links open; if a link can't open, it is copied instead. No rewards are offered for following.
- **Browser favicon** from the supplied GZ icon (transparent corners; 16/32/48/64 px .ico, SVG, 196 px PNG).

## 4. Firebase changes (deploy required)

- **`communityFeature` function:**
  - New `deduct-tokens` action (writes ledger type `admin_debit`; the wallet check accepts it only as a negative amount).
  - `daily-admin` gains `approve` with a date (approve and schedule in one step), `edit-schedule` and `replace-schedule` (refunds the requester in full).
  - The scheduler publishes an admin's edited text.
  - Clearer role and two-step messages.
  - Paid create-code / create-post / chat-pass run only when `config/app.paidCommunity` is true.
- **Policy:** `postFee` is now 50 (from 25). The others are unchanged: chat 30/day, dictionary code 150, Daily Code 250, referral +100.
- **Firestore rules:**
  - `config/app` accepts `paidCommunity`, `encodeFreeDaily` and `encodeCreditCost` (type- and range-checked).
  - When paid mode is on, chat messages need an unexpired `chatPasses/{uid}`, and direct free post/code writes are refused.
  - Collections and existing fields are not renamed or deleted. "Credits" is display wording only; the `tokenLedger`, `tokenWallet` and `tokens.*` names stay as they are for compatibility.
- **One new composite index:** `users` on `stats.levels`, `stats.quizzes`, `stats.reviewed`, `stats.saved`, `stats.streak` (admin Dashboard totals). It takes a few minutes to build after deploy.

## 5. Admin portal changes

- **Errors:** the real Cloud Function message is shown (not deployed, session expired, wrong role, two-step required, unreachable, or the server's own text).
- **Users → Credits:** grant/deduct with confirmation, plus a verification-email shortcut if an admin email is ever unverified.
- **Daily Codes:** the new list, Approve & schedule, inline reasons for disabled buttons.
- **Settings:** the Credits switch and Encode limits.
- **Logs:** filters for the new Daily Code and deduction audit actions.
- The V7 *visual* restyle of the portal and the expanded dashboard statistics are **not** in this build.

## 6. Performance (measured)

`node --import tsx scripts/measure-startup.mts` measures the work done before the first screen can paint:

| | Build 29 | Build 30 |
|---|---|---|
| Locale-sensitive string calls before first paint | **232,990** (170,370 `localeCompare`, 31,310 `normalize`, 31,310 `toLocaleLowerCase`) | **0** |
| JS time on desktop Node (relative only) | 318 ms | 127 ms |
| Deferred until after first paint | — | index + 30 levels: 92 ms, 8,588 `normalize` (non-ASCII entries only) |

Desktop Node is much faster than a phone at these calls, so the phone saving is far larger than the desktop numbers suggest. **A real-device cold start has not been measured.** Please time it on the same phone before and after.

## 7. Security and testing results

- App: TypeScript passes; **150/150 tests**. New tests cover instant likes (6), chunked session storage (6: >2 KB sessions, legacy migration, crash safety, Keystore failure, removal, surrogate pairs), Encode Message (8) and social links (3).
- Backend: compiles; **9/9** tests run the real compiled `communityFeatures` against an in-memory Firestore stand-in. They cover a 500 grant with duplicate protection, role checks, deduction limits, a 250-Credit Daily Code with Approve & schedule, an approved code published on its date, an unapproved request never published (automatic word plus refund), edit/replace/delete with refunds, the chat pass charged once per UTC day, and a 50-Credit post refused when short. The stand-in is not the Firestore emulator.
- Admin: TypeScript passes; **20/20 tests**; production build passes.
- Security scan (`scripts/security-scan.mjs`): no findings (a targeted static scan, not a penetration test).
- **Firestore rules: 61/61 passed on the official emulator** in your GitHub Actions deploy run (they could not run in this workspace because the emulator download is blocked).
- **Backend emulator tests** (`functions/tests/community-features.test.cjs`): the first CI run failed 5 of 20 tests. All five were hard-coded to the old 25-Credit post price (for example, expecting 325 instead of 300). They were updated to the 50-Credit price: 15 assertion lines, with no backend code changed. They must pass in your next CI run before deployment continues.
- No device, live Firebase, AdMob or Play test was possible.

## 8. Remaining issues and what each needs

| Item | Status / what is needed |
|---|---|
| Google sign-in | Add the SHA-1 and SHA-256 of the upload key **and** the Play App Signing key in Firebase → Project settings → Android app; download the new `google-services.json`; confirm the Web OAuth client ID used by `src/googleAuth.ts`. |
| Phone number + OTP | Not built. The Firebase JS SDK needs a reCAPTCHA verifier, which React Native lacks; a native auth module (for example `@react-native-firebase/auth`) and a native rebuild are needed. Owner decision. |
| Password visibility toggle, merged profiles across methods | Not done. |
| Credit purchases and ad-free | Still disabled (`tokenPurchasesEnabled: false`). Needs the Play service-account secret, final product IDs (Credit packs plus an explicit ad-free product), and an internal-track test purchase. |
| Rewarded interstitial | Needs a new AdMob ad unit ID. Banner, interstitial and rewarded already exist. UMP consent was not audited. |
| Encode Message charged in Credits | The admin setting is stored but **not charged** in Build 30 (free limit + rewarded ad only). Needs a small server action. |
| Ranked Posts, blue/gold badges, profile upgrade, feedback replies, user search by username, separated Credit-history categories, admin dashboard statistics | Not in this build. |
| V7 restyle of the remaining screens and the admin portal | Partial (header, post cards, Encode, Daily Code form). |
| Learning points vs Credits | Two balances remain: server Credits (spendable) and device-only learning points (games and level unlocks). Merging them is a product decision. |

## 9. APK / AAB status

`npx expo export --platform android --clear` **passed** with inline requires enabled: Hermes bytecode bundle 9.09 MB. No native APK or signed AAB was built here (no Android SDK or signing keys). Build with **Actions → Android APK**, then the existing signed AAB release process. Version code 30 updates Build 29.

## 10. Deployment and Play readiness

1. Your repository uses **ZIP mode**: keep exactly **one** project ZIP at the repository root (this full ZIP) and delete any other `.zip` there. The workflows extract it automatically.
2. Run **Actions → Firestore rules tests**. Do not deploy until it passes. (The deploy workflow also runs the rules and backend tests before it deploys anything.)
3. Run **Actions → Deploy Firebase → community** (rules, Hosting/admin portal, `communityFeature`, scheduler).
4. Run **Actions → Android APK**, install Build 30 over Build 29 and time the cold start.
5. In the admin portal, grant 500 Credits to a test account and confirm the header updates. If it fails, the message now says why.
6. Only then turn on **Settings → Credits → Charge Credits for community features**. Users on Build 29 cannot pay for chat or posts once it is on.
7. Play readiness is **not complete**: Billing, ad-free, Google/phone sign-in, consent and real-device QA remain (section 8).
