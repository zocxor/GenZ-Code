import {collection,doc,getDoc,runTransaction,serverTimestamp,Timestamp,type Transaction} from 'firebase/firestore/lite';
import {auth,db} from '../firebase';
import type {Role} from '../rbac';
import {communityId} from '../../../shared/community';

export async function sparkAdmin(input:Record<string,unknown>):Promise<{data:Record<string,unknown>}>{
  const user=auth.currentUser;if(!user)throw new Error('Sign in as an administrator.');
  const roleDoc=await getDoc(doc(db,'admins',user.uid));
  if(!roleDoc.exists()||roleDoc.get('active')!==true)throw new Error('An active administrator account is required.');
  const role=roleDoc.get('role') as Role;
  const action=String(input.action),command=String(input.command??''),id=String(input.id??'');
  const audit=(tx:Transaction,target:string,verb:string)=>{
    const ref=doc(collection(db,'auditLogs'));
    tx.set(ref,{actor:user.uid,role,action:verb,target,summary:'Free-edition moderation',at:serverTimestamp(),expireAt:Timestamp.fromMillis(Date.now()+365*86400000)});
    return ref.id;
  };
  const result=await runTransaction(db,async tx=>{
    if(action==='badge-admin'){
      const account=await tx.get(doc(db,'users',id));
      if(!account.exists()||(input.verified===true&&account.get('status')!=='active'))throw new Error('Choose an existing user; badge grants require an active account.');
      const ref=doc(db,'verifiedContributors',id),lastAuditId=audit(tx,ref.path,'community.edit');
      tx.set(ref,{verified:input.verified===true,tier:input.tier==='gold'?'gold':'blue',updatedAt:serverTimestamp(),updatedBy:user.uid,lastAuditId});
      return {id};
    }
    if(action==='code-admin'){
      const ref=doc(db,'submissions',id),snap=await tx.get(ref),data=snap.data();
      if(!data||data.status!=='pending')throw new Error('Choose a pending suggestion.');
      if(data.fee>0)throw new Error('This historical paid application requires the payment backend for review/refunds.');
      const wordId=communityId(data.term),word=doc(db,'communityWords',wordId);
      if(command==='approve'&&(await tx.get(word)).exists())throw new Error('This word already exists in Codes.');
      const lastAuditId=audit(tx,ref.path,command==='approve'?'submission.accept':'submission.reject');
      if(command==='approve'){
        const wordAudit=audit(tx,word.path,'submission.accept');
        tx.set(word,{id:wordId,term:data.term,meaning:data.meaning,example:data.example,category:data.category,uid:data.uid,status:'live',createdAt:serverTimestamp(),updatedAt:serverTimestamp(),schema:3,payment:'free',fee:0,lastAuditId:wordAudit});
      }else if(command!=='reject')throw new Error('Choose approve or reject.');
      tx.update(ref,{status:command==='approve'?'accepted':'rejected',reviewedBy:user.uid,reviewedAt:serverTimestamp(),...(command==='approve'?{contentId:wordId}:{}),lastAuditId});
      return {id};
    }
    if(action==='post-admin'){
      const ref=doc(db,'communityPosts',id),snap=await tx.get(ref),data=snap.data();
      if(!data)throw new Error('Post no longer exists.');
      if(data.schema!==3)throw new Error('Use the payment backend for this historical paid post.');
      const lastAuditId=audit(tx,ref.path,'community.'+(command==='delete'?'delete':command==='restore'?'restore':command==='edit'?'edit':'hide'));
      if(command==='delete'){tx.delete(ref);return {id};}
      const status=command==='approve'||command==='restore'?'approved':command==='reject'?'rejected':command==='hide'?'hidden':command==='remove'?'removed':data.status;
      const changes:Record<string,unknown>={lastAuditId,updatedAt:serverTimestamp(),moderatedBy:user.uid};
      if(command==='edit'){changes.meaning=String(input.meaning??'').trim();changes.example=String(input.example??'').trim();changes.category=input.category;}
      else if(['approve','restore','reject','hide','remove'].includes(command)){changes.status=status;changes.hidden=status!=='approved';if(status==='approved')changes.publishedAt=serverTimestamp();}
      else throw new Error('Choose a moderation action.');
      tx.update(ref,changes);return {id};
    }
    if(action==='resolve-post-report'){
      const ref=doc(db,'postReports',id),snapshot=await tx.get(ref),data=snapshot.data();
      if(!data||data.status!=='open')throw new Error('This report was already handled.');
      const post=doc(db,'communityPosts',data.postId),postSnap=await tx.get(post);
      if(command==='remove'&&postSnap.get('schema')!==3)throw new Error('Use the payment backend for a historical paid post.');
      if(command==='remove'){const lastAuditId=audit(tx,post.path,'community.hide');tx.update(post,{status:'removed',hidden:true,updatedAt:serverTimestamp(),lastAuditId});}
      const lastAuditId=audit(tx,ref.path,command==='remove'?'report.resolve':'report.dismiss');
      tx.update(ref,{status:command==='remove'?'resolved':'dismissed',resolvedBy:user.uid,resolvedAt:serverTimestamp(),resolution:command,lastAuditId});return {id};
    }
    if(action==='daily-admin'&&command==='cancel-schedule'){
      const date=String(input.date??''),slot=doc(db,'dailyCodeDates',date),publication=doc(db,'dailyCodePublic',date);
      const [a,b]=await Promise.all([tx.get(slot),tx.get(publication)]);
      if(date<=new Date().toISOString().slice(0,10)||a.get('schema')!==3||b.get('schema')!==3)throw new Error('Choose a future free-edition schedule.');
      audit(tx,slot.path,'content.archive');tx.delete(slot);tx.delete(publication);return {id:date};
    }
    if(action==='daily-admin'&&command==='schedule-word'){
      const date=String(input.date??'');
      if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<=new Date().toISOString().slice(0,10))throw new Error('Choose a future publication date.');
      const slot=doc(db,'dailyCodeDates',date),publication=doc(db,'dailyCodePublic',date);
      const [old,existing]=await Promise.all([tx.get(slot),tx.get(publication)]);
      if(old.exists()||existing.exists())throw new Error('This date is already booked.');
      const word= input.wordSource==='community'?await tx.get(doc(db,'communityWords',String(input.wordId))):input.wordSource==='published'?await tx.get(doc(db,'publishedContent',String(input.wordId))):null;
      let entry:Record<string,unknown>;
      if(input.wordSource==='bundled'){
        const rows=await fetch('/admin/library-index.json').then(r=>{if(!r.ok)throw new Error('Dictionary unavailable.');return r.json();});
        const found=rows.find((r:{id:string})=>r.id===input.wordId);if(!found)throw new Error('Choose a dictionary code.');
        entry={term:found.expression,meaning:found.meaning,category:found.category};
      }else{
        const found=word?.data();if(!found||!(found.status==='live'||found.status==='published'))throw new Error('Choose a public dictionary code.');
        entry={term:found.term,meaning:found.meaning,category:found.category};
      }
      const lastAuditId=audit(tx,publication.path,'content.publish');
      tx.set(publication,{...entry,date,schema:3,wordSource:input.wordSource,wordId:input.wordId,publishedAt:serverTimestamp(),lastAuditId});
      const slotAudit=audit(tx,slot.path,'content.publish');
      tx.set(slot,{...entry,status:'scheduled',schema:3,wordSource:input.wordSource,wordId:input.wordId,createdAt:serverTimestamp(),lastAuditId:slotAudit});
      return {id:date};
    }
    throw new Error('Paid applications and server-generated publication are unavailable in the free edition. Select a public dictionary word to schedule it.');
  });
  return {data:result};
}
