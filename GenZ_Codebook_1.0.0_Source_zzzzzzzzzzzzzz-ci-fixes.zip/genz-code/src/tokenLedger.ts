/**
 * Token ledger: the permanent, server-side record of purchased tokens.
 *
 * Two documents per account:
 *  - users/{uid}/tokenLedger/{txnId}: one append-only entry per transaction.
 *    Purchases use the Google Play order ID as the document ID
 *    (`order-<orderId>`, see shared/tokens.ts purchaseTxnId), so a second
 *    credit for the same order writes the same document and the Firestore
 *    rules (create-only) refuse it. That is the duplicate guard.
 *  - users/{uid}/tokenWallet/wallet: a cache of {balance, purchasedTotal, ...} so the
 *    wallet screen does not have to sum the whole ledger. The ledger is the
 *    record; the wallet is the cache. A future backend (or an admin) can
 *    recompute the wallet from the ledger at any time. The wallet is one
 *    fixed document named `wallet` inside the tokenWallet collection — a
 *    document path needs an even number of segments, so
 *    users/{uid}/tokenWallet on its own is a collection, not a document.
 *
 * Rules enforce: owner + active account, exact keys, create-only ledger
 * entries, purchase amounts exactly matching the product catalog, and
 * server timestamps. What the rules CANNOT prove on the free tier is that a
 * purchase is genuine against Google's servers — that needs the Play Developer
 * API from a backend (layer 2, see src/billing.ts). The ledger still bounds
 * the damage: a forged purchase can only ever credit the catalog amount once
 * per order ID.
 *
 * All functions are best-effort where noted and never throw into the UI
 * except recordPurchaseTxn, whose failure means "do not consume the purchase".
 */
import {accountAuth} from './firebase/app';
import {purchaseTxnId, MIGRATION_TXN_ID, type TokenTxnType} from '../shared/tokens';
import type {Firestore} from 'firebase/firestore/lite';

export type TokenTxnRow = {
  id: string;
  type: TokenTxnType;
  amount: number;
  balanceAfter: number;
  ref?: string;
  productId?: string;
  createdAt: number;
};
export type TokenWallet = {balance: number; earnedTotal: number; purchasedTotal: number; spentTotal: number};

const libs = () => Promise.all([import('firebase/firestore/lite'), import('./firebase/app')]);

function walletFrom(data: Record<string, unknown> | null): TokenWallet {
  return {
    balance: typeof data?.balance === 'number' ? data.balance : 0,
    earnedTotal: typeof data?.earnedTotal === 'number' ? data.earnedTotal : 0,
    purchasedTotal: typeof data?.purchasedTotal === 'number' ? data.purchasedTotal : 0,
    spentTotal: typeof data?.spentTotal === 'number' ? data.spentTotal : 0,
  };
}

async function readWallet(db: Firestore, uid: string): Promise<TokenWallet> {
  const {doc, getDoc} = await import('firebase/firestore/lite');
  const snap = await getDoc(doc(db, 'users', uid, 'tokenWallet', 'wallet'));
  return walletFrom(snap.exists() ? (snap.data() as Record<string, unknown>) : null);
}

/**
 * Record a purchase credit. Returns 'recorded' (with the new balance) or
 * 'duplicate' when this order ID is already in the ledger. Throws on any
 * other failure — the caller must NOT consume the purchase then, so Play
 * keeps it owned and the next reconcile retries it.
 */
export async function recordPurchaseTxn(uid: string, p: {orderId: string; productId: string; purchaseToken: string; tokens: number}): Promise<{status: 'recorded' | 'duplicate'; balanceAfter: number}> {
  const [{doc, getDoc, writeBatch, serverTimestamp, collection, query, where, getDocs, limit}, {cloudDb: dbFn}] = await libs();
  const db = dbFn();
  const txnId = purchaseTxnId(p.orderId);
  const existing = await getDoc(doc(db, 'users', uid, 'tokenLedger', txnId));
  if (existing.exists()) {
    return {status: 'duplicate', balanceAfter: (await readWallet(db, uid)).balance};
  }
  // Defense-in-depth: the purchaseToken is the unique transaction
  // identifier. A replayed token with a different orderId must not credit
  // twice. (The server path enforces this atomically in
  // processedTokens/{purchaseToken}; this client-side check is a
  // best-effort guard for the local-only fallback, not a substitute.)
  try {
    const tokenSnap = await getDocs(query(collection(db, 'users', uid, 'tokenLedger'), where('purchaseToken', '==', p.purchaseToken), limit(1)));
    if (!tokenSnap.empty) {
      return {status: 'duplicate', balanceAfter: (await readWallet(db, uid)).balance};
    }
  } catch {/* the orderId guard above is the primary duplicate check */}
  const wallet = await readWallet(db, uid);
  const balanceAfter = wallet.balance + p.tokens;
  const batch = writeBatch(db);
  batch.set(doc(db, 'users', uid, 'tokenLedger', txnId), {
    type: 'purchase', amount: p.tokens, balanceAfter, ref: p.orderId,
    productId: p.productId, purchaseToken: p.purchaseToken, createdAt: serverTimestamp(),
  });
  batch.set(doc(db, 'users', uid, 'tokenWallet', 'wallet'), {
    balance: balanceAfter, earnedTotal: wallet.earnedTotal,
    purchasedTotal: wallet.purchasedTotal + p.tokens, spentTotal: wallet.spentTotal,
    updatedAt: serverTimestamp(),
  }, {merge: true});
  try {
    await batch.commit();
  } catch (e) {
    // A create-only rule rejection here means a duplicate landed first.
    const again = await getDoc(doc(db, 'users', uid, 'tokenLedger', txnId));
    if (again.exists()) return {status: 'duplicate', balanceAfter: (await readWallet(db, uid)).balance};
    throw e;
  }
  return {status: 'recorded', balanceAfter};
}

/** One-time opening balance for a pre-ledger local balance. Best-effort. */
export async function recordMigrationTxn(uid: string, amount: number): Promise<void> {
  try {
    const [{doc, getDoc, writeBatch, serverTimestamp}, {cloudDb: dbFn}] = await libs();
    const db = dbFn();
    if (amount <= 0) return;
    if ((await getDoc(doc(db, 'users', uid, 'tokenLedger', MIGRATION_TXN_ID))).exists()) return;
    const wallet = await readWallet(db, uid);
    if (wallet.balance > 0 || wallet.purchasedTotal > 0) return; // already has a server record
    const batch = writeBatch(db);
    batch.set(doc(db, 'users', uid, 'tokenLedger', MIGRATION_TXN_ID), {
      type: 'migration', amount, balanceAfter: amount, ref: 'v1-migration', createdAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', uid, 'tokenWallet', 'wallet'), {
      balance: amount, earnedTotal: 0, purchasedTotal: 0, spentTotal: 0, updatedAt: serverTimestamp(),
    }, {merge: true});
    await batch.commit();
  } catch {/* migration is best-effort; never block the app */}
}

/** Recent ledger entries, newest first. Returns [] when signed out or on error. */
export async function fetchTokenTxns(uid: string, limitN = 25): Promise<TokenTxnRow[]> {
  try {
    const [{collection, query, orderBy, limit, getDocs}, {cloudDb: dbFn}] = await libs();
    const snap = await getDocs(query(collection(dbFn(), 'users', uid, 'tokenLedger'), orderBy('createdAt', 'desc'), limit(limitN)));
    return snap.docs.map(d => {
      const data = d.data();
      return {
        id: d.id,
        type: (typeof data.type === 'string' ? data.type : 'adjustment') as TokenTxnType,
        amount: typeof data.amount === 'number' ? data.amount : 0,
        balanceAfter: typeof data.balanceAfter === 'number' ? data.balanceAfter : 0,
        ref: typeof data.ref === 'string' ? data.ref : undefined,
        productId: typeof data.productId === 'string' ? data.productId : undefined,
        createdAt: typeof data.createdAt?.toMillis === 'function' ? data.createdAt.toMillis() : 0,
      };
    });
  } catch {return [];}
}

/** The cached server wallet, or null when there is none yet. */
export async function fetchTokenWallet(uid: string): Promise<TokenWallet | null> {
  try {
    const [{doc, getDoc}, {cloudDb: dbFn}] = await libs();
    const snap = await getDoc(doc(dbFn(), 'users', uid, 'tokenWallet', 'wallet'));
    if (!snap.exists()) return null;
    return walletFrom(snap.data() as Record<string, unknown>);
  } catch {return null;}
}

/** Delete the whole ledger + wallet (account deletion). Best-effort. */
export async function deleteTokenLedger(uid: string): Promise<void> {
  try {
    const [{collection, doc, deleteDoc, getDocs, writeBatch}, {cloudDb: dbFn}] = await libs();
    const db = dbFn();
    const snap = await getDocs(collection(db, 'users', uid, 'tokenLedger'));
    for (let i = 0; i < snap.docs.length; i += 400) {
      const b = writeBatch(db);
      snap.docs.slice(i, i + 400).forEach(d => b.delete(d.ref));
      await b.commit();
    }
    await deleteDoc(doc(db, 'users', uid, 'tokenWallet', 'wallet'));
  } catch {/* account deletion continues regardless */}
}

export function currentUid(): string | null {
  return accountAuth.currentUser?.uid ?? null;
}
