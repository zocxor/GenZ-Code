/**
 * Community chat room: one shared room for everyone, by nickname.
 *
 * The room is for token holders: you need tokens (balance above zero) to get
 * in and use it — earn them by watching an ad, playing quizzes, or buying a
 * package. Every message costs 10 tokens (CHAT_MESSAGE_COST), shown in the
 * composer before you send and deducted only after the message is accepted;
 * the Send button is disabled when the balance is too low. Once you are in
 * the room this session you stay in it even if your balance drops to zero —
 * you just cannot send more until you earn tokens. Guests can read the room
 * once they hold tokens; only signed-in users can post. Messages are screened
 * on the device before sending (see shared/chat.ts) and again by the server rules. Any message can be reported;
 * moderators hide reported messages from the admin portal. The room only
 * shows live messages, newest last, capped at the newest 50.
 *
 * The composer sits in a KeyboardAvoidingView so the keyboard never covers
 * the text box while typing.
 */
import React, {useEffect, useRef, useState} from 'react';
import {View, Text, TextInput, ScrollView, Pressable, StyleSheet, KeyboardAvoidingView, Keyboard} from 'react-native';
import {C, Glass, Button, Chip, Icon} from './ui';
import {useAccountUser} from './services';
import {subscribeChat, sendChatMessage, deleteOwnMessage} from './chat';
import {reportChatMessage, REPORT_REASONS} from './ugc';
import {CHAT_RULES, CHAT_MAX_LENGTH, type ChatMessage} from '../shared/chat';
import {watchRewardedAd} from './ads';
import {fetchLeaderboard, publishLeaderboard, leaveLeaderboard, type LeaderboardRow} from './tokensSync';
import {earnTokens, spendTokens, setLeaderboardOptIn, type Action} from './learning';
import {TOKENS, type TokensState} from '../shared/tokens';

const timeOf = (at: number) => new Date(at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});

export default function CommunityScreen({active, nickname, onSignIn, onOpenShop, onOpenDaily, onGoToPlay, tokens, onTokensAction}: {active: boolean; nickname: string; onSignIn: () => void; onOpenShop: () => void; onOpenDaily: () => void; onGoToPlay: () => void; tokens: TokensState; onTokensAction: (a: Action) => void}) {
  const user = useAccountUser();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loadError, setLoadError] = useState('');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [earning, setEarning] = useState(false);
  const [earnNote, setEarnNote] = useState('');
  const [joined, setJoined] = useState(false);
  // Entry gate: you need tokens to get in. Once you are in this session you
  // stay in the room even if a message spend drops your balance to zero — you
  // just cannot send more until you earn tokens. (The tab stays mounted, so
  // this survives switching tabs; a fresh app launch re-arms the gate.)
  useEffect(() => { if (active && tokens.balance > 0) setJoined(true); }, [active, tokens.balance]);
  const needsTokens = tokens.balance <= 0 && !joined;
  const [reporting, setReporting] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportNote, setReportNote] = useState('');
  const [reportBusy, setReportBusy] = useState(false);
  const [reportSent, setReportSent] = useState('');
  const [board, setBoard] = useState<LeaderboardRow[]>([]);
  const [boardBusy, setBoardBusy] = useState(false);
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    if (!active) return;
    setLoadError('');
    return subscribeChat(setMessages, setLoadError);
  }, [active]);
  useEffect(() => {
    if (!active) return;
    let live = true;
    void fetchLeaderboard().then(rows => {if (live) setBoard(rows);});
    return () => {live = false;};
  }, [active]);
  useEffect(() => {
    if (active) scrollRef.current?.scrollToEnd({animated: true});
  }, [messages, active]);
  // When the keyboard opens, scroll the room to the latest message so the
  // composer and the newest message stay visible above it.
  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () => {
      setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 120);
    });
    return () => show.remove();
  }, []);

  const send = async () => {
    if (sending || !text.trim()) return;
    if (tokens.balance < TOKENS.CHAT_MESSAGE_COST) {
      setSendError(`You need ${TOKENS.CHAT_MESSAGE_COST} tokens to send a message (you have ${tokens.balance}). Watch an ad or collect your daily reward to earn more.`);
      return;
    }
    setSending(true); setSendError('');
    const r = await sendChatMessage(nickname, text);
    setSending(false);
    if (r.ok) {
      // Deduct only after the message is accepted — never twice for one send
      // (the `sending` guard above blocks a second tap while this runs).
      onTokensAction(spendTokens(TOKENS.CHAT_MESSAGE_COST));
      setText('');
    } else setSendError(r.message);
  };

  const earn = async () => {
    if (earning) return;
    setEarning(true); setEarnNote('');
    const rewarded = await watchRewardedAd();
    setEarning(false);
    if (rewarded) {onTokensAction(earnTokens(TOKENS.REWARDED_AD)); setEarnNote(`+${TOKENS.REWARDED_AD} tokens earned. Welcome to the room.`);}
    else setEarnNote('No tokens this time — the ad closed early. Try again when you like.');
  };

  const report = async (id: string) => {
    if (reportBusy || !reportReason) return;
    setReportBusy(true); setReportSent('');
    const r = await reportChatMessage(id, reportReason, reportNote);
    setReportBusy(false);
    if (r.ok) {setReportSent('Report sent. A moderator will review this message.'); setReporting(null); setReportReason(''); setReportNote('');}
    else setReportSent(r.message);
  };

  const remove = async (id: string) => {
    const r = await deleteOwnMessage(id);
    if (!r.ok) setSendError(r.message);
  };

  const toggleBoard = async (on: boolean) => {
    if (boardBusy || !user) return;
    setBoardBusy(true);
    onTokensAction(setLeaderboardOptIn(on));
    if (on) await publishLeaderboard(nickname, tokens.balance);
    else await leaveLeaderboard();
    setBoard(await fetchLeaderboard());
    setBoardBusy(false);
  };

  return <KeyboardAvoidingView style={s.fill} behavior="padding" keyboardVerticalOffset={0}>
  <View style={s.fill}>
    <View style={s.head}>
      <Text style={s.title}>Community</Text>
      <Text style={s.body}>One room. Everyone chatting, by nickname.</Text>
      <Text style={s.rules}>{CHAT_RULES}</Text>
    </View>
    {loadError ? <Glass><Text accessibilityRole="alert" style={s.err}>{loadError}</Text></Glass> : null}
    <ScrollView ref={scrollRef} keyboardShouldPersistTaps="handled" style={s.scroll} contentContainerStyle={s.list}>
      <Glass>
        <View style={s.boardHead}><Icon name="trophy-outline" size={22} color={C.blue} /><Text style={s.rowTitle}>Top token earners</Text></View>
        <Text style={s.body}>Nicknames only.</Text>
        {board.length === 0 ? <Text style={s.body}>No one yet — be first.</Text> : board.slice(0, 10).map((r, i) => (
          <View key={r.uid} style={s.boardRow}>
            <Text style={s.boardRank}>{i + 1}</Text>
            <Text style={[s.boardName, user && r.uid === user.uid && s.boardMe]} numberOfLines={1}>{user && r.uid === user.uid ? 'You' : r.name}</Text>
            <Text style={s.boardTokens}>{r.tokens.toLocaleString()} tokens</Text>
          </View>
        ))}
        {user && <Button title={boardBusy ? 'Please wait…' : tokens.leaderboard ? 'Leave' : 'Join'} icon="trophy-outline" light={tokens.leaderboard} disabled={boardBusy} onPress={() => void toggleBoard(!tokens.leaderboard)} />}
        {!user && <Text style={s.body}>Sign in to join.</Text>}
      </Glass>
      {needsTokens ? <Glass>
        <Icon name="chatbubbles-outline" size={30} color={C.blue} />
        <Text style={s.rowTitle}>You need tokens to join the chat</Text>
        <Text style={s.body}>Earn tokens to join — watch an ad, play, or buy.</Text>
        <Text style={s.body}>Your tokens: {tokens.balance.toLocaleString()}</Text>
        {!!earnNote && <Text accessibilityLiveRegion="polite" style={s.ok}>{earnNote}</Text>}
        <Button title={earning ? 'Showing ad…' : `Watch an ad · +${TOKENS.REWARDED_AD} tokens`} icon="play-circle-outline" disabled={earning} onPress={() => void earn()} />
        <Button title="Daily reward" icon="gift-outline" light onPress={onOpenDaily} />
        <Button title="Premium options" icon="star-outline" light onPress={onOpenShop} />
        <Button title="Play to earn tokens" icon="game-controller-outline" light onPress={onGoToPlay} />
        <Button title="Buy tokens" icon="card-outline" light onPress={onOpenShop} />
        {!user && <Button title="Sign in or create an account" icon="log-in-outline" light onPress={onSignIn} />}
      </Glass> : <>
      {!messages.length && !loadError ? <Glass><Icon name="chatbubbles-outline" size={30} color={C.blue} /><Text style={s.rowTitle}>No messages yet.</Text><Text style={s.body}>Say hi — keep it friendly.</Text></Glass> : null}
      {messages.map(m => {
        const mine = !!user && m.uid === user.uid;
        return <View key={m.id} style={[s.row, mine && s.rowMine]}>
          <View style={[s.bubble, mine ? s.bubbleMine : s.bubbleTheirs]}>
            <View style={s.meta}><Text style={s.name}>{mine ? 'You' : m.name}</Text><Text style={s.time}>{timeOf(m.at)}</Text></View>
            <Text selectable style={s.text}>{m.text}</Text>
            <View style={s.actions}>
              {mine
                ? <Pressable accessibilityRole="button" accessibilityLabel="Delete my message" onPress={() => void remove(m.id)} style={s.mini}><Icon name="trash-outline" size={15} color={C.muted} /><Text style={s.miniText}>Delete</Text></Pressable>
                : <Pressable accessibilityRole="button" accessibilityLabel={`Report message from ${m.name}`} onPress={() => {setReporting(reporting === m.id ? null : m.id); setReportReason(''); setReportNote(''); setReportSent('');}} style={s.mini}><Icon name="flag-outline" size={15} color={C.muted} /><Text style={s.miniText}>Report</Text></Pressable>}
            </View>
          </View>
          {reporting === m.id && <Glass style={s.reportBox}>
            <Text style={s.label}>What’s wrong with this message?</Text>
            <View style={s.wrap}>{REPORT_REASONS.map(r => <Chip key={r} label={r} selected={reportReason === r} onPress={() => setReportReason(r)} />)}</View>
            <TextInput accessibilityLabel="Report details" value={reportNote} onChangeText={setReportNote} maxLength={300} multiline style={s.input} placeholder="Details (optional)" placeholderTextColor={C.muted} />
            {!!reportSent && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
            <View style={s.reportButtons}>
              <Button title={reportBusy ? 'Sending…' : 'Send report'} icon="flag-outline" disabled={reportBusy || !reportReason} onPress={() => void report(m.id)} />
              <Button light title="Cancel" icon="close-outline" onPress={() => setReporting(null)} />
            </View>
          </Glass>}
        </View>;
      })}
      </>}
    </ScrollView>
    {!!reportSent && reporting === null && <Text accessibilityRole="alert" style={s.ok}>{reportSent}</Text>}
    {needsTokens ? null : user ? <View style={s.composer}>
      <TextInput accessibilityLabel="Message to the community" value={text} onChangeText={v => {setText(v); setSendError('');}} onFocus={() => setTimeout(() => scrollRef.current?.scrollToEnd({animated: true}), 300)} maxLength={CHAT_MAX_LENGTH} multiline style={s.input} placeholder={`Chat as ${nickname || 'Code Explorer'}…`} placeholderTextColor={C.muted} />
      <Text style={s.cost}>{TOKENS.CHAT_MESSAGE_COST} tokens per message · Balance: {tokens.balance.toLocaleString()} tokens</Text>
      {!!sendError && <Text accessibilityRole="alert" style={s.err}>{sendError}</Text>}
      <View style={s.sendRow}>
        <Text style={s.count}>{text.trim().length}/{CHAT_MAX_LENGTH}</Text>
        <Button title={sending ? 'Sending…' : tokens.balance < TOKENS.CHAT_MESSAGE_COST ? `Need ${TOKENS.CHAT_MESSAGE_COST - tokens.balance} more tokens` : 'Send'} icon="paper-plane-outline" disabled={sending || !text.trim() || tokens.balance < TOKENS.CHAT_MESSAGE_COST} onPress={() => void send()} />
      </View>
    </View> : <Glass><Icon name="person-circle-outline" size={32} color={C.blue} /><Text style={s.rowTitle}>Sign in to chat</Text><Text style={s.body}>Keeps the room safe. Reading is free.</Text><Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} /></Glass>}
  </View>
  </KeyboardAvoidingView>;
}

const s = StyleSheet.create({
  fill: {flex: 1},
  scroll: {flex: 1},
  head: {paddingHorizontal: 22, paddingTop: 6, gap: 6},
  title: {fontSize: 32, lineHeight: 38, fontWeight: '900', letterSpacing: -1.2, color: C.ink},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  boardHead: {flexDirection: 'row', alignItems: 'center', gap: 8},
  boardRow: {flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6},
  boardRank: {width: 24, fontSize: 15, fontWeight: '900', color: C.blue, textAlign: 'center'},
  boardName: {flex: 1, fontSize: 15, fontWeight: '700', color: C.ink},
  boardMe: {color: C.blue},
  boardTokens: {fontSize: 14, fontWeight: '800', color: C.muted},
  rules: {fontSize: 12, lineHeight: 18, color: C.muted, backgroundColor: 'rgba(255,255,255,.6)', borderRadius: 12, padding: 10, borderWidth: 1, borderColor: '#fff'},
  list: {padding: 22, gap: 12, paddingBottom: 16},
  row: {alignItems: 'flex-start'},
  rowMine: {alignItems: 'flex-end'},
  bubble: {maxWidth: '88%', borderRadius: 18, padding: 12, gap: 4, borderWidth: 1},
  bubbleTheirs: {backgroundColor: 'rgba(255,255,255,.8)', borderColor: '#fff'},
  bubbleMine: {backgroundColor: '#dceaff', borderColor: '#cfe0ff'},
  meta: {flexDirection: 'row', gap: 8, alignItems: 'baseline'},
  name: {fontSize: 13, fontWeight: '800', color: C.blue},
  time: {fontSize: 11, color: C.muted},
  text: {fontSize: 16, lineHeight: 23, color: C.ink},
  actions: {flexDirection: 'row', gap: 8},
  mini: {flexDirection: 'row', gap: 4, alignItems: 'center', minHeight: 28, paddingHorizontal: 4},
  miniText: {fontSize: 12, color: C.muted, fontWeight: '700'},
  reportBox: {width: '100%', marginTop: 8},
  label: {fontSize: 14, color: C.ink, fontWeight: '800'},
  wrap: {flexDirection: 'row', flexWrap: 'wrap', gap: 9},
  reportButtons: {gap: 10},
  ok: {fontSize: 13, lineHeight: 19, color: '#0d6e4a'},
  err: {fontSize: 13, lineHeight: 19, color: '#a23842'},
  composer: {paddingHorizontal: 22, paddingBottom: 10, gap: 8},
  input: {minHeight: 52, borderRadius: 17, borderWidth: 1, borderColor: '#bccfe6', padding: 14, fontSize: 16, color: C.ink, backgroundColor: '#e7f0fb'},
  sendRow: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  count: {fontSize: 12, color: C.muted},
  cost: {fontSize: 12, color: C.muted, fontWeight: '700'},
  rowTitle: {fontSize: 16, fontWeight: '800', color: C.ink},
});
