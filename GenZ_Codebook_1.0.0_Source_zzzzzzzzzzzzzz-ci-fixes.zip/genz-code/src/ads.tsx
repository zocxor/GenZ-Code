/**
 * Google AdMob — token-based model, NOT advertisement-interruption-based.
 *
 * The app earns tokens, not attention. Advertisements appear in exactly one
 * place: a voluntary rewarded ad, shown only when the user taps a button
 * such as "Watch an ad and earn 10 tokens". There are:
 *  - NO banner ads anywhere (not on feature screens, not in dictionary
 *    entries, not in community messages).
 *  - NO interstitial ads, automatic or otherwise. Nothing interrupts
 *    typing, searching, reading, messaging or gameplay.
 *  - NO automatic ad triggers when the user opens Decode, Words,
 *    Community, Play, Send, Suggest or any other feature.
 *
 * Which ID is which:
 *  - App ID (ca-app-pub-9776667186789824~9376759074) identifies the app to the SDK.
 *    It lives in app.json (config plugin + react-native-google-mobile-ads key) and in
 *    android/app/src/main/AndroidManifest.xml. It is never passed to an ad view.
 *  - Rewarded ad unit ID: pays only on the SDK's EARNED_REWARD callback; dev
 *    builds use Google's test rewarded ad. Rewarded ads are opt-in — the user
 *    taps to watch one and earns 10 Code Tokens. They are the only ads that
 *    pay tokens, and no tokens are awarded when the ad is unavailable, fails,
 *    or is closed early.
 *  - Rewarded interstitial unit (ca-app-pub-9776667186789824/6311057124):
 *    recorded, NOT wired — the app has no RewardedInterstitialAd format code.
 *    It lands with a future 25-token "Watch Ad & Earn" button. Do not use it
 *    as a plain interstitial.
 *  - The banner (…/5427038644) and interstitial (…/4760116398) units were
 *    created in AdMob and previously wired, but are no longer used: the
 *    token-based model removes banner and interstitial placements entirely.
 *    The AdMob units still exist in the AdMob account; nothing in the app
 *    references them.
 *
 * While developing, Google's test ads are served instead of the real ones —
 * never tap a real ad in a debug build; AdMob treats that as invalid
 * traffic. Ads are non-personalised, matching the app's privacy stance and
 * avoiding a consent form for basic serving.
 */
import {Platform} from 'react-native';
import {AdEventType, MobileAds, RewardedAd, RewardedAdEventType, TestIds} from 'react-native-google-mobile-ads';
import {IS_DEV} from './secure/config';

export const ADMOB_APP_ID = 'ca-app-pub-9776667186789824~9376759074';
/** Rewarded unit (created in AdMob 2026-11-08). Pays only on the SDK's EARNED_REWARD callback; dev builds use Google's test rewarded ad. */
export const REWARDED_AD_UNIT_ID = 'ca-app-pub-9776667186789824/4151797642';
/** Rewarded interstitial unit (created in AdMob 2026-11-08). NOT wired yet: the app has no RewardedInterstitialAd format code — it lands with a future 25-token "Watch Ad & Earn" button. Do not use it as a plain interstitial. */
export const REWARDED_INTERSTITIAL_AD_UNIT_ID = 'ca-app-pub-9776667186789824/6311057124';

/** Rewarded ad unit ID: Google's test rewarded ad in dev; the real one in release builds, or null until one is created in AdMob. */
export function rewardedAdUnitId(): string | null {
  if (IS_DEV) return TestIds.REWARDED;
  return REWARDED_AD_UNIT_ID || null;
}

let adsStarted = false;
let adsDisabled = false;
const adsDisabledListeners = new Set<(disabled: boolean) => void>();
/**
 * Premium (ad-free) switch. App.tsx sets this from the subscription
 * entitlement (users/{uid}/subscription/current). Banner and interstitial
 * ads were removed from the app under the token-based model, so this switch
 * currently has nothing to hide — it is kept as part of the subscription
 * integration, so the planned "no ads" Premium benefit stays wired if an
 * ad placement ever returns. Rewarded ads stay available — they are opt-in
 * earning, not an interruption. Defaults to ads on; a failed subscription
 * read leaves ads on.
 */
export function setAdsDisabled(disabled: boolean): void {
  if (adsDisabled === disabled) return;
  adsDisabled = disabled;
  adsDisabledListeners.forEach(cb => {
    try {cb(disabled);} catch {/* ignore */}
  });
}
export function onAdsDisabledChange(cb: (disabled: boolean) => void): () => void {
  adsDisabledListeners.add(cb);
  return () => {adsDisabledListeners.delete(cb);};
}
export function isAdsDisabled(): boolean {
  return adsDisabled;
}

/** Initialise the SDK once, Android only, for rewarded ads. Safe to call on every launch; a failure only means no ads. */
export function initAds(): void {
  if (adsStarted || Platform.OS !== 'android') return;
  adsStarted = true;
  void MobileAds().initialize().catch(() => undefined);
}

/**
 * Show one rewarded ad. Resolves true only when the user actually earned the
 * reward (watched to the end); closing early, an error, or no ad unit ID
 * resolves false and pays nothing. The caller credits the tokens.
 */
export function watchRewardedAd(): Promise<boolean> {
  return new Promise(resolve => {
    if (Platform.OS !== 'android') return resolve(false);
    const unitId = rewardedAdUnitId();
    if (!unitId) return resolve(false);
    let done = false;
    const unsubs: (() => void)[] = [];
    const finish = (earned: boolean) => {
      if (done) return;
      done = true;
      for (const u of unsubs) {try {u();} catch {/* ignore */}}
      resolve(earned);
    };
    const ad = RewardedAd.createForAdRequest(unitId, {requestNonPersonalizedAdsOnly: true});
    unsubs.push(
      ad.addAdEventListener(RewardedAdEventType.LOADED, () => {try {ad.show();} catch {finish(false);}}),
      ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, () => finish(true)),
      ad.addAdEventListener(AdEventType.CLOSED, () => finish(false)),
      ad.addAdEventListener(AdEventType.ERROR, () => finish(false)),
    );
    ad.load();
  });
}
