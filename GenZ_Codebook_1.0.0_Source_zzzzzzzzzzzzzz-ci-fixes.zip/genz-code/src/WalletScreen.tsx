/**
 * Wallet: the token balance, what was bought, and the permanent transaction
 * history. The history comes from the account's Firestore ledger
 * (users/{uid}/tokenLedger) — purchases are recorded there before the tokens
 * are credited, so the list survives logout, reinstall and device change.
 * Earned and spent tokens are still device-local in this release; their
 * history joins the ledger in the next wallet update.
 */
import React, {useEffect, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, ActivityIndicator, Linking} from 'react-native';
import {C, Glass, Button, Icon} from './ui';
import {useAccountUser} from './services';
import {fetchTokenTxns, fetchTokenWallet, currentUid, type TokenTxnRow, type TokenWallet} from './tokenLedger';
import {restorePurchases} from './billing';
import {fetchSubscription, reconcileSubscriptions} from './subscription';
import {isPremiumActive, type SubscriptionDoc} from '../shared/subscriptions';
import {watchRewardedAd} from './ads';
import {earnTokens, setTokenBalance, type Action} from './learning';
import {TOKENS, type TokensState} from '../shared/tokens';

const TYPE_LABEL: Record<string, string> = {
  purchase: 'Token purchase',
  subscription: 'Premium tokens',
  migration: 'Opening balance',
  daily: 'Daily reward',
  ad: 'Rewarded ad',
  game: 'Quiz reward',
  spend: 'Spent',
  adjustment: 'Adjustment',
};

function fmtDate(at: number): string {
  if (!at) return '';
  return new Date(at).toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'});
}

export default function WalletScreen({tokens, onTokensAction, onOpenShop}: {tokens: TokensState; onTokensAction: (a: Action) => void; onOpenShop: () => void}) {
  const user = useAccountUser();
  const [wallet, setWallet] = useState<TokenWallet | null>(null);
  const [txns, setTxns] = useState<TokenTxnRow[]>([]);
  const [loading, setLoading] = useState(!!user);
  const [restoring, setRestoring] = useState(false);
  const [restoreMsg, setRestoreMsg] = useState('');
  const [earning, setEarning] = useState(false);
  const [sub, setSub] = useState<SubscriptionDoc | null>(null);

  const refresh = async () => {
    const uid = currentUid();
    if (!uid) {setLoading(false); return;}
    setLoading(true);
    // Reconcile first: an owned purchase that never got credited lands now.
    await restorePurchases().catch(() => {});
    await reconcileSubscriptions().catch(() => {});
    const [w, list, s] = await Promise.all([fetchTokenWallet(uid), fetchTokenTxns(uid), fetchSubscription()]);
    if (w && w.balance !== tokens.balance) onTokensAction(setTokenBalance(w.balance));
    setWallet(w);
    setTxns(list);
    setSub(s);
    setLoading(false);
  };

  useEffect(() => {void refresh();}, []);

  const restore = async () => {
    setRestoring(true);
    setRestoreMsg('');
    const r = await restorePurchases();
    await refresh();
    setRestoreMsg(r.restored > 0 ? `${r.restored} purchase${r.restored > 1 ? 's' : ''} restored to your wallet.` : 'Nothing to restore — every purchase is already credited.');
    setRestoring(false);
  };

  const earnAd = async () => {
    if (earning) return;
    setEarning(true);
    const ok = await watchRewardedAd();
    if (ok) onTokensAction(earnTokens(TOKENS.REWARDED_AD));
    setEarning(false);
  };

  return (
    <ScrollView contentContainerStyle={s.content}>
      <Glass>
        <View style={s.between}>
          <View>
            <Text style={s.eyebrow}>YOUR BALANCE</Text>
            <Text style={s.balance}>{tokens.balance.toLocaleString()} tokens</Text>
          </View>
          <Icon name="wallet-outline" color={C.blue} size={30} />
        </View>
        <View style={s.totals}>
          <View style={s.total}>
            <Text style={s.totalNum}>{wallet ? wallet.purchasedTotal.toLocaleString() : '—'}</Text>
            <Text style={s.totalLabel}>Purchased</Text>
          </View>
          <View style={s.total}>
            <Text style={s.totalNum}>{wallet ? wallet.balance.toLocaleString() : '—'}</Text>
            <Text style={s.totalLabel}>On record</Text>
          </View>
        </View>
        <Text style={s.caption}>“On record” is your balance as stored on your account. If it ever differs from the balance above, opening this screen syncs them.</Text>
      </Glass>

      <Glass>
        <Text style={s.sectionTitle}>Premium subscription</Text>
        {!user ? (
          <Text style={s.body}>Sign in to see your Premium subscription. Premium gives you no ads and tokens every billing period.</Text>
        ) : loading ? (
          <ActivityIndicator color={C.blue} />
        ) : sub && isPremiumActive(sub) ? (
          <>
            <Text style={s.body}>Premium {sub.productId === 'premium_yearly' ? 'Yearly' : 'Monthly'} is active{sub.autoRenewing ? ' and renews automatically' : ' (auto-renew off)'}. Next billing date: {new Date(sub.expiryTime).toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'})}.</Text>
            <Text style={s.caption}>No ads while Premium is active. Your tokens arrive at the start of every billing period.</Text>
            <Button title="Manage in Google Play" icon="settings-outline" light onPress={() => void Linking.openURL('https://play.google.com/store/account/subscriptions?package=com.genzmode.app')} />
          </>
        ) : sub && sub.productId ? (
          <>
            <Text style={s.body}>Your Premium subscription is not active{sub.state === 'SUBSCRIPTION_STATE_CANCELED' ? ' — it was cancelled and ended ' + new Date(sub.expiryTime).toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'}) : sub.state === 'SUBSCRIPTION_STATE_EXPIRED' ? ' — it expired ' + new Date(sub.expiryTime).toLocaleDateString([], {day: 'numeric', month: 'short', year: 'numeric'}) : ''}.</Text>
            <Button title="See Premium plans" icon="star-outline" light onPress={onOpenShop} />
          </>
        ) : (
          <>
            <Text style={s.body}>No Premium subscription. Premium gives you no ads and tokens every billing period.</Text>
            <Button title="See Premium plans" icon="star-outline" light onPress={onOpenShop} />
          </>
        )}
      </Glass>

      <Glass>
        <Text style={s.sectionTitle}>Get more tokens</Text>
        <Button title="Buy tokens" icon="card-outline" onPress={onOpenShop} />
        <Button title={earning ? 'Watching…' : 'Watch an ad · +10 tokens'} icon="play-circle-outline" light disabled={earning} onPress={() => void earnAd()} />
        <Text style={s.caption}>Purchases are charged through Google Play. The rewarded ad is optional and pays only when you watch it through.</Text>
      </Glass>

      <Glass>
        <Text style={s.sectionTitle}>Transaction history</Text>
        <Button title={restoring ? 'Checking…' : 'Restore purchases'} icon="refresh-outline" light disabled={restoring} onPress={() => void restore()} />
        {restoreMsg ? <Text style={s.caption}>{restoreMsg}</Text> : null}
        {!user ? (
          <Text style={s.body}>Sign in to keep a permanent purchase history. Your balance above is on this device only until then.</Text>
        ) : loading ? (
          <ActivityIndicator color={C.blue} />
        ) : txns.length === 0 ? (
          <Text style={s.body}>No transactions yet. Your purchases will be listed here, newest first, with their Google Play order ID.</Text>
        ) : (
          txns.map(t => (
            <View key={t.id} style={s.row}>
              <View style={{flex: 1}}>
                <Text style={s.rowTitle}>{TYPE_LABEL[t.type] ?? t.type}</Text>
                <Text style={s.caption}>{fmtDate(t.createdAt)}{t.ref ? ` · ${t.ref}` : ''}</Text>
              </View>
              <Text style={[s.amount, t.amount >= 0 ? s.pos : s.neg]}>{t.amount >= 0 ? '+' : ''}{t.amount.toLocaleString()}</Text>
            </View>
          ))
        )}
      </Glass>

      <Text style={s.fine}>A purchase is recorded in your history before its tokens are credited, and each Google Play order can only ever credit once. If a payment was pending, it appears here once Google Play confirms it.</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  eyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.6, color: C.blue},
  balance: {fontSize: 28, fontWeight: '900', color: C.ink, letterSpacing: -.5},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  sectionTitle: {fontSize: 20, fontWeight: '800', letterSpacing: -.4, color: C.ink},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  totals: {flexDirection: 'row', gap: 12, marginTop: 14},
  total: {flex: 1, backgroundColor: '#eef4ff', borderRadius: 16, padding: 12, alignItems: 'center', gap: 2},
  totalNum: {fontSize: 18, fontWeight: '900', color: C.ink},
  totalLabel: {fontSize: 11, fontWeight: '700', color: C.muted},
  row: {flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#e3eefb'},
  rowTitle: {fontSize: 15, fontWeight: '800', color: C.ink},
  amount: {fontSize: 16, fontWeight: '900'},
  pos: {color: '#1d7a43'},
  neg: {color: '#a33'},
});
