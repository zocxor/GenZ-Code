# GenZ Codebook backend — Play purchase verification

Three Cloud Functions: `verifyPurchase` (token packages), `verifySubscription`
(Premium subscriptions) and `rtdnHandler` (Real-time Developer
Notifications). They are the only place that decides whether a Google Play
purchase turns into tokens or Premium benefits.

## What it does

`POST /verifyPurchase` with a Firebase ID token and
`{productId, orderId, purchaseToken}`. It:

1. Verifies the Firebase ID token — the uid from the token is the account
   credited (the caller cannot credit another account).
2. Calls the Google Play Developer API (`purchases.products.get`) with a
   Google service account and checks package `com.genzmode.app`, the
   productId, and `purchaseState == 0` (PURCHASED — pending/cancelled are
   rejected and never credited).
3. Credits exactly once, atomically, in one Firestore transaction:
   `processedTokens/{purchaseToken}` + ledger
   `users/{uid}/tokenLedger/order-{orderId}` + wallet
   `users/{uid}/tokenWallet/wallet`. A retry of the same purchaseToken
   returns `verified: true, duplicate: true` and credits nothing again.
4. Returns `{verified, duplicate, tokens, balanceAfter}` (or
   `{verified: false, reason, retryable}`).

The token amount always comes from the server-side catalog in
`src/index.ts` — never from the client.

`POST /verifySubscription` with a Firebase ID token and
`{productId, purchaseToken}`. It:

1. Verifies the Firebase ID token — the uid from the token owns the
   subscription (the caller cannot subscribe another account).
2. Calls the Play Developer API (`purchases.subscriptionsv2.get`) and
   checks the subscription state. Premium is granted while the state is
   ACTIVE, CANCELED (keeps access until the paid period ends) or
   IN_GRACE_PERIOD and the expiry time is in the future.
3. Acknowledges the subscription server-side if Play says it is still
   pending (the client also acknowledges — this is the safety net so a
   subscription is never refunded after 3 days for a missed
   acknowledgement).
4. Atomically writes the entitlement `users/{uid}/subscription/current`
   + the token mapping `subscriptionTokens/{purchaseToken}` + (once per
   billing period, keyed by order ID) the period token grant: ledger
   `users/{uid}/tokenLedger/sub-{orderId}` + wallet. A renewal brings a
   new order ID, so it grants again; a retry of the same order ID grants
   nothing.
5. Returns `{verified, duplicate, productId, tokens, expiryTime, state}`.

`rtdnHandler` (Cloud Pub/Sub, topic `genz-codebook-rtdn`) receives
Google's Real-time Developer Notifications for subscription lifecycle
events (purchase, renewal, cancellation, expiry, revocation, grace
period, hold, pause, restart). For every event it looks up the user by
purchaseToken and re-reads the CURRENT state from Play
(`subscriptionsv2.get`), then updates the entitlement from that
authoritative state. The notification type is only a trigger — the state
always comes from Play, so a duplicate or out-of-order message cannot
corrupt the entitlement.

## Deploy (do these in order)

### 1. Upgrade Firebase to Blaze (required)

Cloud Functions do not run on the free Spark plan. In the Firebase
console, go to Usage and billing → Upgrade to Blaze (pay-as-you-go).
The function itself is tiny; the cost is the Blaze minimum (usually $0
at this volume). Without Blaze, `firebase deploy --only functions`
refuses to run.

### 2. Create the Play service account (Google Cloud Console)

1. Open [Google Cloud Console](https://console.cloud.google.com/) and
   select the project linked to Play Console (or create one).
2. IAM & Admin → Service Accounts → Create service account.
   Name it e.g. `genz-codebook-play-verify`. No role is needed on the
   service account itself — the permission comes from Play Console.
3. On the service account, Keys → Add key → JSON → download the file.
   **This file is a private credential. Never commit it, never paste it
   into chat, never put it in the app.**
4. In Play Console → Setup → API access → Service accounts → Grant
   access → pick the new service account → grant **View financial data,
   manage orders** (or at minimum the permission to read purchases) →
   Invite / Save. Without this grant, the Play Developer API returns
   403 and every verification fails.

### 3. Store the service account as a Firebase secret

From the project root (the folder containing `firebase.json`):

```powershell
firebase functions:secrets:set PLAY_SERVICE_ACCOUNT_JSON
```

When prompted, paste the **entire contents** of the downloaded JSON
file. Verify it is set:

```powershell
firebase functions:secrets:access PLAY_SERVICE_ACCOUNT_JSON
```

(Do not print it in a shared terminal.) The function reads it with
`defineSecret('PLAY_SERVICE_ACCOUNT_JSON')`; the value never lands in
the repo, the app, or the AAB.

### 4. Deploy the function

Two ways — pick one:

**A. GitHub workflow (recommended).** The "Deploy Firebase" workflow now
has a `functions` target, and the default `everything` target includes
functions. It builds the TypeScript and deploys. Run it from Actions →
"Deploy Firebase" → Run workflow → target `functions` (or `everything`).
The secret (step 3) and Blaze (step 1) must be done first, or the
functions step fails.

**B. From your machine.** Build the TypeScript, then deploy:

```powershell
cd functions
npm install
npm run build
cd ..
firebase deploy --only functions
```

After deploy, copy the function URL. It looks like:

```
https://us-central1-gen-z-code-55caf.cloudfunctions.net/verifyPurchase
```

### 5. Point the app at it

In `src/billing.ts`, set:

```ts
export const BILLING_VERIFY_URL = 'https://us-central1-gen-z-code-55caf.cloudfunctions.net/verifyPurchase';
```

In `src/subscription.ts`, set:

```ts
export const SUBSCRIPTION_VERIFY_URL = 'https://us-central1-gen-z-code-55caf.cloudfunctions.net/verifySubscription';
```

Rebuild the app (new zip → CI → internal testing). Until these are set,
the app stays in local-only mode for tokens (it verifies locally and
writes its own ledger, and says so honestly) and subscriptions cannot be
activated at all — a production build refuses to credit a token purchase
or grant Premium without server verification. Once they are set, the
backend does the verification **and** the ledger + wallet + entitlement
writes, atomically; the client only updates its local balance, consumes
the token purchase, or acknowledges the subscription.

### 6. Set up Real-time Developer Notifications (RTDN) — subscriptions only

Without RTDN, renewals and cancellations are still picked up when the
app re-verifies owned subscriptions on start and on Wallet open. RTDN
makes them near-instant and covers the case where the user never opens
the app again. Do this once:

1. Create the Pub/Sub topic in Google Cloud Console (or with gcloud):
   ```powershell
   gcloud pubsub topics create genz-codebook-rtdn --project gen-z-code-55caf
   ```
2. Grant Google's Play notifications service account permission to
   publish to it:
   ```powershell
   gcloud pubsub topics add-iam-policy-binding genz-codebook-rtdn --project gen-z-code-55caf --member=serviceAccount:google-play-developer-notifications@system.gserviceaccount.com --role=roles/pubsub.publisher
   ```
3. In Play Console → Monetize → Monetization setup → Real-time developer
   notifications, set the topic to
   `projects/gen-z-code-55caf/topics/genz-codebook-rtdn` and save.
4. Deploy the functions (step 4) — `rtdnHandler` subscribes to that
   topic. Use Play Console's "Send test notification" to confirm an event
   arrives (check the function logs in Firebase console).

## Test it (before announcing it works)

### Token purchases

1. Deploy the functions and set `BILLING_VERIFY_URL`.
2. Build the internal-testing AAB, upload it, install from Play as a
   license tester.
3. Buy the cheapest package (`tokens_1000`). Confirm the Wallet shows
   +1,000 and the ledger has the transaction.
4. Buy it again — the second purchase is a *new* purchase (new token),
   so it credits again. That is correct: each real purchase credits once.
5. To prove the duplicate guard: buy once, force-close the app before
   the credit lands, reopen — the reconcile must credit it exactly once
   (the second attempt returns `duplicate: true` and does not add
   tokens again).
6. Cancel a purchase at the Play dialog — no tokens, calm message.

### Subscriptions

1. Deploy the functions and set `SUBSCRIPTION_VERIFY_URL`. Create the
   `premium_monthly` and `premium_yearly` subscriptions in Play Console
   (Monetize → Products → Subscriptions) with a monthly and a yearly base
   plan, and activate them.
2. As a license tester on the Play-installed internal-testing build,
   subscribe to Premium Monthly. Confirm: the Wallet shows Premium active
   with the next billing date, +500 tokens, and banner/interstitial ads
   disappear.
3. Cancel auto-renew in Play → Subscriptions. Confirm Premium stays
   active until the expiry date, then turns off (license-tester
   subscriptions renew quickly, so this is observable the same day).
4. Let it renew (license-tester monthly subscriptions renew every 5
   minutes). Confirm +500 tokens arrive again on renewal and the expiry
   extends — and that a duplicate RTDN message does not grant twice.
5. In Play Console, send a test RTDN notification and confirm the
   function logs show the event being processed.
6. Refund the test subscription in Play Console (order management) and
   confirm Premium turns off (RTDN SUBSCRIPTION_REVOKED / the Play state
   becomes EXPIRED).

## Local development

```powershell
cd functions
npm install
npm run typecheck   # tsc --noEmit
npm run build       # tsc -> lib/
```

The Firebase emulator can run the function locally
(`firebase emulators:start --only functions`), but the Play Developer
API call still needs the real service account secret and a real
purchase token — use a license-tester test purchase for that.

## What is NOT in this backend

- No voided-purchases polling. Refunds and revocations arrive via RTDN
  (SUBSCRIPTION_REVOKED / the Play state becoming EXPIRED); a periodic
  `purchases.voidedpurchases.list` sweep is a possible later addition.
- No user data beyond what the ledger and the subscription entitlement
  already store (order ID, product ID, purchase token, token amount,
  balance, subscription state and expiry).
