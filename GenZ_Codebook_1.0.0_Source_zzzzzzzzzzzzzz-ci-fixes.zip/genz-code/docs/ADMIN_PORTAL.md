# Admin portal & Firebase backend — setup and operations (0.9.1)

The portal is a separate web app (`admin/`), hosted on Firebase Hosting at `/admin/`. No admin code or credential ships in the mobile APK. All permissions are enforced by `firebase/firestore.rules`; the portal UI only hides what a role cannot do.

## Quick start with GitHub Actions (no local tools)

1. **Deploy credentials:** Firebase console → Project settings → **Service accounts** → **Generate new private key** (downloads a JSON file). In Google Cloud console → **IAM**, edit the `firebase-adminsdk-…@gen-z-code-55caf.iam.gserviceaccount.com` principal and add the roles **Firebase Admin** and **Service Usage Consumer**. Open the JSON in Notepad, copy everything, and save it as the GitHub repository secret **`FIREBASE_SERVICE_ACCOUNT`**. Then delete the downloaded file. This key can change your Firebase project: never upload it to the repository.
2. **Actions → Deploy Firebase → Run workflow** (untick the two-step box unless you upgraded to Identity Platform). It runs the security-rules tests on the official emulator, and only if they all pass it publishes the Firestore rules and indexes and the admin portal, privacy policy and deletion page.
3. **Make yourself Super Admin:** Authentication → Users → copy your **User UID**. Firestore → **Start collection** `admins` → Document ID = your UID → fields: `role` (string) `super_admin`, `active` (boolean) `true`, `email` (string) your email, `updatedAt` (timestamp) now, `updatedBy` (string) `console`, `lastAuditId` (string) `bootstrap`.
4. Open **https://gen-z-code-55caf.web.app/admin/** and sign in with the app account's e-mail and password (the e-mail must be verified).

**Two-step verification (optional, 0.8.5):** authenticator-app codes need *Firebase Authentication with Identity Platform*, which the Firebase console offers only as a paid upgrade for this project. Admin sign-in therefore uses a verified e-mail + password by default, with the `admins` allow-list, audit log and 30-minute timeout. To require codes later: upgrade, run Deploy Firebase with the two-step box ticked, then create the Firestore document `config/security` with the boolean field `adminMfaRequired = true` (console only; no app or portal can change it). Every admin will then be asked to scan a QR code at their next sign-in. Use a long, unique password for admin accounts in the meantime.

Creating an account in the app never makes it an admin. Admin access exists only in this web portal and only for UIDs listed in `admins`.

## One-time setup (project owner)

1. **Test the rules first** (needs Java 21+): `npm i -g firebase-tools && npm run test:rules`. Do not deploy rules that fail.
2. *(Optional, paid)* **Upgrade Authentication to Identity Platform**, enable TOTP (Deploy Firebase does this), then set `config/security.adminMfaRequired = true`. Until then, rules require a verified e-mail for every admin request but no second factor.
3. In Authentication settings enable **email enumeration protection**, set the **password policy** (12+ characters to match the app), and review **authorized domains** (keep `gen-z-code-55caf.web.app`).
4. Deploy: `firebase deploy --only firestore:rules,firestore:indexes` then `cd admin && npm ci && npm run build && cd .. && firebase deploy --only hosting`.
5. Retention: Firestore TTL policies need a billing account, so they are not deployed. About once a month a Super Admin opens **Audit & security → Delete expired entries** (security events after 90 days, audit entries after 365 days; rules allow deleting only expired entries, and each clean-up is logged). On a paid plan you can instead add TTL policies on `securityEvents.expireAt` and `auditLogs.expireAt` (Firestore → Time-to-live).
6. **Bootstrap the first Super Admin** (console writes bypass rules by design): create an account in the app or portal, copy its UID from Authentication, then in Firestore create `admins/<UID>` with `{role: "super_admin", active: true, email: "<email>", updatedAt: <now>, updatedBy: "console", lastAuditId: "bootstrap"}`. Sign in at `/admin/`, verify your e-mail, enrol an authenticator app, sign in again. Add a **second** Super Admin from the portal (nobody can edit their own role).
7. Create `config/app` from Settings in the portal (UGC on/off, content updates on/off).
8. Enable PITR / scheduled backups (see DATA_RETENTION.md) and Cloud Billing budget alerts.
9. Restrict the Firebase API key in Google Cloud (Identity Toolkit, Token Service, Cloud Firestore only) — see FIREBASE_SECURITY_0.5.md for the JS-SDK caveats.
10. Strongly recommended: enable **App Check** (Play Integrity) for Firestore once a native App Check provider is added; not configured in this release.

## Community words (0.8.3): suggestions that go live instantly

- In the app, **Suggest a word** (Words tab banner, Decode tab, You tab, and "not found" searches) publishes the word to `communityWords/{id}` **immediately**. It appears in everyone's Words list and decoder within about 10 minutes (on the author's phone, instantly), labelled **Community**.
- Requirements enforced by Firestore rules: signed in, **verified e-mail**, active (not suspended) account, at most one submission per 60 s, word/meaning/example within limits, a valid category, **no links, e-mail addresses or phone numbers**, one document per word (no duplicates, no overwriting), kill switch on.
- The app also refuses words already in the dictionary, and sends words caught by its word filter (slurs, sexual content, self-harm phrases) to **Moderation → Word suggestions** instead of publishing them.
- **Moderation → Community words**: Live / Hidden lists with **Hide** and **Restore** (Super Admin, Content Manager, Moderator). Every action is written to the audit log in the same batch. Apps drop hidden words on their next refresh.
- **Settings → "Publish suggested words instantly"**: untick to send every new word to review instead. "Accept word suggestions and reports" remains the master kill switch.
- Reports on community words arrive in **Content reports** with the word's ID (`c-…`); hide it from the Community words list.
- Account deletion scrubs that person's words (text and UID removed; `{id, status: 'removed'}` remains so every app removes the word).
- Hidden words keep their text in the database (so they can be restored) and stay readable through the API; deletion of a contributor's account removes the text.

## Community chat (0.9.0): one room for everyone

- In the app, the **Community** tab opens a single chat room. The room is for token holders: you need tokens (balance above zero) to get in and use it — earn them by watching an ad, playing quizzes, or buying a package; the gate offers all three. Only signed-in users with a **verified e-mail** and an active account can post, by nickname (max 24 characters), one message per 10 s. Messages are capped at 500 characters, **no links, e-mail addresses or phone numbers**.
- Before sending, the app screens each message (sexual content, abuse, hate, threats, self-harm phrases — including leet-speak) and refuses it with a reason. The server rules re-check length, links and the rate limit, so a tampered client cannot flood the room. A client-side filter can be bypassed, so reports and moderator hiding are the backstop.
- Reports on a chat message arrive in **Moderation → Chat reports** (same reasons as content reports). **Moderation → Community chat** lists live/hidden messages with **Hide** and **Restore** (Super Admin, Content Manager, Moderator). Every action is written to the audit log in the same batch (`chat.hide`, `chat.restore`, `chat.report.resolve`, `chat.report.dismiss`). Hiding removes the message from the room immediately.
- **Settings → \"Community chat is open\"**: untick to close the room (posting is refused; reading still works). **Dashboard → Reports & feedback** shows open chat reports.
- Account deletion scrubs that person's messages (text and nickname removed; `{status: 'removed'}` remains) and deletes their chat reports. Users can delete their own messages in the app. Moderators hide messages instead of deleting them; the rules also let a Super Admin delete a message outright (for illegal content), but the portal has no delete button for it.
- Free-tier cost (Spark plan): one room open costs at most 50 reads, then one read per new message; one write + one rate-limit stamp per message. No Cloud Functions are used.

## Ads (0.9.1): banner, interstitial and rewarded

- Google AdMob banner (ad unit `ca-app-pub-9776667186789824/5427038644`) is shown at the bottom of the **Suggest a word** sheet and at the bottom of the **Community** screen, Android only, non-personalised. App ID `ca-app-pub-9776667186789824~9376759074` is in `app.json` (config plugin + `react-native-google-mobile-ads` key) and in `android/app/src/main/AndroidManifest.xml` (the CI build does not run `expo prebuild`, so the manifest entry is what the shipped APK/AAB uses).
- Interstitial (full-screen) shows when the user opens Suggest a word or the Community tab, at most once a minute (`INTERSTITIAL_COOLDOWN_MS` in `src/ads.tsx`); it is preloaded at start-up and never blocks the screen when nothing is ready. Interstitial ad unit `ca-app-pub-9776667186789824/4760116398` is configured (created in AdMob 2026-11-08); new units may take up to an hour to start showing ads, and dev builds use Google's test interstitial.
- Rewarded ad: shown only when the user taps "Watch an ad" in the Suggest form; watching to the end earns 10 Code Tokens. Rewarded ad unit `ca-app-pub-9776667186789824/4151797642` is configured (created in AdMob 2026-11-08); dev builds use Google's test rewarded ad. The rewarded-interstitial unit `ca-app-pub-9776667186789824/6311057124` is recorded in `src/ads.tsx` but NOT wired to any format yet — it lands with the token upgrade's 25-token "Watch Ad & Earn" button (Phase 4).
- Build requirement (0.9.2): the Kotlin compiler must be **2.3.0 or newer**. Google Mobile Ads 25.4.0 was compiled with Kotlin 2.3.0, and the default 2.1.20 compiler cannot read it — the CI build failed with `:react-native-google-mobile-ads:compileReleaseKotlin FAILED` and 19 "Module was compiled with an incompatible version of Kotlin ... metadata is 2.3.0, expected 2.1.0" errors. The version is pinned in `android/build.gradle` (`ext.kotlinVersion` + `kspVersion` + the explicit `kotlin-gradle-plugin:2.3.0` classpath); do not lower it. `kspVersion` is set only because Expo's plugin knows KSP versions up to Kotlin 2.2.20 — no module in this project applies KSP.
- While developing, Google's test ads are served instead of the real ones. Never tap a real ad in a debug build.
- The privacy policy (`admin/site/privacy.html`) and the in-app Threat Shield screen disclose the banner, the interstitial, the rewarded ad and the advertising ID. The Play Console **Data safety** section must be updated by hand (ads + advertising ID collection) before the 0.9.1 release.

## Code Tokens (1.0.0): earn, spend, levels, leaderboard

- The currency lives in the learning state (`tokens` in `src/profile.ts`, pure rules in `shared/tokens.ts`). Earned and spent tokens are **stored on this device only** — they are not part of any sync domain, because a wallet cannot be merged last-writer-wins without losing concurrent earns/spends. Resetting scores leaves the balance alone. The balance and level are included in the learning-data export. Bought tokens are different: every purchase is written to the account's Firestore ledger (`users/{uid}/tokenLedger`, one document per Google Play order ID) and cached in `users/{uid}/tokenWallet/wallet` — see Google Play Billing below.
- Earn: rewarded ad +10 (opt-in tap); first activity of a new day +5, plus +25 every 7th day of a streak; daily reward +10, collected by tap once a day (a popup on first open of the day and a Collect button on the main Decode page; `lastDailyCollect` guards it); quiz +1 per point a new personal best improves by; perfect round +10; Daily Five +15 once per day; a suggested word a moderator accepts +20 (checked when the Suggest form opens; already-paid words are skipped). Instant-live words pay nothing — the publication is the reward.
- Spend: suggest a word 20 (staff — admins and moderators — suggest free; the form shows the balance and the cost, and spends only after the server accepts the word); community message 10 per message (everyone pays, staff included; the composer shows the cost and the balance, and the Send button is disabled when the balance is too low; deducted only after the message is accepted); unlock a quiz level early 50 (You tab → Tokens card; `unlocked()` in `src/games.ts` also accepts tokens-unlocked levels).
- Admin grant (Send tokens): a Super Admin can send tokens to any active user from the admin portal (Users → open a user → "Send tokens", 1–100,000 per grant). It writes an 'adjustment' ledger entry (with an optional note) and updates the user's wallet in one audited batch, so it can never be credited twice. The user sees the tokens the next time they open their Wallet or sign in again. Enforced by the rules (`TOKENS_SEND()` = super_admin only, positive amount, max 100,000, audit-logged); see the rules test 'token grant' (test 36).
- Levels (tokens ladder, separate from the XP ranks): Rookie 0, Chatter 100, Word Explorer 250, Slang Star 500, Code Master 900, Code Legend 1500.
- Quiz levels (Play tab): 34 in total — the 4 hand-written intro stages, then 30 generated levels (3 tracks x 10: Chat, Emoji, Numbers) built on the quiz engine in `src/discovery.ts` (`levelStages()`). Each generated level is seeded from its own id, so it always deals the same five questions. A level unlocks at 60% on the previous one, or early for 50 tokens.
- Leaderboard: opt-in only. When opted in, the app publishes `{name, tokens}` to `leaderboard/{uid}` (nickname + tokens, nothing else); anyone can read the top 20. Rules (`firebase/firestore.rules`) validate the row (name 1–24 chars, tokens 0–1,000,000, only the owner writes their own row). Leaving deletes the entry; account deletion deletes it too. Tokens are client-reported, like synced quiz scores, so the board is for fun — a determined user could inflate them. No admin action is needed; moderators cannot edit the board.

## Google Play Billing (1.0.0): seven token packages

- Library: `react-native-iap` 12.16.4 (Google Play Billing Library 7.0.0, from the library's own defaults). Android only. The app's `android/app/build.gradle` sets `missingDimensionStrategy 'store', 'play'` because the library ships amazon/play store flavors and the app defines none. The Kotlin compiler must stay at **2.3.0** (see the Ads section).
- Products (consumable, IDs must match Play Console exactly; prices live in Play Console, never in code): `tokens_1000`, `tokens_2500`, `tokens_5000`, `tokens_10000`, `tokens_25000`, `tokens_50000`, `tokens_100000`. The catalog and the credit amounts live in `shared/tokens.ts` (`TOKEN_PRODUCTS`); the rules enforce the same table.
- Screens: Buy Tokens (`src/TokenShopScreen.tsx`, from the You tab Tokens card) shows Play's localized prices and launches the official Play purchase dialog; Wallet (`src/WalletScreen.tsx`) shows the balance, purchased total, and the ledger transaction history, plus a Restore purchases button.
- Purchase pipeline (`src/billing.ts`): Play purchase → pure local checks (`shared/billing.ts`: known product, PURCHASED state, order ID + purchase token + receipt, this package) → server verification when `BILLING_VERIFY_URL` is set (`functions/` `verifyPurchase`: Firebase ID-token auth, Play Developer API `purchases.products.get`, atomic credit keyed by `processedTokens/{purchaseToken}` — see `functions/README.md`; until it is deployed the URL stays empty and the client writes its own ledger) → ledger write under the order ID (create-only, rules-enforced — the duplicate guard) → local balance credit → consume (`finishTransaction`, isConsumable) so the package can be bought again. Pending purchases are never credited; cancelled purchases are reported calmly. If any step before consuming fails, the purchase stays owned and the next reconcile (app start, wallet open, Restore button) retries it.
- Verification layers, honestly: (1) local checks + idempotent ledger (free, built in); (2) server verification via the Play Developer API — NOT built yet, needs a backend endpoint + a Google service account with Play Developer API access (Play Console → Setup → API access). Until then, a rooted device could fake a local purchase object, but the ledger still bounds it to the catalog amount once per order ID. (3) Real-time refund push (RTDN) and voided-purchase detection for already-consumed purchases also need that backend.
- Play Console checklist for the admin (the app is NOT operational until a real test purchase completes and credits correctly): merchant account / payments profile set up; the seven products created and active, with per-country pricing; the app uploaded to at least closed testing; license testers added for test purchases. Test purchase flow: install the closed-testing build on a license-tester account, buy the cheapest package, confirm the tokens appear in the wallet and in the ledger.
- Account deletion (`src/sync/firestoreCloud.ts`) deletes the token ledger and the wallet document along with the rest of the account's data.
- Free-tier cost: one leaderboard open costs at most 20 reads; one write per balance change (throttled to once a minute). No Cloud Functions are used.

## Roles

| Role | Can |
|---|---|
| Super Admin | Everything, including roles, settings, audit and security logs, account deletion processing |
| Content Manager | Create/edit/import/export content, submit for review, publish/archive/roll back, review suggestions, moderate reports |
| Moderator | Read content, review suggestions, moderate reports, read accounts (no e-mail), suspend/reactivate |
| Support Admin | Read accounts incl. e-mail and learning history, support notes, suspend/reactivate, process deletion requests, triage feedback |
| Analyst | Dashboard aggregates, read content, export content, read feedback. No e-mail or learning data |

## What is enforced on the server (rules) vs. done in the console

| Action | Where |
|---|---|
| Role checks, MFA requirement, field validation, ownership | Firestore rules |
| Audit entry for every privileged write (same batch, same actor/target/time) | Firestore rules (`audited()`) |
| Publish only after review; public copy written in the same batch; history immutable | Firestore rules |
| Rate limits: sync writes ≥2 s, activity ≥20 s, submissions ≥60 s, security events ≥10 s | Firestore rules |
| Suspend (blocks sync + submissions) | Portal → rules |
| **Disable sign-in** for a suspended user | Firebase Console → Authentication (no Cloud Functions in this release) |
| **Delete the Authentication account** after processing a deletion request | Firebase Console → Authentication |

Optional upgrade: a small Cloud Functions codebase (Blaze plan) could disable/delete Auth users from the portal and compute nightly aggregate stats; intentionally not added because it requires a paid plan and an owner decision.

## Operations checklist

- Weekly: review Security events (admin_access_denied, sync_permission_denied spikes) and open reports.
- Monthly: purge deletion tombstones whose Auth account is gone; apply the retention periods in DATA_RETENTION.md.
- Each release: `npm run security:scan`, `npm audit --omit=dev`, `npm run test:rules`, and build with `--clear`.
