# GenZ Codebook Premium — subscription system

Two Premium subscriptions, sold through Google Play Billing alongside the
seven consumable token packages. This document is the single reference for
the subscription products, the verification flow, and the launch checklist.

## Products (create exactly these in Play Console)

| Product ID | Base plan | Tokens per period | Benefit |
|---|---|---|---|
| `premium_monthly` | `monthly` | 500 | No ads + 500 tokens every month |
| `premium_yearly` | `yearly` | 6000 | No ads + 6000 tokens every year |

Prices are set in Play Console (per-country pricing) — never in code.
The token grant and the base-plan IDs are the single source of truth in
`shared/subscriptions.ts` (client) and `functions/src/index.ts`
(`SUBSCRIPTION_CATALOG`, backend). Change them in both places if the offer
changes. Rewarded ads stay available for subscribers — they are opt-in
earning, not an interruption.

## How a subscription is granted (never skip a step)

1. **Buy** — the app fetches the subscription products from Play
   (`fetchProducts({type: 'subs'})`), then opens the official Google Play
   subscription dialog with the base plan's offer token
   (`requestPurchase({type: 'subs', subscriptionOffers: [{sku, offerToken}]})`).
2. **Verify** — the purchase is POSTed to `verifySubscription`. The backend
   calls the Play Developer API (`purchases.subscriptionsv2.get`) and checks
   the state is ACTIVE, CANCELED (keeps access until the paid period ends)
   or IN_GRACE_PERIOD with an unexpired period.
3. **Acknowledge** — only after the backend verifies, the client
   acknowledges the purchase with Google Play. A subscription that is never
   acknowledged is refunded by Google after 3 days. The backend also
   acknowledges server-side as a safety net, via the **v1**
   `purchases.subscriptions.acknowledge` endpoint (there is no v2
   acknowledge method; the subscription ID is the product ID).
4. **Entitlement** — the backend atomically writes
   `users/{uid}/subscription/current` (product, base plan, purchase token,
   state, expiry, auto-renew, order IDs) + `subscriptionTokens/{token}`
   (token → uid, for RTDN) + the period token grant (ledger
   `users/{uid}/tokenLedger/sub-{orderId}` + wallet). The grant is
   idempotent per order ID: a renewal brings a new order ID and grants
   again; a retry of the same order ID grants nothing.
5. **Premium in the app** — the app reads the entitlement document.
   Premium is active while the state is ACTIVE, CANCELED or
   IN_GRACE_PERIOD and the expiry time is in the future. No ads while
   premium is active (`setAdsDisabled`). Banner and interstitial ads were
   removed from the app under the token-based model, so this currently means
   no ad placements of any kind.
   A subscription in the PENDING state (created but awaiting payment) never
   grants Premium and never grants tokens — Google's rule, enforced by the
   premium-state check and the token-grant condition.

   **Not available yet:** until the verification backend is deployed and
   `SUBSCRIPTION_VERIFY_URL` is set, the Premium section shows a clear
   "Premium is not available yet" status and no purchase is accepted
   (`isSubscriptionPurchaseEnabled()` gates the Subscribe buttons; the
   purchase function itself also refuses without the URL). The plans, the
   screens and the integration stay in place for later activation.

There is **no local-only fallback for subscriptions** — not even in debug
builds. If `SUBSCRIPTION_VERIFY_URL` is empty, a subscription purchase
cannot be activated and the client says so plainly. The purchase stays
unacknowledged (Google refunds it after 3 days), so no one pays for a
benefit they did not receive. The same production guard applies to token
purchases (`src/billing.ts`).

## Lifecycle (renewals, cancellations, expiry, refunds)

- **Renewal** — Google charges the next period and publishes RTDN
  `SUBSCRIPTION_RENEWED`. The handler re-reads the state from Play, the
  new order ID grants the period's tokens, and the expiry extends.
- **Cancellation (auto-renew off)** — the user cancels in Play. The state
  becomes CANCELED but Premium stays active until the expiry date (the
  period was paid for). After expiry the state becomes EXPIRED and Premium
  turns off. Manage link: the Wallet's "Manage in Google Play" button
  opens the Play subscriptions page for this app.
- **Grace period** — payment fails but Google grants a grace period.
  State IN_GRACE_PERIOD: Premium stays on. If payment recovers, the state
  returns to ACTIVE; if not, it becomes ON_HOLD then EXPIRED.
- **On hold / paused** — Premium is off (access suspended) until the
  subscription recovers.
- **Refund / revocation** — Play publishes RTDN `SUBSCRIPTION_REVOKED`
  (or the state becomes EXPIRED). The handler re-reads Play, and if Play
  has no subscription for the token it clears the entitlement, so Premium
  turns off.
- **Missed RTDN** — the app re-verifies owned subscriptions on start and
  on Wallet open (`reconcileSubscriptions`), so a status change is picked
  up even if an RTDN message was missed.

## RTDN setup (once, manual)

1. Create the Pub/Sub topic:
   `gcloud pubsub topics create genz-codebook-rtdn --project gen-z-code-55caf`
2. Grant Google's Play notifications service account publish permission:
   `gcloud pubsub topics add-iam-policy-binding genz-codebook-rtdn --project gen-z-code-55caf --member=serviceAccount:google-play-developer-notifications@system.gserviceaccount.com --role=roles/pubsub.publisher`
3. Play Console → Monetize → Monetization setup → Real-time developer
   notifications → topic
   `projects/gen-z-code-55caf/topics/genz-codebook-rtdn`.
4. Deploy the functions — `rtdnHandler` subscribes to that topic.
   See `functions/README.md` §6.

## Files

- `shared/subscriptions.ts` — catalog, states, `isPremiumActive`.
- `src/subscription.ts` — client purchase + verify + acknowledge + reconcile.
- `src/billing.ts` — routes subscription purchases to `src/subscription.ts`;
  loads subscription products alongside token packages.
- `src/TokenShopScreen.tsx` — Premium section (two plans, Subscribe buttons, "Not available yet" status until the backend is deployed).
- `src/WalletScreen.tsx` — Premium status card + Manage in Google Play.
- `App.tsx` — reads the entitlement on sign-in, turns ads off while premium.
- `src/ads.tsx` — `setAdsDisabled` (kept for the subscription integration; banner and interstitial ads were removed, so it currently has nothing to hide).
- `functions/src/index.ts` — `verifySubscription` + `rtdnHandler`.
- `firebase/firestore.rules` — subscription doc: owner read, backend-only
  write; `subscriptionTokens`: backend-only.
- `firebase/rules-tests/rules.test.mjs` — tests 38, 39.
- `tests/subscriptions.test.ts` — premium-state unit tests.

## Launch checklist (subscriptions)

- [ ] Blaze plan active (Functions do not run on Spark).
- [ ] Play service account created + granted in Play Console → API access.
- [ ] `PLAY_SERVICE_ACCOUNT_JSON` secret set in Firebase.
- [ ] Functions deployed (`verifyPurchase`, `verifySubscription`, `rtdnHandler`).
- [ ] `BILLING_VERIFY_URL` + `SUBSCRIPTION_VERIFY_URL` set in the app, rebuilt.
- [ ] `premium_monthly` + `premium_yearly` created in Play Console with
      base plans `monthly` / `yearly`, prices set, Active.
- [ ] RTDN topic created, publisher granted, topic set in Play Console.
- [ ] License-tester subscribe → Premium active + 500 tokens + ads off.
- [ ] License-tester renewal → tokens again, expiry extends, no double grant.
- [ ] Cancel auto-renew → Premium until expiry, then off.
- [ ] Refund test → Premium off.
- [ ] Test RTDN notification from Play Console arrives in function logs.
