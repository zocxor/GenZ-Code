/**
 * Billing verification tests (pure logic in shared/billing.ts).
 *
 * These cover the client-side layer: a purchase is only creditable when it
 * is a known product, in the PURCHASED state, with a Play order ID, a purchase
 * token, and a matching package name. No receipt is required: react-native-iap
 * 15.x returns an empty transactionReceipt on Android, so requiring one would
 * reject every real purchase. The duplicate guard (one ledger document per
 * order ID) is enforced by the Firestore rules and covered by
 * firebase/rules-tests/rules.test.mjs, not here.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {verifyPurchaseRecord, PURCHASE_STATE, BILLING_PACKAGE} from '../shared/billing';

const good = {
  productId: 'tokens_5000',
  orderId: 'GPA.1234-5678-9012-34567',
  purchaseToken: 'purchase-token-abc',
  purchaseState: PURCHASE_STATE.PURCHASED,
  packageName: BILLING_PACKAGE,
};

test('billing: a real PURCHASED purchase verifies, with exactly the catalog amount', () => {
  const r = verifyPurchaseRecord(good);
  assert.equal(r.ok, true);
  if (r.ok) {
    assert.equal(r.productId, 'tokens_5000');
    assert.equal(r.tokens, 5000);
    assert.equal(r.orderId, 'GPA.1234-5678-9012-34567');
  }
});

test('billing: every package verifies at its own amount', () => {
  for (const [id, tokens] of [['tokens_1000', 1000], ['tokens_2500', 2500], ['tokens_10000', 10000], ['tokens_25000', 25000], ['tokens_50000', 50000], ['tokens_100000', 100000]] as const) {
    const r = verifyPurchaseRecord({...good, productId: id});
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.tokens, tokens);
  }
});

test('billing: pending and unspecified purchases are never creditable', () => {
  const pending = verifyPurchaseRecord({...good, purchaseState: PURCHASE_STATE.PENDING});
  assert.equal(pending.ok, false);
  if (!pending.ok) assert.match(pending.reason, /pending/i);
  assert.equal(verifyPurchaseRecord({...good, purchaseState: PURCHASE_STATE.UNSPECIFIED}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseState: undefined}).ok, false);
});

test('billing: unknown products, missing order IDs and missing tokens are refused', () => {
  assert.equal(verifyPurchaseRecord({...good, productId: 'tokens_999'}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, productId: 'tokens_5000 '}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, orderId: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, orderId: undefined}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseToken: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseToken: undefined}).ok, false);
});

test('billing: a purchase for another package is refused', () => {
  assert.equal(verifyPurchaseRecord({...good, packageName: 'com.other.app'}).ok, false);
  // No package name reported at all is tolerated (older Play responses omit it).
  assert.equal(verifyPurchaseRecord({...good, packageName: undefined}).ok, true);
});

test('billing: no receipt is required — react-native-iap 15.x returns an empty receipt on Android', () => {
  // The native layer never sets transactionReceipt, so a purchase with an
  // empty or absent receipt must still verify. The purchase token is the
  // credential the backend checks against Google's servers.
  assert.equal(verifyPurchaseRecord({...good}).ok, true);
});

test('billing: root tsconfig excludes functions/ — the apk job never installs functions/node_modules', () => {
  // CI failure 2026-11-09: the apk job's `tsc --noEmit` (root) tried to
  // type-check functions/src/index.ts, but the apk job never runs `npm ci`
  // in functions/, so firebase-admin / firebase-functions / googleapis were
  // missing (TS2307) and the gate failed. functions/ has its own tsconfig
  // and its own typecheck in the Deploy Firebase workflow — the root
  // typecheck must not cover it.
  const tsconfig = JSON.parse(readFileSync('tsconfig.json', 'utf8')) as {exclude?: string[]};
  assert.ok(Array.isArray(tsconfig.exclude), 'tsconfig has an exclude list');
  assert.ok(tsconfig.exclude!.includes('functions'), 'root tsconfig excludes functions/');
  // functions/ still has its own tsconfig + typecheck (the deploy workflow runs it).
  const fnTsconfig = JSON.parse(readFileSync('functions/tsconfig.json', 'utf8')) as {include?: string[]};
  assert.ok(fnTsconfig.include?.includes('src'), 'functions/tsconfig.json still covers its own src');
});

test('billing: react-native-iap is 15.x — 14.0.0 broke the Play AAB Gradle build', () => {
  // CI failure 2026-11-09: react-native-iap 14.0.0's generated Nitro spec
  // calls super.updateNative(), which react-native-nitro-modules 0.37.2
  // does not have — :react-native-iap:compileReleaseKotlin FAILED and the
  // play-aab job failed. 15.0.0+ generates a spec without updateNative.
  const pkg = JSON.parse(readFileSync('package.json', 'utf8')) as {dependencies?: Record<string, string>};
  const iap = pkg.dependencies?.['react-native-iap'] ?? '';
  assert.ok(iap.startsWith('^15.') || iap.startsWith('15.'), `react-native-iap is 15.x, got ${iap}`);
  const installed = JSON.parse(readFileSync('node_modules/react-native-iap/package.json', 'utf8')) as {version?: string};
  assert.ok(installed.version?.startsWith('15.'), `installed react-native-iap is 15.x, got ${installed.version}`);
});
