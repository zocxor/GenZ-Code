/**
 * Subscription entitlement tests (pure logic in shared/subscriptions.ts).
 *
 * These cover the client-side premium decision: a subscription is premium
 * while the backend-recorded state is ACTIVE, CANCELED (keeps access until
 * the paid period ends) or IN_GRACE_PERIOD and the expiry time is in the
 * future. The entitlement itself is written only by the backend
 * (verifySubscription + the RTDN handler); the client only reads it, and
 * the Firestore rules (firebase/rules-tests/rules.test.mjs) enforce that.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {SUBSCRIPTION_PRODUCTS, subscriptionForProduct, isSubscriptionProduct, isPremiumActive, type SubscriptionDoc} from '../shared/subscriptions';

const base: SubscriptionDoc = {
  productId: 'premium_monthly',
  basePlanId: 'monthly',
  purchaseToken: 'sub-token-1',
  state: 'SUBSCRIPTION_STATE_ACTIVE',
  expiryTime: new Date(Date.now() + 30 * 86400_000).toISOString(),
  autoRenewing: true,
  acknowledged: true,
  lastOrderId: 'GPA.2',
  lastTokenGrantOrderId: 'GPA.2',
  updatedAt: null,
};

test('subscriptions: the catalog has exactly the two Premium products with their base plans and token grants', () => {
  assert.equal(SUBSCRIPTION_PRODUCTS.length, 2);
  const monthly = subscriptionForProduct('premium_monthly');
  assert.equal(monthly?.basePlanId, 'monthly');
  assert.equal(monthly?.tokensPerPeriod, 500);
  const yearly = subscriptionForProduct('premium_yearly');
  assert.equal(yearly?.basePlanId, 'yearly');
  assert.equal(yearly?.tokensPerPeriod, 6000);
  assert.equal(subscriptionForProduct('tokens_1000'), null);
  assert.equal(isSubscriptionProduct('premium_monthly'), true);
  assert.equal(isSubscriptionProduct('tokens_1000'), false);
});

test('subscriptions: ACTIVE and IN_GRACE_PERIOD are premium while unexpired', () => {
  assert.equal(isPremiumActive(base), true);
  assert.equal(isPremiumActive({...base, state: 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'}), true);
});

test('subscriptions: CANCELED keeps premium until the paid period ends', () => {
  assert.equal(isPremiumActive({...base, state: 'SUBSCRIPTION_STATE_CANCELED'}), true);
  assert.equal(
    isPremiumActive({...base, state: 'SUBSCRIPTION_STATE_CANCELED', expiryTime: new Date(Date.now() - 1000).toISOString()}),
    false,
  );
});

test('subscriptions: expired, on-hold, paused, pending and pending-canceled are not premium', () => {
  for (const state of [
    'SUBSCRIPTION_STATE_EXPIRED',
    'SUBSCRIPTION_STATE_ON_HOLD',
    'SUBSCRIPTION_STATE_PAUSED',
    'SUBSCRIPTION_STATE_PENDING',
    'SUBSCRIPTION_STATE_PENDING_PURCHASE_CANCELED',
    'SUBSCRIPTION_STATE_UNSPECIFIED',
  ] as const) {
    assert.equal(isPremiumActive({...base, state}), false);
  }
  assert.equal(isPremiumActive({...base, expiryTime: new Date(Date.now() - 1000).toISOString()}), false);
  assert.equal(isPremiumActive(null), false);
});

test('subscriptions: Premium shows "Not available yet" and accepts no purchase until the backend is deployed', () => {
  const shop = readFileSync('src/TokenShopScreen.tsx', 'utf8');
  // The shop gates the Subscribe buttons on the backend being deployed.
  assert.ok(shop.includes('isSubscriptionPurchaseEnabled()'), 'shop checks the backend gate');
  assert.ok(shop.includes('Premium is not available yet.'), 'clear Not available yet status');
  assert.ok(shop.includes('No purchase is accepted until then'), 'no purchase accepted');
  // The gate itself: empty URL means not enabled.
  const sub = readFileSync('src/subscription.ts', 'utf8');
  assert.ok(sub.includes("export const SUBSCRIPTION_VERIFY_URL = '';"), 'verify URL empty until deployed');
  assert.ok(sub.includes('export function isSubscriptionPurchaseEnabled(): boolean'), 'gate helper exists');
  assert.ok(sub.includes('return SUBSCRIPTION_VERIFY_URL.length > 0;'), 'gate is the URL being set');
  // The purchase function itself also refuses without the URL (defense in depth).
  assert.ok(sub.includes("if (!SUBSCRIPTION_VERIFY_URL) {"), 'purchase refuses without the URL');
  // The screens and integration stay in place — nothing is removed.
  assert.ok(shop.includes('GenZ Codebook Premium'), 'Premium section stays');
  assert.ok(shop.includes('premium_monthly') || shop.includes('Premium Monthly'), 'monthly plan stays');
  assert.ok(shop.includes('premium_yearly') || shop.includes('Premium Yearly'), 'yearly plan stays');
});
