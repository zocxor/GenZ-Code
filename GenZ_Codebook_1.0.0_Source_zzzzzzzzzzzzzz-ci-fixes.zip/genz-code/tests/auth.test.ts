import {test} from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';import {accountError,validateCredentials,secureStorageKey} from '../src/auth/policy';import config from '../src/auth/firebaseConfig.json';
test('Firebase public client configuration belongs to the supplied project and contains no admin secrets',()=>{assert.equal(config.projectId,'gen-z-code-55caf');assert(config.apiKey.startsWith('AIza'));assert.deepEqual(Object.keys(config).sort(),['apiKey','projectId']);});
test('credential validation permits existing short passwords but requires stronger new passwords',()=>{assert.equal(validateCredentials('person@example.com','old123'),null);assert(validateCredentials('person@example.com','old123',true));assert.equal(validateCredentials('person@example.com','longer-passphrase',true),null);assert(validateCredentials('broken','longer-passphrase'));assert(validateCredentials('person@example.com',''));});
test('UI never exposes raw Firebase errors, tokens or account-existence details',()=>{for(const code of ['auth/user-not-found','auth/wrong-password','auth/invalid-credential'])assert.equal(accountError({code,message:'secret-token person@example.com'}),'The email or password is incorrect.');assert(!accountError({code:'unknown',message:'secret-token'}).includes('secret-token'));assert(accountError({code:'auth/operation-not-allowed'}).includes('project owner'));});
test('encrypted-storage key encoding preserves identity without invalid native characters',()=>{const inputs=['firebase:authUser:key:GenZCodeAccount','firebase_authUser_key_GenZCodeAccount','a.b','a_b','a:b','a%3Ab','_3a_'];const keys=inputs.map(secureStorageKey);assert.equal(new Set(keys).size,inputs.length);for(const key of keys)assert(/^[a-zA-Z0-9._-]+$/.test(key));});

test('Google sign-in is wired: native flow exchanges an ID token for a Firebase credential, and the button is real', () => {
  const googleAuth = readFileSync('src/googleAuth.ts', 'utf8');
  // The flow: configure with the web client ID, check Play services, sign in
  // with Google, exchange the ID token for a Firebase credential.
  assert.ok(googleAuth.includes("GoogleSignin.configure({webClientId: GOOGLE_WEB_CLIENT_ID})"), 'configure with web client ID');
  assert.ok(googleAuth.includes('GoogleSignin.hasPlayServices()'), 'Play services check');
  assert.ok(googleAuth.includes('GoogleSignin.signIn()'), 'native Google sign-in');
  assert.ok(googleAuth.includes('GoogleAuthProvider.credential(idToken)'), 'ID token exchanged for Firebase credential');
  assert.ok(googleAuth.includes('signInWithCredential(accountAuth,'), 'Firebase sign-in with the credential');
  // Without a web client ID the flow returns a clear setup message, never a
  // cryptic native error and never a fake success.
  assert.ok(googleAuth.includes("if (!GOOGLE_WEB_CLIENT_ID)"), 'missing web client ID is handled');
  assert.ok(googleAuth.includes('not set up yet'), 'setup message');
  // The account screen has a real Continue with Google button when the web
  // client ID is set, and a setup note when it is not — not a dead label.
  const account = readFileSync('src/AccountScreen.tsx', 'utf8');
  assert.ok(account.includes("import {signInWithGoogle, isGoogleSignInConfigured} from './googleAuth'"), 'account screen imports the Google flow');
  assert.ok(account.includes("'Continue with Google'"), 'real Google button');
  assert.ok(account.includes('isGoogleSignInConfigured()'), 'button gated on configuration');
  assert.ok(!account.includes('Not configured</Text>'), 'no dead Not configured label');
});
