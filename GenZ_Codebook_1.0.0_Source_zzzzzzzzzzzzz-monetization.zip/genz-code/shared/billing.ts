/**
 * Google Play purchase verification — pure checks, no React Native, no
 * Firebase — so the rules are unit-tested in Node.
 *
 * What this checks (client-side layer 1):
 *  - the product is one of the seven token packages, and the credit is exactly
 *    that package's token count (never a number from the purchase payload)
 *  - the purchase is in the PURCHASED state (never PENDING or unspecified)
 *  - a Google Play order ID and a purchase token are both present
 *  - the package name, when Play reports one, is this app
 *
 * No signed transaction receipt is required. react-native-iap 14.x (the
 * Nitro rewrite) returns `transactionReceipt: ''` for every Android
 * purchase — the native layer never sets it — so requiring one would reject
 * every real purchase. The purchase token is the verification credential:
 * the backend checks it against Google's servers with the Play Developer
 * API (layer 2), and the ledger bounds any forged local purchase to the
 * catalog amount once per order ID.
 *
 * What this does NOT do: it cannot prove the purchase is genuine against
 * Google's servers — that needs the Play Developer API from a backend (layer
 * 2, see src/billing.ts BILLING_VERIFY_URL). A rooted device can fake a local
 * purchase object. What stops a fake from paying twice, or paying an invented
 * amount, is the Firestore ledger: the credit is written under the order ID
 * (create-only, rules-enforced) for exactly the catalog amount, so a forged
 * purchase still only ever credits the catalog amount once per order ID.
 */
import {tokensForProduct} from './tokens';

export const BILLING_PACKAGE = 'com.genzmode.app';

/** PurchaseAndroidState as Play reports it (react-native-iap enum values). */
export const PURCHASE_STATE = {UNSPECIFIED: 0, PURCHASED: 1, PENDING: 2} as const;

/** The fields the billing wrapper passes in from a react-native-iap purchase. */
export type PurchaseRecord = {
  productId: string;
  /** Google Play order ID (purchase.id). The duplicate guard. */
  orderId?: string | null;
  purchaseToken?: string | null;
  /** Numeric Play purchase state: 1 = PURCHASED, 2 = PENDING, 0 = unspecified. */
  purchaseState?: number | null;
  packageName?: string | null;
};

export type VerifiedPurchase =
  | {ok: true; productId: string; orderId: string; purchaseToken: string; tokens: number}
  | {ok: false; reason: string};

/** Validate a Play purchase before any tokens are credited. */
export function verifyPurchaseRecord(p: PurchaseRecord): VerifiedPurchase {
  const tokens = tokensForProduct(p.productId);
  if (tokens === null) return {ok: false, reason: `Unknown product ${p.productId}`};
  if (!p.orderId || typeof p.orderId !== 'string' || !p.orderId.trim()) return {ok: false, reason: 'Missing Google Play order ID'};
  if (!p.purchaseToken || typeof p.purchaseToken !== 'string' || !p.purchaseToken.trim()) return {ok: false, reason: 'Missing purchase token'};
  if (p.purchaseState !== PURCHASE_STATE.PURCHASED) return {ok: false, reason: p.purchaseState === PURCHASE_STATE.PENDING ? 'Purchase is still pending with Google Play' : 'Purchase is not in the PURCHASED state'};
  if (p.packageName && p.packageName !== BILLING_PACKAGE) return {ok: false, reason: `Purchase is for ${p.packageName}, not ${BILLING_PACKAGE}`};
  return {ok: true, productId: p.productId, orderId: p.orderId.trim(), purchaseToken: p.purchaseToken.trim(), tokens};
}
