/**
 * Billing verification tests (pure logic in shared/billing.ts).
 *
 * These cover the client-side layer: a purchase is only creditable when it
 * is a known product, in the PURCHASED state, with a Play order ID, a purchase
 * token, a matching package name, and a signed receipt. The duplicate guard
 * (one ledger document per order ID) is enforced by the Firestore rules and
 * covered by firebase/rules-tests/rules.test.mjs, not here.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {verifyPurchaseRecord, PURCHASE_STATE, BILLING_PACKAGE} from '../shared/billing';

const good = {
  productId: 'tokens_5000',
  orderId: 'GPA.1234-5678-9012-34567',
  purchaseToken: 'purchase-token-abc',
  purchaseState: PURCHASE_STATE.PURCHASED,
  packageName: BILLING_PACKAGE,
  transactionReceipt: '{"signed":"receipt"}',
};

test('billing: a real PURCHASED purchase verifies, with exactly the catalog amount', () => {
  const r = verifyPurchaseRecord(good);
  assert.equal(r.ok, true);
  if (r.ok) {
    assert.equal(r.productId, 'tokens_5000');
    assert.equal(r.tokens, 5000);
    assert.equal(r.orderId, 'GPA.1234-5678-9012-34567');
  }
});

test('billing: every package verifies at its own amount', () => {
  for (const [id, tokens] of [['tokens_1000', 1000], ['tokens_2500', 2500], ['tokens_10000', 10000], ['tokens_25000', 25000], ['tokens_50000', 50000], ['tokens_100000', 100000]] as const) {
    const r = verifyPurchaseRecord({...good, productId: id});
    assert.equal(r.ok, true);
    if (r.ok) assert.equal(r.tokens, tokens);
  }
});

test('billing: pending and unspecified purchases are never creditable', () => {
  const pending = verifyPurchaseRecord({...good, purchaseState: PURCHASE_STATE.PENDING});
  assert.equal(pending.ok, false);
  if (!pending.ok) assert.match(pending.reason, /pending/i);
  assert.equal(verifyPurchaseRecord({...good, purchaseState: PURCHASE_STATE.UNSPECIFIED}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseState: undefined}).ok, false);
});

test('billing: unknown products, missing order IDs and missing tokens are refused', () => {
  assert.equal(verifyPurchaseRecord({...good, productId: 'tokens_999'}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, productId: 'tokens_5000 '}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, orderId: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, orderId: undefined}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseToken: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, purchaseToken: undefined}).ok, false);
});

test('billing: a purchase for another package, or without a receipt, is refused', () => {
  assert.equal(verifyPurchaseRecord({...good, packageName: 'com.other.app'}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, transactionReceipt: ''}).ok, false);
  assert.equal(verifyPurchaseRecord({...good, transactionReceipt: undefined}).ok, false);
  // No package name reported at all is tolerated (older Play responses omit it).
  assert.equal(verifyPurchaseRecord({...good, packageName: undefined}).ok, true);
});
