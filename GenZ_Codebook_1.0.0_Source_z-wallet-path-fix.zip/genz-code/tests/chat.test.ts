// Community chat filter + AdMob configuration.
// The filter is the first moderation layer: anything sexual, abusive, hateful,
// threatening or encouraging self-harm is refused before it is sent. The server
// rules re-check length, links and the rate limit, and moderators hide reported
// messages from the admin portal.
// The ads wiring is checked as source text: src/ads.tsx imports react-native, which
// cannot load in Node (same reason the app tests never import UI modules).
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {screenMessage, toChatMessage, CHAT_MAX_LENGTH, CHAT_RATE_LIMIT_SECONDS} from '../shared/chat';

test('chat filter: ordinary messages pass, empty and oversize messages are refused', () => {
  assert.deepEqual(screenMessage('no cap, that was funny'), {ok: true});
  assert.deepEqual(screenMessage('  hello everyone  '), {ok: true});
  assert.equal(screenMessage('').ok, false);
  assert.equal(screenMessage('   ').ok, false);
  assert.equal(screenMessage('x'.repeat(CHAT_MAX_LENGTH + 1)).ok, false);
  assert.equal(screenMessage('x'.repeat(CHAT_MAX_LENGTH)).ok, true);
});

test('chat filter: sexual content, abuse, hate and threats are blocked, including leet-speak', () => {
  for (const bad of [
    'check out this porn link', 'you are a stupid slut', 'fuck you',
    'i hate you, nigger', 'you retard', 'send nudes pls',
    'kys', 'kill yourself', 'go die', 'i will kill you',
    'sh!t happens', 'b!tch please', 'sh1t happens', 'bhenchod', 'g4ndu',
  ]) {
    assert.equal(screenMessage(bad).ok, false, bad);
  }
  // The dictionary may explain a sensitive word; the chat room may not carry it.
  assert.equal(screenMessage('what does rizz mean?').ok, true);
  assert.equal(screenMessage('that fit is fire, no cap').ok, true);
});

test('chat filter: links, e-mail addresses and phone numbers are refused', () => {
  for (const bad of ['see https://x.example', 'visit www.spam.example', 'mail me@spam.io', 'call 0300 1234567']) {
    assert.equal(screenMessage(bad).ok, false, bad);
  }
  assert.equal(screenMessage('my number is 143').ok, true);
});

test('chat messages are validated before they are shown', () => {
  const at = {toMillis: () => 1780000000000};
  assert.deepEqual(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'hi', createdAt: at}), {id: 'm1', uid: 'u1', name: 'Aya', text: 'hi', at: 1780000000000});
  assert.equal(toChatMessage('m1', {status: 'hidden', uid: 'u1', name: 'Aya', text: 'hi', createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: '<script>alert(1)</script>', createdAt: at})?.text, '<script>alert(1)</script>');
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'x'.repeat(25), text: 'hi', createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'x'.repeat(CHAT_MAX_LENGTH + 1), createdAt: at}), null);
  assert.equal(toChatMessage('m1', {status: 'live', uid: 'u1', name: 'Aya', text: 'hi'}), null);
  assert.equal(toChatMessage('m1', null), null);
  assert.equal(CHAT_RATE_LIMIT_SECONDS, 10);
});

test('ads: the banner takes the ad unit ID, the app ID is for SDK setup only, interstitial and rewarded are configured', () => {
  const appId = 'ca-app-pub-9776667186789824~9376759074';
  const bannerId = 'ca-app-pub-9776667186789824/5427038644';
  const interstitialId = 'ca-app-pub-9776667186789824/4760116398';
  const rewardedId = 'ca-app-pub-9776667186789824/4151797642';
  const rewardedInterstitialId = 'ca-app-pub-9776667186789824/6311057124';
  const ads = readFileSync('src/ads.tsx', 'utf8');
  assert.ok(ads.includes(`ADMOB_APP_ID = '${appId}'`), 'app ID constant');
  assert.ok(ads.includes(`BANNER_AD_UNIT_ID = '${bannerId}'`), 'banner ad unit ID constant');
  assert.ok(ads.includes(`INTERSTITIAL_AD_UNIT_ID = '${interstitialId}'`), 'interstitial ad unit ID constant');
  assert.ok(ads.includes(`REWARDED_AD_UNIT_ID = '${rewardedId}'`), 'rewarded ad unit ID constant');
  assert.ok(ads.includes(`REWARDED_INTERSTITIAL_AD_UNIT_ID = '${rewardedInterstitialId}'`), 'rewarded interstitial ID recorded for Phase 4');
  assert.ok(!ads.includes(`INTERSTITIAL_AD_UNIT_ID = ''`), 'no empty interstitial placeholder');
  assert.ok(!ads.includes(`REWARDED_AD_UNIT_ID = ''`), 'no empty rewarded placeholder');
  assert.ok(ads.includes('TestIds.BANNER'), 'test banner in dev');
  assert.ok(ads.includes('TestIds.INTERSTITIAL'), 'test interstitial in dev');
  assert.ok(ads.includes('TestIds.REWARDED'), 'test rewarded ad in dev');
  assert.ok(ads.includes('ANCHORED_ADAPTIVE_BANNER'), 'anchored adaptive banner size');
  assert.ok(ads.includes('requestNonPersonalizedAdsOnly: true'), 'non-personalised ads');
  assert.ok(ads.includes('INTERSTITIAL_COOLDOWN_MS = 60_000'), 'interstitial cooldown');
  // The app ID reaches the SDK through the config plugin, the bare-workflow key, and the manifest.
  const appJson = JSON.parse(readFileSync('app.json', 'utf8'));
  const plugin = appJson.expo.plugins.find((p: unknown) => Array.isArray(p) && p[0] === 'react-native-google-mobile-ads');
  assert.equal(plugin?.[1]?.androidAppId, appId, 'config plugin androidAppId');
  assert.equal(appJson['react-native-google-mobile-ads']?.android_app_id, appId, 'bare-workflow android_app_id');
  const manifest = readFileSync('android/app/src/main/AndroidManifest.xml', 'utf8');
  assert.ok(manifest.includes(`com.google.android.gms.ads.APPLICATION_ID" android:value="${appId}"`), 'manifest APPLICATION_ID');
  // The banner is rendered in exactly two places: the Suggest a word sheet and the Community screen.
  const app = readFileSync('App.tsx', 'utf8');
  assert.ok(app.includes(`{sheet==='suggest'&&<AdBanner/>}`), 'banner on the suggest sheet');
  assert.equal(app.split('AdBanner').length - 1, 2, 'import + the one usage in App');
  const community = readFileSync('src/CommunityScreen.tsx', 'utf8');
  assert.ok(community.includes('<AdBanner />'), 'banner on the Community screen');
  // The interstitial shows when the user opens Suggest or Community — and nowhere else.
  assert.ok(app.includes(`if(t==='Community')showInterstitialIfReady();`), 'interstitial on Community tab');
  assert.ok(app.includes(`showInterstitialIfReady();openSheet('suggest')`), 'interstitial on Suggest a word');
});
