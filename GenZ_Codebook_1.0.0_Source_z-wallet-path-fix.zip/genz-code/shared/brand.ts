/**
 * Publisher identity, shown in every footer of the app, the admin portal and the public pages.
 * Change it here only; the app and the portal both import this file.
 */
export const PRODUCT = 'GenZ Codebook';
export const BRAND = 'ZTechX';
export const COMPANY = 'Zocxorian Technologies';
export const FIRST_YEAR = 2026;

/** "© 2026 Zocxorian Technologies" (a range such as 2026–2027 once the year changes). */
export function copyright(now: Date = new Date()): string {
  const y = now.getFullYear();
  return `© ${y > FIRST_YEAR ? `${FIRST_YEAR}–${y}` : FIRST_YEAR} ${COMPANY}`;
}
export const BYLINE = `A ${BRAND} product`;
export const RIGHTS = 'All rights reserved.';
export const SUPPORT_EMAIL = 'zocxoriantechnologies@gmail.com';
export const ADDRESS = 'Zpr, Rahim Yar Khan, Punjab, Pakistan';
/** Opens the user's e-mail app addressed to support. */
export const supportMailto = (subject = 'GenZ Codebook support') => `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}`;
