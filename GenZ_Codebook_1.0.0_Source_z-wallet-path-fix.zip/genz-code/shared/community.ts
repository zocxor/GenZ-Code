/**
 * Community words: suggestions that go live instantly (shared by the app and the admin portal).
 *
 * Firestore rules enforce who can publish (signed in, verified e-mail, active account,
 * 60 s rate limit, kill switch), field limits, one document per word, and "no links,
 * e-mail addresses or phone numbers". This module adds the checks rules cannot do:
 * a word filter that sends sensitive words to moderators instead of publishing them.
 */
import {cleanText, normalizeTerm} from './contentSchema';

export const COMMUNITY_PREFIX = 'c-';
export const COMMUNITY_ID_PATTERN = /^c-[a-z0-9][a-z0-9_-]{0,77}$/;
export const COMMUNITY_STATUSES = ['live', 'hidden', 'removed'] as const;
export type CommunityStatus = (typeof COMMUNITY_STATUSES)[number];

function fnv1a(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0;}
  return h.toString(16).padStart(8, '0');
}

/** One stable document ID per normalised word, so the same word cannot be added twice. */
export function communityId(term: string): string {
  const norm = normalizeTerm(term);
  const slug = norm.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60).replace(/-+$/, '');
  if (slug && slug === norm) return COMMUNITY_PREFIX + slug;
  return `${COMMUNITY_PREFIX}${slug || 'w'}-${fnv1a(norm)}`;
}

/** Mirrors firestore.rules noContact()/noPhone(); keep both in sync. */
export const CONTACT_PATTERN = /(https?:\/\/|www\.|[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,})/i;
export const PHONE_PATTERN = /[0-9][0-9 ()+-]{8,}[0-9]/;

// Words that are never published automatically. They are sent to moderators instead, because a
// slang dictionary can legitimately explain them, but a person should decide how.
const REVIEW_WORDS = new Set([
  'nigger', 'nigga', 'niggas', 'faggot', 'fag', 'fags', 'retard', 'retarded', 'tranny', 'chink', 'spic', 'kike', 'paki', 'coon', 'wetback', 'dyke',
  'cunt', 'whore', 'slut', 'rape', 'rapist', 'raping', 'porn', 'nude', 'nudes', 'pedo', 'paedo', 'pedophile', 'incest', 'molest',
  'bhenchod', 'behenchod', 'madarchod', 'chutiya', 'chutia', 'gandu', 'randi', 'harami', 'haramzada', 'kanjar', 'lund', 'phuddi', 'bhosdi', 'bhosdike', 'kutti',
]);
const REVIEW_PHRASES = ['kill yourself', 'kill urself', 'kill your self', 'go die', 'kys'];
const unLeet = (w: string) => w.replace(/[@4]/g, 'a').replace(/\$/g, 's').replace(/0/g, 'o').replace(/[!1]/g, 'i').replace(/3/g, 'e').replace(/\*/g, '');

export type Screening = {ok: false; message: string} | {ok: true; review: boolean};

/** Decide whether a suggestion can go live now, must wait for a moderator, or is refused. */
export function screenWord(input: {term: string; meaning: string; example: string}): Screening {
  const term = cleanText(input.term, 60), meaning = cleanText(input.meaning, 500), example = cleanText(input.example, 300);
  if (!term) return {ok: false, message: 'Type the word or phrase you want to add.'};
  if (meaning.length < 2) return {ok: false, message: 'Add a short meaning (at least 2 characters).'};
  if (CONTACT_PATTERN.test([term, meaning, example].join(' '))) return {ok: false, message: 'Please remove links and e-mail addresses. They can’t be published.'};
  if (PHONE_PATTERN.test(meaning) || PHONE_PATTERN.test(example)) return {ok: false, message: 'Please remove phone numbers. They can’t be published.'};
  const text = normalizeTerm([term, meaning, example].join(' '));
  const words = text.split(/[^\p{L}\p{N}@$*!]+/u).filter(Boolean);
  const flagged = words.some(w => REVIEW_WORDS.has(w) || REVIEW_WORDS.has(unLeet(w))) || REVIEW_PHRASES.some(p => (` ${text.replace(/[^\p{L}\p{N}]+/gu, ' ')} `).includes(` ${p} `));
  return {ok: true, review: flagged};
}
