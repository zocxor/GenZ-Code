#!/usr/bin/env python3
"""Regenerate the GenZ Codebook Android launcher icons with proper fit.

Problem: the launcher artwork (the neon bubble mark) was placed full-bleed
on the 108dp adaptive-foreground canvas and on the legacy icon. Android's
adaptive-icon mask crops the outer ~19% on every side (only the centre 66dp
is guaranteed visible), so the bubble edges, the orange rays and the tail
were cut off on the phone.

Fix: the artwork is scaled to fit inside the 66dp safe zone (61% of the
108dp foreground canvas), centred on transparency. The legacy / round icons
get the same artwork at 82% of the 48dp canvas, centred on the #FFF4FF
background that the adaptive background already uses.

Source: assets/brand/genz-code-mark.png (bubble only, 448x448).
"""
from PIL import Image
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # genz-code/
RES = os.path.join(ROOT, 'android/app/src/main/res')
BG = (0xFF, 0xF4, 0xFF, 0xFF)  # matches drawable/ic_launcher_background.xml

mark = Image.open(os.path.join(ROOT, 'assets/brand/genz-code-mark.png')).convert('RGBA')
# Crop to the artwork itself (bbox 0,42,448,407) so the scale is set by the
# artwork, not by the empty margins baked into the 448 canvas.
bbox = mark.split()[-1].getbbox()
art = mark.crop(bbox)
print('artwork bbox:', bbox, 'cropped size:', art.size)

# 108dp foreground, 48dp legacy. Sizes in px per density.
FG = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}
LEG = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}

for dpi, size in FG.items():
    # Safe zone is 66dp of 108dp -> artwork width = 66/108 of the canvas.
    w = round(size * 66 / 108)
    h = round(w * art.size[1] / art.size[0])
    scaled = art.resize((w, h), Image.LANCZOS)
    canvas = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    canvas.paste(scaled, ((size - w) // 2, (size - h) // 2), scaled)
    out = os.path.join(RES, f'mipmap-{dpi}', 'ic_launcher_foreground.png')
    canvas.save(out)
    print('foreground', dpi, size, 'artwork', w, 'x', h, '->', out)

for dpi, size in LEG.items():
    # Artwork at 82% of the square, on the #FFF4FF background.
    w = round(size * 0.82)
    h = round(w * art.size[1] / art.size[0])
    scaled = art.resize((w, h), Image.LANCZOS)
    canvas = Image.new('RGBA', (size, size), BG)
    canvas.paste(scaled, ((size - w) // 2, (size - h) // 2), scaled)
    for name in ('ic_launcher.webp', 'ic_launcher_round.webp'):
        out = os.path.join(RES, f'mipmap-{dpi}', name)
        canvas.save(out, 'WEBP')
        print('legacy', dpi, size, 'artwork', w, 'x', h, '->', out)
