// Reproduces a Firebase project whose Firestore security rules were never published
// (Firestore in production mode = every request refused). Starts its own stand-in Firestore on
// :8080 that answers PERMISSION_DENIED to everything, like the real service does.
// Needs: the Auth emulator on :9099 and an emulator-wired web build on :8091 (see README).
// Checks that the app names the cause instead of a vague error, and keeps local data safe.
import http from 'node:http';
import {chromium} from 'playwright';
const URL = 'http://localhost:8091/', AUTH = 'http://127.0.0.1:9099', PROJECT = 'gen-z-code-55caf';
const results = [];
const check = (name, ok, info = '') => {results.push(ok); console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${info ? ' — ' + info : ''}`);};

const cors = {'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE,OPTIONS'};
const denyAll = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {res.writeHead(204, cors); return res.end();}
  res.writeHead(403, {...cors, 'Content-Type': 'application/json'});
  res.end(JSON.stringify({error: {code: 403, message: 'Missing or insufficient permissions.', status: 'PERMISSION_DENIED'}}));
}).listen(8080, '127.0.0.1');

await fetch(`${AUTH}/emulator/v1/projects/${PROJECT}/accounts`, {method: 'DELETE'});
const browser = await chromium.launch();
const page = await (await browser.newContext({viewport: {width: 390, height: 844}})).newPage();
const errors = []; page.on('pageerror', e => errors.push(e.message));
const body = () => page.locator('body').innerText();
await page.goto(URL);
await page.getByText('Start decoding').click();
await page.getByRole('tab', {name: /You/}).click();
await page.getByText('My account', {exact: true}).click();
await page.getByText('Create an account').click();
await page.getByLabel('Account email').fill('owner@example.com');
await page.getByLabel('Account password', {exact: true}).fill('correct horse battery');
await page.getByLabel('Confirm account password').fill('correct horse battery');
await page.getByRole('button', {name: 'Create account'}).last().click();
await page.getByText(/Account created/).waitFor({timeout: 15000});
const codes = (await (await fetch(`${AUTH}/emulator/v1/projects/${PROJECT}/oobCodes`)).json()).oobCodes.filter(c => c.requestType === 'VERIFY_EMAIL');
await fetch(codes.at(-1).oobLink);
let syncText = '';
for (let i = 0; i < 15 && !/switched on yet/.test(syncText); i++) {await page.waitForTimeout(1000); syncText = await body();}
check('sync explains that cloud backup is not switched on yet', /Cloud backup isn’t switched on yet/.test(syncText));
await page.getByRole('button', {name: 'Go back'}).first().click();

await page.getByRole('tab', {name: /Words/}).click();
await page.getByRole('button', {name: /^Suggest a word\./}).filter({visible: true}).first().click();
await page.getByLabel('Suggested word').fill('61');
await page.getByLabel('Meaning').fill('Ohk');
await page.getByLabel('Example').fill('Relaxing expressions then ok');
await page.getByRole('button', {name: 'Publish word'}).click();
await page.getByText(/code: rules-missing/).waitFor({timeout: 15000}).catch(() => {});
const t = await body();
check('suggesting a word names the cause: rules not published', /security rules haven’t been published/.test(t) && /code: rules-missing/.test(t), (t.match(/[^\n]*code:[^\n]*/) ?? [''])[0]);
await page.screenshot({path: '/home/claude/tests-e2e/shots/rules-missing.png'});
check('no uncaught page errors', errors.length === 0, errors.slice(0, 2).join(' | '));
await browser.close(); denyAll.close();
console.log(`${results.filter(Boolean).length}/${results.length} checks passed`);
