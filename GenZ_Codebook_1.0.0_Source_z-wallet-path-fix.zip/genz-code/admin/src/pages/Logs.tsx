import React, {useState} from 'react';
import {collection, query, where, orderBy, limit, getDocs, QueryConstraint, Timestamp} from 'firebase/firestore/lite';
import {db, errorMessage, newBatch, addAudit} from '../firebase';
import {useSession} from '../App';
import {Card, Notice, Pill, useLoad, when} from '../ui';

const ACTIONS = ['all', 'admin.login', 'admin.role.set', 'user.suspend', 'user.reactivate', 'user.delete', 'user.note', 'content.create', 'content.update', 'content.submit_review', 'content.publish', 'content.archive', 'content.rollback', 'content.import', 'submission.accept', 'submission.reject', 'report.resolve', 'report.dismiss', 'feedback.triage', 'config.update', 'community.hide', 'community.restore', 'logs.purge'];
const TYPES = ['all', 'login_succeeded_after_failures', 'session_expired', 'reauth_failed', 'sync_permission_denied', 'sync_blocked_account_status', 'content_validation_rejected', 'account_deletion_started', 'admin_access_denied'];

/** Delete audit entries and security events past expireAt (replaces Firestore TTL, which needs billing). */
async function purgeExpired(): Promise<number> {
  let removed = 0;
  for (const name of ['auditLogs', 'securityEvents']) {
    for (let round = 0; round < 25; round++) {
      const snap = await getDocs(query(collection(db, name), where('expireAt', '<', Timestamp.now()), limit(400)));
      if (snap.empty) break;
      const b = newBatch();
      snap.docs.forEach(d => b.delete(d.ref));
      await b.commit();
      removed += snap.size;
      if (snap.size < 400) break;
    }
  }
  return removed;
}

export default function Logs() {
  const s = useSession();
  const [action, setAction] = useState('all'), [type, setType] = useState('all');
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [busy, setBusy] = useState(false);
  const purge = async () => {
    setBusy(true); setMsg(null);
    try {
      const n = await purgeExpired();
      const b = newBatch(); addAudit(b, s.uid, s.role, 'logs.purge', 'auditLogs', `removed ${n} expired entries`); await b.commit();
      setMsg({kind: 'ok', text: n ? `Deleted ${n} expired entries.` : 'Nothing has expired yet.'});
      audit.reload(); sec.reload();
    } catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}
  };
  const audit = useLoad(async () => {
    const c: QueryConstraint[] = action === 'all' ? [orderBy('at', 'desc'), limit(200)] : [where('action', '==', action), orderBy('at', 'desc'), limit(200)];
    return (await getDocs(query(collection(db, 'auditLogs'), ...c))).docs.map(d => ({id: d.id, ...d.data()} as {id: string; actor: string; role: string; action: string; target: string; summary: string; at: {toMillis(): number}}));
  }, [action]);
  const sec = useLoad(async () => {
    const c: QueryConstraint[] = type === 'all' ? [orderBy('at', 'desc'), limit(200)] : [where('type', '==', type), orderBy('at', 'desc'), limit(200)];
    return (await getDocs(query(collection(db, 'securityEvents'), ...c))).docs.map(d => ({id: d.id, ...d.data()} as {id: string; uid: string; type: string; detail: string; platform: string; appVersion: string; at: {toMillis(): number}}));
  }, [type]);
  return <div className="stack">
    <header className="page-head"><h1>Audit & security</h1><p className="muted">Audit entries are written in the same atomic batch as the action they describe (enforced by security rules) and cannot be edited. They expire after 365 days; security events expire after 90 days and contain no e-mail, IP address or message text.</p></header>
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    {s.role === 'super_admin' && <Card title="Retention clean-up" subtitle="Run about once a month. Only entries past their expiry date can be deleted (the server enforces this), and each clean-up is itself logged.">
      <button className="btn" disabled={busy} onClick={() => void purge()}>{busy ? 'Deleting…' : 'Delete expired entries'}</button>
    </Card>}
    <Card title="Admin audit log" subtitle="Newest 200" actions={<select aria-label="Filter by action" value={action} onChange={e => setAction(e.target.value)}>{ACTIONS.map(a => <option key={a}>{a}</option>)}</select>}>
      {audit.error ? <Notice kind="error">{errorMessage(audit.error)}</Notice> : <table><thead><tr><th>When</th><th>Action</th><th>Actor</th><th>Target</th><th>Summary</th></tr></thead><tbody>{audit.data?.map(a => <tr key={a.id}><td>{when(a.at)}</td><td><Pill tone="info">{a.action}</Pill></td><td><code>{a.actor.slice(0, 10)}</code> <span className="small muted">{a.role}</span></td><td><code>{a.target}</code></td><td className="clip">{a.summary}</td></tr>)}</tbody></table>}
      {audit.loading && <p className="muted">Loading…</p>}
    </Card>
    <Card title="Security events" subtitle="Newest 200" actions={<select aria-label="Filter by type" value={type} onChange={e => setType(e.target.value)}>{TYPES.map(a => <option key={a}>{a}</option>)}</select>}>
      {sec.error ? <Notice kind="error">{errorMessage(sec.error)}</Notice> : <table><thead><tr><th>When</th><th>Type</th><th>User</th><th>Detail</th><th>Client</th></tr></thead><tbody>{sec.data?.map(e => <tr key={e.id}><td>{when(e.at)}</td><td><Pill tone={/denied|failed/.test(e.type) ? 'warn' : 'neutral'}>{e.type}</Pill></td><td><code>{e.uid.slice(0, 10)}</code></td><td>{e.detail || '—'}</td><td>{e.platform} · {e.appVersion}</td></tr>)}</tbody></table>}
      {sec.loading && <p className="muted">Loading…</p>}
    </Card>
  </div>;
}
