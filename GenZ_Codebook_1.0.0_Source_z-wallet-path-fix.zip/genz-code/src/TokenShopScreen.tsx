/**
 * Buy Tokens: the seven consumable token packages, sold through Google Play
 * Billing. Prices come from Play (localized by the user's Play country and
 * currency) — never from code. Tapping Buy opens the official Google Play
 * purchase dialog; there is no in-app payment form and no simulated success.
 *
 * Tokens are credited only after a real Play purchase is verified and recorded
 * in the account's ledger (see src/billing.ts). Pending purchases are never
 * credited; cancelled purchases are reported calmly, not as errors. Purchases
 * need a signed-in account, because the ledger is keyed by the account.
 */
import React, {useEffect, useState} from 'react';
import {View, Text, ScrollView, Pressable, StyleSheet, ActivityIndicator} from 'react-native';
import {C, Glass, Button, Icon} from './ui';
import {useAccountUser} from './services';
import {
  getBillingProducts, getBillingStatus, retryBilling, buyTokens,
  onBillingEvent, type BillingProduct, type BillingEvent,
} from './billing';
import type {TokensState} from '../shared/tokens';

type Msg = {kind: 'success' | 'pending' | 'error' | 'info'; text: string} | null;

export default function TokenShopScreen({tokens, onSignIn, onOpenWallet}: {tokens: TokensState; onSignIn: () => void; onOpenWallet: () => void}) {
  const user = useAccountUser();
  const [products, setProducts] = useState<BillingProduct[]>(() => getBillingProducts());
  const [status, setStatus] = useState(() => getBillingStatus());
  const [loading, setLoading] = useState(products.length === 0 && status.available);
  const [buying, setBuying] = useState<string | null>(null);
  const [retrying, setRetrying] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);

  useEffect(() => onBillingEvent((e: BillingEvent) => {
    if (e.kind === 'products') {
      setProducts(getBillingProducts());
      setStatus(getBillingStatus());
      setLoading(false);
    } else if (e.kind === 'unavailable') {
      setStatus(getBillingStatus());
      setLoading(false);
    } else if (e.kind === 'credited') {
      setBuying(null);
      setMsg({kind: 'success', text: `${e.tokens.toLocaleString()} tokens added to your wallet.`});
    } else if (e.kind === 'already-credited') {
      setBuying(null);
      setMsg({kind: 'info', text: 'This purchase was already credited to your wallet.'});
    } else if (e.kind === 'pending') {
      setBuying(null);
      setMsg({kind: 'pending', text: 'Payment pending — your tokens will arrive once Google Play confirms it. Check back in a moment.'});
    } else if (e.kind === 'failed') {
      setBuying(null);
      setMsg({kind: 'error', text: e.message});
    } else if (e.kind === 'cancelled') {
      setBuying(null);
      setMsg({kind: 'info', text: 'Purchase cancelled. No charge was made.'});
    } else if (e.kind === 'restored' && e.count > 0) {
      setMsg({kind: 'success', text: `${e.count} earlier purchase${e.count > 1 ? 's' : ''} restored to your wallet.`});
    } else if (e.kind === 'signin-required') {
      setBuying(null);
      setMsg({kind: 'error', text: 'Sign in first — purchases are recorded on your account.'});
    }
  }), []);

  const retry = async () => {
    setRetrying(true);
    setMsg(null);
    const r = await retryBilling();
    setProducts(r.products);
    setStatus({available: r.available, missing: r.missing, error: r.error});
    setLoading(false);
    setRetrying(false);
  };

  const buy = async (productId: string) => {
    if (buying) return;
    setMsg(null);
    setBuying(productId);
    const r = await buyTokens(productId);
    if (!r.started) {
      setBuying(null);
      if (r.error && r.error !== 'Purchase cancelled.') setMsg({kind: 'error', text: r.error});
      else if (r.error === 'Purchase cancelled.') setMsg({kind: 'info', text: 'Purchase cancelled. No charge was made.'});
    }
    // When started, the result arrives through the billing event listener.
  };

  return (
    <ScrollView contentContainerStyle={s.content}>
      <Glass>
        <View style={s.between}>
          <View>
            <Text style={s.eyebrow}>YOUR BALANCE</Text>
            <Text style={s.balance}>{tokens.balance.toLocaleString()} tokens</Text>
          </View>
          <Icon name="wallet-outline" color={C.blue} size={30} />
        </View>
        <Text style={s.caption}>Tokens buy nothing yet inside the app beyond suggesting words and unlocking quiz levels early — packages are for topping up your balance.</Text>
      </Glass>

      {!user && (
        <Glass>
          <Text style={s.sectionTitle}>Sign in to buy tokens</Text>
          <Text style={s.body}>Purchases are recorded on your account, so they survive a reinstall or a new phone. Guests can still earn free tokens by playing.</Text>
          <Button title="Sign in or create an account" icon="log-in-outline" onPress={onSignIn} />
        </Glass>
      )}

      {msg && (
        <View style={[s.msg, msg.kind === 'success' ? s.msgOk : msg.kind === 'pending' ? s.msgPending : msg.kind === 'error' ? s.msgErr : s.msgInfo]}>
          <Icon name={msg.kind === 'success' ? 'checkmark-circle-outline' : msg.kind === 'pending' ? 'hourglass-outline' : msg.kind === 'error' ? 'alert-circle-outline' : 'information-circle-outline'} color={msg.kind === 'success' ? '#1d7a43' : msg.kind === 'pending' ? '#8a6d00' : msg.kind === 'error' ? '#a33' : C.blue} size={20} />
          <Text style={s.msgText}>{msg.text}</Text>
        </View>
      )}

      {loading ? (
        <Glass><ActivityIndicator color={C.blue} /><Text style={s.body}>Loading prices from Google Play…</Text></Glass>
      ) : !status.available ? (
        <Glass>
          <Text style={s.sectionTitle}>Google Play billing is unavailable</Text>
          <Text style={s.body}>{status.error || 'Billing could not be reached on this device. Purchases need Google Play on Android.'}</Text>
          <Button title={retrying ? 'Retrying…' : 'Try again'} icon="refresh-outline" onPress={() => void retry()} disabled={retrying} />
        </Glass>
      ) : products.length === 0 ? (
        <Glass>
          <Text style={s.sectionTitle}>No token packages found</Text>
          <Text style={s.body}>Google Play returned no products. The seven packages may not be created or active in Play Console yet.</Text>
          <Button title={retrying ? 'Retrying…' : 'Try again'} icon="refresh-outline" onPress={() => void retry()} disabled={retrying} />
        </Glass>
      ) : (
        products.map(p => (
          <Glass key={p.productId}>
            <View style={s.between}>
              <View style={{flex: 1}}>
                <View style={s.row}>
                  <Text style={s.pkg}>{p.tokens.toLocaleString()} tokens</Text>
                  {p.popular && <View style={s.pop}><Text style={s.popText}>MOST POPULAR</Text></View>}
                </View>
                <Text style={s.caption}>{p.title}</Text>
              </View>
              <Text style={s.price}>{p.localizedPrice}</Text>
            </View>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`Buy ${p.tokens.toLocaleString()} tokens for ${p.localizedPrice}`}
              accessibilityState={{disabled: !user || buying !== null}}
              disabled={!user || buying !== null}
              onPress={() => void buy(p.productId)}
              style={[s.buy, (!user || buying !== null) && {opacity: .5}]}>
              {buying === p.productId
                ? <ActivityIndicator color="#fff" />
                : <Text style={s.buyText}>Buy</Text>}
            </Pressable>
          </Glass>
        ))
      )}

      {status.missing.length > 0 && status.available && (
        <Text style={s.fine}>Not listed yet in Google Play: {status.missing.join(', ')}. Create or activate them in Play Console (Monetize &gt; Products &gt; In-app products) and they will appear here.</Text>
      )}

      <Text style={s.fine}>Prices are set in Google Play Console and shown in your Play country and currency. Payment is charged through Google Play — this app never sees your card. Every purchase is recorded in your account's transaction history (Wallet) before the tokens are credited.</Text>
      <Button title="View my wallet" icon="wallet-outline" light onPress={onOpenWallet} />
    </ScrollView>
  );
}

const s = StyleSheet.create({
  content: {gap: 16, paddingBottom: 8},
  between: {flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12},
  row: {flexDirection: 'row', alignItems: 'center', gap: 8, flexWrap: 'wrap'},
  eyebrow: {fontSize: 10, fontWeight: '800', letterSpacing: 1.6, color: C.blue},
  balance: {fontSize: 28, fontWeight: '900', color: C.ink, letterSpacing: -.5},
  caption: {fontSize: 12, lineHeight: 18, color: C.muted},
  body: {fontSize: 15, lineHeight: 23, color: C.muted},
  sectionTitle: {fontSize: 20, fontWeight: '800', letterSpacing: -.4, color: C.ink},
  fine: {fontSize: 11, lineHeight: 17, color: '#5c7189'},
  pkg: {fontSize: 20, fontWeight: '900', color: C.ink, letterSpacing: -.4},
  price: {fontSize: 18, fontWeight: '900', color: C.blue},
  pop: {backgroundColor: '#ffe9c2', borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3},
  popText: {fontSize: 9, fontWeight: '900', letterSpacing: 1, color: '#8a5a00'},
  buy: {marginTop: 12, minHeight: 48, borderRadius: 16, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center'},
  buyText: {color: '#fff', fontSize: 16, fontWeight: '800'},
  msg: {flexDirection: 'row', gap: 10, padding: 14, borderRadius: 16, borderWidth: 1, alignItems: 'flex-start'},
  msgText: {flex: 1, fontSize: 14, lineHeight: 20, color: C.ink, fontWeight: '600'},
  msgOk: {backgroundColor: '#e1f5e9', borderColor: '#77bb95'},
  msgPending: {backgroundColor: '#fff4cc', borderColor: '#d9b64a'},
  msgErr: {backgroundColor: '#fff0ee', borderColor: '#d0a09c'},
  msgInfo: {backgroundColor: '#e7f0fb', borderColor: '#b6cae2'},
});
