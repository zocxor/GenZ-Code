/**
 * Google Play Billing for GenZ Codebook token packages.
 *
 * Uses the official Google Play Billing Library through react-native-iap
 * 12.16.4 (Billing Library 7.0.0, from the library's own defaults). Android
 * only: on iOS and web, billing reports unavailable and the shop says so.
 *
 * The purchase pipeline (never skip a step):
 *  1. Play returns a purchase -> pure local checks (shared/billing.ts):
 *     known product, PURCHASED state, order ID + purchase token + receipt.
 *  2. Optional server check: if BILLING_VERIFY_URL is set, the purchase is
 *     POSTed to that backend and only credited on {verified: true}. The
 *     backend must call the Play Developer API
 *     (purchases.products.get) with the purchase token. No backend exists
 *     yet, so the URL is empty and this step is dormant — see the delivery
 *     note for exactly what to provide. Local verification alone is NOT
 *     presented as server verification anywhere in the app.
 *  3. Ledger write (src/tokenLedger.ts): the credit is recorded under the
 *     Google Play order ID, create-only, for exactly the catalog amount.
 *     A second credit for the same order is refused by the rules.
 *  4. Local balance credit (the caller's onCredit — App dispatches
 *     earnTokens). Only after the ledger write succeeds.
 *  5. Consume (finishTransaction, isConsumable: true) so the same package
 *     can be bought again. If any step before this fails, the purchase is
 *     deliberately NOT consumed: Play keeps it owned, and the next reconcile
 *     (app start, wallet open, Restore button) retries it.
 *
 * Pending purchases are never credited. Cancelled purchases are reported
 * calmly, not as errors. No fake payment screens, no simulated success:
 * tokens only move on a real Play purchase.
 *
 * Android Gradle note: react-native-iap ships amazon/play store flavors, so
 * android/app/build.gradle sets missingDimensionStrategy 'store', 'play'.
 */
import {Platform} from 'react-native';
import {
  initConnection,
  endConnection,
  getProducts,
  requestPurchase,
  finishTransaction,
  getAvailablePurchases,
  purchaseUpdatedListener,
  purchaseErrorListener,
  type Product,
  type Purchase,
  type PurchaseError,
  PurchaseStateAndroid,
  ErrorCode,
} from 'react-native-iap';
import {verifyPurchaseRecord} from '../shared/billing';
import {TOKEN_PRODUCTS} from '../shared/tokens';
import {recordPurchaseTxn, currentUid} from './tokenLedger';

/**
 * Server verification endpoint (layer 2). Empty = not configured: the app
 * verifies locally (layer 1) + the idempotent ledger, and says so honestly.
 * To enable, deploy an endpoint that accepts
 *   POST {productId, orderId, purchaseToken}
 * and returns {verified: true} only after calling the Play Developer API
 * purchases.products.get and confirming purchaseState == 0 (purchased) and
 * the product matches. It needs a Google service account with Play Developer
 * API access (Play Console > Setup > API access).
 */
export const BILLING_VERIFY_URL = '';

export type BillingProduct = {
  productId: string;
  tokens: number;
  localizedPrice: string;
  price: string;
  currency: string;
  title: string;
  description: string;
  popular: boolean;
};

export type BillingEvent =
  | {kind: 'products'}
  | {kind: 'credited'; productId: string; tokens: number; balanceAfter: number}
  | {kind: 'already-credited'; productId: string; tokens: number}
  | {kind: 'pending'; productId: string}
  | {kind: 'failed'; message: string}
  | {kind: 'cancelled'}
  | {kind: 'restored'; count: number}
  | {kind: 'signin-required'}
  | {kind: 'unavailable'; message: string};

export type BillingInit = {available: boolean; products: BillingProduct[]; missing: string[]; error?: string};

type Handlers = {onCredit: (amount: number, orderId: string) => void | Promise<void>};

const listeners = new Set<(e: BillingEvent) => void>();
function emit(e: BillingEvent): void {
  listeners.forEach(cb => {
    try {cb(e);} catch {/* a listener must never break billing */}
  });
}
export function onBillingEvent(cb: (e: BillingEvent) => void): () => void {
  listeners.add(cb);
  return () => {listeners.delete(cb);};
}

const PRODUCT_IDS = TOKEN_PRODUCTS.map(p => p.id);

let available = false;
let cachedProducts: BillingProduct[] = [];
let cachedMissing: string[] = [...PRODUCT_IDS];
let cachedError: string | undefined;
let updateSub: {remove: () => void} | null = null;
let errorSub: {remove: () => void} | null = null;
let handlers: Handlers | null = null;

function toBillingProduct(p: Product): BillingProduct | null {
  const catalog = TOKEN_PRODUCTS.find(c => c.id === p.productId);
  if (!catalog) return null;
  return {
    productId: p.productId,
    tokens: catalog.tokens,
    localizedPrice: p.localizedPrice || p.price,
    price: p.price,
    currency: p.currency,
    title: p.title,
    description: p.description,
    popular: p.productId === 'tokens_5000',
  };
}

async function verifyWithServer(p: {productId: string; orderId: string; purchaseToken: string}): Promise<boolean> {
  if (!BILLING_VERIFY_URL) return true;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch(BILLING_VERIFY_URL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(p),
      signal: ctrl.signal,
    });
    clearTimeout(timer);
    if (!res.ok) return false;
    const body = (await res.json()) as {verified?: boolean};
    return body.verified === true;
  } catch {return false;}
}

/** Run one owned purchase through the pipeline. Returns what happened. */
async function creditPurchase(purchase: Purchase): Promise<'credited' | 'duplicate' | 'pending' | 'failed'> {
  const state = purchase.purchaseStateAndroid;
  if (state === PurchaseStateAndroid.PENDING) {
    emit({kind: 'pending', productId: purchase.productId});
    return 'pending';
  }
  const checked = verifyPurchaseRecord({
    productId: purchase.productId,
    orderId: purchase.transactionId,
    purchaseToken: purchase.purchaseToken,
    purchaseState: typeof state === 'number' ? state : undefined,
    packageName: purchase.packageNameAndroid,
    transactionReceipt: purchase.transactionReceipt,
  });
  if (!checked.ok) {
    emit({kind: 'failed', message: checked.reason});
    return 'failed';
  }
  const uid = currentUid();
  if (!uid) {
    emit({kind: 'signin-required'});
    return 'failed';
  }
  if (!(await verifyWithServer({productId: checked.productId, orderId: checked.orderId, purchaseToken: checked.purchaseToken}))) {
    emit({kind: 'failed', message: 'Google Play could not verify this purchase. No tokens were credited.'});
    return 'failed';
  }
  let recorded: {status: 'recorded' | 'duplicate'; balanceAfter: number};
  try {
    recorded = await recordPurchaseTxn(uid, {
      orderId: checked.orderId,
      productId: checked.productId,
      purchaseToken: checked.purchaseToken,
      tokens: checked.tokens,
    });
  } catch {
    emit({kind: 'failed', message: 'Could not record this purchase. It stays with Google Play and will be retried automatically.'});
    return 'failed';
  }
  if (recorded.status === 'duplicate') {
    // Already paid for: consume so Play stops offering it, but do not credit
    // the local balance again. The wallet sync repairs any drift.
    try {await finishTransaction({purchase, isConsumable: true});} catch {/* reconcile retries */}
    emit({kind: 'already-credited', productId: checked.productId, tokens: checked.tokens});
    return 'duplicate';
  }
  try {
    await handlers?.onCredit(checked.tokens, checked.orderId);
  } catch {/* the ledger is the record; the wallet sync repairs the local balance */}
  try {
    await finishTransaction({purchase, isConsumable: true});
  } catch {
    // Credited + recorded, but not consumed: Play still shows it owned, so
    // the next reconcile sees the duplicate and consumes it then.
  }
  emit({kind: 'credited', productId: checked.productId, tokens: checked.tokens, balanceAfter: recorded.balanceAfter});
  return 'credited';
}

/** Credit every owned (unconsumed) purchase that has not been recorded yet. */
async function reconcileOwnedPurchases(): Promise<number> {
  let restored = 0;
  try {
    const owned = await getAvailablePurchases({automaticallyFinishRestoredTransactions: false});
    for (const purchase of owned) {
      try {
        const result = await creditPurchase(purchase);
        if (result === 'credited' || result === 'duplicate') restored += 1;
      } catch {/* one bad purchase must not block the others */}
    }
  } catch {/* billing unavailable or Play unreachable; the shop reports it */}
  return restored;
}

/** Connect to Play, load the seven products, reconcile. Listeners are installed by initBilling. */
async function loadBilling(): Promise<BillingInit> {
  try {
    const connected = await initConnection();
    if (!connected) {
      available = false;
      cachedProducts = [];
      cachedMissing = [...PRODUCT_IDS];
      cachedError = 'Could not connect to Google Play. Check your connection and try again.';
      emit({kind: 'unavailable', message: cachedError});
      return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
    }
    available = true;
    cachedError = undefined;
    const products = await getProducts({skus: PRODUCT_IDS});
    cachedProducts = products.map(toBillingProduct).filter((p): p is BillingProduct => p !== null);
    cachedMissing = PRODUCT_IDS.filter(id => !cachedProducts.some(p => p.productId === id));
    emit({kind: 'products'});
    const restored = await reconcileOwnedPurchases();
    if (restored > 0) emit({kind: 'restored', count: restored});
    return {available: true, products: cachedProducts, missing: cachedMissing};
  } catch {
    available = false;
    cachedProducts = [];
    cachedMissing = [...PRODUCT_IDS];
    cachedError = 'Google Play billing is not available right now. Try again later.';
    emit({kind: 'unavailable', message: cachedError});
    return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
  }
}

/** Connect to Play, load the seven products, install listeners, reconcile. */
export async function initBilling(h: Handlers): Promise<BillingInit> {
  handlers = h;
  if (Platform.OS !== 'android') {
    available = false;
    cachedProducts = [];
    cachedMissing = [...PRODUCT_IDS];
    cachedError = 'Google Play billing is only available on Android.';
    emit({kind: 'unavailable', message: cachedError});
    return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
  }
  if (!updateSub) {
    updateSub = purchaseUpdatedListener(purchase => {void creditPurchase(purchase);});
    errorSub = purchaseErrorListener((error: PurchaseError) => {
      // Play's USER_CANCELED (responseCode 1) and the library's
      // E_USER_CANCELLED both mean the user backed out: calm, not an error.
      if (error.code === ErrorCode.E_USER_CANCELLED || error.responseCode === 1) emit({kind: 'cancelled'});
      else emit({kind: 'failed', message: error.message || 'The purchase failed.'});
    });
  }
  return loadBilling();
}

/** Re-run the connection + product load with the stored handlers (shop Retry). */
export async function retryBilling(): Promise<BillingInit> {
  if (!handlers) return {available: false, products: [], missing: [...PRODUCT_IDS], error: 'Billing was not started.'};
  if (Platform.OS !== 'android') return {available: false, products: [], missing: [...PRODUCT_IDS], error: cachedError};
  return loadBilling();
}

export function getBillingProducts(): BillingProduct[] {
  return cachedProducts;
}

export function getBillingStatus(): {available: boolean; missing: string[]; error?: string} {
  return {available, missing: cachedMissing, error: cachedError};
}

export function isBillingAvailable(): boolean {
  return available;
}

/** Launch the official Google Play purchase dialog for one package. */
export async function buyTokens(productId: string): Promise<{started: boolean; error?: string}> {
  if (!currentUid()) {
    emit({kind: 'signin-required'});
    return {started: false, error: 'Sign in first — purchases are recorded on your account.'};
  }
  if (!available) return {started: false, error: 'Google Play billing is not available right now.'};
  if (!PRODUCT_IDS.some(id => id === productId)) return {started: false, error: 'Unknown token package.'};
  try {
    await requestPurchase({skus: [productId]});
    return {started: true};
  } catch (e) {
    const msg = e instanceof Error ? e.message : 'The purchase could not be started.';
    if (msg.toLowerCase().includes('cancel')) {
      emit({kind: 'cancelled'});
      return {started: false, error: 'Purchase cancelled.'};
    }
    emit({kind: 'failed', message: msg});
    return {started: false, error: msg};
  }
}

/** Re-run the owned-purchase reconcile (wallet open, Restore button). */
export async function restorePurchases(): Promise<{restored: number}> {
  if (!available) return {restored: 0};
  const restored = await reconcileOwnedPurchases();
  emit({kind: 'restored', count: restored});
  return {restored};
}

export function disposeBilling(): void {
  try {updateSub?.remove();} catch {/* ignore */}
  try {errorSub?.remove();} catch {/* ignore */}
  updateSub = null;
  errorSub = null;
  handlers = null;
  void endConnection().catch(() => {});
}
