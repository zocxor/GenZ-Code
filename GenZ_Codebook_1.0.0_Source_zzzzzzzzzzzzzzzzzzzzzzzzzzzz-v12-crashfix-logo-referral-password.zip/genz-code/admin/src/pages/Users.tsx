import React, {useState} from 'react';
import {collection, query, where, orderBy, limit, startAfter, getDocs, getDoc, doc, serverTimestamp, QueryDocumentSnapshot, DocumentData, QueryConstraint} from 'firebase/firestore/lite';
import {db, addAudit, newBatch, errorMessage} from '../firebase';
import {useSession} from '../App';
import {can} from '../rbac';
import {userMetrics} from '../lib/metrics';
import {resolveReferrerName} from '../lib/referralNames';
import {Card, Stats, Stat, Skeleton, Notice, Pill, Field, ConfirmButton, useLoad, fmt, when} from '../ui';

type UserRow = {uid: string; status: string; createdAt?: {toMillis(): number}; lastActiveAt?: {toMillis(): number}; appVersion?: string; platform?: string; stats?: Record<string, number>; statusReason?: string};
/** Referral detail for one user row: the display name of who referred them
 *  (null when the name cannot be resolved — the code is shown instead),
 *  the referrer's public referral code (null when they joined directly),
 *  and how many users joined with this user's code. */
type ReferralInfo = {referredBy: string | null; referredByCode: string | null; count: number};
const PAGE = 25;
const statusTone = (s: string) => (s === 'active' ? 'good' : s === 'suspended' ? 'warn' : 'bad');

const UsersIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>;
const ActiveIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg>;
const SuspendedIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10" /><line x1="4.93" y1="4.93" x2="19.07" y2="19.07" /></svg>;
const NewIcon = <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 7.7l5.4-.8L12 2z" /></svg>;

export default function Users() {
  const s = useSession();
  const [status, setStatus] = useState('live'), [sort, setSort] = useState<'createdAt' | 'lastActiveAt'>('lastActiveAt');
  const [search, setSearch] = useState(''), [selected, setSelected] = useState<string | null>(null);
  const [rows, setRows] = useState<UserRow[]>([]), [cursor, setCursor] = useState<QueryDocumentSnapshot<DocumentData> | null>(null), [more, setMore] = useState(false);
  const [referrals, setReferrals] = useState<Record<string, ReferralInfo>>({});
  const [error, setError] = useState(''), [loading, setLoading] = useState(false);
  const metrics = useLoad(() => userMetrics(), []);

  const load = async (reset: boolean) => {
    setLoading(true); setError('');
    if (reset) setReferrals({});
    try {
      const filters: QueryConstraint[] = [status === 'live' ? where('status', 'in', ['active', 'suspended']) : where('status', '==', status), orderBy(sort, 'desc'), limit(PAGE)];
      if (!reset && cursor) filters.push(startAfter(cursor));
      const snap = await getDocs(query(collection(db, 'users'), ...filters));
      const page = snap.docs.map(d => ({uid: d.id, ...(d.data() as Omit<UserRow, 'uid'>)}));
      setRows(r => (reset ? page : [...r, ...page]));
      setCursor(snap.docs.at(-1) ?? null); setMore(snap.size === PAGE);
      void loadReferrals(page.map(p => p.uid), reset);
    } catch (e) {setError(errorMessage(e));} finally {setLoading(false);}
  };
  /** Referral details for one page of users: each user's own claim (who
   *  referred them) plus how many users they referred. One 'in' query for
   *  the counts (25 UIDs fit the 30-value limit); names resolve from the
   *  synced profile for PII roles and fall back to the public referral code.
   *  Best-effort — a failure leaves the columns blank, never wrong. */
  const loadReferrals = async (uids: string[], reset: boolean) => {
    if (!uids.length) return;
    try {
      const claims = await Promise.all(uids.map(async uid => {
        try {
          const s = await getDoc(doc(db, 'referralClaims', uid));
          if (!s.exists()) return null;
          const d = s.data() as {referrerUid?: unknown; code?: unknown};
          return typeof d.referrerUid === 'string' && d.referrerUid ? {uid, referrerUid: d.referrerUid, code: typeof d.code === 'string' ? d.code : ''} : null;
        } catch {return null;}
      }));
      const countsSnap = await getDocs(query(collection(db, 'referralClaims'), where('referrerUid', 'in', uids), limit(500)));
      const countByUid = new Map<string, number>();
      for (const d of countsSnap.docs) {
        const r = (d.data() as {referrerUid?: unknown}).referrerUid;
        if (typeof r === 'string') countByUid.set(r, (countByUid.get(r) ?? 0) + 1);
      }
      const next: Record<string, ReferralInfo> = {};
      for (const uid of uids) next[uid] = {referredBy: null, referredByCode: null, count: countByUid.get(uid) ?? 0};
      await Promise.all(claims.filter((c): c is NonNullable<typeof c> => !!c).map(async c => {
        next[c.uid]!.referredByCode = c.code || null;
        next[c.uid]!.referredBy = await resolveReferrerName(c.referrerUid);
      }));
      setReferrals(prev => (reset ? next : {...prev, ...next}));
    } catch {
      /* referral columns stay blank */
    }
  };
  React.useEffect(() => {void load(true);}, [status, sort]);

  /** Same search the form runs: e-mail prefix via the directory (PII roles
   * only) or a full user ID. Also run on mount for a header quick search. */
  const runSearch = async (raw: string) => {
    setError('');
    const q = raw.trim();
    if (!q) return;
    try {
      if (q.includes('@')) {
        if (!can(s.role, 'users.pii')) {setError('Your role cannot search by e-mail. Search by user ID instead.'); return;}
        const lower = q.toLowerCase();
        const snap = await getDocs(query(collection(db, 'directory'), where('email', '>=', lower), where('email', '<=', lower + '\uf8ff'), limit(10)));
        if (snap.empty) {setError('No account with that e-mail prefix.'); return;}
        if (snap.size === 1) setSelected(snap.docs[0]!.id);
        else {const found = await Promise.all(snap.docs.map(d => getDoc(doc(db, 'users', d.id)))); setRows(found.filter(f => f.exists()).map(f => ({uid: f.id, ...(f.data() as Omit<UserRow, 'uid'>)}))); setMore(false); void loadReferrals(found.filter(f => f.exists()).map(f => f.id), true);}
      } else {
        if (!/^[A-Za-z0-9_-]{6,128}$/.test(q)) {setError('Enter a full user ID or an e-mail address.'); return;}
        const snap = await getDoc(doc(db, 'users', q));
        if (!snap.exists()) {setError('No account with that user ID.'); return;}
        setSelected(q);
      }
    } catch (err) {setError(errorMessage(err));}
  };
  const find = (e: React.FormEvent) => {e.preventDefault(); void runSearch(search);};

  // Header quick search (App.tsx shell): a query stored in sessionStorage
  // under 'adminQuickSearch' is pre-filled, run exactly like a form search,
  // then removed so it runs once.
  React.useEffect(() => {
    let q = '';
    try {q = sessionStorage.getItem('adminQuickSearch') ?? '';} catch {}
    if (!q) return;
    try {sessionStorage.removeItem('adminQuickSearch');} catch {}
    setSearch(q);
    void runSearch(q);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (selected) return <UserDetail uid={selected} onBack={() => {setSelected(null); void load(true);}} />;
  return <div className="stack">
    {metrics.loading ? <Skeleton rows={4} /> : metrics.error ? <Notice kind="error">{errorMessage(metrics.error)}</Notice> : metrics.data ? <Stats>
      <Stat label="Total users" num={metrics.data.total} hint="active + suspended" icon={UsersIcon} tint="blue" />
      <Stat label="Active users" num={metrics.data.total - metrics.data.suspended} icon={ActiveIcon} tint="green" />
      <Stat label="Suspended" num={metrics.data.suspended} icon={SuspendedIcon} tint="amber" />
      <Stat label="New (7 days)" num={metrics.data.new7} icon={NewIcon} tint="purple" />
    </Stats> : null}
    <Card title="Accounts" subtitle="Accounts with a cloud profile. Passwords and tokens are never visible; e-mail is shown only to roles that need it. Referral columns show display names (or the public referral code) — never e-mail.">
      <form className="row wrap" onSubmit={find}>
        <input className="grow" aria-label="Search users" placeholder={can(s.role, 'users.pii') ? 'Search by e-mail prefix or user ID' : 'Search by user ID'} value={search} onChange={e => setSearch(e.target.value)} maxLength={254} />
        <button className="btn primary">Search</button>
        <select aria-label="Status filter" value={status} onChange={e => setStatus(e.target.value)}><option value="live">Active + suspended</option><option value="active">Active</option><option value="suspended">Suspended</option><option value="deleted">Deletion tombstones</option></select>
        <select aria-label="Sort" value={sort} onChange={e => setSort(e.target.value as typeof sort)}><option value="lastActiveAt">Last active</option><option value="createdAt">Registration date</option></select>
      </form>
      {error && <Notice kind="error" onClose={() => setError('')}>{error}</Notice>}
      <div className="table-wrap">
        <table>
          <thead><tr><th>User ID</th><th>Status</th><th>Registered</th><th>Last active</th><th>Saved</th><th>Rounds</th><th>Streak</th><th>Version</th><th>Referred by</th><th>Referrals</th></tr></thead>
          <tbody>{rows.map(r => {const ref = referrals[r.uid]; return <tr key={r.uid} className="clickable" tabIndex={0} onClick={() => setSelected(r.uid)} onKeyDown={e => e.key === 'Enter' && setSelected(r.uid)}>
            <td><code>{r.uid.slice(0, 12)}…</code></td><td><Pill tone={statusTone(r.status)}>{r.status}</Pill></td><td>{when(r.createdAt)}</td><td>{when(r.lastActiveAt)}</td>
            <td>{fmt(r.stats?.saved)}</td><td>{fmt(r.stats?.quizzes)}</td><td>{fmt(r.stats?.streak)}</td><td>{r.appVersion ?? '—'} {r.platform ? `· ${r.platform}` : ''}</td>
            <td>{ref === undefined ? '—' : ref.referredByCode === null ? 'Direct' : (ref.referredBy ?? `via ${ref.referredByCode}`)}</td>
            <td>{ref === undefined ? '—' : fmt(ref.count)}</td>
          </tr>;})}</tbody>
        </table>
      </div>
      {!rows.length && !loading && <p className="muted">No accounts match.</p>}
      {more && <button className="btn ghost" disabled={loading} onClick={() => void load(false)}>{loading ? 'Loading…' : 'Load more'}</button>}
    </Card>
  </div>;
}

function UserDetail({uid, onBack}: {uid: string; onBack: () => void}) {
  const s = useSession();
  const [msg, setMsg] = useState<{kind: 'ok' | 'error'; text: string} | null>(null), [reason, setReason] = useState(''), [note, setNote] = useState(''), [busy, setBusy] = useState(false);
  const [grantAmount, setGrantAmount] = useState(''), [grantNote, setGrantNote] = useState('');
  const data = useLoad(async () => {
    const user = await getDoc(doc(db, 'users', uid));
    const pii = can(s.role, 'users.pii');
    const [dir, scores, saved, notes, wallet] = pii ? await Promise.all([getDoc(doc(db, 'directory', uid)), getDoc(doc(db, 'users', uid, 'sync', 'scores')), getDoc(doc(db, 'users', uid, 'sync', 'saved')), getDocs(query(collection(db, 'users', uid, 'supportNotes'), orderBy('at', 'desc'), limit(50))), getDoc(doc(db, 'users', uid, 'tokenWallet', 'wallet'))]) : [null, null, null, null, null];
    const attempts = scores?.exists() ? Object.values((scores.data().attempts ?? {}) as Record<string, {stage: string; score: number; total: number; at: number}>).sort((a, b) => b.at - a.at) : [];
    const savedItems = saved?.exists() ? Object.values((saved.data().items ?? {}) as Record<string, {d?: number}>) : [];
    const w = wallet?.exists() ? wallet.data() as {balance?: number; earnedTotal?: number; purchasedTotal?: number; spentTotal?: number} : null;
    return {user: user.exists() ? user.data() as Omit<UserRow, 'uid'> : null, email: dir?.exists() ? String(dir.data().email) : null, attempts, savedActive: savedItems.filter(i => !i.d).length, savedRemoved: savedItems.filter(i => i.d).length, notes: notes?.docs.map(d => d.data() as {text: string; author: string; at: {toMillis(): number}}) ?? [], walletBalance: typeof w?.balance === 'number' ? w.balance : null, walletPurchased: typeof w?.purchasedTotal === 'number' ? w.purchasedTotal : null};
  }, [uid]);
  const run = async (fn: () => Promise<string | void>, ok: string) => {setBusy(true); setMsg(null); try {const m = await fn(); setMsg({kind: 'ok', text: typeof m === 'string' ? m : ok}); data.reload();} catch (e) {setMsg({kind: 'error', text: errorMessage(e)});} finally {setBusy(false);}};

  const setStatus = (next: 'active' | 'suspended') => !reason.trim() ? setMsg({kind: 'error', text: 'Enter a reason first.'}) : run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, next === 'suspended' ? 'user.suspend' : 'user.reactivate', `users/${uid}`, reason.trim());
    b.update(doc(db, 'users', uid), {status: next, statusReason: reason.trim().slice(0, 200), statusUpdatedAt: serverTimestamp(), statusUpdatedBy: s.uid, updatedAt: serverTimestamp(), lastAuditId});
    await b.commit(); setReason('');
  }, next === 'suspended' ? 'Account suspended. The user keeps local learning but cannot sync or submit content.' : 'Account reactivated.');
  const addNote = () => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, 'user.note', `users/${uid}`, 'support note added');
    b.set(doc(collection(db, 'users', uid, 'supportNotes')), {text: note.trim().slice(0, 1000), author: s.uid, at: serverTimestamp(), lastAuditId});
    await b.commit(); setNote('');
  }, 'Note added.');
  const sendTokens = () => {
    const amount = Math.floor(Number(grantAmount));
    if (!amount || amount < 1 || amount > 100000) {setMsg({kind: 'error', text: 'Enter an amount between 1 and 100,000 tokens.'}); return;}
    void run(async () => {
      // Fresh read of the wallet so balanceAfter is computed from the latest
      // balance, not the one loaded when this page opened.
      const walletSnap = await getDoc(doc(db, 'users', uid, 'tokenWallet', 'wallet'));
      const w = walletSnap.exists() ? walletSnap.data() as {balance?: number; earnedTotal?: number; purchasedTotal?: number; spentTotal?: number} : {};
      const balance = typeof w.balance === 'number' ? w.balance : 0;
      const earnedTotal = typeof w.earnedTotal === 'number' ? w.earnedTotal : 0;
      const purchasedTotal = typeof w.purchasedTotal === 'number' ? w.purchasedTotal : 0;
      const spentTotal = typeof w.spentTotal === 'number' ? w.spentTotal : 0;
      const balanceAfter = balance + amount;
      if (balanceAfter > 1000000) throw new Error('That would push the balance over the 1,000,000 token cap.');
      const b = newBatch();
      const lastAuditId = addAudit(b, s.uid, s.role, 'tokens.send', `users/${uid}`, `Sent ${amount} tokens${grantNote.trim() ? ` — ${grantNote.trim().slice(0, 200)}` : ''}`);
      b.set(doc(collection(db, 'users', uid, 'tokenLedger')), {type: 'adjustment', amount, balanceAfter, ref: 'admin-grant', note: grantNote.trim().slice(0, 200) || 'Admin token grant', createdAt: serverTimestamp(), lastAuditId});
      b.set(doc(db, 'users', uid, 'tokenWallet', 'wallet'), {balance: balanceAfter, earnedTotal: earnedTotal + amount, purchasedTotal, spentTotal, updatedAt: serverTimestamp()});
      await b.commit();
      setGrantAmount(''); setGrantNote('');
      return `Sent ${amount} tokens. The user's balance is now ${balanceAfter.toLocaleString()} tokens (was ${balance.toLocaleString()}). They will see it the next time they open their Wallet or sign in again.`;
    }, 'Tokens sent.');
  };
  const processDeletion = () => run(async () => {
    const b = newBatch();
    const lastAuditId = addAudit(b, s.uid, s.role, 'user.delete', `users/${uid}`, 'deletion request processed');
    b.set(doc(db, 'users', uid), {status: 'deleted', deletedAt: serverTimestamp(), updatedAt: serverTimestamp(), deletedBy: s.uid, lastAuditId});
    for (const d of ['profile', 'saved', 'progress', 'scores']) b.delete(doc(db, 'users', uid, 'sync', d));
    for (const l of ['ugc', 'sec']) b.delete(doc(db, 'users', uid, 'limits', l));
    b.delete(doc(db, 'directory', uid));
    await b.commit();
  }, 'Cloud data deleted and the account tombstoned. Now delete the sign-in account in Firebase Console → Authentication (search this user ID) to finish.');

  const u = data.data?.user;
  const walletBalance = data.data?.walletBalance ?? null;
  const walletPurchased = data.data?.walletPurchased ?? null;
  return <div className="stack">
    <div className="subhead"><button className="btn ghost" onClick={onBack}>← Users</button><strong>User <code>{uid}</code></strong></div>
    {msg && <Notice kind={msg.kind} onClose={() => setMsg(null)}>{msg.text}</Notice>}
    {data.loading ? <Skeleton rows={4} /> : data.error ? <Notice kind="error">{errorMessage(data.error)}</Notice> : !u ? <Notice kind="error">Account record not found.</Notice> : <>
      <Card title="Account">
        <dl className="grid-dl">
          <dt>Status</dt><dd><Pill tone={statusTone(u.status)}>{u.status}</Pill>{u.statusReason ? <span className="muted"> · {u.statusReason}</span> : null}</dd>
          {can(s.role, 'users.pii') && <><dt>E-mail</dt><dd>{data.data?.email ?? '—'}</dd></>}
          <dt>Registered</dt><dd>{when(u.createdAt)}</dd><dt>Last active</dt><dd>{when(u.lastActiveAt)}</dd>
          <dt>App</dt><dd>{u.appVersion ?? '—'} · {u.platform ?? '—'}</dd>
          <dt>Learning</dt><dd>{fmt(u.stats?.saved)} saved · {fmt(u.stats?.quizzes)} rounds · {fmt(u.stats?.levels)} levels · {fmt(u.stats?.reviewed)} in review · streak {fmt(u.stats?.streak)} · {fmt(u.stats?.xp)} XP</dd>
          {can(s.role, 'users.pii') && <><dt>Tokens</dt><dd>{walletBalance === null ? 'No wallet yet (0 tokens)' : `${walletBalance.toLocaleString()} tokens`}{walletPurchased !== null ? ` · ${walletPurchased.toLocaleString()} bought` : ''}</dd></>}
        </dl>
      </Card>
      {can(s.role, 'tokens.send') && u.status === 'active' && <Card title="Send tokens" subtitle="Grant tokens to this user. The grant is written to their permanent transaction history (type 'adjustment') and their balance is updated in the same step, so it can never be credited twice. The user sees the tokens the next time they open their Wallet or sign in again. Super Admin only; every grant is recorded in the audit log.">
        <p className="muted">Current balance: <strong>{walletBalance === null ? 'no wallet yet (0 tokens)' : `${walletBalance.toLocaleString()} tokens`}</strong>{walletPurchased !== null ? ` · ${walletPurchased.toLocaleString()} bought` : ''}</p>
        <Field label="Amount (1 – 100,000 tokens)"><input type="number" min={1} max={100000} step={1} value={grantAmount} onChange={e => setGrantAmount(e.target.value)} placeholder="e.g. 100" /></Field>
        <Field label="Note (optional, shown in their transaction history)"><input value={grantNote} onChange={e => setGrantNote(e.target.value)} maxLength={200} placeholder="e.g. Compensation for a failed purchase" /></Field>
        <button className="btn primary" disabled={busy || !grantAmount.trim() || Math.floor(Number(grantAmount)) < 1 || Math.floor(Number(grantAmount)) > 100000} onClick={() => void sendTokens()}>{busy ? 'Sending…' : grantAmount.trim() && Math.floor(Number(grantAmount)) >= 1 ? `Send ${Math.floor(Number(grantAmount)).toLocaleString()} tokens` : 'Send tokens'}</button>
      </Card>}
      {can(s.role, 'users.suspend') && u.status !== 'deleted' && <Card title={u.status === 'suspended' ? 'Reactivate account' : 'Suspend account'} subtitle="Suspension blocks cloud sync and submissions (enforced by security rules). To also block sign-in, disable the user in Firebase Console → Authentication.">
        <Field label="Reason (recorded in the audit log)"><input value={reason} onChange={e => setReason(e.target.value)} maxLength={200} /></Field>
        {u.status === 'suspended' ? <button className="btn primary" disabled={busy || !reason.trim()} onClick={() => void setStatus('active')}>Reactivate</button> : <ConfirmButton label="Suspend" word="SUSPEND" disabled={busy || !reason.trim()} onConfirm={() => void setStatus('suspended')} />}
      </Card>}
      {can(s.role, 'users.pii') && <Card title="Quiz history" subtitle={`${fmt(data.data?.savedActive)} saved words (${fmt(data.data?.savedRemoved)} removed) · last ${data.data?.attempts.length ?? 0} rounds`}>
        {data.data?.attempts.length ? <div className="table-wrap"><table><thead><tr><th>Round</th><th>Score</th><th>When</th></tr></thead><tbody>{data.data.attempts.slice(0, 20).map((a, i) => <tr key={i}><td>{a.stage}</td><td>{a.score}/{a.total}</td><td>{when(a.at)}</td></tr>)}</tbody></table></div> : <p className="muted">No synced rounds.</p>}
      </Card>}
      {can(s.role, 'users.notes') && <Card title="Support notes" subtitle="Visible to Support and Super Admins only. Append-only.">
        {data.data?.notes.map((n, i) => <p key={i} className="note"><span className="muted small">{when(n.at)} · {n.author.slice(0, 8)}</span><br />{n.text}</p>)}
        <Field label="Add a note"><textarea value={note} onChange={e => setNote(e.target.value)} maxLength={1000} rows={3} /></Field>
        <button className="btn primary" disabled={busy || !note.trim()} onClick={() => void addNote()}>Add note</button>
      </Card>}
      {can(s.role, 'users.delete') && u.status !== 'deleted' && <Card title="Account deletion" subtitle="For verified deletion requests (e.g. from the web deletion form). Deletes synced learning data, the e-mail directory entry and rate-limit stamps, and leaves a tombstone so the account cannot recreate itself. The Firebase Authentication account must then be deleted in the console.">
        <ConfirmButton label="Delete user’s cloud data" word="DELETE" disabled={busy} onConfirm={() => void processDeletion()} />
      </Card>}
    </>}
  </div>;
}
